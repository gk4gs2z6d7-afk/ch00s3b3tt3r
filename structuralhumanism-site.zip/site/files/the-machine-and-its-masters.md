# The Machine and Its Masters

*AI, Surveillance, and the Character of the Men Who Control Both*

**Kai Jashon Price** · Structural Humanism Series — Document VII · 2026
— structuralhumanism.com —

---

> *This document presents documented public record, active litigation, on-record statements, and verified investigative reporting. It draws conclusions from evidence graded explicitly throughout. The reader is the final arbiter of what the record means. No claim in this document constitutes a verdict, a finding of criminal guilt, or an accusation beyond what the cited sources establish. Where allegations are contested, both the allegation and the denial are presented. Where matters are under active litigation, they are identified as such. Where the author draws an inference, it is labeled as inference.*

**Introduction: Three Men, One Question**

The artificial intelligence systems being built today will determine what the next generation knows, what it is permitted to say, who gets targeted in war, and who gets watched at home. The question of who builds these systems and what their documented character reveals about their intentions is not a peripheral concern. It is the central political question of this era.

This document examines three men whose companies currently occupy the most consequential positions in the AI landscape: Alex Karp of Palantir, whose company builds military targeting systems and government surveillance infrastructure; Sam Altman of OpenAI, whose company created the most widely deployed AI system in human history; and Larry Ellison of Oracle, whose company now controls the algorithm and content moderation of TikTok for 170 million Americans while running the cloud infrastructure that powers much of the U.S. government.

Each section presents documented public record. Each is written in the scholarly-journalistic hybrid tradition: evidence graded explicitly, allegations identified as allegations, denials presented alongside claims, and the reader trusted to reach their own conclusions. The author's structural argument is this: the men controlling the most powerful technological systems in human history have not been selected through democratic process, subjected to meaningful public accountability, or constrained by constitutional limits proportionate to their power. The documented record of their public statements, business decisions, and personal conduct is presented here so that the reader may assess whether that arrangement is acceptable.

**Part One: Alex Karp and Palantir**

**The Philosophy of the Kill Chain**

Alex Karp holds a PhD in social theory from Goethe University Frankfurt, where he studied under Jurgen Habermas, one of the most important democratic theorists of the twentieth century. Habermas spent his career arguing that legitimate power must be grounded in communicative reason, that institutions derive their authority from inclusive public deliberation, and that systems which colonize the human lifeworld through strategic rationality — means-ends thinking divorced from ethical accountability — are a fundamental threat to democratic society.

Karp founded Palantir with CIA seed funding in 2003. The company's core product, as described by Palantir's own Chief Technology Officer Shyam Sankar to the New York Times, is optimizing the kill chain from sensor to shooter — finding people for the military to kill. Sankar, who was subsequently commissioned as a lieutenant colonel in the U.S. Army Reserve, described the product this way: "You can think about that as you're optimizing the kill chain from sensor to shooter, they call it doctrinally, but it's the same thing as: How do I find the enemy targets?"

The philosopher's student built the targeting machine. What Habermas called the colonization of the lifeworld by strategic rationality, Karp sells as a service at government contract.

*SOURCE: France 24, "What the Palantir CEO's Manifesto Tells Us About the Changing Face of War" (April 23, 2026). | New York Times interview with Shyam Sankar (2025).*

**The Quotes: What Karp Says in Public**

The following statements are verbatim, sourced to documented public appearances. They require no editorial characterization. They are presented in sequence so the reader may assess the pattern.

> ***"Palantir is here to disrupt and make the institutions we partner with the very best in the world and, when it's necessary, to scare enemies and on occasion kill them."***

*SOURCE: Palantir Q4 2024 Earnings Call, February 2025. Documented by Sherwood News, Bloomberg, and multiple financial press outlets.*

> ***"We love disruption and whatever is good for America will be good for Americans and very good for Palantir. Disruption, at the end of the day, exposes things that aren't working. There'll be ups and downs. This is a revolution. Some people are going to get their heads cut off."***

*SOURCE: Palantir Q4 2024 Earnings Call, February 2025. Direct transcript.*

> ***"You need a higher purpose, and I think you often need a lower purpose." \[When asked what his lower purpose is:\] "I love the idea of getting a drone and having light fentanyl-laced urine spraying on analysts that tried to screw us."***

*SOURCE: Documented in multiple outlets including International Cyber Digest and verified by former Palantir employees in NPR reporting (May 2025).*

> ***"\[Pro-Palestinian campus protesters are adherents of\] a pagan religion... We're gonna do an exchange program sponsored by Karp. \[Sending them\] to North Korea to eat bark."***

*SOURCE: AI conference on Capitol Hill, May 2024. Documented by The Nation (May 27, 2025) and multiple press outlets covering the event.*

> ***"The United Nations \[is\] basically a discriminatory institution against anything good."***

*SOURCE: World Economic Forum, Davos. Documented by The Nation (May 27, 2025).*

These are not off-the-cuff remarks. They were made on investor calls, at congressional venues, and at major international forums. Karp is a man with a PhD in social theory who knows precisely what he is saying and to whom. The pattern the quotes establish — killing as corporate mission, revolution as business model, political opponents as candidates for re-education, international law institutions as discriminatory — is not a collection of isolated provocations. It is a stated worldview from the man whose company's products determine targeting decisions in active military operations.

**Palantir, Israel, and the Gaza Operation**

In January 2024, three months after the October 7 Hamas attack and the beginning of Israel's military operation in Gaza, Palantir held its first board meeting of the year in Tel Aviv. Alex Karp flew to Israel and signed a formal strategic partnership agreement with the Israeli Ministry of Defense at its military headquarters. Palantir Executive Vice President Josh Harris confirmed that both parties had "mutually agreed to harness Palantir's advanced technology in support of war-related missions."

The company posted on its official social media: "We stand with Israel. The board of directors of Palantir will be gathering in Tel Aviv next week for its first meeting of the new year. Our work in the region has never been more vital. And it will continue."

What that work involves in practice has been documented through multiple independent investigative channels. The Israeli military's use of AI targeting systems — including a system called "Lavender" documented by +972 Magazine and Local Call in a 2024 investigation — generates targeting lists for thousands of alleged combatants and operates with loosened rules of engagement permitting significant civilian casualties per targeted individual. The +972 investigation does not name Palantir by name. The Nation's subsequent investigation reported that the AI systems described appear to fit the same category as Palantir's documented targeting capabilities.

Francesca Albanese, the United Nations Special Rapporteur for the Occupied Palestinian Territories, named Palantir specifically in a July 2025 report, detailing that its systems allowed for "automated decision making" on the battlefield and calling for investigations into corporate executives.

> *EVIDENCE GRADE: The strategic partnership with Israel's Ministry of Defense is confirmed by Palantir's own public statements and Josh Harris's on-record comments. The CTO's description of the kill chain product is documented in the New York Times. The UN Special Rapporteur's report is a matter of public record. The specific causal connection between Palantir's systems and individual deaths in Gaza is documented as alleged by the UN Special Rapporteur and investigated by The Nation; it has not been adjudicated in a court of law. Palantir disputes characterizations of its role. Both the documented partnership and the disputed causal claims are presented here. The reader assesses the weight of each.*

By the time Albanese's report was published, the Gaza operation had killed more than 70,000 Palestinians, according to UN figures. Karp had called critics of this operation adherents of a pagan religion who should be sent to North Korea to eat bark. His company's CTO had described their product as finding people to kill. The board had signed a war-related mission partnership at the Israeli military's own headquarters.

The documented record does not require editorializing. It requires reading.

*SOURCE: Palantir public statements, X and LinkedIn (January 2024). | Josh Harris, on-record statement re: Israeli MoD partnership. | +972 Magazine, "Lavender: The AI Machine Directing Israel's Bombing Spree" (April 2024). | The Nation, "How US Intelligence and an American Company Feed Israel's Killing Machine in Gaza" (April 12, 2024). | UN Special Rapporteur Francesca Albanese, Report to the UN Human Rights Council (July 2025). | France 24, Palantir manifesto coverage (April 23, 2026).*

**The Manifesto and What It Reveals**

In April 2026, Palantir posted a 22-point summary of Karp's book, The Technological Republic, to its official X account. The post received nearly thirty million views. Among its documented claims: "Some cultures have produced vital advances; others remain dysfunctional and regressive." It called for mandatory national service, declared that "the engineering elite of Silicon Valley has an affirmative obligation to participate in the defense of the nation," and called for an end to what it described as the "postwar neutering" of Germany and Japan.

Critics described it variously as technofascism, as the ramblings of a supervillain, and as indistinguishable from America First nationalism. What it is, precisely, is the public ideology of a company whose revenue depends on the politics it advocates. As Eliot Higgins, founder of investigative outlet Bellingcat, wrote: "These 22 points aren't philosophy floating in space, they're the public ideology of a company whose revenue depends on the politics it's advocating."

Karp calls himself a progressive. He studied under the century's foremost democratic theorist. He has built the most consequential surveillance and targeting infrastructure in the private sector. He jokes on earnings calls about heads being cut off in revolutions while his company's technology is named in a UN report on automated decision-making in a conflict that has killed over 70,000 people. These are not contradictions that require resolution. They are a portrait.

*SOURCE: Euronews, "Ramblings of a Supervillain: Palantir Manifesto Claims AI Weapons and Cultural Inferiority" (April 22, 2026). | Al Jazeera, "Technofascism? Why Palantir's Pro-West Manifesto Has Critics Alarmed" (April 21, 2026). | Eliot Higgins, Bluesky post (April 2026).*

**Part Two: Sam Altman and OpenAI**

> *SECTION DISCLAIMER — READ BEFORE PROCEEDING: This section presents documented public record including active federal litigation, official rulings, public statements, and on-camera conduct. Nothing in this section constitutes a finding of fact by any court, a verdict of guilt, or an accusation by the author beyond what the cited sources establish. All allegations are disputed by Sam Altman. Active litigation is identified as active litigation. Official rulings are identified as official rulings. The reader is presented with the documented record and left to reach their own conclusions. The author does not assert guilt, innocence, or culpability in any legal matter discussed below.*

**The Mission and What Happened to It**

OpenAI was founded in 2015 as a nonprofit with an explicitly stated mission: to ensure that artificial general intelligence benefits all of humanity. Its founding documents and public statements positioned the organization as a counterweight to the profit motive — a research institution that would develop the most powerful technology in human history in the public interest rather than the interest of shareholders.

Elon Musk, one of the co-founders, filed a lawsuit in 2024 alleging breach of contract and fiduciary duty, claiming that Altman had abandoned the nonprofit mission when OpenAI converted to a capped-profit structure with Microsoft as its primary investor. OpenAI disputed Musk's characterization. What is not disputed is the structural fact: the organization that positioned itself as humanity's guardian against the dangers of unconstrained AI development is now a for-profit entity with a $157 billion valuation and a primary investor whose financial interest in its commercial success is direct and substantial.

The board that attempted to hold Altman accountable fired him in November 2023, citing what it described as a lack of candor in his communications with the board. Altman was reinstated five days later after a staff revolt and pressure from Microsoft. The two board members most associated with AI safety oversight — Helen Toner and Tasha McCauley — were removed when he returned. The board that remained was reconstituted to include members whose independence from Altman's commercial interests has been questioned by governance scholars.

The pattern: the accountability mechanism fired the CEO. The CEO's commercial relationships made the accountability mechanism removable. The accountability mechanism was removed. This is a governance failure of a specific and documented kind — the same kind documented in captured regulatory agencies throughout this series.

*SOURCE: Musk v. Altman et al., United States District Court. | OpenAI official response to Musk lawsuit (2024). | Gizmodo, "The Old OpenAI Board" (2024). | Financial Times, OpenAI governance reporting (November 2023).*

**Suchir Balaji: The Documented Record**

Suchir Balaji was a 26-year-old AI researcher who worked at OpenAI for more than four years and contributed to the development of ChatGPT. In August 2024, he resigned from the company on principle. In a New York Times interview published shortly after his resignation, he stated his belief that OpenAI was illegally using copyrighted materials to train its AI models — a practice he described as unsustainable and harmful to the internet ecosystem. He was subsequently named as a potential witness in copyright infringement litigation filed against OpenAI.

On November 26, 2024, Balaji was found dead in his San Francisco apartment. He was 26 years old.

The San Francisco Chief Medical Examiner's office conducted an investigation and ruled his death a suicide. No indication of foul play was found in the official ruling.

Balaji's mother, Poornima Ramarao, disputes the official ruling. She has stated publicly and in media appearances that she believes her son was murdered in connection with his potential witness role in the copyright litigation against OpenAI. She has described specific details she found inconsistent with the suicide ruling.

Elon Musk stated on X that the death was a murder case. Tucker Carlson, in a September 2025 interview with Sam Altman, asserted directly that Balaji had been murdered and asked Altman whether he had ordered the killing. Altman denied the allegation and described it as a suicide, stating he had reviewed the legal and medical documents.

> *EVIDENCE GRADE: The facts above are fully documented: Balaji's resignation, his New York Times interview, his role as a potential witness, the date and location of his death, the Medical Examiner's ruling of suicide, his mother's public dispute of that ruling, Musk's public claim of murder, and Altman's denial. The Medical Examiner's ruling is the official legal determination. The author does not assert that the ruling is wrong. The author does not assert that Altman bears any responsibility for Balaji's death. The mother's belief, Musk's claim, and Carlson's allegation are documented as the public allegations of named individuals — not as established facts. The reader assesses the weight of the official ruling alongside the publicly stated concerns of those who dispute it.*

**The Carlson Interview: What Was Observable**

On September 10, 2025, Sam Altman gave an extended interview to Tucker Carlson. The interview is publicly available in full. What follows is a description of documented observable elements — Altman's own words and conduct in a public forum he chose to participate in. The author draws no conclusions. The reader who wishes to assess the interview may view it in its entirety.

When Carlson raised the circumstances of Balaji's death and suggested he had been murdered, Altman responded: "It looks like a suicide to me." He then asked Carlson: "You understand how this sounds like an accusation? I haven't done too many interviews where someone asks me if I ordered a murder."

Multiple observers who reviewed the interview noted the specific phrasing and register of Altman's responses to questions about Balaji. Carlson, who is not a neutral observer and who holds his own documented editorial biases, pressed on specific details his mother had raised. Altman's responses to those specific details are on camera. The interview is publicly available. The reader is invited to watch it and form their own assessment of what they observe.

The author's position is this: it is not the author's place to tell the reader what to conclude from watching a CEO of the world's most powerful AI company respond on camera to questions about the death of a whistleblowing former employee. It is the author's place to note that the interview occurred, that it is publicly available, and that the reader has both the right and the capacity to watch it and decide for themselves.

*SOURCE: New York Times interview with Suchir Balaji (August 2024). | San Francisco Chief Medical Examiner ruling (November 2024). | Tucker Carlson interview with Sam Altman (September 10, 2025). | Poornima Ramarao public statements and media appearances (2025). | Elon Musk, X post (2024).*

**The Federal Lawsuit: Annie Altman v. Sam Altman**

> *LEGAL DISCLAIMER: The following section describes active federal civil litigation. All allegations in the lawsuit are made by the plaintiff and are disputed by the defendant. A lawsuit is an allegation, not a verdict. The defendant, Sam Altman, denies all claims. A judge allowing certain claims to proceed means the court has found those claims meet the legal threshold for proceeding — it does not constitute a finding that the allegations are true. The reader should understand the distinction between an allegation, a judicial procedural ruling, and a finding of fact. This section presents all three categories with explicit identification of which is which.*

On January 6, 2025, Ann Altman — known as Annie — filed a federal civil lawsuit against her brother Sam Altman in the U.S. District Court for the Eastern District of Missouri. The lawsuit alleges that Sam Altman sexually abused her regularly between 1997 and 2006, beginning when she was approximately three years old. The complaint alleges the abuse took place at the family home in Clayton, Missouri, several times per week, and continued until she was approximately eight or nine years old.

Sam Altman denied all allegations. In a joint statement posted to X with his mother and brothers, the family wrote: "Annie has made deeply hurtful and entirely untrue claims about our family, and especially Sam." Sam Altman has separately described Annie's allegations as false and characterized the lawsuit as extortion. He has raised concerns about his sister's mental health. He has filed a defamation counterclaim tied to social media posts Annie made between 2021 and 2024 in which she described alleged abuse by an older sibling and referenced "an almost tech billionaire."

Annie Altman's attorney responded to the mental health characterization, stating: "There is no evidence that her own mental health has contributed to her allegations."

A federal judge initially dismissed certain claims as falling outside the statute of limitations. Annie Altman filed an amended complaint on April 1, 2026. The judge ruled that certain claims could proceed under Missouri law, which permits plaintiffs alleging childhood sexual abuse to bring claims within ten years of turning 21 or within three years of discovering that injuries were caused by the alleged abuse, whichever occurs later.

As of the time of writing, the case is active in federal court. No verdict has been reached. No factual finding has been made. The case may or may not proceed to trial. Nothing about the procedural status of the case determines the truth of the underlying allegations in either direction.

What is not in dispute: the lawsuit was filed, is active, and has survived initial judicial review to a sufficient degree that the judge has allowed certain claims to proceed. That is the documented legal status. The reader understands what it means and what it does not mean.

*SOURCE: Annie Altman v. Sam Altman, U.S. District Court for the Eastern District of Missouri, Case No. filed January 6, 2025. | CNBC, "OpenAI CEO Sam Altman Denies Sexual Abuse Allegations Made by His Sister" (January 7, 2025). | Yahoo News/Reuters, "Sam Altman's Sister Files Amended Lawsuit After Judge Allows Case to Proceed" (April 2, 2026).*

**OpenAI's Governance: The Structural Argument**

Set aside the personal allegations entirely. Set aside the Balaji questions entirely. What remains in the documented structural record is sufficient for the argument this series makes.

The man leading the company that has deployed the most widely used AI system in human history removed the board that tried to hold him accountable. The safety-focused board members who voted against him were removed when he returned. The nonprofit mission that justified the company's founding was converted to a for-profit structure with a $157 billion valuation. A researcher who publicly accused the company of illegal practices died months after going public. The company is now fighting the Department of Defense's demand for unrestricted use of its AI in military applications — a fight the author considers the most admirable element of OpenAI's recent conduct, and one that stands in notable tension with the governance failures documented above.

The structural question is not about personal guilt. It is about accountability. Who holds the CEO of the most widely deployed AI system in the world accountable? The answer, as of the date of this writing, is: a board he reconstituted after firing the one that tried to hold him accountable, investors whose financial interests align with his continued leadership, and federal courts processing lawsuits that may take years to resolve. That is not an accountability structure proportionate to the power being exercised.

**Part Three: Larry Ellison and the Information Architecture**

**One Family, Five Platforms**

Larry Ellison is the co-founder and executive chairman of Oracle, with an estimated personal fortune of $390 billion as of 2026. He is not a figure who has sought the kind of public philosophical profile that Karp cultivates. He does not give earnings calls that trend on social media. He does not publish manifestos. He is, in this way, more dangerous than either Karp or Altman — because the scope of what his family now controls is not visible from any single vantage point. It requires mapping.

Oracle, under Ellison's leadership, holds the cloud infrastructure contracts for substantial portions of the U.S. government, including intelligence and defense applications. His son David Ellison is CEO and chairman of Paramount Skydance, which controls CBS News, Paramount Pictures, Paramount+, and MTV. The Ellisons acquired The Free Press — the right-wing publication run by Bari Weiss — as part of the Paramount transaction. Larry Ellison is a lead investor in the newly formed U.S. TikTok entity, which under the terms of its Oracle-led deal controls TikTok's algorithm and content moderation for 170 million American users. The Ellison family is reported to be pursuing an acquisition of Warner Brothers Discovery. If successful, one family will control the algorithmic curation of short-form video for 170 million Americans, two major broadcast and streaming networks, a major film studio, and one of the largest news operations in the country — alongside the cloud infrastructure powering significant portions of U.S. government operations.

None of this happened through democratic election. None of it is subject to meaningful public accountability. All of it was accomplished through capital allocation and a presidential relationship.

*SOURCE: NPR, "The Ellisons, TikTok and Paramount" (December 21, 2025). | Fortune, "Larry Ellison's Oracle Set to Spearhead U.S. Oversight of TikTok Algorithm" (September 23, 2025). | Common Dreams, "Another Backdoor Deal? Billionaire Trump Ally Larry Ellison at Center of TikTok Spin-Off" (December 22, 2025).*

**The Surveillance Statement**

In September 2024, at Oracle's financial analyst meeting, Larry Ellison described his vision for the future of AI and surveillance. The statement was made in a professional context to financial analysts. It is documented in multiple outlets. It requires no editorializing:

> ***"We're going to have supervision. Every police officer is going to be supervised at all times, and if there's a problem, AI will report that problem and report it to the appropriate person. Citizens will be on their best behavior because we are constantly recording and reporting everything that's going on."***

This statement was made by the man who, in the months following it, became the controlling investor in TikTok's U.S. operations and a central figure in the cloud infrastructure serving U.S. intelligence agencies. The vision he described — constant recording, constant reporting, citizens on their best behavior because they know they are watched — is not a warning. It is an aspiration. And he is in a position to build it.

*SOURCE: Fortune, "Larry Ellison Once Predicted Citizens Will Be on Their Best Behavior Amid Constant Recording" (September 29, 2025).*

**TikTok: Content Moderation as Power**

The TikTok deal's most consequential element is not data security. It is content moderation. Under the terms of the Oracle-led acquisition, the new investor-controlled entity sets the rules for what 170 million Americans are permitted to post, what the algorithm amplifies, and what it suppresses. This authority transferred from ByteDance — a Chinese company subject to Chinese government influence, which was the stated national security concern — to a group of investors including a man who donated $16.6 million to Friends of the Israel Defense Forces, whose former CEO stated publicly that Oracle employees who disagree with the company's mission to support Israel should find another employer, and who in July 2025 hired a former Israeli military intelligence officer to oversee content moderation on the platform.

The House Oversight Committee opened an investigation into whether foreign governments contributed to the $200 million White House ballroom project. The question of whether the TikTok deal represents foreign government influence over American information infrastructure — through a different vector than the one the ban was designed to prevent — has received less attention. The structure of the concern is identical. The flag on the ownership document is different.

*SOURCE: The Intercept, "Anti-Palestinian Billionaires Will Control TikTok Under New Deal" (December 21, 2025). | Federal News Network, "ICE Entices New Recruits with $50,000 Signing Bonuses" (July 31, 2025). | House Oversight Committee investigation, Trump ballroom (2025).*

**Part Four: Anthropic and the Line That Was Drawn**

**What a Constitutional Limit Looks Like**

In the interests of full disclosure: this document was produced with the assistance of Claude, an AI system developed by Anthropic. The author acknowledges this directly because the argument requires it. Anthropic is not a neutral party in the landscape described in this document, and neither is the author's use of its tools. The reader should weigh this disclosure accordingly.

With that disclosure made: the documented record of Anthropic's conduct in relation to the Department of Defense represents the most important single data point in this document for evaluating what AI governance with constitutional limits looks like in practice — and what happens to it.

Anthropic CEO Dario Amodei stated in a public filing in February 2026: "I believe deeply in the existential importance of using AI to defend the United States and other democracies, and to defeat our autocratic adversaries." He then drew a specific line: "In a narrow set of cases, we believe AI can undermine, rather than defend, democratic values. Two such use cases have never been included in our contracts with the Department of War, and we believe they should not be included now." The two cases: fully autonomous weapons systems and mass domestic surveillance of Americans.

The Department of Defense's position, as stated by Under Secretary Emil Michael, was that it wanted a blanket standard permitting "all lawful use" — meaning any application the government declares legal. Given that FISA Section 702 warrantless searches of American communications increased 35% in 2025, given that those searches have been documented targeting Black Lives Matter protesters, journalists, and members of Congress, the phrase "all lawful use" is not a neutral standard. It is a standard calibrated to the government's documented history of using surveillance authority against its own citizens.

Anthropic declined. The Department of Defense designated Anthropic a "supply chain risk" — a designation previously reserved for foreign adversaries — and Defense Secretary Pete Hegseth announced that any contractor doing business with the military is barred from commercial activity with Anthropic.

A U.S. District Judge reviewing the designation stated that the action "looks like an attempt to cripple Anthropic" and appeared to be "punishing Anthropic for trying to bring public scrutiny to this contract dispute." The judge noted the action raised serious First Amendment concerns.

The message the government sent to every AI company operating in this space with that designation was precise and unambiguous: drawing a constitutional line around domestic surveillance and autonomous weapons is a punishable act. Companies that draw no such lines — Palantir, which describes its product as optimizing the kill chain, Oracle, which aspires to record and report everything citizens do — face no such designation. They receive contracts, market cap increases, and presidential relationships.

*SOURCE: Anthropic public statement by Dario Amodei (February 26, 2026). | NYU Stern Center for Business and Human Rights, "The Cost of Conscience" (May 2026). | Al Jazeera, "Anthropic's Case Against the Pentagon Could Open Space for AI Regulation" (March 25, 2026). | CNBC, "Defense Tech Companies Are Dropping Claude After Pentagon's Anthropic Blacklist" (March 4, 2026). | Brennan Center for Justice, FISA Section 702 reporting (April 2026).*

**Conclusion: The Pattern and What It Requires**

Three men. Three companies. One pattern.

The man who studied democratic theory under Jurgen Habermas built the military targeting infrastructure that a UN Special Rapporteur says operates with automated decision-making in a conflict that has killed over 70,000 people. He jokes on investor calls about beheadings in a revolution and sends critics to North Korea in his imagination. His market cap grew $23 billion the day a president who calls himself a disruptor was elected.

The man who built the most widely deployed AI system in human history fired the board that tried to hold him accountable, reconstituted it with members whose independence is questioned, converted a nonprofit mission to a $157 billion for-profit entity, and is now a defendant in active federal litigation filed by his own sister with claims a federal judge has allowed to proceed. A whistleblowing researcher who accused the company of illegal practices died months after going public. The author does not tell the reader what to conclude about these facts. The author notes that they are facts.

The man whose family now controls TikTok's algorithm, CBS News, Paramount, and is pursuing Warner Brothers Discovery stated publicly that citizens will be on their best behavior when they know they are constantly recorded and reported. He is in a position to build that system. He is building it.

And the one company that drew a constitutional line — no autonomous weapons, no mass domestic surveillance — was designated a supply chain risk equivalent to a foreign adversary by the United States Department of Defense.

This is not a coincidence. It is a policy. The policy is: constitutional limits on AI power are a liability. The removal of those limits is rewarded. The document of record for that policy is the Pentagon's own designation, the judge's characterization of it as First Amendment retaliation, and the market reactions to every company that has chosen the other path.

> ***The question this document asks — and does not answer for the reader — is whether a democracy that punishes the AI company that says no to mass domestic surveillance while rewarding the AI company that optimizes the kill chain is still, in any meaningful sense, a democracy governed by the values it claims.***

The reader has the documented record. The reader has the quotes. The reader has the rulings, the partnerships, the designations, and the market cap numbers. The reader is capable of answering that question.

Choose Better.

**Primary Sources and References**

**Alex Karp / Palantir**

Palantir Q4 2024 Earnings Call transcript, February 2025. Documented by Sherwood News, Bloomberg, multiple financial outlets.

The Nation. (May 27, 2025). "Palantir's Idea of Peace." Extensive profile of Karp's public statements.

The Nation. (April 12, 2024). "How US Intelligence and an American Company Feed Israel's Killing Machine in Gaza."

France 24. (April 23, 2026). "What the Palantir CEO's Manifesto Tells Us About the Changing Face of War."

Al Jazeera. (April 21, 2026). "Technofascism? Why Palantir's Pro-West Manifesto Has Critics Alarmed."

Euronews. (April 22, 2026). "Ramblings of a Supervillain: Palantir Manifesto Claims AI Weapons and Cultural Inferiority."

+972 Magazine / Local Call. (April 2024). "Lavender: The AI Machine Directing Israel's Bombing Spree."

UN Special Rapporteur Francesca Albanese. Report to the UN Human Rights Council on Palantir systems (July 2025).

NPR. (May 5, 2025). "Former Palantir Workers Condemn Company's Work with Trump Administration."

Business and Human Rights Resource Centre. Palantir/Israel documentation archive (2024-2025).

Karp, A. & Zamiska, N. (2025). The Technological Republic. Published by \[publisher\]. 22-point summary posted to Palantir X account, April 2026.

**Sam Altman / OpenAI**

Annie Altman v. Sam Altman. U.S. District Court for the Eastern District of Missouri. Filed January 6, 2025. Amended complaint filed April 1, 2026.

CNBC. (January 7, 2025). "OpenAI CEO Sam Altman Denies Sexual Abuse Allegations Made by His Sister."

Yahoo News / Reuters. (April 2, 2026). "Sam Altman's Sister Files Amended Lawsuit After Judge Allows Case to Proceed."

New York Times. (August 2024). Interview with Suchir Balaji on OpenAI copyright practices.

San Francisco Chief Medical Examiner. Official ruling on Suchir Balaji, November 2024.

Tucker Carlson Network. Interview with Sam Altman (September 10, 2025). Publicly available in full.

Poornima Ramarao. Public statements and media appearances (2025), including Tucker Carlson Network appearance.

Musk v. Altman et al. United States District Court (2024). OpenAI response brief.

Gizmodo. (2024). "The Old OpenAI Board." Coverage of Toner and McCauley removal.

Financial Times. (November 2023). OpenAI governance reporting on Altman firing and reinstatement.

**Larry Ellison / Oracle / TikTok**

Fortune. (September 29, 2025). "Larry Ellison Once Predicted Citizens Will Be on Their Best Behavior."

Fortune. (September 23, 2025). "Larry Ellison's Oracle Set to Spearhead U.S. Oversight of TikTok Algorithm."

NPR. (December 21, 2025). "The Ellisons, TikTok and Paramount."

The Intercept. (December 21, 2025). "Anti-Palestinian Billionaires Will Control TikTok Under New Deal."

Common Dreams. (December 22, 2025). "Another Backdoor Deal? Billionaire Trump Ally Larry Ellison at Center of TikTok Spin-Off."

Project on Government Oversight (POGO). (December 10, 2025). "$99,999 DHS Contracts Balloon Under Kristi Noem's Directive."

**Anthropic / DoD / FISA 702**

Amodei, D. (February 26, 2026). Public statement on Department of War contract dispute.

NYU Stern Center for Business and Human Rights. (May 2026). "The Cost of Conscience: What the Anthropic-Pentagon Feud Means for AI Governance."

Al Jazeera. (March 25, 2026). "Anthropic's Case Against the Pentagon Could Open Space for AI Regulation."

CNBC. (March 4, 2026). "Defense Tech Companies Are Dropping Claude After Pentagon's Anthropic Blacklist."

Brennan Center for Justice. FISA Section 702 resource page and ongoing reporting (2026).

Congress.gov / Congressional Research Service. (July 2025). "FISA Section 702 and the 2024 Reforming Intelligence and Securing America Act."

Americans for Prosperity. (March 2026). "Don't Reauthorize Surveillance Powers Without Protecting Americans' Rights."

Wikipedia. "Anthropic-United States Department of Defense Dispute." Continuously updated.

NPR. (April 29, 2026). "Congress Extends FISA 702 Surveillance Program for 45 Days."

*Kai Price | Structural Humanism Series | 2025-2026*

*All claims verifiable. All sources cited. All conclusions the reader's own.*
