# The Body Kept Sick

*How Regulatory Capture Converted Human Health Into a Revenue Stream*

**Kai Jashon Price** · Structural Humanism Series — Document IV · 2025
— structuralhumanism.com —

---

## Maria

Maria is a diabetic in Phoenix, Arizona. In 2018, her insurance stopped covering insulin at the price her pharmacy charged. She stretched a thirty-day supply to sixty days. In August of that year she was hospitalized with diabetic ketoacidosis — a preventable emergency caused by insufficient insulin. Her hospital bill for the three-day stay was $47,000. The insulin she had been rationing costs approximately $3 to manufacture. It sells for $30 in Canada. It sells for up to $300 in the United States.

The difference between $30 and $300 is not production cost, transportation, or research amortization. Insulin was developed in 1921. The patent was sold to the University of Toronto for $1 by its inventors, who believed no one should profit from a medicine people require to live. The difference is what a market, shaped by decades of lobbying-influenced legislation, can extract from people who will die without the drug.

In 2023, under congressional and public pressure, Eli Lilly, Novo Nordisk, and Sanofi cut U.S. insulin list prices by roughly seventy percent and capped out-of-pocket costs at $35 — and remained profitable. That is not a complication for this argument. It is the closing of it: a price that can fall seventy percent the moment the political cost gets high enough was never about cost, research, or anything other than what a captive market would bear. Maria was hospitalized in 2018 because the political cost had not yet arrived.

**Maria's story is not an anecdote about one person's bad luck. It is a precise illustration of a system that functions exactly as designed — for the people who designed it.**

*SOURCE: Kaiser Family Foundation (2022). Insulin Costs and Affordability. | Eli Lilly, Novo Nordisk, and Sanofi insulin price announcements (March 2023). | Inflation Reduction Act of 2022, insulin cost-sharing provisions. | Congressional Budget Office (2022). Prices for Brand-Name Drugs. | Banting, F. & Best, C. (1921). University of Toronto patent records.*

## What Regulatory Capture Actually Means

Regulatory capture is not corruption in the traditional sense of envelopes of cash. It is the structural process by which the industries being regulated come to staff, fund, and direct the agencies regulating them. The revolving door between pharmaceutical companies and the FDA is documented in employment records that are public: senior FDA officials moving to pharmaceutical industry positions, pharmaceutical executives moving to FDA advisory positions, and the salaries available in the industry creating a structural incentive for FDA staff to reach conclusions acceptable to potential future employers.

The result is a healthcare system that produces worse outcomes than peer nations spending significantly less per capita while generating the highest pharmaceutical profits in the world. This is not market failure. It is market success — for the market that was actually built, which is not a market for health but a market for the management of illness at maximum sustainable cost.

*SOURCE: Angell, M. (2004). The Truth About the Drug Companies. Random House. | PLOS Medicine (2018). Revolving Door study of FDA-pharmaceutical industry personnel movement.*

## Two Decades and 50,000 Deaths a Year: The Trans Fat Record

Concerns about partially hydrogenated oils — trans fats — circulated for decades, but the decisive science arrived in the 1990s: Walter Willett's 1993 analysis in The Lancet tied trans fat intake to coronary heart disease in a cohort of more than 85,000 women, and Dariush Mozaffarian's landmark 2006 review in the New England Journal of Medicine estimated that trans fat consumption was causing between 72,000 and 228,000 coronary heart disease events per year in the United States, with approximately 50,000 fatal.

The FDA did not revoke the ingredient's “generally recognized as safe” status until 2015, with compliance required by 2018. Thirteen to twenty-five years elapsed between decisive evidence of mass harm and the product leaving the food supply. At the documented death rate, that delay — not the earlier scientific uncertainty — accounts for hundreds of thousands of preventable deaths. The food industry, which had invested in trans fat infrastructure, lobbied against regulation throughout. The people who died in those decades were not killed by scientific ignorance. They were killed by a regulatory system that moved at the speed of industry convenience and called the arrangement consumer protection.

*SOURCE: Willett, W. et al. (1993). Intake of Trans Fatty Acids and Risk of Coronary Heart Disease Among Women. The Lancet, 341(8845). | Mozaffarian, D. et al. (2006). Trans Fatty Acids and Cardiovascular Disease. New England Journal of Medicine, 354(15), 1601-1613. | FDA Final Determination on Partially Hydrogenated Oils (2015; compliance 2018).*

## The Opioid Crisis: Manufactured Addiction at Scale

Purdue Pharma began marketing OxyContin in 1996 on the basis of a claim that extended-release opioids had a low addiction potential. The company's own research did not support this claim. Purdue paid physicians to speak at conferences promoting the drug, funded patient advocacy organizations, and trained a sales force to minimize addiction concerns when raised by healthcare providers. The DEA and FDA received documented reports of diversion and addiction and delayed substantive action for years.

By 2021, opioid overdoses were killing over 80,000 Americans annually. The Sackler family, which owned Purdue Pharma, withdrew approximately $10 billion from the company in the decade before its bankruptcy. The family then sought what amounted to permanent civil immunity: a bankruptcy plan releasing them from all opioid liability in exchange for payment, though they had not themselves declared bankruptcy. In June 2024 the Supreme Court struck those releases down in Harrington v. Purdue Pharma, and a renegotiated settlement of roughly $7.4 billion followed in 2025. What has never followed, across nearly three decades and more American dead than the Vietnam War, is a criminal charge against any member of the family. That is the accountability the system provides for manufactured addiction at scale: negotiated payments from a fortune the payments do not exhaust, and no one in handcuffs.

*SOURCE: Keefe, P.R. (2021). Empire of Pain: The Secret History of the Sackler Dynasty. Doubleday. | CDC Opioid Overdose Data (2022). | Harrington v. Purdue Pharma L.P., 603 U.S. 204 (2024). | Purdue Pharma settlement announcements (2025).*

## The Medicare Prohibition and the Lobbying Arithmetic

The Medicare Modernization Act of 2003 explicitly prohibited Medicare — the single largest purchaser of pharmaceuticals in the United States — from negotiating drug prices. No other large-volume purchaser in any other industry is legally prohibited from negotiating price. The Veterans Administration negotiates pharmaceutical prices and pays approximately 40% less than Medicare for the same drugs. The Congressional Budget Office has estimated that allowing Medicare price negotiation would save hundreds of billions of dollars over a decade.

The prohibition was written into law by legislators who received pharmaceutical industry campaign contributions. OpenSecrets.org, using publicly available Federal Election Commission records, has documented the correlation between pharmaceutical PAC contributions and votes against Medicare price negotiation over multiple congressional cycles. This is arithmetic performed on public records. The conclusion it produces does not require inference.

*SOURCE: Congressional Budget Office (2019). Incorporating the Effects of Proposals to Modify Drug Rebates. | OpenSecrets.org pharmaceutical industry contribution data (2000-2024). | Medicare Prescription Drug, Improvement, and Modernization Act (2003), Section 1860D-11(i).*

## Three Changes That Would Transform the System

First: repeal the Medicare price negotiation prohibition. This single legislative change — requiring only organized political will sufficient to outweigh pharmaceutical lobbying — would immediately reduce drug costs for the largest buyer in the country and create price pressure throughout the market. The Inflation Reduction Act of 2022 began this process for ten drugs. The prohibition was never justified by anything other than lobbying capacity.

Second: restore standard bankruptcy protections to medical debt. Medical debt is the leading cause of personal bankruptcy in the United States. It is the only category of debt that typically accrues without the debtor's advance knowledge of the amount — you do not know what an emergency room visit will cost before you are treated. Applying standard bankruptcy protections would not eliminate medical debt. It would eliminate the mechanism by which medical debt becomes a permanent financial condition for people who had the misfortune to become sick.

Third: mandate transparent hospital billing. The chargemaster system — by which hospitals assign list prices to procedures that bear no documented relationship to actual costs, then negotiate downward depending on the payer's leverage — is the mechanism that produces $47,000 bills for three-day stays and $200 aspirin. Transparency requirements would not fix the underlying incentive structure but would make the mechanism visible enough to generate the political pressure required to address it.

None of these requires a fundamental restructuring of the healthcare economy. All of them require defeating the lobbying investment of industries that profit from the current arrangement. That is achievable. Maria's situation is not inevitable. It is a policy choice that can be unmade.
