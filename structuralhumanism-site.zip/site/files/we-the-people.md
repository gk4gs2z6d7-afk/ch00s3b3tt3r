# We the People

*A Call to Action for Every American Who Still Believes That Democracy Is Worth Fighting For*

**Kai Jashon Price** · Public Address · 2025
— structuralhumanism.com —

---

*This document is addressed to you.*

*Not to politicians. Not to institutions. To you.*

**I. THE MOMENT WE ARE IN**

There is a specific kind of exhaustion that sets in when a people have been divided against themselves for too long. It is not physical tiredness. It is the exhaustion of always being angry at the wrong target. Of spending your outrage on your neighbor — who is also struggling, also afraid, also watching their children inherit something broken — while the systems that produced both of your struggles continue operating without interruption, without accountability, and without consequence.

That exhaustion is not accidental. It is the intended output of a political and media environment specifically engineered to point your attention sideways and downward rather than upward toward the actual sources of your grievance. As long as you are fighting the person across the street, you are not asking who owns the street.

This document is a refusal of that exhaustion. It is an argument — made with evidence, made with philosophy, made with the full weight of what every great moral tradition in human history has concluded — that silence in the face of documented injustice is not neutrality. It is complicity. And that complicity, when it is widespread enough and lasts long enough, becomes the architecture of tyranny.

> *"The only thing necessary for the triumph of evil is for good men to do nothing."* — Edmund Burke

— ✦ —

**II. WHAT PHILOSOPHY DEMANDS OF US**

Every major moral tradition in human history arrives at the same conclusion through different paths. The Stoics taught that the human being is, by nature, a political animal — that our capacity for reason obligates us to use it in service of the common good. Cicero wrote that to abandon the republic to those who would corrupt it is not wisdom but cowardice dressed in the language of pragmatism.

Immanuel Kant's categorical imperative asks a single clarifying question: What if everyone did what you are doing? If everyone accepted injustice quietly, looked away from documented corruption, decided that engagement was too complicated or too exhausting or too unlikely to succeed — what world would that produce? The answer is the world we are watching arrive. Kant's ethics are not idealistic. They are the most rigorous possible description of what human civilization requires to survive.

> *"Act only according to that maxim whereby you can at the same time will that it should become a universal law."* — Immanuel Kant, Groundwork of the Metaphysics of Morals

John Rawls, the most influential American political philosopher of the 20th century, asked us to imagine designing a society from behind a 'veil of ignorance' — without knowing whether we would be born rich or poor, Black or white, powerful or powerless. Behind that veil, no rational person designs a system in which the rules are written by those with the most money, in which accountability is optional for the powerful and mandatory for everyone else, in which the machinery of democracy exists in name while being emptied of function in practice.

The society Rawls describes as just is not a utopia. It is simply one in which the basic dignity of every person is treated as a non-negotiable starting point. We do not live in that society. We could. The distance between where we are and where justice requires us to be is not a matter of impossibility. It is a matter of will.

> *"Justice is the first virtue of social institutions, as truth is of systems of thought."* — John Rawls, A Theory of Justice

— ✦ —

**III. THE WEIGHT OF WHAT HAS BEEN ALLOWED**

We need to be honest with ourselves about something uncomfortable: the depth of the crisis we are in is proportional to the length of time we have allowed it to develop. Corruption that is permitted long enough does not stay in one place. It spreads into institutions. It becomes normal. It produces a generation that cannot remember what the alternative looked like and therefore cannot demand it.

The systems that need to be reformed — the financial capture of political process, the consolidation of media into a handful of corporate hands, the revolving door between regulatory agencies and the industries they regulate, the pharmaceutical pricing apparatus that treats illness as a profit center, the surveillance infrastructure that was built under emergency authority and made permanent — none of these emerged fully formed overnight. They grew across decades, each step normalized by the last, each accommodation making the next accommodation easier.

Understanding this is not cause for despair. It is cause for honest reckoning. The roots go deep because we let them go deep. Acknowledging that is not self-flagellation. It is the first requirement of effective action. You cannot pull a weed without finding the root.

> *"If you are neutral in situations of injustice, you have chosen the side of the oppressor."* — Desmond Tutu

Reverend Martin Luther King Jr. wrote from Birmingham City Jail in 1963 — eight days after his arrest for peacefully demonstrating — that the greatest obstacle to justice was not the violent opposition of the oppressor but the silence of the 'white moderate' who preferred a negative peace (the absence of tension) to a positive peace (the presence of justice). He was describing a failure of moral nerve that repeats itself in every generation and in every context where injustice establishes itself: the people who privately agree that something is wrong but publicly do nothing because the personal cost of action feels greater than the personal cost of inaction.

That calculation is always wrong in the long run. The personal cost of inaction compounds. The personal cost of action, shared across millions of people, becomes nearly nothing.

> *"Injustice anywhere is a threat to justice everywhere. We are caught in an inescapable network of mutuality, tied in a single garment of destiny."* — Martin Luther King Jr., Letter from Birmingham Jail

— ✦ —

**IV. THE AMERICAN PROMISE AND THE AMERICAN FAILURE**

The founding documents of the United States contain, in their best passages, some of the most radical political philosophy ever committed to paper. 'We hold these truths to be self-evident, that all men are created equal, that they are endowed by their Creator with certain unalienable Rights, that among these are Life, Liberty and the pursuit of Happiness.' That sentence, written in 1776, was not a description of reality. It was a demand — a standard against which every subsequent American generation was obligated to measure its institutions and find them wanting where they fell short.

Every expansion of American democracy — the abolition of slavery, women's suffrage, the Civil Rights Act, the Voting Rights Act — came not from the generosity of those in power but from the organized, sustained, costly insistence of people who took the founding promise seriously enough to hold the country accountable to it. They were called radicals. They were called dangerous. They were surveilled, imprisoned, beaten, and in many cases killed. They were right. And the country they refused to give up on is, in every meaningful way, better for their refusal.

We are their descendants. Not biologically — generationally, morally, politically. We inherited the democracy they bled for. We are responsible for what we do with it.

> *"America was not built on fear. America was built on courage, on imagination and an unbeatable determination to do the job at hand."* — Harry S. Truman

Frederick Douglass — who had been enslaved, who understood the machinery of oppression from inside it, who had every rational reason for despair — chose instead to remain in America and fight for it. 'I know of no soil better adapted to the growth of reform than American soil,' he said. He was not naive. He was strategic. He understood that the gap between America's stated values and America's actual practice was not a reason to abandon the project but a lever to use against it. The promise itself was the tool.

That lever is still there. The promise is still on the paper. The question is whether we are willing to pick it up.

> *"Power concedes nothing without a demand. It never did and it never will."* — Frederick Douglass

— ✦ —

**V. THE TRAP THEY BUILT FOR YOU — AND HOW TO SEE THROUGH IT**

Here is the most important thing to understand about the political environment you live in: it was not designed to help you think. It was designed to prevent you from thinking in certain directions while making you feel that you are thinking freely. The tribal binary of left and right, red and blue, conservative and liberal, is not an accurate map of American political reality. It is a management tool. As long as you define yourself primarily by opposition to the other tribe, you will never ask the question that the people who built the system most fear: what do we all have in common, and why are none of us getting it?

The answer to that question is where actual politics begins. Americans across the entire political spectrum — rural conservatives and urban progressives, religious communities and secular ones, veterans and activists — share a set of material interests that the current system consistently fails to serve: affordable healthcare, housing that a working person can afford, an education system that doesn't require your child to take on a mortgage before they have a job, a government that is accountable to voters rather than to donors, a foreign policy that doesn't create enemies faster than it defeats them.

These are not left-wing or right-wing positions. They are the minimum conditions of a decent society. The fact that they have been made to feel partisan — that wanting affordable medicine is somehow ideological — is itself evidence of how successfully the tribal management system has operated.

> *"When I give food to the poor, they call me a saint. When I ask why the poor have no food, they call me a communist."* — Dom Helder Camara

See through it. Not by abandoning your values — but by asking, honestly, whether the political identity you have been assigned actually serves those values, or whether it serves the interests of people who profit from keeping you divided from the Americans who could be your allies.

— ✦ —

**VI. IT WILL BE HARD. IT IS SUPPOSED TO BE HARD.**

Anyone who tells you this will be easy is either lying or doesn't understand the scale of what has been allowed to take root. The corruption we are dealing with is not a recent development. The financial capture of democratic process, the revolving door between government and industry, the use of media to manage rather than inform public opinion — these systems have been building for decades, in some cases for a century or more. They have deep institutional roots. They have enormous resources. They have every incentive to continue and every tool available to resist change.

The people who built these systems did not do so incompetently. They are patient, they are organized, and they understand that the best defense of an unjust arrangement is to make the population feel that changing it is impossible. Learned helplessness is not an accident. It is a product. If you feel that nothing you do matters, that the system is too big, too entrenched, too corrupt to respond to ordinary people — that feeling was manufactured for you. It is the most powerful weapon in the arsenal of those who benefit from the status quo.

> *"First they ignore you, then they laugh at you, then they fight you, then you win."* — Mahatma Gandhi

But here is what the history actually shows — and this is not optimism, it is the documented record: every system that has ever seemed permanent has ended. Slavery seemed permanent. Colonial empires seemed permanent. The Soviet Union seemed permanent. Apartheid seemed permanent. They ended not because they were unsustainable in principle but because enough people decided, at a specific historical moment, that the cost of continuing to accept them was higher than the cost of organizing against them.

We are at one of those moments. The evidence is visible. The accountability is available if we demand it. The solidarity is possible if we choose it. The difficulty is real — but difficulty has never been an acceptable reason for moral abdication. If anything, it is the measure of how much the answer matters.

> *"The most common way people give up their power is by thinking they don't have any."* — Alice Walker

— ✦ —

**VII. WHAT CHOOSING EACH OTHER ACTUALLY MEANS**

Unity does not mean agreement. It does not mean the erasure of difference, the suppression of debate, or the pretense that all political positions are equally valid. It means the recognition that every American — whatever their background, their politics, their religion, their identity — has a stake in whether their democracy functions. It means choosing to fight the system that has failed all of us rather than fighting each other over the scraps the system distributes to keep us occupied.

The person across the political divide from you is not your enemy. They are, in most cases, a person with legitimate grievances who has been handed a different explanation for why those grievances exist. Your job — our collective job — is not to defeat them. It is to find the common ground of shared material interest that the tribal management system works so hard to prevent you from discovering.

When you choose each other over the fight they designed for you, you become ungovernable in the way that actually matters. Not violent. Not destructive. Simply impossible to manage through division. An organized, informed, multi-political citizenry that agrees on the basic conditions of democratic function — accountability, transparency, the non-capture of public institutions by private interests — is the one thing that the architecture described in this document cannot absorb.

> *"We must learn to live together as brothers or perish together as fools."* — Martin Luther King Jr.

— ✦ —

**VIII. WHAT YOU CAN DO — STARTING NOW**

The call to action is not abstract. It is specific. It begins with the smallest possible political unit — yourself — and radiates outward.

**Know what is actually happening:** Turn off the outrage machine for one hour per day and replace it with primary sources. Read the actual congressional record. Read the actual declassified documents. Read the actual financial disclosures. The information that documents the failures described in this paper is publicly available. It does not require special access. It requires the decision to look.

**Vote in every election, especially local ones:** The school board. The city council. The county prosecutor. The state legislature. These are the positions that determine curriculum, control local police, write state financial law, and prosecute financial crime. The national conversation happens on television. The actual decisions that govern your daily life happen at the local level, in elections where turnout is often below 20% and where a few hundred votes determine outcomes.

**Move your money:** Over 130 million Americans already bank with credit unions — member-owned, democratically governed institutions operating outside the primary banking architecture. If you bank with a institution that helped cause the 2008 financial crisis and was bailed out with public money — consider whether your deposits should continue to capitalize that institution.

**Demand media accountability:** Cancel subscriptions that do not serve you. Support independent, reader-funded local journalism. When you share information, verify it first. The media ecosystem survives on your attention. Withdraw it strategically.

**Have the hard conversation:** The most politically transformative thing you can do is talk honestly with the people in your life who disagree with you — not to win, but to find the shared material interest beneath the tribal disagreement. This is uncomfortable. It is also how political movements actually begin.

**Show up:** Town halls. Public comment periods. Protests. Letters to elected officials. Organized these actions seem inadequate. At scale, organized across communities, sustained over time — they are the mechanism through which every reform in American history has ever been achieved. Every single one.

> **This is not a left document or a right document.**
>
> **It is a human document.**
>
> **It is addressed to every American who is tired of being managed.**

**IX. THE ONLY ACCEPTABLE RESPONSE**

We end where we began — with the question of what moral seriousness demands. Not moral perfection. Not the absence of doubt or fear or uncertainty. Moral seriousness means taking the evidence seriously, taking the stakes seriously, and acting accordingly.

To know what is documented in the public record about the capture of democratic institutions, the manufacture of division, the systematic extraction of public wealth for private benefit — and to decide that it is someone else's problem, that you are too tired, that change is impossible, that comfort is worth more than conscience — is a moral choice. It is a choice that has been made by majorities in every era in which injustice entrenched itself. It has never been the right choice. It will not be the right choice now.

The most radical act available to an American citizen right now is not violent and it is not dramatic. It is the decision to become genuinely, persistently, organizedly informed — and to act on that information in community with other people who have made the same decision. It is choosing solidarity over tribe. Evidence over narrative. Accountability over comfort. Each other over the fight they built for us.

It will be hard. Of course it will be hard. Two hundred and fifty years of democracy, fifty years of accelerating institutional capture, and the deepest economic inequality since the Gilded Age do not unwind themselves. The roots are deep. That is not a reason to walk away from the garden. It is a reason to bring better tools.

You are the tool. You — informed, organized, unmanaged, and committed to something larger than your own tribe — are precisely the thing this system was built to prevent. Becoming that thing is the most patriotic act available to an American in 2025. It is also the most human act available to any person on earth who believes that the civilization we are capable of building together is worth more than the division we have been sold.

> *"We shall overcome because the arc of the moral universe is long, but it bends toward justice."* — Martin Luther King Jr.

**It bends because people bend it.**

*With their hands. With their votes. With their voices.*

**With their refusal to stop.**

**WE THE PEOPLE**

*It was always ours.*

**QUOTES REFERENCED IN THIS DOCUMENT**

> *"The only thing necessary for the triumph of evil is for good men to do nothing."*
>
> **— Edmund Burke**
>
> *"Act only according to that maxim whereby you can at the same time will that it should become a universal law. (Groundwork of the Metaphysics of Morals, 1785)"*
>
> **— Immanuel Kant**
>
> *"Justice is the first virtue of social institutions, as truth is of systems of thought. (A Theory of Justice, 1971)"*
>
> **— John Rawls**
>
> *"If you are neutral in situations of injustice, you have chosen the side of the oppressor."*
>
> **— Desmond Tutu**
>
> *"Injustice anywhere is a threat to justice everywhere. We are caught in an inescapable network of mutuality, tied in a single garment of destiny. (Letter from Birmingham Jail, 1963)"*
>
> **— Martin Luther King Jr.**
>
> *"We must learn to live together as brothers or perish together as fools."*
>
> **— Martin Luther King Jr.**
>
> *"We shall overcome because the arc of the moral universe is long, but it bends toward justice."*
>
> **— Martin Luther King Jr.**
>
> *"Power concedes nothing without a demand. It never did and it never will."*
>
> **— Frederick Douglass**
>
> *"America was not built on fear. America was built on courage, on imagination and an unbeatable determination to do the job at hand."*
>
> **— Harry S. Truman**
>
> *"First they ignore you, then they laugh at you, then they fight you, then you win."*
>
> **— Mahatma Gandhi**
>
> *"The most common way people give up their power is by thinking they don't have any."*
>
> **— Alice Walker**
>
> *"When I give food to the poor, they call me a saint. When I ask why the poor have no food, they call me a communist."*
>
> **— Dom Helder Camara**
