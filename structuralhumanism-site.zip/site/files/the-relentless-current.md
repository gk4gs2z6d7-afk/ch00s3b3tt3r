# The Relentless Current

*A Citizens’ Constitutional Action Framework for the Repair of Democratic Self-Government*

**Kai Jashon Price** · Action Framework · 2025
— structuralhumanism.com —

---

> **Non-Violent. Constitutional. Immediate. Sustained.**
>
> Every mechanism in this document is legal. Every argument in this document is documented.
>
> **Every call to action in this document is what the Founders called performing your civic duty.**

**SECTION ONE: THE QUESTION PATRIOTISM ACTUALLY ASKS**

**IF YOU DON'T LIKE IT, LEAVE — THE MOST ANTI-AMERICAN SENTENCE EVER SPOKEN**

Let us begin with the argument that gets used to silence every serious criticism of American institutions, because it needs to be dismantled completely before anything else in this document can land.

'If you don't like it, leave.'

This is the sentence spoken by people who have confused comfort with patriotism. People who have mistaken silence for loyalty. People who have, without realizing it, adopted the posture of subjects rather than citizens. Because here is what that sentence actually says when you follow it to its logical end: it says that the proper response to tyranny is emigration. It says that the proper response to corruption is acceptance. It says that the proper response to a government that has drifted from its founding compact with the people is to find a different government and leave this one alone.

That is not the American tradition. That is the tradition of every country this nation was founded in opposition to.

The men who signed the Declaration of Independence did not leave. They did not quietly relocate to France and live comfortable lives under a more agreeable monarch. They pledged their lives, their fortunes, and their sacred honor to the proposition that a people have not only the right but the obligation to alter or abolish any form of government that becomes destructive of the ends for which it was established. Those are not radical words. They are the first principles of the American republic, written in its founding document, ratified by blood at Lexington and Concord and Valley Forge and Yorktown.

The Civil War was fought because Americans on both sides of a fundamental moral question believed so deeply in their position that they were willing to die for it rather than leave. The suffragettes did not emigrate to countries where women could vote. They chained themselves to fences, went to prison, and conducted hunger strikes inside that prison until this country was forced to reckon with its own stated principles. The civil rights movement did not advise Black Americans to find a country that treated them as human beings. It stayed, organized, marched, bled on the Edmund Pettus Bridge, and bent the arc of this nation toward something closer to its own promise.

This is the American tradition. Not leaving. Staying. Fighting. Using every constitutional tool available. Making the cost of injustice higher than the cost of change. Refusing to normalize what should not be normal. Insisting, generation after generation, that the distance between what this country claims to be and what it actually is can be closed — not by abandoning the country but by earning what you claim to be proud of.

> *Here is the honest inversion: if you are content with regulatory capture, with 88 percent of S&P 500 companies owned by three asset managers, with covert foreign policy decisions that kill American service members and fund the organizations that later attack us, with a media ecosystem that tells you what to argue about while the real mechanisms of power operate outside the frame — if you are content with all of that and you want no disruption to your comfort, then perhaps you are the one who does not belong in a democratic republic. Because democracy requires citizens who perform their citizenship. Monarchy requires only obedience. There are monarchies available. A democracy that is allowed to rot into managed consent is just a monarchy with better marketing.*

**You Rooted for the Rebel Alliance. You Rooted for William Wallace. Now What.**

Every American who has ever sat in a movie theater knows exactly what they are supposed to do when the Death Star appears on screen. They root for the rebels. When the Empire occupies a galaxy and rules through terror and consolidated power, the morally correct position is to join the Rebellion — the scrappy, outgunned, outspent, perpetually losing faction that refuses to stop because they understand that losing slowly with integrity is better than winning in chains.

Nobody watches Star Wars and roots for the Emperor. Nobody cheers for the stormtroopers. Nobody says 'the Empire has legitimate governance concerns and the rebels should respect established authority.' You know who the good guys are. You have always known who the good guys are. The entire moral vocabulary of science fiction, fantasy, and action storytelling — from Star Wars to Braveheart to The Hunger Games to V for Vendetta to 1984 to Spartacus — is organized around a single axis: concentrated power that serves itself against the people who live under it, and the individuals who refuse to accept that arrangement as permanent.

William Wallace did not have a plan that was guaranteed to work. He did not wait until the odds were favorable. He stood on a battlefield with an army of farmers against armored cavalry and professional soldiers and he asked a fundamental human question: what is a life worth if you trade everything that makes it meaningful to preserve it? 'They may take our lives, but they will never take our freedom.' People have repeated that line for 30 years in movie theaters and on social media. And then they go home and do not call their representative.

This is not a criticism. It is an honest observation about the gap between the values people hold and the actions those values would require if they were taken seriously. The gap exists for real and documented reasons: debt payments that cannot be missed, children who need to be fed, jobs that punish political expression, a political system engineered to make participation feel futile. These are not character flaws. They are the load-bearing pillars of managed consent, and they function exactly as designed.

But here is what is also true: the rebels in every story you have ever loved did not have better odds than you have. Luke Skywalker did not have a plan when he climbed into an X-wing. The Gryffindors who faced Voldemort did not have a reasonable expectation of survival. The Hungarian revolutionaries of 1956, the Solidarity movement in Poland, the students in Tiananmen Square — none of them had odds that a rational actor would have taken. They acted anyway, because there are conditions under which the cost of inaction becomes higher than the cost of action, and the only honest question is whether we have reached those conditions.

The evidence documented in The Great Consolidation and Blowback and Immunity suggests we have.

> *When three asset managers hold voting control over 88 percent of the largest American companies and those companies stop competing with each other on price, that affects your wallet every day. When covert foreign policy decisions made without public consent produce the organizations that attack us and then ask us to fund the response, that affects your children's lives. When the architects of a war that killed 4,500 Americans on false premises receive Presidential Medals of Freedom and paid speaking engagements, that affects what your service and your sacrifice mean. This is not abstract. It is in your bank account, your grocery bill, your fuel costs, your healthcare premiums, and the wars your family members are asked to fight.*
>
> **COUNTERARGUMENT: The system is too big to change. Individual action is meaningless against institutional power of this scale.**
>
> *The Big Three asset managers hold $24 trillion. Three firms. A few hundred people in corporate governance departments cast 25 percent of all votes at the largest American companies. BlackRock, Vanguard, and State Street are simultaneously the largest shareholders in Ford and General Motors, in Coke and Pepsi, in all four major airlines. The concentrated power documented in The Great Consolidation is genuinely enormous. What can one person, or one organization, do against that?*
>
> **WHY THAT DOES NOT SAVE THE FRAMING: The same argument was made in 1773, in 1861, in 1955, and in 1989.**
>
> In 1773, the British East India Company controlled a monopoly on tea trade backed by the most powerful naval and military force in the world. The colonists had no standing army, no navy, no formal government, and no guarantee of French support. They dumped the tea anyway. In 1955, Rosa Parks was one woman with no institutional power, no organization behind her, and no guarantee that anyone would follow. The Montgomery Bus Boycott lasted 381 days and destroyed the bus company's revenue model through organized economic non-participation. In 1989, the Berlin Wall fell in weeks after decades of managed consent — not because the East German government became less powerful, but because enough people simultaneously decided to stop consenting. The argument that the system is too big has been made against every successful reform in history. It has never once been correct as a reason to stop. It has only ever been correct as a reason to be strategic rather than impulsive — which is exactly what this document is.

**SECTION TWO: THE DOCUMENTED RECORD — WHAT YOU ARE BEING ASKED TO ACCEPT**

**THE CASE, STATED PLAINLY, WITH SOURCES**

This is not outrage. This is the documented record. Every number in this section has a named source. Every claim has a named institution behind it. This is important because the first defense of concentrated power is to call its critics conspiracy theorists. The second defense is to say the evidence is partisan. A documented record with named peer-reviewed sources from the National Bureau of Economic Research, the Journal of Finance, the Quarterly Journal of Economics, Senate Intelligence Committee reports, and sworn affidavits from retired admirals is not a conspiracy theory. It is a bill of particulars.

**The Economy Is Consolidated to a Degree the Law Was Written to Prevent**

Three asset management firms — BlackRock ($10.5 trillion), Vanguard ($9.3 trillion), and State Street ($4.3 trillion) — are collectively the largest shareholder in 88 percent of S&P 500 companies. Vanguard alone is the single largest institutional shareholder in 422 of the 505 firms in the index. This finding is documented by Jan Fichtner, Eelke Heemskerk, and Javier Garcia-Bernardo at the University of Amsterdam's CORPNET project. It is updated by SEC filing analysis through 2025.

These three firms simultaneously hold large positions in every major airline. A peer-reviewed study by José Azar, Martin Schmalz, and Isabel Tecu, published in the Journal of Finance in 2018, found that airline ticket prices on routes where carriers shared common institutional owners were 3 to 7 percent higher than they would have been under separate ownership. That is money coming out of your pocket on every flight, produced by an ownership structure that antitrust law as currently written does not reach.

The tobacco industry acquired the dominant share of America's shelf-stable processed food category between 1985 and 2000 — Philip Morris buying General Foods ($5.8 billion), then Kraft ($12.9 billion), then Nabisco ($18.9 billion); R.J. Reynolds merging with Nabisco Brands. A peer-reviewed study published in the journal Addiction in 2023 by Fazzino and colleagues found that during the period of tobacco ownership, these food brands were 80 percent more likely to be formulated in the carbohydrate-and-sodium combinations that trigger compulsive eating. The methodology for making food addictive was transferred directly from cigarette research to food formulation. The 2003 divestiture did not undo the formulations. The products you buy at the grocery store today still carry the engineering decisions made in the 1980s by companies that had already spent decades studying how to make something impossible to stop consuming.

**The Foreign Policy Record Carries Names and Dates**

In January 1998, Zbigniew Brzezinski told Le Nouvel Observateur that the first presidential finding authorizing covert aid to anti-Soviet forces in Afghanistan was signed on July 3, 1979 — almost six months before the Soviet invasion. He said, in print, that the United States 'knowingly increased the probability' of the Soviet intervention. When asked whether he regretted the decision given the subsequent rise of international jihadist networks, Brzezinski replied: 'Regret what? That secret operation was an excellent idea.' Robert Gates confirmed the July 3, 1979 timeline in his 1996 memoir From the Shadows. The infrastructure built under Operation Cyclone — recruitment networks, training camps, weapons pipelines — did not dissolve when the Soviets withdrew. The same logistical network produced the foreign-fighter cohort from which al-Qaeda recruited.

On May 23, 2003, L. Paul Bremer issued CPA Order 2, dissolving the Iraqi army. The decision reversed prior planning documented by James Pfiffner in Intelligence and National Security (2010). The 720,000 men suddenly unemployed included the people who would staff ISIS's command structure. A 2015 Der Spiegel investigation found that roughly one-third to one-half of ISIS's senior leadership had served in Saddam Hussein's military before CPA Order 2 threw them into the street. The Atlantic Council stated plainly: 'There was good evidence that some of these same regime elites and soldiers wound up helping to generate the Islamic State.' The same architects who made these decisions faced no criminal charges. Several received Presidential Medals of Freedom. The public was then asked to fund a second war to address the conditions the first war created.

On October 22, 2003, retired Navy Captain Ward Boston Jr. signed a sworn affidavit stating that the 1967 Court of Inquiry into the Israeli attack on the USS Liberty — which killed 34 American sailors — had been ordered to a predetermined conclusion by President Lyndon Johnson and Secretary of Defense Robert McNamara. Boston stated that he and Admiral Kidd 'were given only one week to gather evidence for the Navy's official investigation, though we both estimated that a proper Court of Inquiry would take at least six months.' The Liberty remains the only major attack on a U.S. naval vessel in the modern era that has never received a full congressional inquiry. Thirty-four American sailors. No investigation. No accountability. No answers for their families.

> **COUNTERARGUMENT: These are complex geopolitical situations that cannot be judged in hindsight with perfect information. The decision-makers were operating under real constraints with incomplete intelligence.**
>
> *Brzezinski knew he was increasing the probability of a Soviet invasion. He said so on the record. He expressed no regret. The Pfiffner documentation shows that the decision to dissolve the Iraqi army reversed prior planning that had been briefed to the President. These were not intelligence failures. They were deliberate choices made by people who faced no consequences when those choices produced disasters they were warned about.*
>
> **WHY THAT DOES NOT SAVE THE FRAMING: The question is not whether the decisions were understandable. The question is whether accountability followed.**
>
> It did not. That is the documented fact. And a system in which consequential decisions that harm the public carry no consequence for the decision-makers will produce more such decisions. This is not a theory. It is the logical prediction of the institutional incentive structure. If you can launch a war on false premises, receive a Presidential Medal of Freedom, and move to a think tank at $40,000 per speech, the incentive to be honest about intelligence assessments before the next war is precisely zero. The accountability gap is not a peripheral complaint. It is the mechanism that makes every subsequent failure more likely.

**SECTION THREE: WHAT THE CONSTITUTION ACTUALLY GIVES YOU**

**THE FOUNDERS BUILT THE TOOLS. THEY ARE WAITING TO BE USED.**

The men who wrote the Constitution had just fought a revolution. They were not naive about power. They were not optimistic about the tendency of institutions to serve the public rather than themselves. James Madison wrote in Federalist No. 51: 'If men were angels, no government would be necessary.' He was not writing about other people. He was writing about the people who would hold the offices he was helping to design. The entire architecture of the Constitution — separation of powers, the Bill of Rights, the amendment process, the impeachment clause, the First Amendment's protection of petition and assembly — was built on the assumption that concentrated power would eventually be used against the people it was supposed to serve, and that citizens would need tools to fight back.

Those tools exist. They are documented in the sections that follow. They are not perfect. They are not fast. They do not guarantee victory. But they are real, they are constitutional, and they are what distinguishes a citizen in a democratic republic from a subject in a managed state. The difference between a citizen and a subject is not income, not education, not social status. It is whether you use the power your Constitution gave you or whether you leave it sitting on the table while the people who benefit from your silence use theirs.

> *The Founders did not pledge their lives, their fortunes, and their sacred honor to build a country whose citizens would one day say 'it's too hard' and go back to watching television. They built a system that requires participation to function. A democracy that is not practiced is not a democracy. It is a performance of democracy — exactly what The Great Consolidation documents as the current condition: a Permitted Narrative that keeps the public arguing about the shadows on the wall while the real mechanisms of power operate outside the frame.*

**What You Cannot Do: The Honest Constitutional Reality**

Citizens cannot directly impeach anyone. The Constitution gives the House of Representatives the sole power of impeachment (Article I, Section 2) and the Senate the sole power to try all impeachments (Article I, Section 3). Grounds are 'Treason, Bribery, or other high Crimes and Misdemeanors' — a phrase the Constitution deliberately leaves undefined because the Founders understood that political accountability cannot be fully reduced to a legal checklist.

There is no federal recall mechanism. Recall exists in 19 states for state-level officials. At the federal level it does not exist and would require a constitutional amendment. Energy directed toward a federal recall campaign is energy taken away from mechanisms that do exist and have worked.

What citizens can do regarding impeachment is more powerful than the mechanism itself: make the political cost of not impeaching higher than the political cost of impeaching. Every historical impeachment proceeding — Andrew Johnson in 1868, Bill Clinton in 1998, Donald Trump in 2019 and 2021 — followed sustained periods of organized public pressure that made inaction politically costlier than action. The citizen role is not formal. It is the engine that makes the formal mechanism move.

**SECTION FOUR: THE CONSTITUTIONAL TOOLKIT — FIFTEEN TOOLS, FOUR TIERS**

**TIER ONE: WHAT YOU CAN DO TODAY, ALONE, FOR FREE**

These tools require nothing but your time and your willingness to use them. They are the foundation. They are also the most consistently underused tools in the democratic toolkit, because the managed consent system works by making participation feel futile before it begins. It is not futile. It is the only thing that has ever worked.

**1. Freedom of Information Act Requests**

*Legal Authority: 5 U.S.C. § 552 — the law every federal agency must comply with*

> **WHAT:** Every federal agency is legally required to provide access to government records upon request. This is how investigative journalism actually gets its primary documents. The revolving door between the FDA and pharmaceutical companies, the correspondence between FCC officials and broadcast industry lobbyists, the internal memos on CPA Orders 1 and 2 — all of this is obtainable through FOIA. State equivalents apply to state agencies.
>
> **HOW:** File at FOIA.gov or directly through each agency's portal. Request correspondence between agency officials and regulated industries. Request calendars showing regulator-lobbyist meetings. Request financial disclosure documents. Use MuckRock.com (free) to track requests and publish results publicly. If denied, appeal administratively, then to federal district court. File simultaneously with multiple requesters on the same subject to build documentary pressure.
>
> **COST:** Free **TIMELINE:** 20 business days by law; litigation if necessary
>
> **DOCUMENTED PRECEDENT:** *The tobacco industry's internal documents revealing its knowledge of addiction and its deliberate transfer of addictive formulation methodology to food products — the foundation of the Fazzino 2023 Addiction study — were released through exactly this mechanism under the 1998 Master Settlement Agreement. The Brzezinski July 3, 1979 finding was declassified. The AZC-FARA files were declassified in 2008 after 46 years. The documents exist. The law says you can see them. File the request.*

**2. Administrative Procedure Act Public Comment**

*Legal Authority: 5 U.S.C. §§ 553-559 — agencies must read every substantive comment and respond*

> **WHAT:** Every proposed federal regulation must accept public comments. Courts have overturned regulations where agencies failed to adequately respond to substantive public comments. This is legally binding participation in rule-making. The Azar-Schmalz-Tecu Journal of Finance findings on airline common ownership — cited by name, with journal and year — submitted as a public comment to the FCC, SEC, or DOJ during the relevant rule-making period becomes part of the administrative record that courts review.
>
> **HOW:** Track proposed rules at Regulations.gov. File comments that cite specific peer-reviewed research and demand a response. Organize coordinated campaigns submitting substantive documented comments from multiple citizens. The combination of volume and specificity — not form letters but documented arguments — is what creates legal and political pressure.
>
> **COST:** Free **TIMELINE:** 30-60 day comment windows; final rule within 12-18 months
>
> **DOCUMENTED PRECEDENT:** *The FCC's 2003 attempt to relax media ownership rules was challenged through this mechanism. The public comment record and subsequent litigation constrained the rule. When substantive comments citing published research are submitted and the agency proceeds without addressing them, the administrative record supports judicial review. Tool 2 is the foundation for Tool 11 (administrative law challenge).*

**3. Constituent Contact at Volume and Specificity**

*Legal Authority: First Amendment right to petition government; documented in Broockman and Skovron, American Journal of Political Science, 2018*

> **WHAT:** Congressional offices track constituent contact on specific legislation and votes. High-volume constituent contact on specific issues measurably shifts stated representative positions. Phone calls to the district office outweigh emails. In-person appearances at town halls outweigh everything.
>
> **HOW:** Call the district office (not Washington) with a specific ask: the bill number, the vote, the date. Organize coordinated calling campaigns. Attend every town hall and ask documented, specific, on-the-record questions. Record and publish responses. The combination of volume and specificity is what creates perceived electoral threat rather than ambient noise.
>
> **COST:** Free **TIMELINE:** Immediate impact on office tracking; electoral impact within election cycle
>
> **DOCUMENTED PRECEDENT:** *During the 2017 ACA repeal fight, town hall pressure campaigns organized by Indivisible chapters contributed directly to the bill's failure. The mechanism was not persuasion but perceived electoral threat from organized, vocal constituents in competitive districts. Three senators changed their votes. The bill died.*

**4. Public Meeting Participation**

*Legal Authority: First Amendment; state open meetings laws*

> **WHAT:** Every city council, county commission, school board, planning board, and public utility commission holds public meetings where citizens have a legal right to speak. These meetings are transcribed into the public record. Local officials are accountable to far smaller numbers of organized constituents than federal officials.
>
> **HOW:** Attend regularly. Learn the procedural rules for public comment. Organize with neighbors to have multiple voices on the same issue. Submit written comments in addition to oral testimony so they enter the formal record. Ask for roll call votes rather than voice votes so positions are documented. Run for these positions — city council and school board seats regularly go uncontested.
>
> **COST:** Free **TIMELINE:** Immediate; local officials respond faster than federal
>
> **DOCUMENTED PRECEDENT:** *Local government is where the Relentless Current has its highest immediate return. The distance between citizen pressure and visible outcome is shortest at the local level. The accountability infrastructure built at city council is the training ground for everything that follows.*

**TIER TWO: TOOLS THAT REQUIRE ORGANIZING — NO MONEY NEEDED**

**5. Recall Campaigns**

*Legal Authority: State constitutions in 19 states including California, Wisconsin, Colorado, Michigan, and others*

> **WHAT:** 19 states allow recall of elected officials. California requires signatures equal to 12% of votes cast in the last election within 160 days. Wisconsin requires 25% of the last gubernatorial vote total within 60 days. A recall campaign that generates 30% of required signatures and fails still produces a documented public record of organized opposition that changes the official's political calculus for their remaining term.
>
> **HOW:** Identify your state's recall statute. Form a recall committee. File the required notice with your state election authority. Build a signature collection campaign — door-to-door is more effective than online for verified signatures. Document every step formally. Sustain a replacement candidate coalition simultaneously.
>
> **COST:** Filing fees only ($25-$200) **TIMELINE:** 3-6 months to signature deadline; election within 60-90 days after certification
>
> **DOCUMENTED PRECEDENT:** *The 2003 California recall of Governor Gray Davis succeeded with 55.4% of voters supporting removal. The 2012 Wisconsin recall of Governor Scott Walker failed at the ballot but produced the organized civic infrastructure that flipped the Wisconsin state legislature in subsequent cycles. Win or lose, a recall campaign builds the coalition that persists.*

**6. Primary Challenges Against Captured Officials**

*Legal Authority: Federal Election Commission regulations; state primary law*

> **WHAT:** The primary election is where the most powerful citizen electoral intervention occurs. Most congressional districts are not competitive in general elections but are competitive in primaries where turnout is 15-25% of registered voters. Organized minority factions have disproportionate influence. Primary campaigns do not require winning to change behavior — the credible threat of a primary challenge moves positions.
>
> **HOW:** Build a documented accountability record: voting history, donor history, revolving door employment, public statements versus votes. Recruit a credible challenger or run yourself. File with the FEC — required above $5,000. Check your state election authority for filing deadlines, typically 3-6 months before the primary. Lead with the documented record, not with personality attacks.
>
> **COST:** Low — primary campaigns have won with budgets under $50,000 **TIMELINE:** 12-18 months from launch to primary date
>
> **DOCUMENTED PRECEDENT:** *Alexandria Ocasio-Cortez defeated 10-term incumbent Joe Crowley in New York's 14th district in 2018 with 15,897 votes. The documented accountability record of the incumbent's donor relationships and voting history was central to the campaign. Between 2018 and 2022, 23 incumbent House members lost primaries. In every case the defeat followed organized accountability campaigning on specific documented votes.*

**7. Coordinated FOIA Documentary Campaigns**

*Legal Authority: 5 U.S.C. § 552; Administrative exhaustion doctrine*

> **WHAT:** A single FOIA request is an inquiry. A coordinated campaign of FOIA requests filed by dozens of citizens and organizations on the same institutional target over a sustained period is a documentary siege. The goal is not any single document but the construction of a complete public record that makes institutional denial progressively indefensible and that provides raw material for investigative journalism and legal challenge.
>
> **HOW:** Identify a specific institutional target. Divide the request scope among organized participants to maximize coverage without duplication. Use MuckRock.com to file, track, and publish requests publicly. When agencies deny or delay, file administrative appeals collectively and document the pattern of obstruction. Submit results to investigative journalists at ProPublica, The Intercept, The Lever, and The American Prospect.
>
> **COST:** Free — MuckRock has a free tier **TIMELINE:** 20 days per request by law; full campaigns run 6-18 months
>
> **DOCUMENTED PRECEDENT:** *The tobacco industry documents that revealed Philip Morris's deliberate transfer of addictive formulation methodology to food products were released through coordinated legal pressure over years. Ward Boston's sworn affidavit about the Liberty cover-up was made public 36 years after the fact through sustained documentary pressure by survivors and investigators. The documents exist. The law says you can access them. The organizing determines whether you find them before or after the damage becomes irreversible.*

**8. Ballot Initiative Campaigns**

*Legal Authority: State constitutions in 26 states plus the District of Columbia*

> **WHAT:** 26 states allow citizens to place legislation or constitutional amendments directly on the ballot through initiative petition, bypassing the legislature entirely. Ballot initiatives have produced minimum wage increases in states where legislatures refused to act, ranked choice voting adoption, redistricting reform, and campaign finance reform. These are real structural policy changes achieved outside of partisan legislative gridlock.
>
> **HOW:** Identify your state's initiative statute — requirements range from 2% to 15% of registered voters' signatures. Draft initiative language carefully; courts interpret it literally and opponents challenge ambiguity. Build a campaign committee. Organize signature collection. File with your state election authority. Defend against legal challenges. Run the ballot campaign.
>
> **COST:** Volunteer-driven: near $0; professional signature collection: $3-$8 per verified signature **TIMELINE:** Signature collection: 3-6 months; placement on next general election ballot
>
> **DOCUMENTED PRECEDENT:** *In November 2020, voters in 32 states voted on 120 ballot measures. Of those related to structural accountability, the majority passed even in states where the partisan legislative majority opposed them. Citizens in states with initiative authority have a direct route around captured legislatures on issues where the language can be drafted clearly enough to reach voters directly.*

**TIER THREE: LEGAL AND LITIGATION TOOLS**

**9. False Claims Act — Qui Tam Whistleblower Suits**

*Legal Authority: 31 U.S.C. §§ 3729-3733 — the law that pays citizens who expose fraud against the federal government*

> **WHAT:** Any private citizen with documented knowledge of fraud against the federal government can file a lawsuit on the government's behalf and receive 15-30% of any recovery. This covers fraudulent Medicare and Medicaid billing, defense contractor fraud, federal grant fraud, and any false claim submitted to the federal government. Recoveries have exceeded $2 billion in single cases.
>
> **HOW:** If you have documented evidence of fraud against the federal government, consult a False Claims Act attorney. Most take these cases on contingency — no upfront cost. File the complaint under seal in federal district court. The Department of Justice has 60 days to decide whether to intervene. Even if DOJ declines, the relator can proceed independently.
>
> **COST:** Contingency fee — no upfront cost if attorney takes the case **TIMELINE:** DOJ review: 60 days minimum; full litigation: 2-7 years
>
> **DOCUMENTED PRECEDENT:** *Since 1986, qui tam cases have recovered over $50 billion for the federal government. Pharmaceutical companies billing Medicare for off-label promotions, defense contractors overbilling the Department of Defense, banks misrepresenting mortgage quality to federal agencies — citizens with documented inside knowledge have used this statute to produce the largest financial accountability outcomes available to private individuals in American law.*

**10. State Attorney General Antitrust Actions**

*Legal Authority: Clayton Act parens patriae authority; state antitrust statutes*

> **WHAT:** State attorneys general have independent antitrust enforcement authority. When federal enforcement is captured or underfunded, state AG action is the most viable alternative. The 2020 Google antitrust investigation was initiated by a coalition of 38 state AGs. State AGs can investigate concentration in industries affecting their residents regardless of federal enforcement priorities.
>
> **HOW:** File a documented antitrust complaint through your state AG's portal. Cite the peer-reviewed literature — the Azar-Schmalz-Tecu Journal of Finance paper on airline common ownership is directly applicable. Document specific harm to state residents. Organize a coordinated complaint campaign. Connect with the American Antitrust Institute, the Open Markets Institute, and Public Citizen for technical assistance.
>
> **COST:** Free to file; legal costs covered by AG office if investigation opens **TIMELINE:** Investigation: 6-24 months; litigation: 2-5 years
>
> **DOCUMENTED PRECEDENT:** *Multistate AG coalitions have produced consent decrees, market structure changes, and structural remedies in industries where federal enforcement was absent. The mechanism does not require federal cooperation. It requires 20 or more state AG offices to agree that the documented harm to their residents warrants action — which is precisely why the documented record built through Tier One and Tier Two tools is the prerequisite for Tier Three.*

**11. Administrative Law Challenges — Judicial Review of Agency Action**

*Legal Authority: 5 U.S.C. § 702 — any person adversely affected by federal agency action can petition federal courts for review*

> **WHAT:** If an agency failed to respond to substantive public comments, failed to consider relevant evidence, or adopted rules beyond its statutory authority, those rules can be overturned in federal court. This is the formal legal mechanism by which the public comment campaigns in Tier One produce binding structural outcomes.
>
> **HOW:** This requires legal representation — contact Public Citizen Litigation Group, the Natural Resources Defense Council, Earthjustice, or the Electronic Frontier Foundation depending on your issue. The substantive public comments filed during the notice-and-comment period become the evidentiary basis for this challenge. File the comments first. Challenge the rule second.
>
> **COST:** Pro bono or nonprofit legal representation; filing fees waived for nonprofits **TIMELINE:** District court: 1-2 years; appeals: 2-4 years additional
>
> **DOCUMENTED PRECEDENT:** *The FCC's 2003 media ownership relaxation rules were partially reversed through this mechanism (Third Circuit, 2004). The Supreme Court ordered the EPA to regulate greenhouse gases in Massachusetts v. EPA (2007) following exactly this process. Administrative law challenges have overturned Department of Labor overtime rules, EPA rollbacks, and consumer financial protection regulations. The administrative record built through public comments is the foundation.*

**12. Shareholder Activism and Proxy Campaigns**

*Legal Authority: SEC Rule 14a-8 — shareholders with $2,000 in stock for 12 months can submit proposals*

> **WHAT:** If you own shares in publicly traded companies through a 401(k) or IRA, you have standing to attend shareholder meetings, file resolutions, and vote on corporate governance questions. The three-firm common ownership concentration documented in The Great Consolidation operates through voting power. Shareholder activism operates through the same mechanism from the other direction.
>
> **HOW:** Track proxy vote calendars at ProxyMonitor.org. File a Rule 14a-8 proposal at least 120 days before the annual meeting. Connect with coordinated shareholder campaigns through As You Sow (asyousow.org) and the Interfaith Center on Corporate Responsibility. Even proposals that fail build the public record and generate press attention on the specific governance failures you are documenting.
>
> **COST:** Minimum $2,000 stock holding for 12 months; no filing cost **TIMELINE:** Annual meeting cycle
>
> **DOCUMENTED PRECEDENT:** *Activist fund Engine No. 1 won three Exxon board seats in 2021 with less than 0.02% of shares — by building a coalition of larger institutional investors around a documented argument about the company's strategic direction. The mechanism is legally binding. It operates inside the corporate governance structure that The Great Consolidation identifies as the primary concentration mechanism. Shareholder activism is the inside game that complements the outside game of legislative and regulatory pressure.*

**TIER FOUR: STRUCTURAL REFORM — THE LONG GAME**

These tools operate on the longest timescales. They are also the tools that produce durable change rather than single victories. Every structural reform in American history — the Sherman Antitrust Act, the Clayton Act, the Glass-Steagall Act, the Civil Rights Act, the 17th Amendment — followed years or decades of organized pressure through the earlier tiers before the political moment arrived that made structural change possible. The job right now is building the foundation. The structural reform comes when the foundation is ready.

**13. State Legislation as Policy Laboratory**

*Legal Authority: State legislative authority; Supremacy Clause does not preempt state regulation where federal law is absent*

> **WHAT:** Reforms that cannot pass in a captured federal legislature can be piloted at the state level. State adoption produces the evidence base and political momentum that eventually moves federal policy. Every major federal reform of the 20th century was piloted in states first.
>
> **HOW:** Identify state legislatures where your issue has a viable coalition. Connect with state-level policy organizations. Draft or support model legislation. Organize a coordinated multi-state campaign that demonstrates replicable results. The policy result at the state level becomes the evidence that federal opponents cannot dismiss as untested.
>
> **COST:** Coalition organizing costs **TIMELINE:** Legislative session cycle: 12-24 months per state
>
> **DOCUMENTED PRECEDENT:** *California's consumer privacy law (CCPA, 2018) preceded and shaped the federal privacy debate. California's vehicle emissions standards forced national automaker production decisions that effectively set national policy. Maine and Alaska's adoption of ranked choice voting in federal elections created the first results under RCV and changed the political viability calculation for federal RCV legislation.*

**14. Antitrust Legislative Reform Campaign**

*Legal Authority: Article I congressional authority; Sherman Act (1890); Clayton Act (1914)*

> **WHAT:** The post-1978 Bork consumer welfare standard that narrowed antitrust enforcement is a judicial interpretation, not a statutory mandate. Congress can restore the structural standard — the principle that market concentration itself is a public harm — through legislation. Active legislative proposals include the American Innovation and Choice Online Act, the Platform Competition and Opportunity Act, and the 21st Century Glass-Steagall Act.
>
> **HOW:** Support the specific legislative vehicles — contact your representatives about each bill specifically by name and number. Support the American Antitrust Institute, the Open Markets Institute, and the Economic Policy Institute. Build cross-partisan coalitions — antitrust reform has genuine support from progressive Democrats and economic nationalist Republicans because market concentration harms ordinary voters across party lines.
>
> **COST:** Advocacy coalition costs **TIMELINE:** 2-8 years to passage
>
> **DOCUMENTED PRECEDENT:** *The Sherman Antitrust Act of 1890 was passed after a decade of Populist movement organizing. The Clayton Act of 1914 followed years of Progressive Era pressure. The Glass-Steagall Act of 1933 was passed in the first 100 days of the Roosevelt administration — but the organizing and evidence-building for bank reform had been ongoing for 15 years. Structural legislative reform follows this pattern: sustained evidence-building and organizing, then rapid passage when the political moment arrives.*

**15. Constitutional Amendment Campaigns**

*Legal Authority: Article V — two pathways: congressional supermajority or state convention*

> **WHAT:** The campaign finance structure that allows concentrated economic power to convert itself directly into political power through unlimited campaign contributions requires a constitutional remedy. Citizens United v. FEC (2010) is a Supreme Court decision. Overturning it requires either a new Court decision or a constitutional amendment. The convention threat mechanism — 34 states calling for a convention — has historically forced congressional action before the convention is needed.
>
> **HOW:** The campaign finance amendment campaign currently has 22 state resolutions; 34 required for a convention call. Build or support this campaign in your state. The single-issue focus and cross-partisan appeal (dark money harms voters of both parties) is the model. The 10-15 year horizon requires the long-game commitment that The Relentless Current describes as the foundational discipline.
>
> **COST:** Major campaign infrastructure; multi-year commitment **TIMELINE:** 10-20 years historically; convention threat faster when close to 34
>
> **DOCUMENTED PRECEDENT:** *The 17th Amendment (direct election of Senators, 1913) required a 10-year campaign after Congress repeatedly refused to act — it was achieved through the convention threat that forced congressional action. The 26th Amendment (voting age 18) was ratified in 100 days because the organizing had been sustained for years. The amendment process works. It requires the patience of people who understand that the most important changes are the ones that survive the next administration.*

**SECTION FIVE: THE EARLY-STAGE FRAMEWORK — WHAT TO BUILD BEFORE ANYTHING ELSE**

**THE FIVE THINGS THAT COME BEFORE EVERYTHING ELSE**

The Relentless Current is not an event. It is a practice. The early stage of any reform movement that lasts builds five things before it does anything else, and the movements that skipped these steps are the ones you have watched fail. Every failed populist surge in American history — and there have been many — failed for the same reason: it had energy without infrastructure, passion without documentation, anger without a strategic theory of change. This framework produces the infrastructure.

**1. The Documentary Record**

The load-bearing pillar of concentrated power is forgetting. The Great Consolidation documents this explicitly: the public absorbs each merger, each covert decision, each accountability failure as an isolated event, mourns the damage, funds the response, and forgets. Documentary memory — named officials, named decisions, named dates, named outcomes — is what makes the structure harder to sustain.

The first task is therefore making forgetting impossible. FOIA campaigns, public comment filings, voting record documentation, donor disclosure tracking, revolving door mapping. The record precedes everything. You cannot hold accountable what you have not documented. You cannot build a legal case without a paper trail. You cannot run a primary challenge without a voting record. The record is the foundation on which every other tool rests.

**Practical first step:** identify one official, one agency, or one institution in your community whose decisions on a specific issue are not publicly documented. File three FOIA requests this week. Attend the next public meeting and submit written testimony. Publish what you find. The record begins with one documented fact that would otherwise be invisible.

**2. The Local Accountability Infrastructure**

The Performance Republic — real-time accountability dashboards for elected officials — does not require legislation to begin. It can be built by citizen organizations using publicly available data. GovTrack.us tracks congressional votes. VoteSmart.org maintains public voting records. OpenSecrets.org documents campaign contributions. FollowTheMoney.org tracks state-level money. The data exists. The citizen organization builds the synthesis that makes it legible to ordinary voters who do not have time to research each official individually.

**Practical first step:** for each of your three local elected officials, build a single-page documented profile this month: their five most consequential local votes, their top five donors, any employment or board positions with organizations affected by their votes. Publish it publicly. Update it every six months. This is the Performance Dashboard at the local level, built by citizens, costing nothing.

**3. The Cross-Partisan Coalition**

The most durable reform coalitions in American history succeeded because they crossed traditional partisan divisions. Systems-based structural arguments — antitrust, media concentration, regulatory capture, debt weaponization, covert foreign policy accountability — have genuine constituencies on both the left and the right because these systems harm ordinary people regardless of party affiliation. The airline ticket price increases produced by common ownership cost a conservative in Oklahoma the same as a progressive in California. The revolving door between the FDA and pharmaceutical companies produces the same opioid crisis in rural red counties as in urban blue ones.

The early-stage organizing task is explicitly building the cross-partisan coalition rather than the partisan one. The partisan approach feels faster but it is not — it guarantees that half the country will defend the system you are trying to reform because their team is currently benefiting from it. The structural approach is slower to build and more durable when built.

**Practical first step:** identify one issue with documented cross-partisan support. Antitrust reform is the clearest current example, with Warren and Sanders on the left and Hawley and Rubio on tech antitrust on the right. Lead every coalition conversation with that documented cross-partisan support, not with partisan framing.

**4. The Parallel Institutions**

La Boétie asked the most dangerous question in the history of political philosophy: why do free people willingly accept their own oppression? His answer was habit, comfort, and the subtle power of custom. The strategy that follows from his answer is not confrontation of the existing system but withdrawal of participation from it, combined with the building of alternatives.

If your community has no independent local news coverage of city council and school board decisions, start one. Substack costs nothing. If your banking relationship is with one of the four mega-banks that collectively hold more than half the assets of the top 25 American financial institutions, move it to a credit union or a community development financial institution. If your information environment is entirely organized by platforms whose algorithmic decisions are made by five firms — Alphabet, Meta, ByteDance, X, Amazon — diversify it deliberately. Each alternative institution reduces the participation in extractive systems that sustains those systems. La Boétie's insight is that power depends on active participation, and every withdrawal of participation is a structural reform.

**Practical first step:** identify one system you participate in daily that you have the practical ability to exit or reduce your participation in. Move one account. Subscribe to one independent local publication. Attend one public meeting that you have never attended before. The alternatives do not need to be perfect to begin the withdrawal.

**5. The Long Game Commitment**

The most important psychological and strategic commitment of the early stage is accepting the long game explicitly. The Populist movement that produced the Sherman Antitrust Act organized for a decade before the law passed. The suffragettes organized for 72 years — from the Seneca Falls Convention in 1848 to the 19th Amendment in 1920. The civil rights movement sustained organized pressure for over a century from Reconstruction to the Civil Rights Act. These were not slow movements. They were movements that understood something that most people resist understanding: that the timeline of meaningful structural change does not fit inside a single news cycle, a single administration, or a single life, and that understanding this is not pessimism but the prerequisite for the kind of sustained action that actually works.

The Relentless Current is not a campaign. It is a practice. The river does not ask permission. It does not need to move the mountain today. It needs to flow with sufficient persistence that the landscape itself is reshaped. The early-stage commitment is not to win immediately. It is to build the infrastructure of winning — the documentation, the coalitions, the alternative institutions, the sustained civic practice — so that when the political moment arrives, the work is ready.

> *Being spineless is not an option. That is not a slogan. It is a description of the stakes. The debt that keeps you working, the job that punishes political expression, the family obligations that demand your time — these are real, and they are also exactly the conditions that managed consent is designed to produce and maintain. The system does not keep you busy and indebted because of coincidence. It does so because a busy, indebted, exhausted population is a population that does not have time to perform its citizenship. Knowing this does not make the obligations less real. It makes the choice to find the time anyway a different kind of choice — not a sacrifice of what you have but an investment in whether what you have will still be worth something in a generation.*

**THE DEMAND**

**CHOOSE BETTER — NOT SOMEDAY, BUT NOW**

The founders of this country were not waiting for perfect conditions. The abolitionists were not waiting for the political moment. Rosa Parks was not waiting for the polls to show majority support. The Solidarity workers in Poland were not waiting for the Soviet Union to weaken on its own. Every person who has ever moved a system larger than themselves understood one thing that the comfortable have always resisted: the moment to act is never ideal, the odds are never favorable, and the question is not whether the path is difficult but whether the destination is worth the difficulty.

You already know the answer. You knew it every time you watched the rebel alliance fight the Death Star. You knew it every time you watched William Wallace ride into battle against armored cavalry with a sword and a refusal to kneel. You knew it every time you read about the Boston Tea Party or Gettysburg or the Edmund Pettus Bridge. You have always known who the good guys are and what they are supposed to do.

This document is the map from the theater to the street. From the movie to the meeting. From the story you tell yourself about what you believe to the action that proves you believe it.

The tools in this document are legal. They are constitutional. They are what the Founders built when they designed a system that requires citizens rather than subjects. They are not fast. They are not guaranteed. They are the only things that have ever worked.

> *The river does not ask permission. It does not wait for perfect conditions. It does not need to see the ocean to know which direction to flow. It simply moves — steady, lawful, and relentless — until the landscape itself is reshaped. That is The Relentless Current. That is the American tradition. That is what citizenship in a democratic republic actually requires. Get up. Walk into your mayor's office. Fill the city council chambers. File the FOIA request. Show up at the town hall. Run for the school board. Build the record. Build the coalition. Build the alternatives. Make the cost of inaction higher than the cost of change. Do it again tomorrow. The river is already moving. Add your strength to it.*

**Choose Better — not someday, but now.**

**Rise.**

*Kai Jashon Price · Structural Humanism · structuralhumanism.com*

**COMPLETE REFERENCE TABLE — ALL 15 TOOLS**

<table>
<colgroup>
<col style="width: 4%" />
<col style="width: 25%" />
<col style="width: 12%" />
<col style="width: 11%" />
<col style="width: 11%" />
<col style="width: 33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>#</strong></td>
<td><strong>Tool</strong></td>
<td><strong>Tier</strong></td>
<td><strong>Cost</strong></td>
<td><strong>Timeline</strong></td>
<td><strong>Constitutional Authority</strong></td>
</tr>
<tr class="even">
<td>1</td>
<td>FOIA Requests</td>
<td>1 — Individual, Now</td>
<td>Free</td>
<td>20 days by law</td>
<td>5 U.S.C. § 552</td>
</tr>
<tr class="odd">
<td>2</td>
<td>APA Public Comment</td>
<td>1 — Individual, Now</td>
<td>Free</td>
<td>30-60 day windows</td>
<td>5 U.S.C. § 553</td>
</tr>
<tr class="even">
<td>3</td>
<td>Constituent Contact</td>
<td>1 — Individual, Now</td>
<td>Free</td>
<td>Immediate</td>
<td>First Amendment</td>
</tr>
<tr class="odd">
<td>4</td>
<td>Public Meeting Testimony</td>
<td>1 — Individual, Now</td>
<td>Free</td>
<td>Immediate</td>
<td>First Amendment + state open meetings law</td>
</tr>
<tr class="even">
<td>5</td>
<td>Recall Campaigns</td>
<td>2 — Organize</td>
<td>Filing fees only</td>
<td>3-6 months</td>
<td>State constitutions (19 states)</td>
</tr>
<tr class="odd">
<td>6</td>
<td>Primary Challenges</td>
<td>2 — Organize</td>
<td>Low</td>
<td>12-18 months</td>
<td>FEC regulations; state election law</td>
</tr>
<tr class="even">
<td>7</td>
<td>Coordinated FOIA Campaign</td>
<td>2 — Organize</td>
<td>Free</td>
<td>6-18 months</td>
<td>5 U.S.C. § 552</td>
</tr>
<tr class="odd">
<td>8</td>
<td>Ballot Initiatives</td>
<td>2 — Organize</td>
<td>Variable</td>
<td>12-24 months</td>
<td>State constitutions (26 states)</td>
</tr>
<tr class="even">
<td>9</td>
<td>False Claims Act Suit</td>
<td>3 — Legal</td>
<td>Contingency</td>
<td>2-7 years</td>
<td>31 U.S.C. §§ 3729-3733</td>
</tr>
<tr class="odd">
<td>10</td>
<td>State AG Antitrust Action</td>
<td>3 — Legal</td>
<td>Free to file</td>
<td>1-5 years</td>
<td>Clayton Act parens patriae</td>
</tr>
<tr class="even">
<td>11</td>
<td>Administrative Law Challenge</td>
<td>3 — Legal</td>
<td>Pro bono/nonprofit</td>
<td>2-4 years</td>
<td>5 U.S.C. § 702</td>
</tr>
<tr class="odd">
<td>12</td>
<td>Shareholder Activism</td>
<td>3 — Legal</td>
<td>$2,000 minimum holding</td>
<td>Annual cycle</td>
<td>SEC Rule 14a-8</td>
</tr>
<tr class="even">
<td>13</td>
<td>State Legislation Campaign</td>
<td>4 — Structural</td>
<td>Coalition costs</td>
<td>1-3 years</td>
<td>State legislative authority</td>
</tr>
<tr class="odd">
<td>14</td>
<td>Antitrust Legislative Reform</td>
<td>4 — Structural</td>
<td>Advocacy costs</td>
<td>2-8 years</td>
<td>Article I congressional authority</td>
</tr>
<tr class="even">
<td>15</td>
<td>Constitutional Amendment</td>
<td>4 — Structural</td>
<td>Major investment</td>
<td>10-20 years</td>
<td>Article V</td>
</tr>
</tbody>
</table>
