# “Food Pyramid”

*The Complete Evidence-Based Guide to Optimal Nutrition*

**Kai Jashon Price** · Public Health — Field Guide · 2025
— structuralhumanism.com —

---

> What the research actually says — stripped of industry lobbying, government food politics,
>
> **and the marketing myths that have made Americans sick for 70 years.**

*MYTH BUSTED (red) · THE SCIENCE (green) · WATCH OUT (gold) · WHAT TO DO (blue)*

**SECTION ONE**

**THE BIGGEST LIES AMERICANS ARE TOLD ABOUT FOOD**

*Debunking 70 Years of Industry-Influenced Nutritional Guidance*

**1.1 THE ORIGINAL FOOD PYRAMID WAS DESIGNED BY LOBBYISTS, NOT SCIENTISTS**

The USDA Food Guide Pyramid — introduced in 1992 and used to shape school lunch programs, hospital nutrition guidelines, and public health campaigns for decades — was not primarily designed by nutrition scientists. The USDA's own internal documents, released through Freedom of Information requests and analyzed by food policy researchers including Marion Nestle (Food Politics, 2002) and Michael Pollan, show that the pyramid's heavy emphasis on grains (6–11 servings per day at its base) was influenced substantially by the grain and dairy industries, whose trade associations participated directly in the design process.

The pyramid told Americans to eat more refined grains, more low-fat dairy, and to fear dietary fat — particularly saturated fat. The scientific basis for these recommendations was, at the time of their adoption, far weaker than the government presented to the public. The low-fat dietary guidelines, which gained official status in the 1980 Dietary Guidelines for Americans, were primarily based on Ancel Keys' Seven Countries Study (1970) — a dataset that Keys selected after discarding data from 15 countries that contradicted his fat-heart disease hypothesis. This selective analysis was not hidden at the time; critics including statistician Jacob Yerushalmy pointed it out in 1957. The criticism was ignored for 40 years.

> **MYTH BUSTED: 3 Meals a Day Is Biologically Optimal**
>
> *The three-meal-a-day pattern — breakfast, lunch, dinner, typically every 4–6 hours — is a cultural and industrial construct, not a biological requirement. Pre-agricultural humans ate when food was available, which produced natural fasting periods. The three-meal structure became dominant in industrialized societies because it aligned with factory work schedules. There is no peer-reviewed evidence that three evenly spaced meals per day is optimal for human metabolism. Multiple randomized controlled trials (including Sutton et al., 2018, Cell Metabolism) show that restricting eating to a shorter daily window improves insulin sensitivity, blood pressure, and body composition independent of caloric intake.*
>
> **MYTH BUSTED: Breakfast Is the Most Important Meal of the Day**
>
> *This phrase was popularized by the breakfast cereal industry — specifically by Edward Bernays, hired by the Beech-Nut Packing Company in the 1920s to sell bacon and eggs, and later refined by Kellogg's advertising campaigns. The underlying biology does not support the claim. A 2019 BMJ analysis of breakfast-skipping trials found that breakfast consumption does not improve metabolism or reduce overall calorie intake for most adults. People who skip breakfast and practice morning fasting (intermittent fasting) show no metabolic disadvantage and in controlled trials often show improved insulin sensitivity.*
>
> **MYTH BUSTED: Dietary Fat Causes Heart Disease**
>
> *The diet-heart hypothesis — that saturated fat raises LDL cholesterol, which causes cardiovascular disease — was presented as settled science from the 1980s onward. A 2020 systematic review in the Journal of the American College of Cardiology (Astrup et al.) concluded that the evidence does not support the conclusion that dietary saturated fat intake causes cardiovascular disease. The 2014 meta-analysis by Chowdhury et al. in Annals of Internal Medicine, analyzing 72 studies covering 640,000 participants, found no significant association between saturated fat intake and cardiovascular disease. The key variable is what replaces saturated fat: replacing it with refined carbohydrates (as food manufacturers did when creating low-fat products) increases cardiovascular risk. Replacing it with whole foods including vegetables, nuts, and fish has different outcomes entirely.*
>
> **MYTH BUSTED: Low-Fat Products Are Healthier**
>
> *When fat is removed from food products, it must be replaced with something to maintain palatability. Food manufacturers almost universally replaced fat with refined carbohydrates, sugar, corn syrup, and artificial additives. Low-fat yogurt typically contains 2–3 times as much sugar as full-fat yogurt. Low-fat salad dressings contain more sugar, high-fructose corn syrup, and gums than their full-fat counterparts. The low-fat era (1980–2010) coincided precisely with the obesity epidemic: American obesity rates doubled from approximately 15% to 30% during the same period that dietary fat intake declined as a percentage of calories.*
>
> **MYTH BUSTED: All Calories Are Equal — Calories In, Calories Out**
>
> *The thermodynamic principle that 1 calorie of sugar and 1 calorie of protein produce equal energy in a closed system is true in a bomb calorimeter. The human body is not a bomb calorimeter. Protein has a thermic effect of food of 20–30% (meaning 20–30% of the energy from protein is used just in processing it), compared to 5–10% for carbohydrates and 0–3% for fat. Protein and fiber produce satiety hormones (GLP-1, PYY, cholecystokinin) that sugar does not. The hormone insulin — spiked by refined carbohydrates — directly drives fat storage through its inhibitory effect on hormone-sensitive lipase and its activation of lipoprotein lipase. The same caloric intake from different macronutrient compositions produces different fat accumulation outcomes.*
>
> **MYTH BUSTED: Whole Grain Bread Is Healthy**
>
> *The FDA allows products labeled 'whole grain' to contain as little as 51% whole grain flour — the remainder can be refined white flour, high-fructose corn syrup, dough conditioners, and preservatives. 'Multigrain' means only that multiple grains were used, with no requirement that any of them be whole. The glycemic index of commercially produced whole wheat bread (approximately 71) is barely lower than white bread (75) because the industrial milling process pulverizes grain particle size regardless of bran inclusion, causing rapid glucose absorption. Look for: the word 'whole' as the first ingredient, at least 3g fiber per slice, and an ingredient list under 5 items.*
>
> **MYTH BUSTED: Plant-Based Meat Alternatives Are Healthier**
>
> *Impossible Burgers, Beyond Burgers, and most commercial plant-based meat alternatives are ultraprocessed foods with lengthy ingredient lists including methylcellulose, leghemoglobin, modified starch, natural flavors, cocoa butter, and industrial seed oils. A standard Impossible Burger contains 390mg sodium and 14g fat per patty. An NIH-funded randomized controlled trial by Hall et al. (2019) comparing ultraprocessed to minimally processed diets found that participants on the ultraprocessed diet ate 508 more calories per day on average, and gained weight, while those on the minimally processed diet lost weight — with the same ad libitum eating instructions. The key variable was the degree of processing, not the macronutrient content.*

**SECTION TWO**

**THE CHEMISTRY OF WHAT'S IN YOUR FOOD**

*What Labels Hide, What Manufacturers Do, and What Actually Harms You*

**2.1 THE CHEMICALS ON LABELS MOST PEOPLE DON'T RECOGNIZE**

The average American grocery item contains 5–7 ingredients the purchaser cannot define. Food manufacturers exploit FDA labeling loopholes to obscure the true composition of products. The following are the most consequential hidden or obscured ingredients, organized by harm mechanism.

**Industrially Refined Seed Oils — The Most Overlooked Dietary Risk**

Industrial seed oils — soybean oil, corn oil, cottonseed oil, sunflower oil, safflower oil, and canola oil — are the most consumed fats in the American diet and among the most poorly studied in terms of their long-term health effects. They appear on labels under their own names and also hidden in ingredient lists of crackers, dressings, frozen meals, restaurant food, and almost every packaged snack food. The USDA estimates that soybean oil alone accounts for approximately 7% of all calories consumed in the American diet.

The specific concern with these oils is their high omega-6 linoleic acid content and their susceptibility to oxidation. The ancestral human diet had an omega-6 to omega-3 ratio of approximately 1:1 to 4:1. The current American diet has an omega-6 to omega-3 ratio of approximately 15:1 to 25:1, driven primarily by seed oil consumption. This ratio matters because omega-6 and omega-3 fatty acids compete for the same enzymatic pathways. Linoleic acid oxidation products (including 4-hydroxynonenal and malondialdehyde) are toxic to mitochondria and have been implicated in lipid peroxidation chain reactions in arterial walls. High-heat cooking with these oils — common in restaurant and processed food production — dramatically increases the oxidation product concentration.

> **WATCH OUT: Seed Oils Hidden on Labels**
>
> *Partially hydrogenated soybean oil = contains trans fats (FDA phased these out but old stock persists). Vegetable oil = almost always a blend of seed oils, not a stable saturated fat. Expeller-pressed canola = still high in omega-6. 'Made with olive oil' on a product almost always means predominantly seed oil with trace olive oil. Any product listing 'natural flavors' alongside seed oils may be using seed oil as a flavor carrier.*

**HFCS and Its Aliases — High-Fructose Corn Syrup by Other Names**

High-fructose corn syrup (HFCS) was introduced into the American food supply in 1975 and by 2000 was present in approximately 75% of sweetened packaged foods. When consumer awareness of HFCS grew in the 2000s, manufacturers began labeling it under alternative names including: corn sugar, corn syrup solids, maize syrup, fructose (on its own without the 'corn syrup' qualifier — particularly HFCS-90, which is 90% fructose and labeled simply as 'fructose'), crystalline fructose, and glucose-fructose syrup (in European and Canadian products).

The specific metabolic concern with fructose is hepatic. Unlike glucose, which can be metabolized by every cell in the body, fructose is metabolized primarily in the liver. At the quantities consumed in the modern diet, fructose overwhelms hepatic fructokinase capacity and is shunted into de novo lipogenesis — the liver's fat-manufacturing pathway. This process produces small dense LDL particles (the cardiovascular risk factor, not total LDL), elevates triglycerides, deposits fat in the liver (non-alcoholic fatty liver disease, now the most common liver disease in the United States), and drives uric acid production. Robert Lustig's 2012 analysis (Nature, 'The Toxic Truth About Sugar') presented this mechanism and the epidemiological data linking fructose consumption to metabolic syndrome.

> **WATCH OUT: HFCS Aliases to Know on Labels**
>
> *Fructose (alone, not 'fruit'); crystalline fructose; maize syrup; corn sugar; glucose-fructose; glucose-fructose syrup; iso glucose; chicory syrup (when industrially processed). Agave nectar — heavily marketed as a 'healthy' sweetener — is typically 70–90% fructose, significantly higher than HFCS (55%). Honey is approximately 40% fructose but contains beneficial enzymes and phenolic compounds at whole-food quantities.*

**Artificial Sweeteners — The Metabolic Disruption Problem**

Artificial sweeteners — aspartame (NutraSweet, Equal), sucralose (Splenda), acesulfame potassium (Ace-K), saccharin, and the newer monk fruit and stevia extracts — were promoted for 40 years as weight-management tools with no metabolic consequences. The original studies supporting their safety were almost exclusively short-term and industry-funded. A 2022 meta-analysis published in the British Medical Journal (Rios-Leyvraz and Montez), commissioned by the WHO, analyzed 283 studies and found that while non-nutritive sweeteners produced modest short-term weight loss, long-term consumption was associated with increased BMI, type 2 diabetes, cardiovascular disease, and all-cause mortality.

The proposed mechanisms include: cephalic phase insulin response (the brain releases insulin in anticipation of calories when sweetness is detected on the tongue, causing blood sugar drop and increased appetite even when no calories are consumed); gut microbiome disruption (Suez et al., 2014, Nature, showed sucralose and saccharin produced glucose intolerance in mice and in some human subjects by altering the gut microbiome composition); and reward pathway disruption (sweet taste without calories may increase cravings for calorie-dense sweet foods by maintaining the reward association without the caloric satisfaction).

**Emulsifiers — The Gut Lining Problem**

Emulsifiers — added to processed foods to maintain texture, extend shelf life, and prevent oil-water separation — are among the most widely used food additives and among the most poorly studied in terms of gut health effects. Common emulsifiers include: carrageenan, polysorbate 80, carboxymethylcellulose (CMC), soy lecithin, sunflower lecithin, mono and diglycerides, and various modified starch derivatives.

A 2015 study by Chassaing et al. published in Nature showed that dietary emulsifiers (specifically polysorbate 80 and CMC, at concentrations lower than those approved for food use) disrupted the protective mucus layer of the intestinal tract in mice, promoted bacterial translocation across the gut barrier, and induced low-grade inflammation and metabolic syndrome features. A 2021 human population study by Sellem et al. (The Lancet) found associations between emulsifier consumption and inflammatory bowel disease. Carrageenan — derived from seaweed and marketed as a 'natural' additive — has been classified as a possible carcinogen by the International Agency for Research on Cancer when degraded, and has been associated with intestinal inflammation in animal studies.

**Pesticide Residues — The Dirty Dozen and the Science Behind It**

The Environmental Working Group publishes an annual 'Dirty Dozen' list of conventionally grown produce with the highest pesticide residue loads, based on USDA Pesticide Data Program testing. The EWG list has been criticized by some toxicologists for not weighting by the toxicological significance of specific residues. The most rigorous position is: pesticide residue risk is real, dose-dependent, and varies enormously by crop, growing method, and compound.

The compounds with the strongest evidence for harm at real-world dietary exposure levels include: organophosphates (chlorpyrifos — banned in the US for food use in 2021 after decades of industry lobbying to prevent the ban; the EPA's own analysis found it causes neurodevelopmental harm in children at realistic dietary exposures); neonicotinoids (imidacloprid, clothianidin, thiamethoxam — neurotoxic to insects at very low concentrations, with emerging evidence of effects on human gut microbiome and possibly neurological development); and glyphosate (Roundup's active ingredient, classified as 'probably carcinogenic to humans' by the WHO's International Agency for Research on Cancer in 2015, though the EPA maintains it is not carcinogenic — the science is genuinely contested with significant methodological disputes between studies).

> **WATCH OUT: The Dirty Dozen 2024 — Highest Pesticide Load (Buy Organic for These)**
>
> *Strawberries, spinach, kale/collard/mustard greens, peaches, pears, nectarines, apples, grapes, bell/hot peppers, cherries, blueberries, green beans. The Clean Fifteen (lowest residues, conventional is fine): avocados, sweet corn, pineapple, onions, papaya, frozen sweet peas, asparagus, honeydew melon, kiwi, cabbage, mushrooms, mangoes, sweet potatoes, watermelon, carrots.*

**Nitrates, Nitrites, and Processed Meat**

Nitrates (NO3) and nitrites (NO2) are added to processed meats — bacon, hot dogs, deli meats, salami, pepperoni — as preservatives and to produce the characteristic pink color. In the gut, nitrites combine with amino acids to form nitrosamines, which are classified as Group 2A probable carcinogens by IARC. The IARC's 2015 review, analyzing over 800 studies, classified processed meat as a Group 1 carcinogen (definitely causes cancer) and red meat as a Group 2A probable carcinogen, specifically for colorectal cancer.

The absolute risk increase is modest but real: approximately 18% increased relative risk of colorectal cancer per 50g daily serving of processed meat — translating to approximately 6 additional colorectal cancers per 1,000 people who eat processed meat daily over a lifetime. Products labeled 'no nitrates added' or 'uncured' typically substitute celery powder or celery juice, which are naturally high in nitrates. The resulting nitrate/nitrite levels are often comparable to or higher than conventional cured meats. The 'no nitrates' label is largely meaningless from a biochemical standpoint.

**Food Dyes — The Behavioral and Allergic Concern**

Synthetic petroleum-derived food dyes — Red 40 (Allura Red), Yellow 5 (Tartrazine), Yellow 6, Blue 1, Blue 2, Green 3, Red 3 — are found in candies, cereals, sports drinks, fruit snacks, maraschino cherries, and many medications and supplements. Their safety assessment for children specifically has been a contentious issue. A 2007 randomized, double-blind, placebo-controlled trial by McCann et al. (The Lancet) funded by the UK Food Standards Agency found that a mixture of artificial colors and sodium benzoate increased hyperactivity in both 3-year-old and 8/9-year-old children. This led the UK and EU to require warning labels on products containing these dyes. The US FDA reviewed the same evidence and concluded it was insufficient to require labeling.

Red 3 (erythrosine) was shown to cause thyroid tumors in male rats and was banned by the FDA from cosmetics in 1990 but inexplicably remained approved for food use. In 2024, the FDA finally announced plans to revoke its food authorization — 34 years after banning it from cosmetics. This gap illustrates the regulatory inconsistency that allows consumers to be exposed to additives that regulatory agencies themselves have identified as potentially harmful.

**BPA and Phthalates — The Endocrine Disruption Problem**

Bisphenol A (BPA) is a plasticizer used in polycarbonate plastic and the lining of metal food cans. It is a documented endocrine disruptor — a compound that interferes with hormonal signaling at concentrations far below those originally used to assess 'safe' exposure. The 'BPA-free' labeling trend that followed consumer pressure has not solved the problem: the bisphenol analogues used as replacements (BPS, BPF, BPAF) show similar or in some cases greater endocrine-disrupting activity than BPA in cell-based and animal studies.

Phthalates — plasticizers found in flexible PVC food packaging, food processing equipment tubing, and some food coatings — are among the best-documented endocrine disruptors in the human food supply. A 2021 study published in Environmental Health Perspectives estimated that phthalate exposure from food consumption was responsible for approximately 100,000 preterm births and 5,600 premature deaths per year in the United States.

**SECTION THREE**

**THE TRUTH ABOUT EVERY FOOD GROUP**

*What to Buy, What to Avoid, and What the Label Doesn't Tell You*

**3.1 MEAT AND ANIMAL PROTEIN**

**Grass-Fed vs. Grain-Fed Beef: What the Science Actually Shows**

The comparison between grass-fed and grain-fed beef is one of the most substantively supported distinctions in food science. The differences are not marketing — they are documented compositional differences in the animal's fatty acid profile, micronutrient content, and secondary metabolite content that have measurable implications for human health.

Grass-fed beef contains: approximately 2–5 times more omega-3 fatty acids (primarily alpha-linolenic acid, ALA) compared to grain-fed; approximately 2–4 times more conjugated linoleic acid (CLA), which has anti-inflammatory properties and has been associated with reduced cancer risk in animal studies; higher concentrations of vitamin E, vitamin K2 (specifically menaquinone MK-4), and beta-carotene (which gives grass-fed fat its yellow color vs. the white fat of grain-fed beef); and a better omega-6 to omega-3 ratio (approximately 2:1 in grass-fed vs. approximately 7:1 in grain-fed). The most comprehensive analysis, by Daley et al. (Nutrition Journal, 2010), reviewed 11 studies and confirmed these compositional differences consistently.

'Grass-finished' is the critical distinction — not 'grass-fed.' USDA rules allowed cattle to be labeled 'grass-fed' even if finished on grain for the final 90–120 days before slaughter. The finishing period determines most of the fatty acid composition. Look for 'grass-finished' or '100% grass-fed' certifications from the American Grassfed Association (AGA) or PCO (Certified Grassfed by AGW).

> **THE SCIENCE: Grain-Finishing Changes the Fatty Acid Profile in 30–60 Days**
>
> The shift from grass to grain changes a steer's rumen microbiome within days. The fatty acid composition of the muscle fat follows the feed composition with a lag of approximately 30–60 days. A steer that spent its entire life on pasture but was grain-finished for 90 days will have a fatty acid profile much closer to fully grain-fed beef than to fully grass-finished beef. This is why 'grass-fed' without 'grass-finished' is a legally exploitable but misleading label.

**Poultry: The Pastured Difference**

'Free range' on chicken means only that the birds had some access to the outdoors — a small door in an industrial shed that 10,000 birds may never use qualifies. 'Pasture-raised' (certified by Certified Humane or the American Humane Association) requires at least 108 square feet of outdoor space per bird and access for at least 6 hours per day. Pasture-raised eggs contain approximately 3 times more omega-3 fatty acids, 7 times more beta-carotene, and significantly more vitamins D and E than conventional eggs.

The yellow-orange color of a pasture-raised yolk compared to the pale yellow of a conventional egg is entirely determined by the xanthophylls and carotenoids (lutein, zeaxanthin, beta-carotene) in the bird's diet. Some producers add marigold extract or synthetic carotenoids to grain feed to produce a darker yolk without providing actual pasture access — look for certified pasture-raised labels rather than color alone.

**Processed Meat: The Evidence Is Clear**

Hot dogs, commercial deli meats, sausage, salami, pepperoni, and bacon are the most heavily processed animal products in the American diet. The IARC Group 1 carcinogen classification for processed meat is among the strongest epidemiological evidence in nutrition science — based on 800+ studies with consistent dose-response relationships across multiple populations and study designs. This does not mean eating one hot dog will cause cancer; it means regular consumption increases lifetime colorectal cancer risk in a measurable, dose-dependent way. The same mechanism (nitrosamine formation from nitrite preservatives combined with heme iron) does not apply to whole, unprocessed red meat to the same degree.

**3.2 DAIRY — THE MOST COMPLEX FOOD GROUP**

**Pasteurized vs. Raw Milk: The Actual Tradeoffs**

Pasteurization — heating milk to 161°F for 15 seconds (HTST) or 280°F for 2 seconds (UHT) — kills pathogenic bacteria including Listeria monocytogenes, Salmonella, E. coli O157:H7, and Campylobacter. The CDC reports approximately 202 outbreaks linked to raw dairy between 1993 and 2012, causing approximately 2,645 illnesses, 269 hospitalizations, and 3 deaths. In the same period, pasteurized dairy caused approximately 55 outbreaks. The absolute safety difference is significant and not trivially dismissed.

Raw milk proponents cite: the destruction of milk's native enzymes (lactoperoxidase, lysozyme, immunoglobulins) by pasteurization; the degradation of certain heat-sensitive vitamins (B1, B12, C — though milk is not a primary source of these); and the alteration of milk proteins that may affect digestibility and allergenicity. The scientific evidence for raw milk's health advantages over properly pasteurized milk from healthy cows is weak. The safety risk is real and disproportionately affects immunocompromised individuals, children, pregnant women, and the elderly. The FDA, CDC, and AAP all recommend against raw milk consumption. This is not contested among mainstream public health authorities.

> **THE SCIENCE: UHT vs. HTST Pasteurization — The Difference Matters**
>
> Ultra-high temperature (UHT) pasteurization (common in shelf-stable European milk boxes) causes significantly more denaturation of milk proteins and destruction of heat-sensitive nutrients than high-temperature short-time (HTST) pasteurization used in most refrigerated US milk. If choosing pasteurized milk, HTST-pasteurized is nutritionally closer to raw milk. Look for refrigerated milk from local dairies — most small-scale local dairies use HTST. The shelf-stable milk in cartons has been through more aggressive heat treatment.

**Whole vs. Low-Fat Dairy: The Evidence Has Reversed**

The recommendation to choose low-fat or skim dairy over whole-fat dairy — part of the original low-fat dietary guidelines — has been substantially undermined by subsequent research. A 2016 study by Mozaffarian et al. in Circulation analyzed biomarkers of dairy fat intake and found that higher dairy fat consumption was associated with lower risk of type 2 diabetes. A 2017 Lancet analysis of 9 cohort studies found no association between full-fat dairy consumption and cardiovascular disease or total mortality.

The specific concern with low-fat dairy is that fat serves as the carrier for fat-soluble vitamins A, D, K, and E in dairy. Skim milk is legally required to have vitamins A and D re-added (added back as supplements after fat removal) because they are removed with the fat. The added forms (retinyl palmitate, cholecalciferol) are synthetic and not bioequivalent to the natural fat-embedded forms in whole milk. Full-fat, pasture-raised dairy also contains the K2 content discussed in the beef section.

**The A1/A2 Protein Question**

Most conventional dairy milk in the US comes from Holstein-Friesian cows that produce A1 beta-casein. A2 milk comes from cows that produce only A2 beta-casein (including Jersey, Guernsey, and Normande breeds, and human breast milk). When A1 beta-casein is digested, it releases a peptide called BCM-7 (beta-casomorphin-7) that does not form from A2 casein digestion. BCM-7 is an opioid peptide that has been implicated in delayed intestinal transit, increased mucus production, and potentially type 1 diabetes and cardiovascular disease in some studies — though the human evidence remains suggestive rather than conclusive. Many people who believe they are lactose intolerant report tolerating A2 milk without the digestive symptoms they experience with conventional milk. A 2019 randomized crossover trial in the European Journal of Clinical Nutrition confirmed reduced gastrointestinal symptoms with A2 milk in self-reported lactose-intolerant subjects.

**3.3 FISH AND SEAFOOD**

**The Mercury Paradox and How to Navigate It**

Fish is simultaneously one of the most nutritionally valuable foods available — the primary dietary source of EPA and DHA omega-3 fatty acids, with documented cardiovascular, cognitive, and anti-inflammatory benefits — and a significant source of mercury, PCBs, and dioxins in the modern food supply. Navigating this tradeoff requires specific knowledge rather than general avoidance.

Mercury (specifically methylmercury) bioaccumulates through the marine food chain — small fish absorb it from plankton, larger fish eat the small fish, and top predators concentrate it at the highest levels. The FDA/EPA joint advisory recommends that pregnant women and young children avoid: swordfish, shark, king mackerel, tilefish (Gulf of Mexico), orange roughy, bigeye tuna, and marlin. These are the highest-mercury species. Canned light tuna (skipjack) contains approximately 0.128 ppm mercury; canned albacore (white) tuna contains approximately 0.350 ppm — nearly 3 times higher. Salmon (wild-caught) contains approximately 0.022 ppm.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 36%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Fish/Seafood</strong></td>
<td><strong>Mercury (ppm avg)</strong></td>
<td><strong>Omega-3 per 3oz</strong></td>
<td><strong>PCB Concern</strong></td>
<td><strong>Recommendation</strong></td>
</tr>
<tr class="even">
<td>Wild Alaskan Salmon</td>
<td>0.022</td>
<td>~2000mg</td>
<td>Low</td>
<td>Best choice — high omega-3, low contaminants</td>
</tr>
<tr class="odd">
<td>Sardines (canned)</td>
<td>0.013</td>
<td>~1350mg</td>
<td>Very low</td>
<td>Excellent — inexpensive, sustainable, high omega-3</td>
</tr>
<tr class="even">
<td>Mackerel (Atlantic)</td>
<td>0.050</td>
<td>~2300mg</td>
<td>Low</td>
<td>Excellent — avoid king mackerel (high mercury)</td>
</tr>
<tr class="odd">
<td>Anchovies</td>
<td>0.016</td>
<td>~1650mg</td>
<td>Very low</td>
<td>Excellent — very low on food chain</td>
</tr>
<tr class="even">
<td>Rainbow Trout (farmed)</td>
<td>0.071</td>
<td>~840mg</td>
<td>Low</td>
<td>Good choice</td>
</tr>
<tr class="odd">
<td>Skipjack Tuna (canned light)</td>
<td>0.128</td>
<td>~350mg</td>
<td>Moderate</td>
<td>2–3 servings/week safe for adults</td>
</tr>
<tr class="even">
<td>Albacore Tuna (canned)</td>
<td>0.350</td>
<td>~700mg</td>
<td>Moderate</td>
<td>Limit to 1 serving/week; avoid for pregnant women</td>
</tr>
<tr class="odd">
<td>Farmed Atlantic Salmon</td>
<td>0.050</td>
<td>~1800mg</td>
<td>Moderate-High</td>
<td>Check country of origin — Norwegian farmed is cleaner than some</td>
</tr>
<tr class="even">
<td>Shrimp (farmed)</td>
<td>0.009</td>
<td>~130mg</td>
<td>Low–High</td>
<td>Origin matters: avoid imported farmed from Thailand, Vietnam; US farmed is safer</td>
</tr>
<tr class="odd">
<td>Swordfish</td>
<td>0.995</td>
<td>~900mg</td>
<td>High</td>
<td>Avoid — highest mercury of common species</td>
</tr>
<tr class="even">
<td>Tilapia (farmed)</td>
<td>0.013</td>
<td>~115mg</td>
<td>Low</td>
<td>Low omega-3; low mercury; poor omega-6 to omega-3 ratio if corn-fed</td>
</tr>
<tr class="odd">
<td>Oysters</td>
<td>0.013</td>
<td>~440mg</td>
<td>Variable</td>
<td>Excellent filter feeders — buy from clean certified waters</td>
</tr>
</tbody>
</table>

**Wild-Caught vs. Farmed: Not a Simple Answer**

'Wild-caught' is not universally superior to farmed, and 'farmed' is not universally inferior. The quality of farmed fish depends almost entirely on what the fish are fed and the environmental conditions of farming. Norwegian farmed Atlantic salmon — raised in cold-water fjords with relatively strict environmental standards and high-oil diets — has a fatty acid profile comparable to many wild Pacific salmon. Thai farmed shrimp from poorly regulated facilities may contain antibiotic residues, chemical treatment compounds, and significantly worse environmental profiles.

**3.4 PRODUCE: FRUITS AND VEGETABLES**

**The Organic Decision — When It Matters and When It Doesn't**

Buying exclusively organic for all produce is neither financially necessary nor always justified by the evidence. The pesticide residue differential between organic and conventional varies enormously by crop. For the Clean Fifteen crops listed in Section 2, conventional is essentially equivalent from a pesticide standpoint. For the Dirty Dozen — particularly strawberries, spinach, and peppers — organic reduces pesticide exposure substantially.

The nutritional superiority of organic produce over conventional is modest and inconsistent across studies. A 2012 Stanford meta-analysis found weak evidence for nutritional differences. A 2014 British Journal of Nutrition meta-analysis (Baranski et al.) analyzing 343 peer-reviewed studies found organic crops contained 19–69% more antioxidants than conventional crops, which the researchers attributed to the plant's increased production of phytochemicals under the stress of no synthetic pesticide protection. The evidence is real but the magnitude is debatable.

**Cooking Methods and Nutrient Preservation**

How produce is prepared significantly affects its nutritional content. Water-soluble vitamins (C, B vitamins, folate) leach into cooking water — boiling vegetables reduces B vitamin content by 25–50%. Fat-soluble vitamins (A, D, E, K) and carotenoids (lycopene, beta-carotene, lutein) are actually better absorbed when consumed with fat — raw carrot absorbs approximately 1% of its beta-carotene, while cooked carrot with fat absorbs approximately 25–50%. Lycopene in tomatoes is more bioavailable cooked than raw. Broccoli retains the most glucosinolates when steamed briefly or eaten raw — boiling destroys myrosinase (the enzyme that converts glucosinolates to the cancer-preventive isothiocyanates) unless you eat the broccoli with other myrosinase-containing foods (mustard, arugula).

**3.5 GRAINS — HOW TO ACTUALLY IDENTIFY GENUINE WHOLE GRAIN**

The majority of 'whole grain' products in American supermarkets are marketing constructs. Genuine whole grain bread should: have whole grain flour as the first and predominant ingredient (not 'enriched bleached flour' followed by some whole wheat); contain at least 3g of fiber per slice; have an ingredient list that does not include high-fructose corn syrup, dextrose, or more than 2–3 non-grain items. The best commercially available bread options are sourdough made from whole grain flour (the fermentation process reduces phytic acid, which inhibits mineral absorption), sprouted grain bread (Ezekiel brand and similar products — the sprouting process increases nutrient bioavailability and reduces glycemic impact), or bread from a local bakery with visible, verifiable ingredient sourcing.

The glycemic impact of grain products is determined not just by grain type but by particle size. Whole grain flour that has been industrially milled to fine particle size produces blood glucose responses similar to white flour because the fine particle size allows rapid enzymatic access. Stone-ground whole wheat flour, with its larger particle size and intact fiber structure, produces a significantly lower glycemic response. The glycemic index of steel-cut oats (55) is substantially lower than quick oats (66) or instant oatmeal (83) — the same grain processed to different particle sizes.

**3.6 FATS AND OILS — THE HIERARCHY**

Not all fats are created equal, and the evidence for different cooking fats is more robust than for almost any other food category.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 16%" />
<col style="width: 11%" />
<col style="width: 14%" />
<col style="width: 36%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Fat/Oil</strong></td>
<td><strong>Primary Fat Type</strong></td>
<td><strong>Smoke Point</strong></td>
<td><strong>Oxidation Stability</strong></td>
<td><strong>Recommendation &amp; Use</strong></td>
</tr>
<tr class="even">
<td>Extra virgin olive oil</td>
<td>Monounsaturated (MUFA)</td>
<td>375°F</td>
<td>High (polyphenols protect)</td>
<td>Best all-purpose: salads, low-medium heat cooking. The most evidence-backed oil for cardiovascular health (PREDIMED trial, NEJM 2013).</td>
</tr>
<tr class="odd">
<td>Grass-fed butter</td>
<td>Saturated + some MUFA</td>
<td>302°F (250°F for baking)</td>
<td>Very high</td>
<td>Excellent for medium heat cooking. Contains K2, CLA, butyrate (short-chain fatty acid that feeds colonocytes).</td>
</tr>
<tr class="even">
<td>Ghee (clarified butter)</td>
<td>Saturated + MUFA</td>
<td>485°F</td>
<td>Very high</td>
<td>Best for high-heat cooking. Milk solids removed — tolerated by most lactose-sensitive individuals.</td>
</tr>
<tr class="odd">
<td>Coconut oil (unrefined)</td>
<td>Saturated (MCTs)</td>
<td>350°F</td>
<td>Very high</td>
<td>Good for medium heat. Medium-chain triglycerides (MCTs) are metabolized differently from long-chain — preferentially used as fuel, less likely to be stored. Limited LDL evidence.</td>
</tr>
<tr class="even">
<td>Avocado oil (unrefined)</td>
<td>Monounsaturated</td>
<td>480°F</td>
<td>High</td>
<td>Best for high-heat cooking among plant oils. Good substitute for olive oil in high-temp applications.</td>
</tr>
<tr class="odd">
<td>Soybean oil</td>
<td>Polyunsaturated (high omega-6)</td>
<td>450°F (but damages easily)</td>
<td>Very low</td>
<td>Avoid. Dominant US restaurant and processed food oil. High omega-6, oxidizes at cooking temperatures despite high smoke point.</td>
</tr>
<tr class="even">
<td>Corn oil</td>
<td>Polyunsaturated (high omega-6)</td>
<td>450°F</td>
<td>Very low</td>
<td>Avoid. Same concerns as soybean oil.</td>
</tr>
<tr class="odd">
<td>Canola oil</td>
<td>Monounsaturated + some omega-3</td>
<td>400°F</td>
<td>Moderate</td>
<td>Marginal. The omega-3 ALA in canola degrades under heat. Industrial processing (hexane extraction) leaves residues.</td>
</tr>
<tr class="even">
<td>Vegetable shortening / margarine</td>
<td>Trans fats or heavily hydrogenated</td>
<td>Variable</td>
<td>High chemically, toxic metabolically</td>
<td>Avoid entirely. Even 'trans-fat-free' versions contain small amounts under FDA rounding rules.</td>
</tr>
</tbody>
</table>

**SECTION FOUR**

**FASTING — THE EVIDENCE BASE**

*Intermittent Fasting, Extended Fasting, and Their Documented Effects*

**4.1 THE METABOLIC SWITCH: HOW FASTING WORKS BIOLOGICALLY**

Fasting is not starvation — it is a metabolic state that the human body evolved to enter regularly, and that its regulatory systems are specifically designed to manage. The transition from the fed state to the fasted state is characterized by a series of hormonal and metabolic shifts that have been studied in detail since the 1960s. The key variables are insulin, glucagon, and the substrate switch from glucose to fatty acids and ketone bodies as the primary cellular fuel.

In the fed state (0–4 hours after eating), blood insulin is elevated, fat storage is active (insulin activates lipoprotein lipase and inhibits hormone-sensitive lipase), glucose is the primary fuel for most tissues, and gluconeogenesis (liver glucose production) is suppressed. In the post-absorptive state (4–12 hours), glycogen stores are being depleted, insulin falls, glucagon rises, and the liver begins producing glucose from stored glycogen. In the fasted state (12–24 hours), glycogen is largely depleted, fat mobilization from adipose tissue increases, the liver begins producing ketone bodies (beta-hydroxybutyrate and acetoacetate), and the brain begins substituting ketones for glucose — a substitution that can eventually reach 60–70% of brain energy supply.

Mark Mattson's research at the National Institute on Aging — including his 2019 New England Journal of Medicine review article on intermittent fasting — identifies the metabolic switch from glucose to fatty acids and ketones as the mechanism behind many of the documented benefits of fasting: improved insulin sensitivity, reduced inflammation (via reduced mTOR signaling and increased AMPK activation), activation of autophagy (cellular cleanup), and potential neuroprotective effects.

**Intermittent Fasting Protocols — What Works for Whom**

The term 'intermittent fasting' encompasses several distinct protocols with different evidence bases, difficulty profiles, and applicability to people with different schedules and exercise patterns.

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 21%" />
<col style="width: 13%" />
<col style="width: 23%" />
<col style="width: 25%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Protocol</strong></td>
<td><strong>Structure</strong></td>
<td><strong>Evidence Quality</strong></td>
<td><strong>Best For</strong></td>
<td><strong>Cautions</strong></td>
</tr>
<tr class="even">
<td>16:8 (Time-Restricted Eating)</td>
<td>16-hour fast, 8-hour eating window daily (e.g., eat 11am–7pm)</td>
<td>Strong — most studied protocol</td>
<td>People exercising 5–8x/week who train midday or afternoon. Most sustainable long-term.</td>
<td>May reduce morning training performance until fat-adapted. Eat first meal with protein to prevent muscle catabolism.</td>
</tr>
<tr class="odd">
<td>18:6</td>
<td>18-hour fast, 6-hour window</td>
<td>Good</td>
<td>Accelerated fat loss; easier calorie control. Good for evening trainers.</td>
<td>Not ideal for heavy morning lifting without pre-workout nutrition.</td>
</tr>
<tr class="even">
<td>OMAD (One Meal a Day)</td>
<td>23-hour fast, 1-hour eating window</td>
<td>Limited in RCTs</td>
<td>Short-term fat loss. Not optimal for muscle gain or high-frequency training.</td>
<td>Difficult to meet protein targets in one sitting. Risk of muscle loss if protein insufficient.</td>
</tr>
<tr class="odd">
<td>5:2 Protocol</td>
<td>5 normal days, 2 non-consecutive days at 500–600 kcal</td>
<td>Moderate — Mosley et al.</td>
<td>People who prefer to eat normally most of the week. Flexible scheduling.</td>
<td>The two restricted days should prioritize protein to protect muscle mass.</td>
</tr>
<tr class="even">
<td>Alternate Day Fasting</td>
<td>Full fast / very low calorie alternating with normal eating</td>
<td>Moderate</td>
<td>Significant weight loss needed. Krista Varady's research shows comparable results to daily restriction.</td>
<td>Socially difficult. Risk of compensatory overeating on eating days.</td>
</tr>
<tr class="odd">
<td>Extended Fasting (36–72 hours)</td>
<td>Periodic multi-day fasts 1–4x per year</td>
<td>Limited RCTs; mechanistic evidence strong</td>
<td>Autophagy maximization; insulin reset; mental clarity reset. Not for ongoing use.</td>
<td>Requires electrolyte supplementation. Not appropriate for high-frequency exercise periods. Medical supervision for &gt;48 hours if any health conditions.</td>
</tr>
</tbody>
</table>

**Fasting and Exercise — The Interaction Is Critical for Your Goal**

Training fasted versus fed produces different hormonal environments and different adaptations. For people exercising 5–8 times per week, understanding this interaction is not optional — it determines whether fasting is synergistic with your training or counterproductive to it.

**Fasted aerobic training (cardio in the morning before eating):** Consistently shown to increase fat oxidation during the training session and upregulate fat oxidation enzyme expression. A 2010 study in the Journal of Applied Physiology (Van Proeyen et al.) showed that 6 weeks of fasted endurance training produced greater improvement in fat oxidation capacity and glucose tolerance than fed training at identical intensities and volumes. However, performance at high intensities (&gt;80% VO2max) is compromised in the fasted state due to glycogen dependency. Fasted training is best applied to steady-state cardio and Zone 2 work, not high-intensity intervals or heavy lifting.

**Fasted resistance training:** More complex. Testosterone and growth hormone are elevated in the fasted state (growth hormone rises dramatically in prolonged fasting). However, elevated cortisol in the fasted state increases muscle protein breakdown. The net effect on muscle mass depends critically on post-workout protein consumption: if protein is consumed within 30–60 minutes after fasted resistance training, muscle protein synthesis is robustly stimulated and the net muscle protein balance is positive. If the training session remains fasted for hours post-workout, net muscle loss may occur.

**The practical protocol for 5–8x/week training with intermittent fasting:** Separate your training sessions by type of fasting. Morning steady-state cardio: fully fasted (black coffee or tea acceptable). Morning resistance training: consider BCAAs (3–5g leucine specifically) or a small protein-only meal 30–60 minutes before, and a full protein meal immediately after to blunt cortisol and stimulate MPS. Afternoon or evening training: break your fast 1–2 hours before training with a protein-carbohydrate meal, perform the full workout fed, then have another protein-containing meal within 2 hours.

**Who Should Not Fast or Should Fast With Caution**

Intermittent fasting is contraindicated or requires medical supervision for: individuals with a history of eating disorders (fasting can trigger restriction behaviors in those with anorexia or bulimia history); individuals with type 1 diabetes (fasting can cause hypoglycemia without insulin adjustment — fasting with type 1 diabetes requires physician supervision and insulin protocol modification); pregnant or breastfeeding women (caloric restriction affects fetal development and milk production); individuals who are underweight or have low lean body mass relative to body fat; and people on certain medications (particularly blood thinners, diabetes medications, and blood pressure medications whose dosing is calibrated to fed-state metabolism).

**SECTION FIVE**

**NUTRITION FOR 5–8 WORKOUTS PER WEEK**

*Timing, Macros, Recovery, and What Actually Moves Performance*

**5.1 PROTEIN — THE MOST IMPORTANT MACRONUTRIENT FOR ACTIVE PEOPLE**

Protein is the macronutrient with the strongest evidence base for body composition, recovery, satiety, and metabolic health. It is also the macronutrient most chronically under-consumed by active Americans who follow standard dietary guidelines, which recommend 0.8g of protein per kilogram of body weight per day — an amount calibrated for sedentary individuals, not people training 5–8 times per week.

The evidence-based protein requirement for individuals performing resistance training 4+ times per week is 1.6–2.2g per kilogram of body weight per day (Morton et al., British Journal of Sports Medicine, 2018 — a meta-analysis of 49 studies covering 1,800 participants). For reference, a 180-pound (82kg) person requires approximately 131–180g of protein daily to maximize muscle protein synthesis — approximately 2–3 times the RDA. Above 2.2g/kg, additional protein produces diminishing returns in muscle protein synthesis in most individuals.

> **THE SCIENCE: Leucine Is the Trigger for Muscle Protein Synthesis**
>
> Of the 20 amino acids, leucine specifically activates the mTOR signaling pathway that initiates muscle protein synthesis. The minimum leucine threshold for maximally stimulating MPS is approximately 2–3g per meal, achieved by approximately 25–40g of most whole food proteins (meat, eggs, dairy, fish). Plant proteins typically have lower leucine content per gram of protein — approximately 1.8g leucine per 100g protein in pea protein vs. approximately 2.5g in whey. This is why plant-protein sources require higher total intake to match the MPS-stimulating effect of animal proteins, not because they are inherently inferior, but because the leucine density differs.

**Protein Quality and Source Hierarchy**

All protein sources are not metabolically equivalent. The two most relevant quality metrics are the DIAAS (Digestible Indispensable Amino Acid Score), which measures both the amino acid profile and the digestibility of the protein, and leucine content. Whole food proteins are generally superior to processed protein supplements for overall nutrition, though supplements can be a practical tool for hitting protein targets.

<table>
<colgroup>
<col style="width: 21%" />
<col style="width: 13%" />
<col style="width: 9%" />
<col style="width: 17%" />
<col style="width: 38%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Protein Source</strong></td>
<td><strong>Protein per 100g food</strong></td>
<td><strong>DIAAS Score</strong></td>
<td><strong>Leucine per 100g protein</strong></td>
<td><strong>Practical Notes</strong></td>
</tr>
<tr class="even">
<td>Eggs (whole)</td>
<td>13g</td>
<td>1.13 (excellent)</td>
<td>8.5g</td>
<td>Best whole-food protein — complete amino acid profile; eat the yolk</td>
</tr>
<tr class="odd">
<td>Grass-fed beef (sirloin)</td>
<td>26g</td>
<td>1.10</td>
<td>8.0g</td>
<td>Excellent — also provides heme iron, zinc, B12, creatine, carnitine</td>
</tr>
<tr class="even">
<td>Wild salmon</td>
<td>25g</td>
<td>~1.05</td>
<td>7.9g</td>
<td>Excellent — protein + omega-3 package</td>
</tr>
<tr class="odd">
<td>Greek yogurt (full-fat)</td>
<td>10g</td>
<td>1.00</td>
<td>9.0g</td>
<td>Excellent — casein and whey combined; live cultures for gut health</td>
</tr>
<tr class="even">
<td>Cottage cheese</td>
<td>11g</td>
<td>~1.00</td>
<td>9.2g</td>
<td>High in casein — slow-digesting; good before sleep for overnight MPS</td>
</tr>
<tr class="odd">
<td>Chicken breast</td>
<td>31g</td>
<td>~1.08</td>
<td>7.9g</td>
<td>Lean; high protein density; low micronutrient compared to darker cuts</td>
</tr>
<tr class="even">
<td>Whey protein isolate</td>
<td>90g (as supplement)</td>
<td>~1.09</td>
<td>10.9g</td>
<td>Fastest-absorbing; best post-workout; leucine-rich</td>
</tr>
<tr class="odd">
<td>Pea protein isolate</td>
<td>85g (as supplement)</td>
<td>~0.82</td>
<td>7.2g</td>
<td>Best plant protein supplement; combine with rice protein for full amino profile</td>
</tr>
<tr class="even">
<td>Lentils (cooked)</td>
<td>9g</td>
<td>0.58</td>
<td>6.5g</td>
<td>Good plant source but incomplete — combine with grain or dairy to complete</td>
</tr>
<tr class="odd">
<td>Tofu (firm)</td>
<td>8g</td>
<td>0.52</td>
<td>6.1g</td>
<td>Complete amino acids but lower digestibility; fermented soy (tempeh) is better</td>
</tr>
<tr class="even">
<td>Quinoa (cooked)</td>
<td>4g</td>
<td>0.76</td>
<td>5.4g</td>
<td>Best grain-based protein — all essential amino acids; still low in leucine density</td>
</tr>
<tr class="odd">
<td>Hemp seeds</td>
<td>33g</td>
<td>~0.63</td>
<td>5.9g</td>
<td>Good plant protein; added omega-3 benefit; good to add to meals</td>
</tr>
</tbody>
</table>

**Carbohydrate Timing — When They Matter and When They Don't**

Carbohydrates are the most contextual macronutrient for active people. Their optimal intake depends heavily on training volume, training type, time of training, and individual metabolic flexibility. The common error is treating carbohydrate intake as a constant when it should be a variable matched to training demands.

The most evidence-backed framework for carbohydrate periodization is: high-carbohydrate intake on high-training-volume days (particularly when training multiple sessions or doing glycolytic work like interval training, heavy lifting for multiple sets, or team sport practice); moderate carbohydrates on moderate training days; and low-carbohydrate or carbohydrate-restricted intake on rest days and low-intensity training days. This approach — supported by research from the Australian Institute of Sport and formalized in Burke et al.'s work on 'train low, compete high' — improves fat oxidation capacity on low-carb training days while maintaining glycolytic capacity for high-intensity performance on high-carb training days.

**The Supplement Reality — What Is Supported and What Is Marketing**

<table>
<colgroup>
<col style="width: 19%" />
<col style="width: 13%" />
<col style="width: 16%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Supplement</strong></td>
<td><strong>Evidence Level</strong></td>
<td><strong>Effective Dose</strong></td>
<td><strong>Verdict</strong></td>
</tr>
<tr class="even">
<td>Creatine monohydrate</td>
<td>Grade A — strongest evidence base of any ergogenic</td>
<td>3–5g/day; no loading required</td>
<td>Take it. Increases phosphocreatine stores, improves high-intensity performance, accelerates recovery, and has documented cognitive benefits. Cheapest effective supplement per dollar.</td>
</tr>
<tr class="odd">
<td>Vitamin D3 + K2</td>
<td>Grade A for deficiency; Grade B for performance</td>
<td>2000–5000 IU D3 with 100–200mcg K2-MK7 daily</td>
<td>Most Americans are deficient (average serum level 16ng/mL vs. optimal 40–60ng/mL). Deficiency impairs testosterone production, immune function, and muscle function.</td>
</tr>
<tr class="even">
<td>Magnesium glycinate or malate</td>
<td>Grade B — widespread deficiency in active people</td>
<td>300–400mg elemental magnesium before sleep</td>
<td>60–75% of Americans don't meet RDA. Deficiency impairs sleep quality, muscle relaxation, and over 300 enzymatic reactions. Glycinate form best tolerated.</td>
</tr>
<tr class="odd">
<td>Omega-3 (EPA/DHA)</td>
<td>Grade A for anti-inflammatory; Grade B for body composition</td>
<td>2–3g EPA+DHA combined daily</td>
<td>Take if fish consumption is less than 3x per week. Reduces muscle soreness, supports recovery, reduces cardiovascular risk.</td>
</tr>
<tr class="even">
<td>Protein powder (whey or plant)</td>
<td>Grade A as a practical protein delivery tool</td>
<td>Depends on dietary protein gap</td>
<td>A tool to hit protein targets, not a magic supplement. Whole foods first; powder to fill gaps.</td>
</tr>
<tr class="odd">
<td>Caffeine</td>
<td>Grade A for acute performance</td>
<td>3–6mg/kg body weight, 45–60 min before training</td>
<td>Most robust acute performance enhancer available. Reduces perceived exertion, improves endurance and strength. Tolerance develops — cycle off 1–2 weeks monthly.</td>
</tr>
<tr class="even">
<td>Beta-alanine</td>
<td>Grade B — reduces muscular fatigue</td>
<td>3.2–6.4g/day; split doses reduce tingling</td>
<td>Effective for repeated high-intensity efforts lasting 1–4 minutes. Limited benefit for pure strength work.</td>
</tr>
<tr class="odd">
<td>Collagen + Vitamin C</td>
<td>Grade B for connective tissue</td>
<td>15g collagen + 50mg C, 30–60 min before exercise</td>
<td>Shaw et al. (2017) showed doubled collagen synthesis in tendons when supplemented pre-training. Relevant for injury prevention in high-volume training.</td>
</tr>
<tr class="even">
<td>BCAA supplements</td>
<td>Grade D when protein intake is adequate</td>
<td>Any dose</td>
<td>Redundant if eating sufficient protein (1.6g+/kg/day). Waste of money. The leucine mechanism is better served by whole protein.</td>
</tr>
<tr class="odd">
<td>Testosterone boosters (herbal)</td>
<td>Grade F — no evidence</td>
<td>N/A</td>
<td>None of the commercially sold 'natural testosterone boosters' have shown clinically meaningful testosterone increases in rigorous trials. Marketing category with no scientific support.</td>
</tr>
<tr class="even">
<td>Fat burners / thermogenics</td>
<td>Grade D — mostly placebo or caffeine repackaged</td>
<td>N/A</td>
<td>The only thermogenic ingredient with consistent evidence is caffeine. Everything else in these products adds cost, often adds risk, and adds negligible efficacy.</td>
</tr>
<tr class="odd">
<td>Athletic greens / superfood powders</td>
<td>Grade D for most health claims</td>
<td>Per product</td>
<td>Some contain genuinely useful ingredients (adaptogens, probiotics, spirulina). None have rigorous evidence for the sweeping claims made. Whole vegetables outperform on every measurable metric.</td>
</tr>
</tbody>
</table>

**SECTION SIX**

**HOW TO SHOP — READING LABELS AND FINDING REAL FOOD**

*Practical Frameworks for Navigating the Grocery Store*

**6.1 THE 5-INGREDIENT RULE AND ITS LIMITS**

Michael Pollan's well-known guidance — 'Don't eat anything your great-grandmother wouldn't recognize as food' and 'If it has more than five ingredients, don't buy it' — is a useful heuristic that correctly identifies processed food complexity as a proxy for degree of industrial manipulation. But it has limits: some highly nutritious foods (properly made whole grain sourdough bread, fermented foods, bone broth) have more than 5 ingredients; some single-ingredient foods can be problematic depending on sourcing (conventional strawberries, factory-farmed meat). A more rigorous framework:

Rule 1: Every ingredient should be something you could buy separately at a grocery store. 'Carboxymethylcellulose' is not a grocery store ingredient. 'Oats, honey, almonds, coconut oil, sea salt' are. Rule 2: The first ingredient determines the product. If wheat flour (not whole wheat flour) is the first ingredient in bread, you are primarily buying refined grain regardless of what the front label says. Rule 3: If a health claim appears on the front of the package ('heart-healthy,' 'low-fat,' 'natural,' 'reduces cholesterol'), be more skeptical, not less. Truly nutritious whole foods rarely require health claims. Rule 4: The serving size is legally defined by the manufacturer. A 'serving' of peanut butter is 2 tablespoons; a 'serving' of cola is 8 ounces (not the 20-ounce bottle). Always calculate for your actual consumption.

**Certification Labels That Actually Mean Something vs. Marketing Labels**

<table>
<colgroup>
<col style="width: 26%" />
<col style="width: 10%" />
<col style="width: 41%" />
<col style="width: 21%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Label / Certification</strong></td>
<td><strong>Regulated?</strong></td>
<td><strong>Meaning</strong></td>
<td><strong>Reliability</strong></td>
</tr>
<tr class="even">
<td>USDA Organic</td>
<td>Yes — federal law</td>
<td>No synthetic pesticides, fertilizers, GMOs, or antibiotics. For livestock: access to pasture.</td>
<td>High — but 'access to pasture' is loosely defined. Best for produce; meaningful for dairy and eggs.</td>
</tr>
<tr class="odd">
<td>Certified Humane Raised &amp; Handled</td>
<td>Yes — third-party audit</td>
<td>Species-specific welfare standards; meaningful outdoor access for relevant species.</td>
<td>High — one of the most rigorous animal welfare standards</td>
</tr>
<tr class="even">
<td>American Grassfed Association (AGA)</td>
<td>Yes — third-party verified</td>
<td>100% grass and forage diet from weaning to harvest; never confined; no hormones or antibiotics.</td>
<td>High — the gold standard for grass-finished beef and lamb</td>
</tr>
<tr class="odd">
<td>Certified Grassfed by AGW</td>
<td>Yes — third-party</td>
<td>Similar to AGA; USDA-approved process</td>
<td>High</td>
</tr>
<tr class="even">
<td>Non-GMO Project Verified</td>
<td>Yes — third-party audit</td>
<td>Product or ingredients not genetically modified. Does not address pesticide use or nutritional quality.</td>
<td>High for GMO status only — does not imply organic or pesticide-free</td>
</tr>
<tr class="odd">
<td>Pasture Raised (Certified Humane or AWA)</td>
<td>Yes when combined with those certifications</td>
<td>108+ sq ft outdoor access per bird; 6+ hours/day outdoors</td>
<td>High when certified; meaningless without certification body</td>
</tr>
<tr class="even">
<td>Wild-Caught</td>
<td>Partially regulated</td>
<td>Fish was caught in the wild, not farmed. Does not address fishing method, mercury level, or sustainability.</td>
<td>Medium — real distinction but incomplete information</td>
</tr>
<tr class="odd">
<td>MSC Certified (Marine Stewardship Council)</td>
<td>Yes — independent audit</td>
<td>Wild fish from certified sustainable fishery</td>
<td>Medium-High — some controversies about MSC standard rigor but generally reliable</td>
</tr>
<tr class="even">
<td>Natural</td>
<td>Minimally regulated</td>
<td>USDA allows 'natural' for meat with no artificial ingredients and minimal processing. FDA has no definition for other foods.</td>
<td>Very low — essentially marketing</td>
</tr>
<tr class="odd">
<td>Free Range (poultry)</td>
<td>Yes — USDA defined for poultry</td>
<td>Access to outside. No square footage, quality, or duration requirements.</td>
<td>Low — a door to a concrete pad qualifies</td>
</tr>
<tr class="even">
<td>Cage Free (eggs)</td>
<td>Yes — USDA defined</td>
<td>Hens not in battery cages. Indoor confinement is still permitted. No outdoor access required.</td>
<td>Low for welfare; irrelevant for nutrition vs. pasture-raised</td>
</tr>
<tr class="odd">
<td>All Natural / No Artificial Ingredients</td>
<td>No definition</td>
<td>Manufacturer self-declaration with no regulatory backing</td>
<td>Zero — pure marketing</td>
</tr>
<tr class="even">
<td>Gluten-Free</td>
<td>Yes — FDA: &lt;20ppm gluten</td>
<td>Meaningful for celiac disease patients. No nutritional superiority claim for non-celiac individuals.</td>
<td>High for stated purpose; often used as a health halo for nutritionally poor products</td>
</tr>
</tbody>
</table>

**The Best Brands by Category — Based on Ingredient Quality and Sourcing**

The following represents current (2024–2025) best-available options in major categories based on ingredient quality, independent testing results, certification status, and absence of the problematic additives covered in Section 2. This is not a permanent list — brands are acquired, reformulated, and sourced differently over time. Always check the current ingredient list, as formulations change.

**Beef and Meat**

Best: ButcherBox (subscription delivery; grass-finished beef, pasture-raised chicken, wild-caught salmon — AGA certified); White Oak Pastures (regenerative farm in Georgia; ships direct); US Wellness Meats (AGA certified; ships direct); Thousand Hills Lifetime Grazed; local farms with AGA certification verifiable at localharvest.org. For grocery stores: Applegate Farms deli meats are among the cleanest commercially available processed meats (no nitrates, no antibiotics, organic options) — though processed meat is still processed meat. Avoid: Oscar Mayer, Hormel, most conventional deli counter products.

**Eggs**

Best: Vital Farms (Certified Humane pasture-raised; independently tested with highest omega-3 in category); Alexandre Family Farm (regenerative; A2 milk products also); local pasture-raised eggs at farmers markets (look for orange yolks as a visual indicator of carotenoid content — though some manufacturers artificially color feed). Avoid: conventional eggs labeled only 'cage free' or 'free range' — the omega-3 and micronutrient content is not meaningfully better than conventional caged eggs.

**Dairy**

Best: Organic Valley (cooperative; pasture-raised standard required; available in most grocery stores); Alexandre Family Farm (A2 pastured milk); Maple Hill (100% grass-fed certified); Straus Family Creamery (California; certified organic; HTST pasteurized only). For yogurt: Organic Valley whole milk plain; Maple Hill whole milk plain; Chobani whole milk plain (decent option, widely available). For cheese: raw-milk aged cheeses (legal in the US when aged 60+ days — many small American cheesemakers); Kerrygold butter (Irish pasture-raised cows; widely available; significantly higher K2 than conventional butter). Avoid: Yoplait (high sugar, artificial colors); Dannon Activia (probiotic strain research largely industry-funded; high sugar in flavored versions).

**Bread and Grains**

Best: Dave's Killer Bread 21 Whole Grains (genuine whole grain; widely available); Food for Life Ezekiel 4:9 Sprouted Grain Bread (no flour at all; made from sprouted whole grains; lowest glycemic impact of commercial breads); local bakery sourdough made with whole grain flour (lacto-fermentation reduces phytic acid and glycemic index). For oats: Bob's Red Mill thick-rolled or steel-cut oats (minimal processing; no added sugars); purely organic rolled oats tested for glyphosate — Costco Kirkland organic oats have independently tested clean. Avoid: Wonder Bread and similar enriched white flour products; most 'multigrain' breads; Pepperidge Farm products that list enriched flour first.

**Cooking Oils**

Best for cold use: California Olive Ranch extra virgin olive oil (one of the few US-produced EVOOs with consistent authenticity — the olive oil fraud problem means many 'Italian' olive oils are cut with seed oils; domestic production is more verifiable); Kirkland Organic EVOO (independently verified). Best for high-heat: Chosen Foods avocado oil (high smoke point; independently tested for purity); Ancient Organics ghee (grass-fed; HTST only). Avoid: Wesson, Crisco, any generic 'vegetable oil,' any product labeled 'light olive oil' (lighter in flavor means more refined, not healthier).

**Canned and Packaged**

Best: Wild Planet canned fish (pole and line caught; tested for heavy metals; BPA-free cans; highest omega-3 content in category for tuna and sardines); Jovial tomatoes (canned in Italy; glass jars or BPA-free cans; tested for phthalates); Patagonia Provisions (responsibly sourced packaged foods); Thrive Market house brand (their sourcing standards are transparent and generally high for the category). For canned beans: any brand with BPA-free labeling and nothing added but water and salt. Avoid: Most conventional canned soups (Campbell's, Progresso) — very high sodium, often lined with BPA, frequently contain seed oils and additives.

**SECTION SEVEN**

**THE OPTIMAL DAILY FRAMEWORK**

*Putting It All Together for 5–8 Workouts Per Week*

**7.1 THE EVIDENCE-BASED DAILY EATING FRAMEWORK FOR ACTIVE PEOPLE**

The following is synthesized from the strongest evidence in nutrition science for someone exercising 5–8 times per week, combining strength training and cardiovascular work, and wanting to optimize body composition, performance, and long-term health simultaneously.

**The Non-Negotiables**

These are dietary principles with the strongest evidence base — multiple independent large-scale studies, mechanistic understanding, and consistency across populations:

**1. Total protein:** 1.6–2.2g per kilogram of body weight daily. This is the single most impactful dietary variable for body composition and recovery in active people. Hit this number first before optimizing anything else.

**2. Vegetable intake:** Aim for 6–10 servings of non-starchy vegetables daily. This is where most of the micronutrients, fiber, and phytochemicals come from. Dark leafy greens (kale, spinach, arugula, Swiss chard) and cruciferous vegetables (broccoli, Brussels sprouts, cauliflower) should appear daily.

**3. Eliminate or radically minimize:** Ultra-processed foods (anything requiring more than basic home cooking to assemble); industrial seed oils (soybean, corn, cottonseed, partially hydrogenated anything); refined sugar beyond very small amounts; and refined grains as the dietary staple.

**4. Eat within a consistent window:** A 10–16 hour eating window (8–14 hour fast) is supported by evidence for metabolic improvement. Choose a window that fits your training schedule.

**5. Prioritize whole foods over supplements:** Every supplement in Section 5's table is a compensation for dietary gaps. Close the gap with food first; supplement specifically identified deficiencies second.

**The Practical Weekly Template — Training Days vs. Rest Days**

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 33%" />
<col style="width: 25%" />
<col style="width: 26%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Timing</strong></td>
<td><strong>Training Day (Heavy)</strong></td>
<td><strong>Training Day (Cardio/Light)</strong></td>
<td><strong>Rest Day</strong></td>
</tr>
<tr class="even">
<td>First meal (break fast)</td>
<td>30–60g protein + 50–80g complex carbs (eggs + oatmeal; Greek yogurt + fruit; salmon + sweet potato)</td>
<td>25–40g protein + moderate fat + moderate carbs</td>
<td>25–40g protein + mostly fat + minimal carbs</td>
</tr>
<tr class="odd">
<td>Pre-training (1–2hr before)</td>
<td>25–40g protein + 40–60g fast-digesting carbs (rice, banana, potato)</td>
<td>Coffee/tea + optional small protein source</td>
<td>N/A</td>
</tr>
<tr class="even">
<td>Intra-workout</td>
<td>Electrolytes + optional 30–50g carbs for sessions &gt;90 min</td>
<td>Electrolytes + water for sessions &lt;60 min</td>
<td>N/A</td>
</tr>
<tr class="odd">
<td>Post-training (within 45 min)</td>
<td>25–40g fast protein (whey preferred) + 40–60g carbs. This is the most important meal window of the day for recovery.</td>
<td>25–40g protein + moderate carbs</td>
<td>N/A</td>
</tr>
<tr class="even">
<td>Main meal</td>
<td>Grass-fed meat or wild fish + 2+ cups vegetables + one serving complex starch (rice, sweet potato, quinoa)</td>
<td>Protein + vegetables + moderate starch</td>
<td>Large protein + large vegetable intake + fats (olive oil, avocado, nuts) + minimal starch</td>
</tr>
<tr class="odd">
<td>Evening (if needed)</td>
<td>Casein-heavy protein source (cottage cheese, Greek yogurt) before sleep supports overnight MPS</td>
<td>Same if training was in morning</td>
<td>Optional — cottage cheese or handful of nuts if genuinely hungry</td>
</tr>
<tr class="even">
<td>Total macros (approx)</td>
<td>Protein: 1.6–2.2g/kg | Carbs: 3–5g/kg | Fat: 0.8–1.2g/kg</td>
<td>Protein: 1.6–2g/kg | Carbs: 2–3g/kg | Fat: 1–1.5g/kg</td>
<td>Protein: 1.8–2.2g/kg | Carbs: 0.5–1g/kg | Fat: 1.5–2g/kg</td>
</tr>
</tbody>
</table>

**Gut Health — The System That Determines How Well You Absorb Everything Else**

The gut microbiome — the community of approximately 100 trillion microorganisms inhabiting the human digestive tract — has emerged in the past decade as one of the most important determinants of nutrient absorption, immune function, inflammation levels, and even mood and cognitive function through the gut-brain axis. The diversity and composition of the microbiome is substantially determined by diet. A 2021 Stanford study by Wastyk et al. (Cell) found that 10 weeks of a high-fermented-food diet increased microbiome diversity significantly more than a high-fiber diet, and reduced markers of systemic inflammation. The most evidence-backed approaches to gut health:

**Fermented foods daily:** Yogurt (with live cultures — look for 'live and active cultures' seal and a short ingredient list), kefir (higher bacterial count than yogurt), sauerkraut (unpasteurized — the pasteurized shelf-stable version has no live bacteria), kimchi, tempeh, kombucha (watch the sugar content — commercial versions vary from 2g to 25g per bottle). The bacterial count in these foods is far higher than any commercial probiotic supplement.

**Prebiotic fiber:** Feeds the bacteria you want. Best sources: garlic (raw is most potent), onions, leeks, asparagus, Jerusalem artichoke, green banana, oats. Aim for 20–35g total dietary fiber daily — most Americans get 10–15g.

**Avoid microbiome disruptors:** Emulsifiers (polysorbate 80, CMC — listed in Section 2); artificial sweeteners (sucralose and saccharin shown to alter microbiome in Suez et al.); unnecessary antibiotics; chronic NSAIDs (ibuprofen, naproxen damage the gut lining with regular use).

**Hydration — The Underestimated Variable**

Hydration is the most underestimated performance variable for athletes training at high frequency. A 2% body weight fluid deficit reduces aerobic performance by approximately 10–20% and impairs strength output and cognitive function. For a 180-pound person, 2% is approximately 3.6 pounds of water — easily lost during a moderately intense 60-minute workout in warm conditions.

The current evidence does not support the '8 glasses of water per day' guideline as a universal recommendation — individual needs vary by body weight, sweat rate, temperature, and activity level. A practical target for active individuals: urine should be pale yellow to clear. Dark yellow urine indicates underhydration. Clear urine throughout the day indicates adequate hydration. For intense training in hot conditions, electrolyte replacement (sodium, potassium, magnesium, chloride) is as important as water — plain water alone during extended intense exercise can cause hyponatremia (dangerously low sodium) in rare but real cases.

**SECTION EIGHT**

**WORST OFFENDERS AND BEST ALTERNATIVES**

*Quick Reference Guide by Category*

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 28%" />
<col style="width: 25%" />
<col style="width: 30%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Category</strong></td>
<td><strong>Worst Options — Avoid or Minimize</strong></td>
<td><strong>Best Options — What to Buy Instead</strong></td>
<td><strong>The Key Difference</strong></td>
</tr>
<tr class="even">
<td>Cooking oil</td>
<td>Crisco shortening; Wesson vegetable oil; Pam cooking spray (seed oil aerosol); generic 'light olive oil'</td>
<td>EVOO for cold/medium heat; avocado oil for high heat; grass-fed ghee or butter for cooking</td>
<td>Oxidation stability and omega-6 load</td>
</tr>
<tr class="odd">
<td>Breakfast cereal</td>
<td>Lucky Charms; Fruit Loops; Honey Nut Cheerios (high sugar despite health halo); Special K (refined grain, sugar)</td>
<td>Rolled oats (unsweetened); whole grain puffed cereals with &lt;6g sugar; steel-cut oats</td>
<td>Sugar content; glycemic load; degree of processing</td>
</tr>
<tr class="even">
<td>Bread</td>
<td>Wonder Bread; most store-brand 'wheat' bread; Pepperidge Farm (enriched flour first); any 'multigrain' without whole grain first</td>
<td>Ezekiel sprouted grain; Dave's Killer Bread; local sourdough with whole grain flour</td>
<td>Whether whole grain is actually the primary ingredient</td>
</tr>
<tr class="odd">
<td>Yogurt</td>
<td>Yoplait (up to 26g sugar); Dannon Activia flavored; any yogurt with 'corn starch,' 'modified starch,' or artificial flavors</td>
<td>Whole milk plain Greek yogurt (Organic Valley, Maple Hill); full-fat plain Siggi's; whole milk Kefir</td>
<td>Sugar content; fat type; live culture status</td>
</tr>
<tr class="even">
<td>Deli meat</td>
<td>Oscar Mayer bologna; most conventional deli sliced meats; hot dogs; processed sausages with nitrites</td>
<td>Applegate organic turkey or chicken (nitrate-free); whole roasted meat sliced yourself; canned sardines or salmon</td>
<td>Nitrosamine formation; sodium content; processing degree</td>
</tr>
<tr class="odd">
<td>Chips / snacks</td>
<td>Lay's Classic (soybean oil); Doritos (seed oils + artificial colors); Pringles (corn starch tube snack)</td>
<td>Lesser Evil popcorn (avocado oil); Siete grain-free chips (avocado oil); Jackson's Honest chips (coconut oil); raw nuts</td>
<td>Oil type; artificial additive load</td>
</tr>
<tr class="even">
<td>Salad dressing</td>
<td>Hidden Valley Ranch (soybean oil, sugar, EDTA); Kraft Italian (soybean oil, HFCS); any fat-free dressing (replaces fat with sugar/thickeners)</td>
<td>Make your own: EVOO + apple cider vinegar + Dijon + salt; Primal Kitchen dressings (avocado oil base); Tessemae's (EVOO base)</td>
<td>Oil base; sugar content; additive load</td>
</tr>
<tr class="odd">
<td>Protein bar</td>
<td>Clif Bar (essentially a candy bar — 45g carbs, 20g sugar); Kind bars (better but still high sugar); Zone bars</td>
<td>Epic bars (meat-based); RX Bar (minimal ingredients); homemade: dates + protein powder + nuts</td>
<td>Sugar content; protein quality; degree of processing</td>
</tr>
<tr class="even">
<td>Sports drink</td>
<td>Gatorade (HFCS + food dyes + no real electrolyte balance); Powerade; most commercial sports drinks</td>
<td>LMNT electrolytes; Nuun tablets; homemade: water + sea salt + lemon + honey for endurance; water for sessions &lt;60 min</td>
<td>Electrolyte balance; sugar source; artificial color presence</td>
</tr>
<tr class="odd">
<td>Coffee creamer</td>
<td>International Delight (seed oils + corn syrup + carrageenan); Coffeemate (hydrogenated oil)</td>
<td>Whole milk; heavy cream; grass-fed half-and-half; unsweetened coconut cream</td>
<td>Trans fat presence; seed oil content; emulsifier content</td>
</tr>
<tr class="even">
<td>Peanut butter</td>
<td>Jif or Skippy (added sugar, palm oil, partially hydrogenated soybean oil)</td>
<td>Natural peanut butter (peanuts + salt only); almond butter; any nut butter with only nuts as ingredients</td>
<td>Ingredient list length; oil type; sugar presence</td>
</tr>
<tr class="odd">
<td>Plant-based protein</td>
<td>Impossible Burger (methylcellulose, seed oils, 390mg sodium, heavily processed)</td>
<td>Whole legumes; tempeh; edamame; lentils with complete amino acid combinations</td>
<td>Degree of processing; additive load; sodium content</td>
</tr>
<tr class="even">
<td>Dairy alternatives</td>
<td>Oat milk with added sugar and sunflower oil (Oatly OG); most commercial almond milk (2–4 almonds per cup)</td>
<td>Forager organic cashew milk (cleaner); Malk almond milk (almonds + water only); homemade oat milk (zero additives)</td>
<td>Additive load; actual food content vs. water with flavoring</td>
</tr>
</tbody>
</table>

**The most important sentence in this document:**

**Eat mostly whole, minimally processed foods, in a time-restricted window,**

with adequate protein, a wide variety of vegetables, quality animal products from properly raised animals,

**and as little from a factory as possible.**

*Every recommendation in this document is either from peer-reviewed research cited by study name and authors,*

*established nutritional biochemistry, or government testing programs. No ideology. No industry funding. Just what the evidence shows.*
