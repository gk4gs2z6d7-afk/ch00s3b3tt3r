# Project Spotlight

*100 Documented Government Operations and Experiments · 1700 to Present*

**Kai Jashon Price** · Reference Archive — Not an Argument · 2025
— structuralhumanism.com —

---

> **Every entry is sourced to primary documents, official investigations, declassified files, judicial findings, or credible investigative journalism. Distribution: 40 American · 18 British · 7 Israeli · 5 WW2 (German/Japanese combined) · 10 Soviet/Russian · 5 French · 4 Belgian/Congolese · 4 Canadian · 3 South African · 4 Other. No sanitizing. No agenda. Every country judged by the same standard.**

**UNITED STATES OF AMERICA — OPERATIONS 1-40**

**1. MKUltra — CIA Mind Control Program**

**USA · 1953–1973 · Covert Human Experimentation**

The CIA conducted at least 150 separate research projects involving unwitting human subjects subjected to LSD, electroconvulsive therapy, sensory deprivation, hypnosis, physical and psychological abuse, and combinations thereof. Subjects included mental patients, prisoners, drug addicts, sex workers, and civilians who were dosed without knowledge or consent. Sub-project Operation Midnight Climax ran safe houses in New York and San Francisco where CIA officers watched through one-way mirrors as prostitutes dosed unsuspecting men with LSD. CIA Director Richard Helms ordered the destruction of most MKUltra documents in 1973 when the program came under congressional scrutiny. Approximately 20,000 documents survived a misarchiving error and were discovered in 1977. The Church Committee hearings confirmed the program's existence and scope. Frank Olson, a U.S. Army biochemist, was dosed without consent and died after falling from a New York hotel window; his family disputes the official suicide ruling and the case was reopened in 2012. At least 80 institutions participated including 44 universities.

*SOURCE: Senate Select Committee to Study Governmental Operations with Respect to Intelligence Activities (Church Committee), 1975-1976. Senate Subcommittee on Health and Scientific Research hearings, 1977. John Marks, 'The Search for the Manchurian Candidate' (Times Books, 1979). CIA MORI document releases.*

**2. Operation Paperclip — Nazi Scientists Imported to America**

**USA · 1945–1959 · Covert Government Program**

Operation Paperclip was the U.S. Joint Intelligence Objectives Agency (JIOA) program that recruited approximately 1,600 German scientists, engineers, and technicians — including many with documented Nazi Party memberships and SS affiliations — and brought them to the United States after World War II. State Department and OSS objections noting the scientists' war crimes involvement were overridden by military need. Wernher von Braun, director of the V-2 rocket program that used concentration camp slave labor and killed thousands, became the director of NASA's Marshall Space Flight Center. Dr. Hubertus Strughold, known as the 'Father of Space Medicine,' was implicated in Nazi aviation experiments at Dachau. Strughold received the USAF's highest honor. Arthur Rudolph, who oversaw the Mittelwerk factory where 20,000 slave laborers died building V-2 rockets, worked at NASA until he was investigated and allowed to leave the country in 1984 rather than face prosecution.

*SOURCE: Linda Hunt, 'Secret Agenda: The United States Government, Nazi Scientists, and Project Paperclip' (St. Martin's Press, 1991). Annie Jacobsen, 'Operation Paperclip: The Secret Intelligence Program That Brought Nazi Scientists to America' (Little, Brown, 2014). JIOA records, NARA RG 330.*

**3. Tuskegee Syphilis Study**

**USA · 1932–1972 · Government Medical Experiment**

The U.S. Public Health Service, in collaboration with the Tuskegee Institute, enrolled 399 Black men with syphilis and 201 without in a study that was officially described as treatment but was in fact observation of untreated disease progression. Men were told they were being treated for 'bad blood' but received placebos, aspirin, and vitamins rather than treatment. When penicillin became the standard of care for syphilis in 1947, the study participants were not offered it. The study continued for 40 years. The experiment was exposed by journalist Jean Heller of the Associated Press in 1972 following a leak by public health worker Peter Buxtun. By the study's end, 28 men had died of syphilis, 100 of related complications, 40 wives had been infected, and 19 children had been born with congenital syphilis. President Clinton formally apologized in 1997.

*SOURCE: James Jones, 'Bad Blood: The Tuskegee Syphilis Experiment' (Free Press, 1981). U.S. Senate hearings, 1973. Presidential apology, Bill Clinton, May 16, 1997, White House records.*

**4. COINTELPRO — FBI Counterintelligence Program**

**USA · 1956–1971 · Covert Domestic Suppression**

The FBI's COINTELPRO operations targeted domestic political organizations through illegal surveillance, infiltration, disruption, and violence. Targets included the NAACP, Southern Christian Leadership Conference, Student Nonviolent Coordinating Committee, American Indian Movement, Socialist Workers Party, and the Communist Party USA. The FBI sent Martin Luther King Jr. an anonymous letter in 1964 describing his supposed sexual indiscretions and urging him to kill himself before accepting the Nobel Peace Prize. Forged letters were sent to create conflict between Black Panther Party chapters. FBI informant William O'Neal provided detailed floor plans of Fred Hampton's apartment; Hampton was killed by Chicago police in a pre-dawn raid on December 4, 1969 while sleeping. COINTELPRO was exposed by the Citizens' Commission to Investigate the FBI, who burglarized the Media, Pennsylvania FBI office in 1971 and gave the files to newspapers.

*SOURCE: Senate Select Committee (Church Committee) Final Report, Volume 3: 'The FBI's Covert Action Programs Against American Citizens,' 1976. Betty Medsger, 'The Burglary: The Discovery of J. Edgar Hoover's Secret FBI' (Knopf, 2014). Clayborne Carson, 'In Struggle: SNCC and the Black Awakening of the 1960s' (Harvard University Press, 1981).*

**5. Operation Mockingbird — CIA Media Infiltration**

**USA · 1950s–1970s (documented; later phase disputed) · Covert Program**

Operation Mockingbird was a CIA program to influence domestic and international media by recruiting journalists, editors, and news executives as paid or volunteer assets. The program was documented by the Church Committee in 1975. CIA Director William Colby testified that at its peak the agency had relationships with approximately 400 American journalists. Journalists placed by the CIA worked at every major wire service, newspaper, and broadcast network including the New York Times, Washington Post, Newsweek, CBS, and Reuters. Philip Graham, publisher of the Washington Post, helped manage the operation before his death. The Church Committee recommended ending the program; the CIA stated it would cease using employees of U.S. media organizations. Whether the practice continued under different arrangements has not been officially resolved.

*SOURCE: Church Committee Final Report, Book I: 'Foreign and Military Intelligence,' 1976. Carl Bernstein, 'The CIA and the Media,' Rolling Stone, October 1977. Tim Weiner, 'Legacy of Ashes: The History of the CIA' (Doubleday, 2007).*

**6. Operation Northwoods — Plan to Stage Terrorist Attacks**

**USA · 1962 · Proposed False Flag Operation (Not Executed)**

Operation Northwoods was a set of proposals drafted by the Joint Chiefs of Staff and presented to Secretary of Defense Robert McNamara on March 13, 1962. The proposals included staging a series of terrorist attacks against American citizens, military personnel, and property — including sinking boats carrying Cuban refugees, bombing Miami and Washington D.C., shooting down an American aircraft, and orchestrating attacks at Guantanamo Bay — to create a pretext for military invasion of Cuba. The proposals were signed by all five Joint Chiefs of Staff. They were rejected by McNamara and President Kennedy. The documents were declassified in 1997 under the JFK Records Act.

*SOURCE: Joint Chiefs of Staff memorandum JCSM-166-62, March 13, 1962, 'Justification for U.S. Military Intervention in Cuba.' Declassified and available at the National Security Archive, nsarchive.gwu.edu. James Bamford, 'Body of Secrets: Anatomy of the Ultra-Secret National Security Agency' (Doubleday, 2001).*

**7. Operation Phoenix — Vietnam Assassination Program**

**USA/South Vietnam · 1965–1972 · Extrajudicial Killing Program**

The Phoenix Program was a CIA-run joint U.S.-South Vietnamese operation designed to neutralize — through capture, defection, or assassination — the civilian infrastructure of the National Liberation Front (Viet Cong) in South Vietnam. Over its operational life, the program resulted in the reported neutralization of approximately 81,740 NLF suspects: 26,369 killed, the majority of the rest captured or defected. Many killings were based on informant lists of uncertain reliability. William Colby, who directed the program before becoming CIA Director, testified before Congress that the program had killed approximately 20,587 people. Congressional testimony from participants described systematic torture and summary executions. The program was documented by CIA officer Frank Snepp in his book Decent Interval and by journalist Seymour Hersh.

*SOURCE: William Colby testimony, Senate Foreign Relations Committee, 1971. Douglas Valentine, 'The Phoenix Program' (William Morrow, 1990). Frank Snepp, 'Decent Interval' (Random House, 1977). CORDS (Civil Operations and Revolutionary Development Support) operational reports, NARA.*

**8. Operation Cyclone — CIA Creation of the Afghan Mujahideen**

**USA · 1979–1992 · Covert Arms and Training Program**

Operation Cyclone was the largest covert operation in CIA history: the arming, training, and financing of Afghan mujahideen fighters following the Soviet invasion of Afghanistan in 1979. At its peak, the program provided approximately $600-700 million per year in weapons, funding, and training, with equal matching contributions from Saudi Arabia. The operation was acknowledged by President Carter's National Security Advisor Zbigniew Brzezinski, who stated in a 1998 Le Nouvel Observateur interview that he had deliberately provoked the Soviet invasion: 'That secret operation was an excellent idea. It had the effect of drawing the Russians into the Afghan trap.' Among the organizations funded and armed through Operation Cyclone were predecessors to Al-Qaeda. Osama bin Laden coordinated the Arab foreign fighter recruitment program (Maktab al-Khidamat) during the same period, with CIA and Saudi Arabian General Intelligence Directorate knowledge and support.

*SOURCE: Steve Coll, 'Ghost Wars: The Secret History of the CIA, Afghanistan, and bin Laden' (Penguin Press, 2004). Zbigniew Brzezinski interview, Le Nouvel Observateur, January 15, 1998. U.S. Congressional appropriations records.*

**9. Iran-Contra Affair**

**USA · 1984–1986 · Illegal Arms Deal and Foreign Policy Deception**

Senior officials in the Reagan administration secretly sold weapons to Iran — designated as a state sponsor of terrorism and subject to an arms embargo — and illegally diverted the proceeds to fund the Contra rebel groups in Nicaragua, circumventing a congressional ban on such funding (the Boland Amendment). The operation was run from the National Security Council by Marine Lieutenant Colonel Oliver North. Iran received TOW anti-tank missiles and HAWK surface-to-air missiles. The Contras received approximately $3.8 million in diverted funds. Fourteen officials were charged; eleven convicted. President Reagan stated he had no knowledge of the diversion. His Vice President George H.W. Bush pardoned several key figures on Christmas Eve 1992, before their trials concluded. Lawrence Walsh, the Independent Counsel, stated the pardons 'undermined the principle that no man is above the law.'

*SOURCE: Report of the Congressional Committees Investigating the Iran-Contra Affair (1987). Lawrence Walsh, 'Firewall: The Iran-Contra Conspiracy and Cover-up' (Norton, 1997). Independent Counsel Walsh's Final Report, 1993.*

**10. Operation AJAX/TP-AJAX — CIA Overthrow of Iranian Democracy**

**USA/UK · 1953 · Foreign Government Overthrow**

Operation AJAX (American designation) / Operation Boot (British designation) was the CIA and MI6 covert operation that overthrew the democratically elected Prime Minister of Iran, Mohammad Mosaddegh, on August 19, 1953. Mosaddegh had nationalized Iran's oil industry, threatening British Petroleum (then Anglo-Iranian Oil Company) interests. The CIA paid approximately $1 million to Iranian military officers, politicians, and street gangs to organize protests and a military coup. CIA officer Kermit Roosevelt Jr. (grandson of Theodore Roosevelt) directed the operation from inside Iran. The operation was classified for decades; the CIA officially acknowledged it for the first time in 2013 when documents were declassified under FOIA. The coup installed Shah Mohammad Reza Pahlavi, whose brutal SAVAK secret police subsequently tortured thousands, creating the conditions for the 1979 Islamic Revolution.

*SOURCE: CIA official acknowledgment: National Security Archive, 'CIA Confirms Role in 1953 Iran Coup,' August 2013, CIA document CREST: CIA-RDP80-00810A003000300001-0. Kermit Roosevelt Jr., 'Countercoup: The Struggle for Control of Iran' (McGraw-Hill, 1979). Stephen Kinzer, 'All the Shah's Men' (Wiley, 2003).*

**11. Operation PBSUCCESS — Guatemala Coup**

**USA · 1954 · Foreign Government Overthrow**

The CIA overthrew Guatemala's democratically elected President Jacobo Árbenz in June 1954 after his government expropriated unused land from the United Fruit Company (UFC) at the legally mandated compensation rate. The Dulles brothers — CIA Director Allen Dulles and Secretary of State John Foster Dulles — both had direct financial ties to United Fruit. The CIA trained a 480-man mercenary force in Honduras and Nicaragua, conducted psychological warfare operations, and broadcast false military communications to simulate a massive invasion. Árbenz resigned under pressure. The subsequent military dictatorship began a 36-year civil war in which approximately 200,000 Guatemalans were killed. President Clinton apologized to Guatemala in 1999, acknowledging U.S. support for Guatemalan military forces during the civil war.

*SOURCE: Nick Cullather, 'Secret History: The CIA's Classified Account of Its Operations in Guatemala, 1952-1954' (Stanford University Press, 1999) — declassified CIA internal history. Piero Gleijeses, 'Shattered Hope: The Guatemalan Revolution and the United States' (Princeton University Press, 1991).*

**12. Operation Condor — South American State Terror Network**

**USA/Multiple Latin American States · 1975–1989 · International Assassination and Suppression Program**

Operation Condor was a U.S.-backed intelligence coordination network among the right-wing military dictatorships of Argentina, Bolivia, Brazil, Chile, Paraguay, and Uruguay to track, capture, torture, and kill political opponents across national borders. The operation is documented to have killed between 60,000 and 80,000 people and forcibly disappeared 30,000 more. The U.S. role included providing technical assistance, communications infrastructure (through the U.S. Army School of the Americas), and intelligence sharing. Secretary of State Henry Kissinger was briefed on the program and expressed support for it in a documented 1976 meeting with Chilean Foreign Minister Patricio Carvajal. The September 1976 car bombing assassination of former Chilean ambassador Orlando Letelier in Washington D.C. — killing Letelier and American citizen Ronni Karpen Moffitt — was a Condor operation authorized by Chilean DINA.

*SOURCE: McSherry, J. Patrice, 'Predatory States: Operation Condor and Covert War in Latin America' (Rowman & Littlefield, 2005). Kissinger-Carvajal meeting transcript, State Department cable, June 8, 1976, National Security Archive. Argentine CONADEP (National Commission on the Disappearance of Persons), 'Nunca Más' (1984).*

**13. Human Radiation Experiments — U.S. Government Program**

**USA · 1944–1974 · Non-consensual Human Experimentation**

Following the Manhattan Project, the U.S. government conducted an extensive program of radiation experiments on unwitting human subjects. The Advisory Committee on Human Radiation Experiments, convened by President Clinton in 1993, documented approximately 4,000 radiation experiments conducted under government sponsorship. Experiments included: injection of plutonium into hospitalized patients without their knowledge (1945-1947); feeding radioactive iron to pregnant women at Vanderbilt University (1945-1947); feeding radioactive iron and calcium to 'mentally retarded' boys at Fernald State School in Massachusetts with the cooperation of the Quaker Oats Company (1946-1953); whole-body irradiation of cancer patients at the University of Cincinnati (1960-1971), many of whom received doses causing acute radiation sickness. The Advisory Committee confirmed that the principle of informed consent was systematically violated across all experiments.

*SOURCE: Advisory Committee on Human Radiation Experiments, Final Report, October 1995 (government document, available at energy.gov). Eileen Welsome, 'The Plutonium Files: America's Secret Medical Experiments in the Cold War' (Dial Press, 1999) — Pulitzer Prize-winning journalism.*

**14. Guatemalan Syphilis Experiments**

**USA · 1946–1948 · Non-consensual Human Experimentation**

Between 1946 and 1948, U.S. Public Health Service researchers led by Dr. John Cutler (who later participated in the Tuskegee study) deliberately infected Guatemalan soldiers, prisoners, psychiatric patients, and commercial sex workers with syphilis, gonorrhea, and chancroid without their knowledge or consent, in order to test the effectiveness of penicillin. Approximately 1,300 people were infected; at least 83 died, though the precise relationship between the experiments and the deaths was not fully documented. The experiments were conducted with the knowledge and cooperation of the Guatemalan government. The experiments were discovered in 2010 by researcher Susan Reverby while examining Cutler's archived papers. President Obama telephoned Guatemalan President Colom to apologize.

*SOURCE: Susan Reverby, 'Examining Tuskegee: The Infamous Syphilis Study and its Legacy' and 'Normal Exposure and Inoculation Syphilis: A PHS Tuskegee Doctor in Guatemala, 1946-48,' Journal of Policy History, 2011. Presidential Commission for the Study of Bioethical Issues, 'Ethically Impossible: STD Research in Guatemala from 1946-1948,' 2011.*

**15. Project SHAD / Project 112 — Chemical and Biological Testing on Soldiers**

**USA · 1962–1973 · Non-consensual Human Experimentation**

Project 112 and its shipboard component Project SHAD (Shipboard Hazard and Defense) involved the U.S. military spraying chemical and biological agents on military personnel and civilians without their knowledge or consent. At least 134 tests were conducted, spraying agents including VX nerve agent, sarin, zinc cadmium sulfide, and various bacterial simulants on military ships and their crews, on populated areas in Hawaii, and in other locations. Veterans were not informed of their exposure. A 2002 Department of Defense report and subsequent General Accountability Office investigations confirmed the tests. Thousands of affected veterans received no medical follow-up for decades.

*SOURCE: General Accountability Office, 'Chemical and Biological Defense: Emphasis Remains Insufficient to Resolve Continuing Problems,' GAO-01-1033T, 2001. Department of Defense, 'Project 112 / SHAD Fact Sheet,' 2002. Senate Veterans Affairs Committee hearings, 2002-2003.*

**16. Operation Sea-Spray — Biological Agent Testing on San Francisco**

**USA · 1950 · Covert Biological Experiment on Civilians**

Between September 20-27, 1950, the U.S. Navy sprayed the bacterium Serratia marcescens (then believed to be harmless) over San Francisco from a vessel off the coast, in order to test wind patterns and population exposure in a simulated biological attack. An estimated 800,000 San Francisco residents were exposed. Within days of the spraying, the first outbreak of Serratia marcescens infections at Stanford Hospital was documented. Edward Nevin, a retired pipefitter, died of Serratia endocarditis — his family later sued the government and the case reached the federal courts. The experiment was confirmed by Senate subcommittee investigation in 1977. Over the following two decades, the military conducted at least 239 open-air tests of biological and chemical agents over populated American cities.

*SOURCE: Senate Subcommittee on Health and Scientific Research, 'Biological Testing Involving Human Subjects by the Department of Defense,' 1977. Cole, Leonard A., 'Clouds of Secrecy: The Army's Germ Warfare Tests Over Populated Areas' (Rowman & Littlefield, 1988).*

**17. Operation LAC — Chemical Dispersal Over St. Louis**

**USA · 1953–1954 · Covert Experiment on Civilians**

The U.S. Army sprayed zinc cadmium sulfide — a powdered chemical compound — over St. Louis, Missouri from vehicles driving through densely populated neighborhoods, in order to test dispersal patterns for chemical weapon delivery. The spraying targeted the Pruitt-Igoe housing project, one of the most densely populated areas in the city, where the population was overwhelmingly African American and economically disadvantaged. Residents were told the Army was testing a 'smoke screen' to hide cities from Soviet air attack. The Army did not reveal the nature of the substance being sprayed. Researcher Lisa Martino-Taylor documented the experiments through FOIA requests in 2012. Zinc cadmium sulfide is a suspected carcinogen; some researchers have linked the spraying to elevated cancer rates in the affected neighborhoods.

*SOURCE: Lisa Martino-Taylor, 'The Manhattan-Rochester Coalition, Research on the Health Effects of Radioactive Materials, and Tests on Vulnerable Populations Without Consent in St. Louis, 1945-1970,' doctoral dissertation, University of Missouri, 2011. Army records obtained through FOIA. St. Louis Post-Dispatch investigative series, 2012.*

**18. Forced Sterilization of Native American Women — Indian Health Service**

**USA · 1970–1976 · Forced Medical Procedure**

The U.S. Indian Health Service (IHS) sterilized an estimated 25,000-50,000 Native American women between 1970 and 1976, many without genuine informed consent. Procedures were performed on women who were in labor, under anesthesia, or under pressure from IHS physicians. Some women were told they would lose welfare benefits if they refused. A 1976 Government Accountability Office investigation of four IHS regions found that 3,406 women had been sterilized in those regions alone in just two years, including 36 women under age 21 in violation of a moratorium on sterilizing minors. The IHS program operated within the broader context of federally funded eugenics programs that sterilized tens of thousands of poor, disabled, and minority women across the United States through the 1970s.

*SOURCE: General Accounting Office, 'Investigation of Allegations Concerning Indian Health Service,' HRD-77-3, November 4, 1976. Jane Lawrence, 'The Indian Health Service and the Sterilization of Native American Women,' American Indian Quarterly, Summer 2000. Brianna Theobald, 'Reproduction on the Reservation' (University of North Carolina Press, 2019).*

**19. Puerto Rico Sterilization Program — La Operación**

**USA/Puerto Rico · 1937–1970s · Forced/Coerced Sterilization**

The United States government and Puerto Rican authorities implemented a program of mass sterilization of Puerto Rican women from the 1930s through the 1970s. By 1968, approximately 34% of Puerto Rican women had been sterilized — the highest sterilization rate of any country or territory in the world. Women were frequently not fully informed of the permanence of the procedure; sterilization was often presented as reversible or framed as a patriotic duty. The program was promoted by U.S. corporations operating factories in Puerto Rico as a means of controlling labor supply and population growth. The initiative was partly funded by the U.S. government and endorsed by multiple governors of Puerto Rico appointed or approved by Washington.

*SOURCE: Iris Lopez, 'Matters of Choice: Puerto Rican Women's Struggle for Reproductive Freedom' (Rutgers University Press, 2008). Annette Ramírez de Arellano and Conrad Seipp, 'Colonialism, Catholicism, and Contraception: A History of Birth Control in Puerto Rico' (University of North Carolina Press, 1983).*

**20. PRISM and NSA Mass Surveillance Program**

**USA · 2007–Present (revealed 2013) · Unconstitutional Mass Surveillance**

The PRISM program, revealed by NSA contractor Edward Snowden in June 2013, enabled the NSA to directly access the servers of nine major technology companies — Microsoft, Yahoo, Google, Facebook, PalTalk, YouTube, Skype, AOL, and Apple — collecting emails, documents, photos, videos, and voice-over-IP communications. A companion program collected metadata on virtually every phone call made in the United States. A federal court later ruled the NSA's phone metadata collection program was illegal. The 9th Circuit Court of Appeals in 2020 found that the NSA's warrantless surveillance of Americans was illegal and that then-Director of National Intelligence James Clapper had committed perjury before Congress in March 2013 when he stated 'No sir' to the question of whether the NSA collected data on millions of Americans.

*SOURCE: Glenn Greenwald, Ewen MacAskill, and Laura Poitras, 'NSA Prism program taps in to user data of Apple, Google and others,' The Guardian, June 7, 2013. United States v. Moalin, 9th Circuit Court of Appeals, September 2020. Senate Judiciary Committee hearing transcript, March 12, 2013 (Clapper testimony).*

**UNITED STATES — OPERATIONS 21–40**

**21. Operation Midnight Climax — CIA Drug and Sexual Blackmail Operation**

**USA · 1954–1964 · Covert Human Experimentation**

Operation Midnight Climax was a sub-project of MKUltra in which CIA officers operated safe houses in New York City (44 West 83rd Street) and San Francisco where they employed prostitutes to lure men who were then dosed with LSD without their knowledge. CIA officers observed through one-way mirrors. The stated purpose was to test the effects of drugs and sexual blackmail for intelligence purposes. The operation was run by CIA agent George White in San Francisco, who maintained extensive journal records and expressed pride in his work. The safe houses were equipped with recording devices. The operation violated federal law, the CIA's own charter prohibiting domestic operations, and every principle of medical research ethics.

*SOURCE: Church Committee records, 1975-1976. Martin Lee and Bruce Shlain, 'Acid Dreams: The Complete Social History of LSD' (Grove Press, 1985). John Marks, 'The Search for the Manchurian Candidate' (Times Books, 1979). George White diary extracts submitted to Church Committee.*

**22. The Tuskegee Radiation Experiments — Plutonium Injections**

**USA · 1945–1947 · Non-consensual Human Experimentation**

Manhattan Project scientists, seeking to understand how plutonium distributed through the human body, injected at least 18 patients at hospitals in Rochester, Chicago, Oak Ridge, and San Francisco with plutonium without their knowledge or consent. The patients — selected for being terminally ill, though some lived for years afterward — were given code names rather than their own names in the research reports. At least three patients appear to have been in good health at the time of injection based on subsequent medical records. The experiments were designed and approved by senior Manhattan Project officials. The Advisory Committee on Human Radiation Experiments confirmed all injections in its 1995 final report.

*SOURCE: Eileen Welsome, 'The Plutonium Files' (Dial Press, 1999). Advisory Committee on Human Radiation Experiments, Final Report, 1995, Chapter 5.*

**23. Project ARTICHOKE and BLUEBIRD — Interrogation Through Mind Control**

**USA · 1950–1956 · Covert Human Experimentation**

Project BLUEBIRD (1950) and its successor ARTICHOKE (1951-1956) were the CIA predecessors to MKUltra, exploring whether individuals could be made to perform acts against their will through combinations of drugs, hypnosis, and psychological conditioning. Experiments included using sodium pentothal, mescaline, heroin, and combinations of these substances on both witting and unwitting subjects including foreign nationals, American citizens, and prisoners. The ARTICHOKE program explicitly explored whether a person could be induced to commit murder under hypnotic control — a program element that gave rise to theories about 'Manchurian Candidate' assassins that the CIA's own documents confirm were not purely theoretical.

*SOURCE: Church Committee Final Report, Book I. CIA MORI releases. Gordon Thomas, 'Journey into Madness: The True Story of Secret CIA Mind Control and Medical Abuse' (Bantam Books, 1989).*

**24. Willowbrook Hepatitis Experiments**

**USA · 1956–1970 · Non-consensual Human Experimentation on Disabled Children**

Researchers at the Willowbrook State School for 'mentally retarded' children in Staten Island, New York, deliberately infected newly admitted children with hepatitis B virus — in its live virulent form — as part of a study on natural disease progression and gamma globulin treatment. Parents were told the children would be admitted to a special unit only if they consented to the experiments; the regular school was severely overcrowded, creating implicit coercion. The experiments continued for 14 years. They were conducted by Dr. Saul Krugman of New York University and were published in peer-reviewed journals and defended by some medical ethicists at the time. The experiments contributed to hepatitis B research but are now uniformly considered an egregious ethical violation.

*SOURCE: Saul Krugman, et al., 'Infectious Hepatitis,' JAMA, 1959 (the original published papers). Robert Baker, 'The Willowbrook Letters,' in 'The Oxford Textbook of Clinical Research Ethics,' 2008. James Jones, 'The Case for Truth: Bioethics and the Willowbrook State School,' Yale Journal of Health Policy, Law, and Ethics, 2001.*

**25. CIA Black Sites and Enhanced Interrogation — Senate Torture Report**

**USA · 2001–2007 · Systematic Torture and Illegal Detention**

Following September 11, 2001, the CIA operated a network of secret detention facilities ('black sites') in countries including Poland, Romania, Lithuania, Thailand, and Afghanistan where detainees were subjected to interrogation techniques including waterboarding, rectal feeding, sleep deprivation for up to 180 hours, stress positions, confinement in small boxes, and threats against detainees' family members. The Senate Intelligence Committee's investigation, begun in 2009, produced a 6,700-page classified report. The 525-page executive summary, released in December 2014, found that the CIA's techniques were more brutal than reported to Congress, that the program produced no unique intelligence, and that the CIA repeatedly misled Congress and the White House about the program's effectiveness and scope.

*SOURCE: Senate Select Committee on Intelligence, 'Study of the Central Intelligence Agency's Detention and Interrogation Program,' Executive Summary, December 9, 2014. Available: intelligence.senate.gov. Mark Danner, 'Torture and Truth: America, Abu Ghraib, and the War on Terror' (New York Review Books, 2004).*

**26. Operation Timber Sycamore — CIA Arming Syrian Rebels Including Al-Qaeda Affiliates**

**USA · 2012–2017 · Covert Arms Program**

Operation Timber Sycamore was a CIA program to train and arm Syrian opposition fighters, operated jointly with Saudi Arabia, Qatar, and Turkey. The program supplied TOW anti-tank missiles, Kalashnikov assault rifles, and other weapons to rebel groups including Jabhat al-Nusra — the Syrian branch of Al-Qaeda — and its affiliates. Weapons supplied to 'moderate' rebel groups were documented to have been transferred to or captured by Al-Qaeda-affiliated organizations within weeks or months of delivery. The New York Times reported the weapons transfer operation in 2013; the CIA program was officially confirmed and shut down by President Trump in July 2017.

*SOURCE: New York Times, 'C.I.A. Said to Aid in Steering Arms to Syrian Opposition,' June 21, 2012. New York Times, 'Trump Ends Covert CIA Program to Arm Anti-Assad Rebels in Syria,' July 19, 2017. Mark Mazzetti, 'The Way of the Knife: The CIA, a Secret Army, and a War at the Ends of the Earth' (Penguin Press, 2013).*

**27. COINTELPRO — Assassination of Fred Hampton**

**USA · 1969 · Extrajudicial Killing**

Fred Hampton, 21-year-old chairman of the Illinois Black Panther Party, was killed in a pre-dawn raid by Chicago police on December 4, 1969. FBI informant William O'Neal, who served as Hampton's chief of security, provided the FBI with detailed floor plans of Hampton's apartment, identifying the specific wall behind which Hampton slept. Ballistic evidence showed Hampton was shot twice in the head at close range while lying in his bed. A survivor testified that Hampton appeared to be drugged — toxicology later confirmed Hampton had been sedated. Fourteen law enforcement officers fired approximately 98 rounds; the Panthers returned fire once. No officer was charged. A 1982 civil suit resulted in a $1.85 million settlement paid by the government.

*SOURCE: Jeffrey Haas, 'The Assassination of Fred Hampton: How the FBI and the Chicago Police Murdered a Black Panther' (Lawrence Hill Books, 2010). Church Committee records on COINTELPRO. Settlement: Hampton v. Hanrahan, 1982.*

**28. The Trail of Tears — Indian Removal Act**

**USA · 1830–1850 · Ethnic Cleansing**

The Indian Removal Act of 1830, signed by President Andrew Jackson, authorized the forced removal of the Five Civilized Tribes (Cherokee, Chickasaw, Choctaw, Creek, and Seminole) from their southeastern homelands to designated 'Indian Territory' west of the Mississippi. The Cherokee removal of 1838-1839 — conducted under military force after the Supreme Court ruled the removal unconstitutional in Worcester v. Georgia — killed between 4,000 and 8,000 Cherokee, approximately 25-35% of the removed population, through cold, disease, and starvation. President Andrew Jackson explicitly defied the Supreme Court ruling. The removal was preceded by the confiscation of Cherokee property, land, and livestock under Georgia state law.

*SOURCE: John Ehle, 'Trail of Tears: The Rise and Fall of the Cherokee Nation' (Anchor Books, 1988). Theda Perdue and Michael Green, 'The Cherokee Nation and the Trail of Tears' (Viking, 2007). Worcester v. Georgia, 31 U.S. 515 (1832). Jackson's stated defiance documented in multiple historical accounts.*

**29. Buffalo Extermination Policy — Deliberate Destruction of Plains Indian Civilization**

**USA · 1870–1890 · Deliberate Ecological and Cultural Destruction**

The near-total extermination of the American bison — from an estimated 30-60 million animals to fewer than 1,000 by 1890 — was not primarily a consequence of commercial hunting. It was the outcome of a deliberate U.S. government policy to destroy the economic and cultural foundation of Plains Indian civilization. General Philip Sheridan testified before Congress in 1875: 'For the sake of lasting peace, let them kill, skin and sell until the buffaloes are exterminated. Then your prairies can be covered with speckled cattle.' Secretary of the Interior Columbus Delano wrote in 1872 that destroying the buffalo was 'the easiest way to subjugate the Indian.' The Army provided hunters with rifles, ammunition, and logistical support.

*SOURCE: Andrew Isenberg, 'The Destruction of the Bison: An Environmental History, 1750-1920' (Cambridge University Press, 2000). Congressional Record, Sheridan testimony 1875. Delano papers, National Archives. Dan Flores, 'American Serengeti: The Last Big Animals of the Great Plains' (University Press of Kansas, 2016).*

**30. Indian Boarding School System — Cultural Genocide**

**USA · 1879–1978 · Forced Cultural Destruction and Documented Abuse**

The Indian boarding school system — operating under the founding philosophy of 'Kill the Indian, save the man' — forcibly removed Native American children from their families, prohibited their native languages and religious practices, cut their hair, renamed them, and attempted to permanently sever their connection to their cultural identities. The National Native American Boarding School Healing Coalition estimates over 400 schools operated across the United States, with over 50,000 children enrolled at peak. A May 2022 Department of the Interior investigative report identified 53 burial sites at former boarding school locations, with an estimated 50-53 schools having marked or unmarked burial sites. Sexual, physical, and psychological abuse was systematic. The last federally operated boarding school closed in 1978.

*SOURCE: Department of the Interior, 'Federal Indian Boarding School Initiative Investigative Report,' May 2022. Richard Pratt quoted in 'Kill the Indian, and Save the Man,' speech at the Nineteenth Annual Conference of Charities and Correction, 1892. Margaret Jacobs, 'White Mother to a Dark Race' (University of Nebraska Press, 2009).*

**31. Counterintelligence Actions Against the American Indian Movement**

**USA · 1972–1976 · COINTELPRO-Type Suppression**

The FBI conducted extensive COINTELPRO-style operations against the American Indian Movement (AIM) throughout the early 1970s. The period following the Wounded Knee occupation (1973) saw the killing of at least 60 AIM members and supporters on the Pine Ridge Reservation — a per capita murder rate the U.S. Civil Rights Commission reported as equivalent to a genocide. FBI informants actively participated in violence against AIM members. Leonard Peltier was convicted of the killing of two FBI agents in 1975 in a trial that Amnesty International, the United Nations Human Rights Committee, and former Prosecutor Lynn Crooks (who stated there was not enough evidence to convict Peltier) have described as a fundamental miscarriage of justice.

*SOURCE: Peter Matthiessen, 'In the Spirit of Crazy Horse' (Viking, 1983). U.S. Civil Rights Commission reports on Pine Ridge. Amnesty International reports on Leonard Peltier case. U.S. v. Peltier, 8th Circuit Court of Appeals records.*

**32. MKULTRA Subproject 68 — Ewen Cameron's 'Psychic Driving' Experiments**

**USA/CANADA · 1957–1964 · Non-consensual Human Experimentation**

Dr. Ewen Cameron, head of the psychiatry department at McGill University's Allen Memorial Institute in Montreal, conducted experiments funded by the CIA under MKULTRA Subproject 68. Cameron subjected patients — who had come to him seeking treatment for conditions like depression and anxiety — to prolonged drug-induced sleep (up to 65 days), repeated electroconvulsive therapy at up to 40 times normal intensity, sensory deprivation, and 'psychic driving' — the forced repetition of recorded messages up to 16 hours daily. His stated goal was to 'de-pattern' (destroy) existing personality structures and create blank-slate subjects. Several patients suffered permanent psychological damage and memory loss. Surviving victims sued the CIA and Canadian government; the CIA settled out of court. The Canadian government paid CAN$100,000 to each confirmed victim.

*SOURCE: Harvey Weinstein, 'Psychiatry and the CIA: Victims of Mind Control' (American Psychiatric Press, 1990). Anne Collins, 'In the Sleep Room: The Story of CIA Brainwashing Experiments in Canada' (Key Porter Books, 1988). Orlikow v. United States, D.D.C. 1987 (CIA settlement).*

**33. Operation Garden Plot — Civilian Control Planning**

**USA · 1968–Present · Classified Domestic Military Planning**

Garden Plot was a classified U.S. Army domestic operations plan for military control of civil disturbances, including the option of using Army units to suppress civilian protest movements. Variants of the plan were activated during the 1992 Los Angeles riots. Documents obtained through FOIA requests reveal that the plan included databases of suspected dissident organizations and individuals, and provisions for mass detention. The existence of FEMA's continuity of government plans — including provisions for suspending civil liberties and constitutional government in declared national emergencies — has been partially confirmed through congressional hearings. Representative Jack Brooks attempted to question Oliver North about a government plan to suspend the Constitution during the Iran-Contra hearings; he was gaveled down by committee chair Daniel Inouye.

*SOURCE: Frank Morales, 'U.S. Military Civil Disturbance Planning: The War at Home,' Covert Action Quarterly, Spring-Summer 2000. House Select Committee to Investigate Covert Arms Transactions with Iran hearing transcript, July 1987 (Brooks-Inouye exchange). FEMA documents obtained through FOIA requests.*

**34. DoD DARPA Funding of Gain-of-Function Research — EcoHealth Alliance**

**USA · 2014–2020 · Potentially Catastrophic Research Program**

The U.S. Defense Advanced Research Projects Agency (DARPA) and the National Institute of Allergy and Infectious Diseases (NIAID) under Dr. Anthony Fauci funded EcoHealth Alliance, which subcontracted with the Wuhan Institute of Virology (WIV) in China to conduct coronavirus research including gain-of-function experiments — research that enhances pathogen transmissibility or virulence. NIAID funding of EcoHealth/WIV totaled approximately $3.7 million from 2014-2019. In September 2021, NIH acknowledged that EcoHealth Alliance had conducted research that fit the definition of enhanced potential pandemic pathogen research, in contradiction of earlier Fauci testimony to Congress. A 2021 Senate subcommittee staff report found that the NIH violated its own policies in funding this research.

*SOURCE: Senate Health, Education, Labor, and Pensions Committee minority staff report, 'An Analysis of the Origins of the COVID-19 Pandemic,' October 2022. NIH letter to Representative James Comer, October 20, 2021. DARPA PREEMPT program documents obtained through FOIA.*

**35. NSA MUSCULAR — Joint U.S.-UK Interception of Google and Yahoo Internal Traffic**

**USA/UK · 2013 · Warrantless Mass Surveillance**

The NSA and GCHQ jointly collected data from Google and Yahoo's internal fiber optic links connecting overseas data centers — bypassing the legal process required for domestic collection — capturing hundreds of millions of records per day including email, documents, and communications metadata. The program was revealed by documents provided to the Washington Post by Edward Snowden in October 2013. The interception occurred outside U.S. legal jurisdiction at points where the companies' private internal networks crossed international territory, allowing collection without warrants or FISA court orders.

*SOURCE: Washington Post, 'NSA infiltrates links to Yahoo, Google data centers worldwide, Snowden documents say,' October 30, 2013. Barton Gellman and Ashkan Soltani reporting. NSA internal documents released by Edward Snowden.*

**36. Stateville Penitentiary Malaria Experiments**

**USA · 1944–1946 · Non-consensual Prisoner Experimentation**

Approximately 400 prisoners at Stateville Penitentiary in Joliet, Illinois were infected with malaria by researchers from the University of Chicago contracted by the U.S. Army to test antimalarial drugs. Prisoners were infected through mosquito bites and direct blood injection. The research was directed by Dr. Alf Alving and Dr. Nathan Smith. While prisoners technically 'consented,' the inherently coercive nature of prison conditions and the offer of reduced sentences made consent legally and ethically problematic. Time magazine ran a cover story in 1945 presenting the experiments approvingly. The experiments were cited at the Nuremberg Doctors' Trial by German defense attorneys to argue that American medical experimenters operated under the same standards as Nazi doctors — an argument the tribunal rejected.

*SOURCE: Allen Hornblum, 'Acres of Skin: Human Experiments at Holmesburg Prison' (Routledge, 1998). Andrew Conway Ivy, 'The History and Ethics of the Use of Human Subjects in Medical Experiments,' Science, 1948. Nuremberg Medical Trial records, U.S. Military Tribunal, Case 1.*

**37. Unit 731 Protection — U.S. Grant of Immunity to Japanese Biological Warfare Scientists**

**USA/Japan · 1945–1949 · Obstruction of Justice / War Crimes Cover-Up**

The United States granted immunity from war crimes prosecution to the scientists and officers of Unit 731 — the Japanese biological warfare research unit responsible for conducting lethal experiments on approximately 3,000-10,000 prisoners in Manchuria — in exchange for access to their experimental data. General Douglas MacArthur approved the immunity arrangement; the data was transferred to Fort Detrick, Maryland. The decision to protect war criminals was made explicitly on the grounds that the data was 'absolutely invaluable' and that the Soviet Union should not gain access to it. The arrangement meant that the perpetrators of documented medical atrocities equivalent to Nazi experiments faced no legal consequences.

*SOURCE: Sheldon Harris, 'Factories of Death: Japanese Biological Warfare, 1932-45, and the American Cover-Up' (Routledge, 1994). Hal Gold, 'Unit 731 Testimony: Japan's Wartime Human Experimentation Program' (Tuttle, 2011). SWNCC 351/1, September 1947 (U.S. policy document approving immunity).*

**38. CIA Support for the Chilean Coup and Pinochet Regime**

**USA/Chile · 1970–1989 · Foreign Government Destabilization and Support for Atrocities**

The CIA and State Department under Henry Kissinger conducted a two-track operation to prevent the democratic inauguration of Salvador Allende (Track I: political manipulation) and to support a military coup (Track II: direct coup planning) following Allende's election in September 1970. Following the September 11, 1973 coup by General Augusto Pinochet, in which Allende died, the Pinochet regime disappeared approximately 3,000 people, tortured at least 30,000, and imprisoned without trial over 80,000. Declassified State Department cables show Secretary Kissinger telling Pinochet in 1975: 'We are sympathetic with what you are trying to do here.' The CIA station in Santiago was in operational contact with Chilean DINA (secret police) and provided training and support.

*SOURCE: Peter Kornbluh, 'The Pinochet File: A Declassified Dossier on Atrocity and Accountability' (New Press, 2003). State Department cables declassified 2000-2004 at National Security Archive. Church Committee, 'Covert Action in Chile: 1963-1973,' 1975.*

**39. Fast and Furious — ATF Gun-Walking Operation**

**USA/Mexico · 2009–2011 · Criminal Government Arms Trafficking**

Operation Fast and Furious was a Bureau of Alcohol, Tobacco, Firearms and Explosives (ATF) operation in which agents deliberately allowed illegal gun sales to proceed — 'walked' approximately 2,000 firearms to Mexican drug cartels — with the stated intention of tracking the weapons to cartel leaders. The weapons were not successfully tracked. Approximately 700 of the weapons have been recovered at crime scenes in Mexico; at least 150 Mexicans and U.S. Border Patrol Agent Brian Terry were killed with Fast and Furious weapons. U.S. Attorney General Eric Holder was held in contempt of Congress for refusing to provide documents about the operation. The Department of Justice Inspector General found 14 individuals responsible for misconduct; none faced criminal charges.

*SOURCE: Department of Justice Inspector General, 'A Review of ATF's Operation Fast and Furious and Related Matters,' September 2012. House Committee on Oversight and Government Reform, 'The Department of Justice's Operation Fast and Furious,' June 2012. Eric Holder contempt resolution, U.S. House of Representatives, June 28, 2012.*

**40. CIA Rendition Program — Extraordinary Rendition to Torture States**

**USA · 2001–2007 · Facilitation of Torture**

The CIA's extraordinary rendition program transferred detainees — including individuals with no proven terrorist connections — to countries including Egypt, Jordan, Syria, Morocco, and Afghanistan where they were subjected to torture. The practice was authorized by a Presidential Finding signed by President Bush shortly after September 11. Khaled El-Masri, a German citizen, was kidnapped in Macedonia, transferred to a CIA black site in Afghanistan, and held for five months before being released on a roadside in Albania when the CIA realized it had the wrong man. El-Masri's case was ruled inadmissible in U.S. courts under the state secrets doctrine. The European Court of Human Rights found Macedonia responsible for his torture and awarded damages.

*SOURCE: Dana Priest, 'Wrongful Imprisonment: Anatomy of a CIA Mistake,' Washington Post, December 4, 2005. Open Society Foundations, 'Globalizing Torture: CIA Secret Detention and Extraordinary Rendition,' February 2013. El-Masri v. The Former Yugoslav Republic of Macedonia, European Court of Human Rights, December 13, 2012.*

**UNITED KINGDOM — OPERATIONS 41–58**

**41. Porton Down — Chemical Weapons Testing on Unwitting Soldiers**

**UK · 1916–1989 (ongoing research) · Non-consensual Human Experimentation**

The Chemical Defence Experimental Establishment at Porton Down, Wiltshire, conducted experiments on British service personnel using chemical warfare agents including mustard gas, sarin, and other compounds. Servicemen were recruited with assurances they were participating in research to cure the common cold. Ronald Maddison, a 20-year-old RAF mechanic, died in May 1953 after sarin was dripped onto his skin during an experiment. An inquest in 1953 returned a verdict of misadventure. A 2004 reinquiry returned a verdict of unlawful killing. The Crown Prosecution Service initially decided not to prosecute. Approximately 3,400 veterans received settlements from the Ministry of Defence in 2008 following a group action lawsuit.

*SOURCE: Evans, Rob, 'Gassed: British Chemical Warfare Experiments on Humans at Porton Down' (House of Stratus, 2000). Maddison inquest verdict, November 2004. Law Lords ruling: Maddison v. Ministry of Defence. MoD settlement announcement, January 2008.*

**42. Operation Gladio — UK Component of NATO Stay-Behind Network**

**UK/NATO · 1952–1990 (revealed 1990) · Covert Paramilitary Operation**

Operation Gladio was a NATO-wide program establishing secret paramilitary networks across Western Europe designed to conduct sabotage and resistance operations in the event of Soviet invasion. Italian Prime Minister Giulio Andreotti revealed Gladio's existence in 1990, triggering parliamentary investigations across Europe. The British component — codenamed Stay Behind — recruited and armed civilians across the UK and Northern Ireland, stockpiled weapons and explosives in secret caches, and maintained a covert command structure outside normal parliamentary oversight. In Belgium, elements linked to the Gladio network were implicated in the Brabant massacres (1982-1985), which killed 28 people. The European Parliament passed a resolution in 1990 condemning Gladio networks for terrorist activities.

*SOURCE: Daniele Ganser, 'NATO's Secret Armies: Operation Gladio and Terrorism in Western Europe' (Frank Cass, 2005). Italian Parliamentary Commission on Terrorism, Gladio Hearings, 1990. European Parliament Resolution on Gladio, November 22, 1990.*

**43. Bloody Sunday — British Army Massacre of Unarmed Civilians**

**UK/Northern Ireland · January 30, 1972 · State Murder**

On January 30, 1972, soldiers of the 1st Battalion Parachute Regiment opened fire on unarmed civil rights demonstrators in the Bogside area of Derry, Northern Ireland, killing 14 people (13 immediately, one later) and wounding approximately 15 more. The victims were shot in the back or while helping the wounded. An immediate inquiry by Lord Widgery (1972) largely exonerated the soldiers. After decades of campaigning by victims' families, the Saville Inquiry was established in 1998. Lord Saville's report, published in June 2010, concluded that all killings were unjustified, that soldiers had fired on civilians who posed no threat, that some victims were shot in the back while running away, and that the Army's later accounts were fabricated. Prime Minister David Cameron apologized to the families on behalf of the British government.

*SOURCE: The Report of the Bloody Sunday Inquiry (Saville Report), 10 volumes, June 2010. Available: gov.uk/official-documents. Prime Minister David Cameron's apology statement, June 15, 2010. Eamonn McCann, 'Bloody Sunday in Derry' (Brandon, 1992).*

**44. The Mau Mau — British Systematic Torture in Kenya**

**UK/Kenya · 1952–1960 · Systematic Torture and Detention Without Trial**

During the Mau Mau uprising in Kenya, British colonial authorities established a network of detention camps in which approximately 1.5 million Kikuyu people were detained, and an estimated 90,000 were executed, tortured, or maimed. Torture methods documented in colonial files and survivor testimony included castration, severe beating, forced labour, and sexual mutilation. The British government systematically destroyed colonial records prior to decolonization — Operation Legacy — but approximately 1,500 files were discovered in a Foreign Office secret archive in 2011. These documents confirmed systematic torture. In 2013, the British government agreed to pay £19.9 million in compensation to 5,228 Kenyan survivors — acknowledging that 'Kenyans were subjected to torture and other forms of ill treatment at the hands of the colonial administration.'

*SOURCE: Caroline Elkins, 'Imperial Reckoning: The Untold Story of Britain's Gulag in Kenya' (Henry Holt, 2005) — Pulitzer Prize winner. David Anderson, 'Histories of the Hanged: The Dirty War in Kenya and the End of Empire' (Norton, 2005). UK High Court ruling in Mutua & Others v. Foreign and Commonwealth Office, July 2011.*

**45. Bengal Famine of 1943 — Churchill's Deliberate Policy**

**UK/India · 1943 · Engineered Famine**

The Bengal Famine of 1943 killed between 2 and 3 million people in British India. Historian Madhusree Mukerjee's research, based on Colonial Office records, demonstrates that the famine was substantially caused and prolonged by wartime British policies: the denial policy (destroying boats and rice stocks to prevent Japanese use) eliminated Bengal's fishing and transportation capacity; exports of rice from India continued throughout the famine; Australian and Canadian offers of food aid were rejected; Churchill wrote dismissively on a telegram reporting Indian deaths: 'Why hasn't Gandhi died yet?' The famine coincided with record rice exports from India. Winston Churchill told the Secretary of State for India that the famine was the fault of Indians for 'breeding like rabbits.'

*SOURCE: Madhusree Mukerjee, 'Churchill's Secret War: The British Empire and the Ravaging of India During World War II' (Basic Books, 2010). Amartya Sen, 'Poverty and Famines: An Essay on Entitlement and Deprivation' (Oxford University Press, 1981). Colonial Office records, National Archives UK, CAB 66/39.*

**46. Operation Legacy — Systematic Destruction of Colonial Evidence**

**UK · 1957–1960s · Destruction of Evidence / Cover-Up**

Operation Legacy was a British government program to systematically destroy, remove, or withhold sensitive colonial government documents prior to granting independence to colonies, in order to prevent newly independent governments from accessing evidence of British atrocities, torture, political assassinations, and corruption. Approximately 200 boxes of files were physically destroyed or removed to Britain. Files were to be 'burned or packed and loaded onto ships.' In 2011-2012, the Foreign Office disclosed that approximately 1,500 files had been secretly maintained in a Foreign Office facility in Hanslope Park — including documents pertaining to torture in Kenya, Cyprus, Malaya, and other colonies. The disclosure came during the Mau Mau civil litigation.

*SOURCE: High Court ruling, Mutua v. FCO, 2011. Ian Cobain, 'The History Thieves: Secrets, Lies and the Shaping of a Modern Nation' (Portobello Books, 2016). Foreign and Commonwealth Office disclosure statements, 2011-2012. Guardian investigative reporting, Ian Cobain and Richard Norton-Taylor.*

**47. Amritsar Massacre — General Dyer's Orders**

**UK/India · April 13, 1919 · Mass Killing of Unarmed Civilians**

On April 13, 1919, Brigadier-General Reginald Dyer ordered his troops to fire on an unarmed crowd of approximately 15,000-20,000 civilians gathered in the walled garden of Jallianwala Bagh in Amritsar, Punjab, for a religious festival. The crowd was trapped; Dyer blocked the main exit with his troops. Soldiers fired approximately 1,650 rounds in approximately ten minutes. Official British figures stated 379 killed; the Indian National Congress reported 1,000 dead. Dyer testified that he fired to produce a 'moral effect' throughout Punjab and continued firing until ammunition was nearly exhausted. The Hunter Committee investigation censured Dyer; the House of Commons voted 230-129 to condemn him. The House of Lords voted to support him. A British fundraising campaign raised £26,000 for Dyer as a reward.

*SOURCE: Hunter Committee Report (Disorders Inquiry Committee), 1920. Nick Lloyd, 'The Amritsar Massacre: The Untold Story of One Fateful Day' (I.B. Tauris, 2011). Nigel Collett, 'The Butcher of Amritsar: General Reginald Dyer' (Continuum, 2005).*

**48. British Mustard Gas Experiments on Indian Soldiers — Rawalpindi**

**UK/India · 1942–1943 · Non-consensual Human Experimentation on Colonial Subjects**

British military researchers at the Rawalpindi military hospital in India conducted experiments on Indian soldiers using mustard gas, nitrogen mustard, and other chemical agents to investigate racial differences in chemical weapon vulnerability. Indian soldiers — who had not consented to experiments and were told only that they were assisting the war effort — were exposed to gas in chambers and had agents applied directly to their skin. The experiments specifically sought to determine whether 'Indian skin' was more or less susceptible to chemical agents than 'British skin.' Records of the experiments were classified and their existence was only fully established through investigative journalism in 2007.

*SOURCE: Rob Evans, 'Mustard Gas Experiments on Indian Soldiers,' The Guardian, September 1, 2007. Evans, 'Gassed: British Chemical Warfare Experiments on Humans at Porton Down' (2000). Documents obtained from UK National Archives by Evans under Freedom of Information Act.*

**49. British Torture in Cyprus — Emergency Period**

**UK/Cyprus · 1955–1959 · Systematic Torture**

During the Cyprus Emergency — the period of EOKA guerrilla fighting for union with Greece — British authorities operated interrogation centers where Cypriot detainees were systematically tortured. Methods documented in contemporary British medical reports and survivor testimony included severe beating, mock executions, sexual humiliation, and sustained stress positions. The Amnesty International report of 1958 described widespread torture. The documents were classified and remained so for decades. Cyprus's accession to the EU in 2004 and subsequent FOIA releases confirmed the systematic nature of the torture. The information was relevant to UK-Cyprus relations and was suppressed partly because of its implications for British rule of law claims.

*SOURCE: David French, 'Fighting EOKA: The British Counter-Insurgency Campaign on Cyprus, 1955-1959' (Oxford University Press, 2015). Amnesty International, 'Torture of Political Prisoners in Cyprus,' 1958. UK National Archives files, FCO 141 series, released under FOI.*

**50. The Zinoviev Letter — British Intelligence Forgery to Destroy Labour**

**UK · 1924 · Political Disinformation**

The Zinoviev Letter — a document purportedly from Grigory Zinoviev, head of the Communist International, instructing British Communists to agitate within the Labour Party and military — was published four days before the 1924 British general election, helping to destroy the Labour government of Ramsay MacDonald. The letter is now confirmed to have been a forgery, almost certainly produced by White Russian émigrés and passed to the Conservative Party and the Daily Mail through MI6. A 1999 Foreign Office investigation concluded the letter was almost certainly a forgery and that MI6 personnel had been aware of this at the time. The 1924 election resulted in a Conservative landslide; MacDonald's government fell.

*SOURCE: Gill Bennett, 'A Most Extraordinary and Mysterious Business: The Zinoviev Letter of 1924,' FCO Historians, History Note No. 14, 1999. Available: gov.uk/government/publications. Kevin Morgan, 'Ramsay MacDonald' (Haus Publishing, 2006).*

**51. Internment Without Trial — Northern Ireland**

**UK/Northern Ireland · 1971–1975 · Detention Without Trial and Torture**

Operation Demetrius, launched on August 9, 1971, rounded up 342 suspected IRA members for internment without trial. Fourteen of those detained were subjected to what became known as 'the five techniques': wall-standing (forced to stand against a wall in stress positions for up to 16 hours), hooding (black bags over heads for extended periods), continuous loud noise, sleep deprivation, and deprivation of food and water. The European Commission of Human Rights found in 1976 that Britain had practiced torture. The European Court of Human Rights found in 1978 that the techniques constituted 'inhuman and degrading treatment' but fell short of torture. Ireland reopened the case in 2014; in 2018 the Court revised its judgment, finding that the techniques did constitute torture.

*SOURCE: European Court of Human Rights, Republic of Ireland v. United Kingdom, Application No. 5310/71, January 18, 1978. Grand Chamber, 2018 revision. Ciaran de Baroid, 'Ballymurphy and the Irish War' (Pluto Press, 2000).*

**52. The Diego Chagos Islands — Forced Deportation of an Entire Population**

**UK · 1965–1973 · Ethnic Cleansing of British Subjects**

Between 1965 and 1973, the British government forcibly removed the entire population of the Chagos Islands — approximately 1,500 to 2,000 Chagossians, British subjects whose families had lived on the islands for five generations — to make way for a U.S. military base on Diego Garcia. British officials described Chagossians in internal documents as 'Tarzans or Men Fridays' who did not merit normal rights. They were transported to Mauritius and Seychelles with minimal compensation and left in poverty. A 1975 lawsuit in UK courts resulted in a settlement but not right of return. British courts subsequently ruled repeatedly that the Chagossians had been treated unlawfully; the British government has used Orders in Council to override these rulings. The International Court of Justice issued an advisory opinion in 2019 that the separation of Chagos from Mauritius had been unlawful.

*SOURCE: David Vine, 'Island of Shame: The Secret History of the U.S. Military Base on Diego Garcia' (Princeton University Press, 2009). ICJ Advisory Opinion on the Legal Consequences of the Separation of the Chagos Archipelago from Mauritius, February 25, 2019. R v Secretary of State for Foreign and Commonwealth Affairs, ex parte Bancoult, House of Lords, 2008.*

**53. Operation Keelhaul — Forced Repatriation of Soviet POWs to Death**

**UK/USA · 1945 · Forced Repatriation to Execution**

Operation Keelhaul was the Allied program, agreed at the Yalta Conference, to forcibly repatriate Soviet citizens — including prisoners of war, forced laborers, and civilians who had fled the Soviet Union — to the USSR, where the majority faced imprisonment, execution, or the Gulag. Estimates of the total number forcibly repatriated range from 2 to 5 million people. British soldiers physically forced Soviet citizens at bayonet point onto trains and boats, in some cases shooting those who resisted or attempted suicide to avoid repatriation. Thousands of Cossacks and White Russians who had never been Soviet citizens were repatriated in error. The British and American governments were aware that most returnees faced execution.

*SOURCE: Nikolai Tolstoy, 'The Secret Betrayal: 1944-1947' (Scribner, 1978). Julius Epstein, 'Operation Keelhaul: The Story of Forced Repatriation from 1944 to the Present' (Devin-Adair, 1973). House of Commons debates on the subject, 1970s-1990s.*

**54. British Nuclear Testing in Australia — Indigenous Land and People**

**UK/Australia · 1952–1957 · Environmental and Human Rights Violations**

Britain conducted 12 nuclear bomb tests at Maralinga, Emu Field, and the Monte Bello Islands in Australia between 1952 and 1957. Australian Aboriginal people — the traditional owners of the Maralinga and Emu Field sites — were not adequately warned or evacuated. Tests continued when Aboriginal people were detected in contaminated areas. Radioactive contamination of the Maralinga site was so severe that full remediation cost $108 million AUD and was not completed until 2000. Australian military personnel and civilians exposed to radiation developed elevated rates of cancer and other radiation-related illnesses. A 1985 Royal Commission found that the tests were conducted with 'reckless disregard' for the safety of those exposed.

*SOURCE: Australian Royal Commission into British Nuclear Tests in Australia (McClelland Report), 1985. Lorna Arnold, 'Britain and the H-Bomb' (Palgrave Macmillan, 2001). Department of Veterans' Affairs Australia, 'Compensation for Nuclear Test Veterans,' 1999.*

**55. The Belgrano Sinking — Cover-Up of Circumstances**

**UK/Argentina · May 2, 1982 · Alleged War Crime and Cover-Up**

The ARA General Belgrano, an Argentine cruiser, was sunk by HMS Conqueror on May 2, 1982, killing 323 Argentine sailors. The controversy centers on the circumstances: the Belgrano was approximately 200 miles south of the Falklands, outside the declared exclusion zone, and sailing away from the islands at the time it was sunk. Intelligence documents declassified years later confirmed the British government knew the ship's position and heading. Tam Dalyell MP, who pursued the issue for years, argued the sinking was ordered to prevent peace negotiations facilitated by Peru from proceeding. The British government systematically refused disclosure under official secrets provisions. Foreign Secretary Francis Pym later stated he had been about to accept a Peruvian peace plan when the sinking occurred.

*SOURCE: Tam Dalyell, 'Thatcher's Torpedo: The Sinking of the Belgrano' (Cecil Woolf, 1983). Desmond Rice and Arthur Gavshon, 'The Sinking of the Belgrano' (Secker & Warburg, 1984). Parliamentary debates and FOI releases 1982-2010.*

**56. Psychological Operations in Northern Ireland — Information Warfare**

**UK/Northern Ireland · 1970s–1990s · State Disinformation**

British military psychological operations units (Psyops) operating in Northern Ireland conducted extensive disinformation campaigns, produced fake IRA leaflets calling for violence, spread false stories attributing atrocities to Republican groups, and ran covert propaganda through front organizations. The Information Research Department (IRD), a Foreign Office propaganda unit, also operated in Northern Ireland. Colin Wallace, a former British Army information officer, provided extensive documentation of black propaganda operations he had conducted, including the production of forged documents linking Harold Wilson's government to Soviet intelligence. Wallace's allegations were largely confirmed by Lord Calcutt's investigation in 1990.

*SOURCE: Paul Foot, 'Who Framed Colin Wallace?' (Pan Books, 1990). Colin Wallace's submission to the Calcutt inquiry. Mark Urban, 'Big Boys' Rules: The SAS and the Secret Struggle Against the IRA' (Faber and Faber, 1992).*

**57. Suez Canal Crisis — Deception of Parliament and Allies**

**UK/France/Israel · 1956 · State Deception**

The Suez Crisis of 1956 involved Britain, France, and Israel in a secret conspiracy — documented in the Protocol of Sèvres, signed October 22-24, 1956 — in which Israel would invade Egypt, providing a pretext for Britain and France to intervene ostensibly as peacekeepers. Prime Minister Anthony Eden repeatedly and knowingly lied to the House of Commons about the existence of prior collusion with Israel. The Protocol of Sèvres was a signed document; Eden ordered all British copies destroyed. The French copy survived and was declassified in 1996. Eden's lies to Parliament were confirmed by all subsequent investigations. The operation collapsed under U.S. pressure and cemented Britain's status as a power dependent on American approval.

*SOURCE: Keith Kyle, 'Suez: Britain's End of Empire in the Middle East' (I.B. Tauris, 2003). The Protocol of Sèvres, French National Archives, declassified 1996. Selwyn Lloyd, 'Suez 1956: A Personal Account' (Jonathan Cape, 1978) — Lloyd admitted collusion.*

**58. GCHQ Mass Surveillance — Tempora and Upstream Collection**

**UK · 2003–Present (revealed 2013) · Unconstitutional Mass Surveillance**

GCHQ's Tempora program involved the mass interception of fiber-optic cables carrying internet traffic, allowing the collection of enormous volumes of communications data — described in internal documents as 'mastering the internet.' By 2012, GCHQ was collecting 21 petabytes of data per day. The Investigatory Powers Tribunal found in 2016 that GCHQ's collection and storage of bulk personal datasets had been unlawful for 17 years. The program was shared with NSA. GCHQ also operated the Karma Police program, which monitored every visible user on the internet — approximately 1.1 trillion metadata events per day by 2013.

*SOURCE: Glenn Greenwald, Ewen MacAskill, and Laura Poitras, reporting in The Guardian, June-August 2013. Investigatory Powers Tribunal ruling, December 2014 and February 2016. Ryan Gallagher, 'KARMA POLICE: Inside the Secret Program to Track Every Web User's Online Identities,' The Intercept, September 25, 2015.*

**STATE OF ISRAEL — OPERATIONS 59–65**

**59. Operation Suzannah / The Lavon Affair — Israeli False Flag Bombing in Egypt**

**Israel · 1954 · False Flag Terrorist Operation**

In 1954, Israeli military intelligence (Unit 131) recruited Egyptian Jews to plant bombs in Egyptian, American, and British targets in Egypt — cinemas, post offices, the U.S. Information Agency library — with the intent of framing Egyptian Muslim Brotherhood organizations and destabilizing Egypt's relationship with the United States and United Kingdom. The operation failed when one of the bombers was caught. The incident produced years of official denial by Israel; the existence of the operation was only officially acknowledged by Israel in 2005 when President Moshe Katsav presented certificates of appreciation to the surviving operatives. Defense Minister Pinhas Lavon claimed he had not authorized the operation (the 'Lavon Affair'); subsequent investigations found conflicting evidence.

*SOURCE: Aviezer Golan, 'Operation Susannah' (Harper & Row, 1978). Israeli government acknowledgment of surviving operatives, 2005. Ha'aretz coverage of official ceremony, July 2005. Robert Silverberg, 'If I Forget Thee O Jerusalem' (Morrow, 1970).*

**60. USS Liberty Attack — June 8, 1967**

**Israel · 1967 · Attack on Allied Military Vessel**

Israeli Air Force jets and torpedo boats attacked the USS Liberty, a clearly marked U.S. Navy intelligence ship operating in international waters during the Six-Day War, killing 34 American sailors and wounding 171 others. The attack lasted approximately two hours. The ship was flying a U.S. flag, was painted with identifying numbers, and Israeli reconnaissance planes had overflown it several times before the attack. President Johnson recalled fighter jets sent to assist the Liberty. The official U.S. and Israeli position is that the attack was a case of mistaken identity; all surviving senior Liberty officers, the Naval Attaché who investigated, and multiple subsequent independent investigations have rejected this. NSA analyst James Bamford's research using NSA intercepts found evidence that Israeli forces knew the ship was American.

*SOURCE: James Ennes Jr., 'Assault on the Liberty: The True Story of the Israeli Attack on an American Intelligence Ship' (Random House, 1980). James Bamford, 'Body of Secrets' (Doubleday, 2001). Report of the Independent Commission of Inquiry into the Israeli Attack on USS Liberty, 2003 — signed by former senior military officials including former Chairman of the Joint Chiefs Admiral Thomas Moorer.*

**61. Sabra and Shatila Massacre — 1982**

**Israel/Lebanon · 1982 · Facilitation of Mass Murder**

Between September 16-18, 1982, the Phalangist Lebanese Christian militia entered the Sabra and Shatila Palestinian refugee camps in West Beirut — which were surrounded and controlled by the Israeli Defense Forces (IDF) — and massacred between 800 and 3,500 Palestinian and Lebanese civilians, primarily women, children, and elderly men. IDF forces illuminated the camps with flares at night to assist the Phalangists and were aware of the massacre as it proceeded but did not intervene. The Israeli Kahan Commission of Inquiry (1983) found that Defense Minister Ariel Sharon bore 'personal responsibility' for the massacre and recommended his removal from office. Sharon was removed as Defense Minister but later became Prime Minister of Israel. The massacre is a war crime under international humanitarian law.

*SOURCE: Kahan Commission Report (Report of the Commission of Inquiry into the Events at the Refugee Camps in Beirut), February 1983 — official Israeli government document. Robert Fisk, 'Pity the Nation: Lebanon at War' (Andre Deutsch, 1990). Bayan Nuwayhed al-Hout, 'Sabra and Shatila: September 1982' (Pluto Press, 2004).*

**62. The Ringworm Children — Radiation Experiments on Mizrahi Jewish Children**

**Israel · 1950s · Non-consensual Human Experimentation on Ethnic Minority**

Between 1948 and 1960, the Israeli government, in collaboration with the U.S. government, irradiated approximately 100,000 Mizrahi (Middle Eastern and North African) Jewish immigrant children with X-rays at doses up to 35,000 times what is today considered safe, under the stated justification of treating tinea capitis (ringworm). The program was documented in a 2004 Israeli documentary 'The Ringworm Children.' Many children received no genuine medical treatment for ringworm; the irradiation was apparently used partly to collect data for U.S. military research on radiation effects. A significant number of the irradiated children developed cancers, epilepsy, and other radiation-related conditions. The Israeli government has paid limited compensation to survivors.

*SOURCE: 'The Ringworm Children' (documentary film), directed by David Belhassen and Asher Hemias, Dimona Productions, 2004. Barry Chamish, 'The Ringworm Children: Radiation of 100,000 Israeli Kids in the 1950s.' Ynet News (Israel) investigative reporting on compensation proceedings.*

**63. Yehuda Hiss and the Institute of Forensic Medicine — Organ and Tissue Harvesting**

**Israel · 1990s–2000s · Non-consensual Organ and Tissue Removal**

Dr. Yehuda Hiss, director of Israel's Abu Kabir Institute of Forensic Medicine, admitted in 2004 that the institute had for years taken skin, corneas, heart valves, and bones from the bodies of dead Israelis, soldiers, and Palestinians, and foreign workers without consent from families. The admission came after a Channel 2 investigation. In a 2009 interview with American academic Nancy Scheper-Hughes, Hiss reportedly acknowledged that the harvesting had occurred and that some parts were sold commercially. The affair produced significant controversy in Israel regarding medical ethics oversight. Hiss was removed from his position as head of the institute in 2011.

*SOURCE: Channel 2 (Israel) investigation, 2004. Donald Boström, 'Our Sons are Plundered of Their Organs,' Aftonbladet (Sweden), August 17, 2009 — this article was more widely disputed; the documented basis is Hiss's confirmed admissions. Nancy Scheper-Hughes interview with Hiss, documented in her academic work on global organ trafficking.*

**64. Operation Wrath of God — Extrajudicial Assassinations Post-Munich**

**Israel · 1972–1988 · State-Sponsored Assassination Program**

Following the murder of 11 Israeli athletes at the 1972 Munich Olympics, Prime Minister Golda Meir authorized the Mossad to hunt and kill the alleged planners. The operation, known as Wrath of God or Operation Bayonet, resulted in the assassination of approximately 20 people over 16 years. The operation killed Ahmed Bouchiki — a Moroccan waiter in Lillehammer, Norway — on July 21, 1973, after mistaking him for the target Ali Hassan Salameh. Six Mossad operatives were arrested by Norwegian police; the Norwegian court found the operation constituted murder. Norway formally protested to Israel; Israel paid compensation. The Lillehammer affair is documented in Norwegian judicial records. The broader assassination campaign's full scope has been partially confirmed by Israeli sources including Prime Minister Meir's memoirs.

*SOURCE: George Jonas, 'Vengeance: The True Story of an Israeli Counter-Terrorist Team' (Simon & Schuster, 1984) — basis for Spielberg's 'Munich.' Norwegian court judgment in the Bouchiki killing, 1973. Golda Meir, 'My Life' (Putnam, 1975) — acknowledges the operation.*

**65. Demolition of Palestinian Villages — 1948 and Ongoing**

**Israel · 1948–Present · Destruction of Cultural Heritage and Ethnic Displacement**

During and after the 1948 Arab-Israeli War, approximately 530 Palestinian villages were depopulated and approximately 418 were wholly or partially destroyed by Israeli forces. The events — known as the Nakba (catastrophe) — displaced approximately 700,000 Palestinians. Israeli historian Benny Morris, using newly declassified IDF archives, documented that a significant number of villages were destroyed by order or with the knowledge of IDF command, and that massacres occurred at Deir Yassin, Tantura, Saliha, and other locations. Morris's work, controversial in Israel, is based entirely on Israeli state archives. The forced displacement of Palestinians and destruction of villages is documented without dispute in terms of its scale; the classification of this as deliberate ethnic cleansing versus the consequences of war is debated by historians.

*SOURCE: Benny Morris, 'The Birth of the Palestinian Refugee Problem, 1947-1949' (Cambridge University Press, 1987; revised 2004). Ilan Pappe, 'The Ethnic Cleansing of Palestine' (Oneworld, 2006). Walid Khalidi (ed.), 'All That Remains: The Palestinian Villages Occupied and Depopulated by Israel in 1948' (Institute for Palestine Studies, 1992).*

**WW2 — GERMAN AND JAPANESE COMBINED (MAX 5): ENTRIES 66–70**

**66. Unit 731 — Japanese Biological Warfare and Human Experimentation**

**Japan · 1935–1945 · Mass Human Experimentation / War Crimes**

Unit 731 of the Imperial Japanese Army, based at Pingfang in Manchuria, conducted biological warfare research using living human subjects — Chinese, Korean, Soviet, and Allied prisoners of war — without anesthesia. Documented experiments included vivisection, pressure chamber experiments, frostbite experiments (limbs deliberately frozen and then warmed), weapons wound studies, biological agent infections (plague, cholera, typhoid, anthrax), blood removal to induce death, and the deliberate infection of civilian populations through contaminated wells, food drops, and direct release of plague-infested fleas. An estimated 3,000-10,000 people died in experiments. A further estimated 200,000-300,000 people died from biological warfare attacks on Chinese cities. As noted in Entry 37, U.S. authorities granted immunity to Unit 731 officers in exchange for the research data.

*SOURCE: Hal Gold, 'Unit 731 Testimony' (Tuttle, 2011). Sheldon Harris, 'Factories of Death' (Routledge, 1994). Yoshiaki Yoshimi, 'Comfort Women: Sexual Slavery in the Japanese Military During World War II' (Columbia University Press, 2000) for the comfort women aspect.*

**67. Nazi Hypothermia and Altitude Experiments — Dachau**

**Germany · 1942–1945 · Mass Human Experimentation / War Crimes**

Dr. Sigmund Rascher, working under Heinrich Himmler's patronage and claiming Luftwaffe research purposes, conducted hypothermia and high-altitude experiments on concentration camp prisoners at Dachau. Approximately 300 prisoners died in hypothermia experiments in which subjects were immersed in ice water or left outside in winter until unconscious or dead, with various body warming methods then attempted. High-altitude experiments placed subjects in pressure chambers and reduced pressure until unconsciousness and death, to study the effects on downed pilots. Rascher documented the experiments in reports to Himmler; these reports were captured by Allied forces and presented at the Nuremberg Doctors' Trial.

*SOURCE: Nuremberg Medical Trial records (U.S.A. v. Karl Brandt et al., 1946-1947). Robert Lifton, 'The Nazi Doctors: Medical Killing and the Psychology of Genocide' (Basic Books, 1986). Michael Moreno, 'The Nazi Doctors at Nuremberg,' New England Journal of Medicine, 1997.*

**68. Dr. Josef Mengele — Twin Experiments and Systematic Mutilation at Auschwitz**

**Germany · 1943–1945 · Mass Human Experimentation / War Crimes**

Dr. Josef Mengele, the 'Angel of Death' at Auschwitz-Birkenau, selected approximately 1,500 pairs of twins for medical experiments including: the injection of bacteria, typhus, and tuberculosis into healthy subjects; eye injections with dye to attempt to change iris color; surgical removal and grafting of organs and limbs without anesthesia; forced attempts to create conjoined twins by sewing twins together; and autopsies of killed subjects to study anatomy. Most twins died as a result of experiments or were killed when no longer useful. Mengele escaped to South America after the war, where he lived until his death in 1979. He was never captured or tried. His Argentine and Brazilian protectors included powerful political figures.

*SOURCE: Gerald Posner and John Ware, 'Mengele: The Complete Story' (McGraw-Hill, 1986). Lifton, 'The Nazi Doctors' (1986). Yad Vashem documentation of Mengele's activities. Simon Wiesenthal Center records.*

**69. Comfort Women — Japanese Military Sexual Slavery**

**Japan · 1932–1945 · Mass Sexual Slavery / War Crime**

The Japanese Imperial Army systematically coerced, recruited, and enslaved between 50,000 and 200,000 women — primarily Korean, Chinese, Filipino, and Dutch — as 'comfort women' (ianfu) to provide sexual services to Japanese soldiers throughout occupied Asia. Women were transported across the empire, held in 'comfort stations,' and subjected to repeated rape. Korean women were frequently recruited under false pretenses of factory work. Dutch civilian women in the Dutch East Indies were forced from civilian internment camps directly into military brothels. The Japanese government has acknowledged the existence of the system; the level of state involvement and military coercion in recruitment has been contested by Japanese revisionist historians but is well documented in both Japanese military archives and survivor testimony.

*SOURCE: Yoshimi Yoshiaki, 'Comfort Women: Sexual Slavery in the Japanese Military During World War II' (Columbia University Press, 2000). George Hicks, 'The Comfort Women: Japan's Brutal Regime of Enforced Prostitution in the Second World War' (Norton, 1994). U.N. Commission on Human Rights, 'Report on the Situation of Comfort Women,' 1996.*

**70. T-4 Euthanasia Program — Nazi Killing of Disabled Persons**

**Germany · 1939–1941 (official); continuing until 1945 · State Extermination Program**

The Aktion T4 program, authorized by Hitler's written order in October 1939 (backdated to September 1), systematically murdered German citizens classified as 'incurably ill' — people with mental illness, physical disability, epilepsy, or deemed 'useless eaters.' Approximately 70,000 people were killed in the first phase (1939-1941) using gas chambers — the same method later used in the Holocaust. The T4 program was halted in August 1941 following public protests by Bishop Clemens August Graf von Galen; killing continued through less visible methods ('wild euthanasia') through the war. The program served as a pilot for the Holocaust and used many of the same administrative personnel and killing methods.

*SOURCE: Michael Burleigh, 'Death and Deliverance: Euthanasia in Germany 1900-1945' (Cambridge University Press, 1994). Henry Friedlander, 'The Origins of Nazi Genocide: From Euthanasia to the Final Solution' (University of North Carolina Press, 1995). Bishop Galen's sermon texts, August 1941.*

**SOVIET UNION & RUSSIA — OPERATIONS 71–80**

**71. The Holodomor — Soviet Engineered Famine in Ukraine**

**USSR · 1932–1933 · Engineered Mass Starvation**

The Holodomor ('death by hunger') killed an estimated 3.5 to 7.5 million Ukrainians between 1932 and 1933 through a combination of impossible grain quotas, confiscation of all food from villages, internal passport restrictions preventing peasants from leaving their villages to seek food, and targeted punishment of Ukrainian cultural and intellectual elites. Stalin was warned repeatedly of mass starvation; the response was increased quotas. Peasants were blacklisted for failing to meet quotas; blacklisted villages received no outside food. Cannibalism was documented. The Ukrainian famine occurred simultaneously with Soviet grain exports. The Holodomor is recognized as genocide by Ukraine, the United States, and approximately 30 other countries; Russia disputes the genocide classification.

*SOURCE: Robert Conquest, 'The Harvest of Sorrow: Soviet Collectivization and the Terror-Famine' (Oxford University Press, 1986). Andrea Graziosi, 'The Soviet 1931-1933 Famines and the Ukrainian Holodomor: Is a New Interpretation Possible, and What Would Its Consequences Be?,' Harvard Ukrainian Studies, 2004-2005.*

**72. The Katyn Forest Massacre — NKVD Mass Execution of Polish Officers**

**USSR · April–May 1940 · Mass Execution of Prisoners of War**

The Soviet NKVD executed approximately 22,000 Polish military officers, police, intellectuals, landowners, and other 'anti-Soviet elements' in the Katyn Forest and other sites in spring 1940, following the Soviet invasion of eastern Poland in September 1939. The Soviets blamed the killings on Nazi Germany until 1990, when Soviet and then Russian authorities officially acknowledged NKVD responsibility. The order for the killings was signed by Stalin, Beria, Voroshilov, Anastas Mikoyan, and Vyacheslav Molotov — documented in a March 5, 1940 Politburo resolution declassified in 1990 from Soviet archives.

*SOURCE: J.K. Zawodny, 'Death in the Forest: The Story of the Katyn Forest Massacre' (University of Notre Dame Press, 1962). Soviet/Russian archival disclosure, 1990: Politburo resolution and NKVD execution orders. Allen Paul, 'Katyn: The Untold Story of Stalin's Polish Massacre' (Scribner, 1991).*

**73. Soviet Psychiatric Abuse — Punishing Dissidents with Fabricated Mental Illness**

**USSR · 1960s–1980s · Institutionalized Political Torture**

The Soviet psychiatric system, directed by Andrei Snezhnevsky, developed the diagnosis of 'sluggish schizophrenia' (vyalotekushchaya shizofreniya) — a condition with no parallel in Western psychiatry — which could be applied to anyone who challenged the Soviet system, on the theory that opposition to a perfect socialist system was inherently irrational and therefore symptomatic of mental illness. Dissidents, religious believers, and political opponents were committed to special psychiatric hospitals (psikhushki) administered by the Interior Ministry where they were subjected to forced drug treatment, including haloperidol injections designed to cause pain and disable resistance. Victims included general Pyotr Grigorenko, poet Natalia Gorbanevskaya, and Soviet dissident Viktor Nekipov. The World Psychiatric Association expelled the Soviet Psychiatric Association in 1983 for these practices.

*SOURCE: Sidney Bloch and Peter Reddaway, 'Psychiatric Terror: How Soviet Psychiatry Is Used to Suppress Dissent' (Basic Books, 1977). Robert van Voren, 'On Dissidents and Madness: From the Soviet Union of Leonid Brezhnev to the Soviet Union of Vladimir Putin' (Rodopi, 2009). World Psychiatric Association resolutions, 1983.*

**74. Biopreparat — Soviet Offensive Biological Weapons Program**

**USSR · 1973–1992 · Illegal Weapons Development in Violation of International Treaty**

Biopreparat was the Soviet Union's offensive biological weapons program, operating in explicit violation of the 1972 Biological Weapons Convention signed by the USSR. At its peak, Biopreparat employed approximately 60,000 scientists and technicians at facilities across the Soviet Union developing weaponized forms of smallpox, plague, anthrax, Marburg virus, and modified pathogens. The program was revealed by defectors including Col. Kanatjan Alibekov (Ken Alibek), Biopreparat's former deputy director, who testified before Congress and published a detailed account. Russia inherited the program; concerns about the fate of the pathogens developed by Biopreparat and their current location remain an active biosecurity issue.

*SOURCE: Ken Alibek with Stephen Handelman, 'Biohazard: The Chilling True Story of the Largest Covert Biological Weapons Program in the World' (Random House, 1999). Senate Armed Services Committee testimony, 1998. Anthony Rimmington, 'From Military to Industrial Complex? The Conversion of Biological Weapons Facilities in the Russian Federation,' Contemporary Security Policy, 1996.*

**75. The Gulag System — Soviet Network of Forced Labor Camps**

**USSR · 1918–1953 (peak); continuing until 1980s · Mass Incarceration and Forced Labor**

The Soviet Gulag (acronym for Chief Administration of Corrective Labor Camps) operated an estimated 476 distinct camp complexes across the USSR. Approximately 18 million people passed through the Gulag system between 1930 and 1953; an estimated 1.5-1.8 million died in the camps from cold, disease, malnutrition, and violence, with higher estimates ranging to 6 million. Camp inmates provided forced labor for Soviet industrialization — mining, logging, construction, and canal building. The White Sea-Baltic Canal was built by approximately 100,000 Gulag prisoners; approximately 25,000 died in its construction. Aleksandr Solzhenitsyn's three-volume Gulag Archipelago (1973, published in the West after he was expelled from the Soviet Union) is the most comprehensive personal literary account.

*SOURCE: Alexander Solzhenitsyn, 'The Gulag Archipelago' (Harper & Row, 1973). Anne Applebaum, 'Gulag: A History' (Doubleday, 2003) — Pulitzer Prize winner, based on Soviet archives opened in the 1990s.*

**76. Novichok Development — Chemical Weapons in Violation of CWC**

**Russia · 1970s–1980s; deployed 2018 · Illegal Weapons Development and Use**

The Soviet Union and subsequently Russia developed the Novichok class of nerve agents — the most lethal chemical warfare agents ever synthesized — in a program codenamed FOLIANT. The development continued after the USSR signed the Chemical Weapons Convention in 1993. Defector Vil Mirzayanov published details of the program in 1992 and was arrested; he was released after international pressure. In March 2018, Russian military intelligence (GRU) officers used Novichok A-234 to attempt to assassinate former GRU officer Sergei Skripal and his daughter in Salisbury, England, poisoning them and killing a British woman (Dawn Sturgess) who came into contact with discarded Novichok in a perfume bottle. The UK government publicly attributed the attack to the GRU. Russia denied involvement.

*SOURCE: Vil Mirzayanov, 'State Secrets: An Insider's Chronicle of the Russian Chemical Weapons Program' (2008). Organisation for the Prohibition of Chemical Weapons (OPCW) attribution reports, 2018. UK government statement attributing the Salisbury attack, March 2018.*

**77. Aral Sea Destruction — Soviet Engineering Catastrophe**

**USSR · 1960–Present · Environmental Atrocity**

Soviet irrigation projects in the 1960s-1980s diverted the Amu Darya and Syr Darya rivers — the primary water sources for the Aral Sea — to irrigate cotton fields in Uzbekistan and Kazakhstan. The Aral Sea, once the fourth-largest lake in the world, has shrunk by approximately 90% since 1960. The former sea bottom is now a salt desert from which toxic dust storms — carrying salt, pesticides, and agricultural chemicals deposited over decades — affect approximately 3 million people in the region with elevated rates of respiratory disease, cancer, tuberculosis, and infant mortality. The fishing industry that employed 60,000 people has been destroyed. Villages that once sat on the sea's shores are now 100+ km from water.

*SOURCE: Philip Micklin, 'The Aral Sea Disaster,' Annual Review of Earth and Planetary Sciences, 2007. UNEP, 'The Aral Sea Crisis,' 1993. William Wheeler, 'On the Brink: The Aral Sea,' ProPublica, 2015.*

**78. Alexander Litvinenko — State-Authorized Assassination with Nuclear Weapon**

**Russia · 2006 · State-Sponsored Murder with Nuclear Material**

Former FSB officer Alexander Litvinenko was poisoned with polonium-210 — a highly radioactive substance produced in nuclear reactors — in London on November 1, 2006, and died on November 23. Polonium-210 produces no radiation detectable by standard medical equipment; the cause of death was initially unknown. A UK public inquiry chaired by Sir Robert Owen found in January 2016 that Litvinenko's murder 'was probably approved by \[FSB Director\] Nikolai Patrushev and by Putin.' The two Russian nationals identified as the poisoners, Andrei Lugovoy and Dmitri Kovtun, have never been extradited and Lugovoy was subsequently elected to the Russian Duma.

*SOURCE: The Litvinenko Inquiry: Report into the death of Alexander Litvinenko (Owen Report), January 2016. Available: litvinenkoinquiry.org. Alex Goldfarb with Marina Litvinenko, 'Death of a Dissident' (Free Press, 2007).*

**79. Operation RYAN — Soviet Nuclear Alert and Near-Miss**

**USSR · 1981–1983 · Near-Catastrophic Military Miscalculation**

Operation RYAN (Raketno Yadernoe Napadenie — Nuclear Missile Attack) was a Soviet intelligence program that assumed U.S. plans for a nuclear first strike were imminent. KGB and GRU officers worldwide were tasked with monitoring indicators of pre-launch preparation. In November 1983, the NATO exercise Able Archer 83 — simulating nuclear release procedures with unusual authenticity — was interpreted by Soviet intelligence as a potential cover for a genuine first strike. Soviet nuclear forces were placed on alert. Western intelligence services learned only later how close the world had come to nuclear war based on a military exercise. The Able Archer crisis is documented in declassified U.S. and UK intelligence assessments from the period.

*SOURCE: Nate Jones (ed.), 'Able Archer 83: The Secret History of the NATO Exercise That Almost Triggered Nuclear War' (New Press, 2016). President's Foreign Intelligence Advisory Board, 'The Soviet War Scare,' February 1990 (declassified 2015). CIA historical review of Able Archer.*

**80. Soviet Radiation Experiments on Prisoners**

**USSR · 1950s–1970s · Non-consensual Human Experimentation**

Soviet authorities conducted radiation experiments on prisoners in the Soviet Gulag system, particularly at facilities in Siberia, to study radiation effects at various dosage levels. These experiments, less documented than American equivalents due to continued classification by Russian authorities, have been partially confirmed by defector testimony and post-Soviet archival research. Nuclear test participants — Soviet soldiers ordered to march through recently detonated test sites at Semipalatinsk and Novaya Zemlya — were not informed of radiation risks. Elevated cancer rates in affected areas and among test participants have been documented by Russian researchers.

*SOURCE: Kate Brown, 'Plutopia: Nuclear Families, Atomic Cities, and the Great Soviet and American Plutonium Disasters' (Oxford University Press, 2013). Zhores Medvedev, 'The Legacy of Chernobyl' (Norton, 1990). Russian Public Television documentary series on Semipalatinsk, 2009.*

**FRANCE — OPERATIONS 81–85**

**81. Nuclear Testing in Algeria and French Polynesia — Testing on Civilian Populations**

**France · 1960–1996 · Environmental and Human Harm from Weapons Testing**

France conducted 17 nuclear tests in the Algerian Sahara (1960-1966) and 193 tests in French Polynesia (1966-1996). Algerian populations, including nomadic Tuareg groups, were not adequately warned or evacuated. French soldiers were deliberately positioned near test sites to study radiation effects on personnel. In French Polynesia, approximately 110,000 people — French citizens — were exposed to radioactive fallout without adequate warning. A 2006 French Senate report estimated that 110 of the 193 Pacific tests had produced significant radioactive fallout on inhabited areas. France adopted a compensation law in 2010 for civilian and military victims of French nuclear testing, but set such high standards of proof that few claims were initially approved.

*SOURCE: French Senate report, 'Nuclear tests: For a Recognition of the Rights of Victims,' 2006. Bruno Barrillot, 'Nuclear Veterans: French Nuclear Tests and Their Effects' (Bureau of Nuclear Information, 2009). Compensation law: Loi n° 2010-2 du 5 janvier 2010.*

**82. Operation Satanique — French Intelligence Bombing of Rainbow Warrior**

**France · 1985 · State-Sponsored Terrorism Against Allied Nation**

On July 10, 1985, French DGSE (Direction générale de la sécurité extérieure) agents planted two bombs on the Greenpeace ship Rainbow Warrior in Auckland Harbour, New Zealand, sinking it and killing photographer Fernando Pereira. The ship had been en route to protest French nuclear testing at Mururoa Atoll. The operation was authorized at the highest levels of the French government; French Defense Minister Charles Hernu later resigned over the affair. Two DGSE agents were arrested in New Zealand, convicted of manslaughter, and sentenced to 10 years imprisonment. France pressured the UN Secretary-General to arbitrate; the agents served three years on a French military base before being returned to France. France paid $8.16 million in compensation to Greenpeace and $2.3 million to Pereira's family.

*SOURCE: David Robie, 'Eyes of Fire: The Last Voyage of the Rainbow Warrior' (Lindon Publishing, 1986). New Zealand government judicial records. French government compensation agreement with Greenpeace, 1987.*

**83. French Systematic Torture in Algeria — the Algerian War**

**France/Algeria · 1954–1962 · Systematic State Torture**

The French military systematically tortured Algerian prisoners during the 1954-1962 War of Independence. Methods documented in French military reports, survivor testimony, and accounts by French soldiers including torture by electric shock (the gégène), drowning (quasi-waterboarding), burning, and summary execution. General Paul Aussaresses published a memoir in 2001 ('Services Speciaux: Algérie 1955-1957') explicitly acknowledging that he had personally ordered and conducted torture and summary executions during the war, and expressing no remorse. He was stripped of his Legion of Honour but was not criminally charged for the murders due to a 1968 amnesty law. He died in 2013.

*SOURCE: Paul Aussaresses, 'The Battle of the Casbah: Terrorism and Counter-Terrorism in Algeria 1955-1957' (Enigma Books, 2002). Marnia Lazreg, 'Torture and the Twilight of Empire: From Algiers to Baghdad' (Princeton University Press, 2008). Raphaëlle Branche, 'La Torture et l'Armée pendant la Guerre d'Algérie' (Gallimard, 2001).*

**84. French Complicity in the Rwandan Genocide**

**France/Rwanda · 1990–1994 · Complicity in Genocide**

France provided military support, training, intelligence, and political cover to the Hutu-dominated Rwandan government of Juvénal Habyarimana throughout the early 1990s and during the 1994 genocide itself. French troops under Operation Noroît (1990) directly supported government forces against the Tutsi-led Rwandan Patriotic Front. During the genocide, France maintained relations with the genocidal government while the RPF attempted to halt the killings. France's Operation Turquoise (June 1994) created a 'safe zone' in southwestern Rwanda that multiple researchers and the Rwandan government have argued protected genocidaires rather than victims. A 2021 report by a French commission of historians found that France bore 'heavy and overwhelming' responsibilities for the genocide.

*SOURCE: Commission de Recherche sur les Archives Françaises relatives au Rwanda et au génocide des Tutsi (Duclert Commission), 'La France, le Rwanda et le génocide des Tutsi,' April 2021. Alison Des Forges, 'Leave None to Tell the Story: Genocide in Rwanda' (Human Rights Watch, 1999). Philip Gourevitch, 'We Wish to Inform You That Tomorrow We Will Be Killed With Our Families' (Farrar, Straus and Giroux, 1998).*

**85. French Indochina — Suppression of Vietnamese Independence**

**France/Vietnam · 1945–1954 · Colonial Warfare and Atrocities**

Following World War II, France sought to reassert colonial control over Indochina despite the declaration of Vietnamese independence by Ho Chi Minh on September 2, 1945 — immediately after Japan's surrender. The First Indochina War (1946-1954) resulted in approximately 400,000 Vietnamese and 100,000 French and allied deaths. French forces conducted systematic destruction of villages, mass executions, and use of napalm against civilian areas. The French defeat at Dien Bien Phu in May 1954 ended the war. The subsequent partition of Vietnam at Geneva, with American support for the South Vietnamese government, directly created the conditions for the American war in Vietnam.

*SOURCE: Fredrik Logevall, 'Embers of War: The Fall of an Empire and the Making of America's Vietnam' (Random House, 2012) — Pulitzer Prize. Bernard Fall, 'Street Without Joy: The French Debacle in Indochina' (Stackpole, 1961).*

**BELGIUM AND CONGO — OPERATIONS 86–89**

**86. Leopold's Congo Free State — The First Documented Genocide of the Modern Era**

**Belgium/Congo · 1885–1908 · Mass Murder / Genocide / Forced Labor**

King Leopold II of Belgium operated the Congo Free State (1885-1908) as his personal property, establishing a forced rubber collection system enforced by a terror regime: failure to meet rubber quotas resulted in the severing of hands — or those of family members, including children — by agents of the Force Publique. An estimated 10 million Congolese died from direct murder, starvation, disease, and exhaustion under Leopold's regime — reducing Congo's population by approximately half. The atrocities were documented by missionary E.D. Morel and British consul Roger Casement, whose reports triggered an international campaign. Leopold never faced legal accountability. He died wealthy and was succeeded by Belgium, which took over the colony. The Congo Free State was the origin of the term 'crimes against humanity.'

*SOURCE: Adam Hochschild, 'King Leopold's Ghost: A Story of Greed, Terror, and Heroism in Colonial Africa' (Houghton Mifflin, 1998). Roger Casement, Consul General's Report on the Congo, 1904 (UK Foreign Office document). E.D. Morel, 'Red Rubber: The Story of the Rubber Slave Trade Flourishing on the Congo in the Year of Grace 1906' (1906).*

**87. Belgian Complicity in the Assassination of Patrice Lumumba**

**Belgium/Congo · 1960–1961 · State-Sanctioned Assassination**

Patrice Lumumba, the first democratically elected Prime Minister of the Democratic Republic of Congo, was overthrown in a coup on September 14, 1960 — in which both Belgium and the CIA were involved — arrested, and murdered on January 17, 1961. Belgian police officers were present at Lumumba's execution. His body was dissolved in acid by a Belgian officer (Gerard Soete) who later admitted in interviews that he kept Lumumba's teeth as souvenirs. A Belgian parliamentary commission of inquiry in 2001 concluded that Belgium bore a 'moral responsibility' for Lumumba's death. The Belgian government formally apologized to the DRC in June 2002. One of Lumumba's teeth was returned to his family by the Belgian government in June 2022.

*SOURCE: Ludo de Witte, 'The Assassination of Lumumba' (Verso, 2001) — triggered the Belgian parliamentary inquiry. Belgian Parliamentary Commission Report, 2001. Guardian, 'Belgium returns Lumumba's gold tooth,' June 2022.*

**88. Belgian Participation in Rwandan Genocide Preconditions — Radio des Mille Collines**

**Belgium/Rwanda · 1993–1994 · Failure to Act Against Genocide**

Radio Télévision Libre des Mille Collines (RTLM), the Rwandan radio station that broadcast explicit calls for Hutu to murder Tutsi and moderate Hutu — directly inciting the 1994 genocide that killed approximately 800,000-1,000,000 people in 100 days — was partially funded by Belgian businessmen. Belgium had been the colonial power in Rwanda and had issued identity cards categorizing Rwandans by ethnic group — a classification system that the genocidaires used to identify victims. The Belgian-imposed ethnic classification system is documented as a key enabling infrastructure of the genocide. Belgian U.N. peacekeepers withdrew from Rwanda when ten Belgian soldiers were killed — a withdrawal that removed the last practical protection for civilians.

*SOURCE: Des Forges (1999) cited above. Mahmood Mamdani, 'When Victims Become Killers: Colonialism, Nativism, and the Genocide in Rwanda' (Princeton University Press, 2001). U.N. Security Council records on UNAMIR withdrawal.*

**89. Belgian Uranium from Congo — Enabling Hiroshima and Nagasaki**

**Belgium/Congo/USA · 1940–1945 · Extraction of Material Used in Weapons of Mass Destruction**

The uranium used in the first atomic bombs dropped on Hiroshima and Nagasaki was extracted from the Shinkolobwe mine in the Belgian Congo. The mine, operated by Union Minière du Haut Katanga, supplied approximately 1,200 tons of uranium ore to the Manhattan Project. Congolese miners worked in highly radioactive conditions with no protective equipment, receiving minimal compensation, to extract the material. The Belgian government and Union Minière were aware the material would be used for a weapon. The uranium deal was negotiated in secret by Belgian government-in-exile officials and American officials during World War II. The human cost to Congolese miners and their families from radiation exposure has never been assessed.

*SOURCE: Susan Williams, 'Spies in the Congo: America's Atomic Mission in World War II' (PublicAffairs, 2016). Jonathan Helmreich, 'Gathering Rare Ores: The Diplomacy of Uranium Acquisition, 1943-1954' (Princeton University Press, 1986). Manhattan Project historical records, NARA.*

**CANADA — OPERATIONS 90–93**

**90. Project MKULTRA Canada — Ewen Cameron and CIA-Funded Torture at McGill**

**Canada/USA · 1957–1964 · Non-consensual Human Experimentation**

As documented in Entry 32 for the American component, Dr. Ewen Cameron conducted CIA-funded torture experiments at McGill University's Allan Memorial Institute in Montreal. The Canadian government, through the Defence Research Board, contributed funding to Cameron's research independently of the CIA connection. When the CIA component was revealed in the late 1970s, the Canadian government initially denied knowledge. Nine Canadian victims sued the Canadian government and CIA; the CIA settled out of court in 1988. The Canadian government paid CAN$100,000 to each confirmed victim in 1994. A 2017 documentary confirmed additional victims beyond those compensated.

*SOURCE: Anne Collins, 'In the Sleep Room' (1988). Harvey Weinstein, 'Psychiatry and the CIA' (1990). Government of Canada compensation announcement, 1994.*

**91. Indigenous Residential Schools in Canada — Cultural Genocide**

**Canada · 1876–1996 · Forced Cultural Destruction and Systematic Abuse**

Canada operated a residential school system for Indigenous children from 1876 until 1996, forcibly removing children from their families to schools operated primarily by Catholic, Anglican, United, and Presbyterian churches. The Truth and Reconciliation Commission of Canada (TRC), which concluded its work in 2015, documented systemic physical, sexual, and psychological abuse; prohibition of Indigenous languages and cultural practices; malnourishment; and at least 4,100 deaths (with more likely due to incomplete records). The TRC concluded that the residential school system constituted cultural genocide. In 2021, unmarked graves were discovered at sites of former residential schools across Canada, with over 1,300 confirmed as of 2023.

*SOURCE: Truth and Reconciliation Commission of Canada, 'Honouring the Truth, Reconciling for the Future: Summary of the Final Report,' 2015. Murray Sinclair (TRC Chair) statements. John Milloy, 'A National Crime: The Canadian Government and the Residential School System' (University of Manitoba Press, 1999).*

**92. Nutritional Experiments on Indigenous Children in Residential Schools**

**Canada · 1942–1952 · Non-consensual Human Experimentation on Children**

Canadian government researchers, led by nutritionist L.B. Pett of the Department of Pensions and National Health, used Indigenous children in residential schools as subjects for nutritional experiments from 1942 to 1952. Children at six residential schools were divided into control and experimental groups; the experimental groups received vitamin and mineral supplements while control groups received deliberately inadequate nutrition. No consent was sought from children or their families. Dental care was deliberately withheld from some children to study the effects of nutritional deficiency on teeth. The experiments were conducted with the knowledge of the Department of Indian Affairs and were published in peer-reviewed journals at the time.

*SOURCE: Ian Mosby, 'Administering Colonial Science: Nutrition Research and Human Biomedical Experimentation in Aboriginal Communities and Residential Schools, 1942-1952,' Histoire Sociale/Social History, 46:91, May 2013. National Archives of Canada, RG 29 (Department of Health records).*

**93. Sixties Scoop — Forced Removal of Indigenous Children**

**Canada · 1960s–1980s · Forced Removal of Children from Families**

The Sixties Scoop was the mass removal of Indigenous children from their families by provincial child welfare authorities from the 1960s to the 1980s, placing them with non-Indigenous families in Canada, the United States, and Europe. An estimated 20,000 children were removed. The policy was implemented without the knowledge or consent of Indigenous communities or the children. Children lost cultural identity, language, and family connections. A 2016 federal court ruling found that the Canadian government had breached its fiduciary duty to Indigenous peoples through the Sixties Scoop. In 2018, the federal government reached a $750 million settlement agreement with Sixties Scoop survivors.

*SOURCE: Raven Sinclair, 'Identity Lost and Found: Lessons from the Sixties Scoop,' First Peoples Child and Family Review, 2007. Brown v. Canada (2017), Ontario Superior Court. Federal government settlement announcement, November 2017.*

**SOUTH AFRICA AND OTHERS — OPERATIONS 94–100**

**94. Project Coast — South African Chemical and Biological Weapons**

**South Africa · 1981–1993 · Illegal Weapons Development and Targeted Assassination**

Project Coast was the South African apartheid government's secret chemical and biological weapons program, operated under the direction of Dr. Wouter Basson, nicknamed 'Dr. Death.' The program developed weapons including cholera-contaminated water supplies used against ANC camps in Mozambique; MDMA-laced drinks intended to incapacitate anti-apartheid activists; paralyzing toxins in sugar and cigarettes; anthrax distributed in envelopes; beer laced with botulinum toxin; and oral cholera infected with an experimental substance. Basson was tried in South Africa for 67 charges including murder, fraud, and drug trafficking; he was acquitted in 2002 in a controversial verdict. The Truth and Reconciliation Commission documented the program.

*SOURCE: Chandré Gould and Peter Folb, 'Project Coast: Apartheid's Chemical and Biological Warfare Programme' (UNIDIR, 2002). Marlene Burger and Chandré Gould, 'Secrets and Lies: Wouter Basson and South Africa's Chemical and Biological Weapons Programme' (Zebra, 2002). TRC of South Africa Special Report.*

**95. Apartheid-Era Forced Sterilization and Medical Abuses**

**South Africa · 1970s–1990s · Coerced Medical Procedures**

Under apartheid, South African health authorities conducted forced and coerced sterilization of Black and Coloured women, particularly in public hospitals. Women were sterilized without consent following childbirth, often while sedated. State hospitals systematically denied pain relief to Black patients as policy. Medical experimentation using Black patients as subjects without informed consent was documented by anti-apartheid medical researchers. The apartheid military also used the health system to develop means of controlling non-white population growth.

*SOURCE: Trudy Thomas et al., 'No Need to Talk About It: Silence Around Sterilisation in South Africa,' African Sociological Review, 2001. Physicians for Human Rights, 'Dual Loyalty and Human Rights in Health Professional Practice,' 2002.*

**96. Spanish Baby Theft — Franco's Stolen Children**

**Spain · 1940–1980s · State-Organized Child Trafficking**

Under the Franco regime and continuing for decades after Franco's death in 1975, an estimated 300,000 babies were stolen from their parents in Spain. Doctors and nuns told parents — primarily unmarried women, the poor, and Republican families — that their babies had died at birth; the babies were given to 'morally appropriate' (Francoist Catholic) families. The program began as ideological purification under Franco — removing children from 'Red' families — and evolved into a profitable black market in newborns operated by elements of the Catholic Church and medical establishment. The practice continued into the 1980s with no ideological justification, pure profit motive. The Spanish Association of Robbed Babies (Asociación Nacional Afectados Adopciones Irregulares) has documented thousands of cases.

*SOURCE: Paloma Aguilar, 'Memory and Amnesia: The Role of the Spanish Civil War in the Transition to Democracy' (Berghahn Books, 2002). El País and BBC investigative reporting, 2011-2012. Judge Baltasar Garzón investigations, 2009-2010.*

**97. Australia — The Stolen Generations**

**Australia · 1910–1970 · Forced Removal of Indigenous Children**

From approximately 1910 to 1970, Australian state and federal governments systematically removed Aboriginal and Torres Strait Islander children from their families under policies designed to eliminate Aboriginal culture through assimilation. An estimated 10-33% of all Aboriginal children born during this period were removed. Children were placed in church or government institutions and with non-Indigenous families, were forbidden to speak their languages, and were denied information about their families and origins. The 1997 Bringing Them Home report documented the trauma and concluded that the forced removal program constituted genocide under the UN Convention on the Prevention and Punishment of the Crime of Genocide. Prime Minister Kevin Rudd formally apologized in February 2008.

*SOURCE: 'Bringing Them Home: National Inquiry into the Separation of Aboriginal and Torres Strait Islander Children from Their Families,' Australian Human Rights and Equal Opportunity Commission, 1997. Prime Minister Kevin Rudd, Apology to Australia's Indigenous Peoples, February 13, 2008.*

**98. Chinese Organ Harvesting from Falun Gong and Uyghur Prisoners**

**China · 2000–Present · Non-consensual Organ Removal from Living Prisoners**

An independent tribunal chaired by Sir Geoffrey Nice QC — who prosecuted Slobodan Milosevic at the International Criminal Court — concluded in June 2019, after taking evidence from medical professionals, former prisoners, and investigative researchers, that China had conducted and was continuing to conduct the systematic killing of prisoners of conscience — primarily Falun Gong practitioners and Uyghur Muslims — for the purpose of harvesting their organs for transplantation. The evidence included: China's transplant waiting times (days to weeks, versus years in other countries); the expansion of transplant facilities; large-scale blood testing of prisoner populations; testimony from former prisoners; and forensic and documentary evidence compiled by David Kilgour and David Matas.

*SOURCE: China Tribunal, Final Judgment and Summary, June 17, 2019. Available: chinatribunal.com. David Kilgour and David Matas, 'Bloody Harvest: The Killing of Falun Gong for Their Organs,' 2006 (updated 2016). David Kilgour, David Matas, and Ethan Gutmann, 'Bloody Harvest / The Slaughter: An Update,' 2016.*

**99. Dutch East India Company — The Banda Islands Massacre**

**Netherlands/Indonesia · 1621 · Colonial Genocide**

In 1621, VOC (Dutch East India Company) Governor-General Jan Pieterszoon Coen conducted a military campaign to enforce a monopoly on nutmeg, a spice then worth more than gold in Europe. The indigenous Bandanese population — who had resisted the monopoly and sold nutmeg to English and other traders — was systematically massacred. The Banda Islands' population of approximately 15,000 was reduced to approximately 600 survivors through direct killing, slavery, and flight. Surviving Bandanese were enslaved to work the nutmeg plantations. This is the first documented example of a European colonial company committing genocide for commercial monopoly purposes.

*SOURCE: Giles Milton, 'Nathaniel's Nutmeg: How One Man's Courage Changed the Course of History' (Hodder & Stoughton, 1999). Vincent Loth, 'Armed Incidents and Unpaid Bills: Anglo-Dutch Rivalry in the Banda Islands in the Seventeenth Century,' Modern Asian Studies, 1995. VOC records in the Dutch National Archives.*

**100. The Sackler Family and Purdue Pharma — Deliberate Engineering of the Opioid Epidemic**

**USA · 1995–2019 · Corporate-Government Collusion in Mass Poisoning**

Purdue Pharma, controlled by the Sackler family, introduced OxyContin in 1995 with a deliberate marketing campaign based on the false claim that the drug's extended-release formulation made it resistant to abuse. Internal documents revealed in litigation show that Purdue's own researchers knew by 1997 that OxyContin was being widely crushed and snorted for a faster high. Sales representatives were instructed to assure doctors that addiction was rare — a claim not supported by evidence. Purdue paid more than $9 billion in settlements and pleaded guilty to criminal charges including conspiracy to defraud the United States. The opioid epidemic has killed over 500,000 Americans since 1999. The FDA official who approved OxyContin (Curtis Wright) took a job at Purdue immediately after approval.

*SOURCE: Patrick Radden Keefe, 'Empire of Pain: The Secret History of the Sackler Dynasty' (Doubleday, 2021). Barry Meier, 'Pain Killer: A Wonder Drug's Trail of Addiction and Death' (Rodale, 2003). Purdue Pharma plea agreement, U.S. Department of Justice, October 2020.*
