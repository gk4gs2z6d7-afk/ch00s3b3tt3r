# The Debt Machine

*How Financial Architecture Was Built to Keep You Compliant*

**Kai Jashon Price** · Structural Humanism Series — Document II · 2025
— structuralhumanism.com —

---

## The Oldest Weapon After Division

Debt is older than money. David Graeber's archaeological and anthropological research in Debt: The First 5,000 Years established that early human economies operated on flexible social obligations — systems of mutual aid and reciprocal exchange. Debt became a weapon at the precise historical moment it was made impersonal, quantified with interest, and enforced by violence. Once a human obligation could be converted into a number and that number could be separated from any relationship or context, it became the ideal control mechanism: self-enforcing, morally compelling, and infinitely scalable.

**The moral language of debt — "you owe," "you are responsible," "you agreed to this" — is the most successful ideological achievement in human history. It converts the victims of structural exploitation into sinners who deserve their condition.**

The pattern repeats from ancient Mesopotamia to modern Phoenix: a person in medical debt who cannot pay is not a victim of a system designed to extract maximum value from their illness. They are someone who failed to budget properly. A nation that borrowed from Western banks to pay reparations to the people who enslaved them — as Haiti did for 122 years — is not a victim of financial imperialism. It is simply a country that needs better fiscal management. The moral language makes the structural machinery invisible.

*SOURCE: Graeber, D. (2011). Debt: The First 5,000 Years. Melville House. | New York Times Haiti investigation (May 2022).*

## Jekyll Island: The Meeting That Created the Federal Reserve

In November 1910, a group of men traveled in a private railcar from New Jersey to Jekyll Island, Georgia under assumed names. They had been instructed to tell no one where they were going or what they were doing. They stayed for nine days and produced the document that became the basis for the Federal Reserve Act of 1913.

This is not theory. Frank Vanderlip, Vice President of National City Bank and one of the attendees, described the meeting in a 1935 article in the Saturday Evening Post: "I was as secretive — indeed, as furtive — as any conspirator. Discovery, we knew, simply must not happen, or else all our time and effort would be wasted. If it were to be exposed publicly that our particular group had gotten together and written a banking bill, that bill would have no chance whatever of passage by Congress."

The attendees represented the Rockefeller banking interests, the Morgan banking interests, the Kuhn Loeb banking interests, and the U.S. Treasury. The result was a central banking system whose governance structure placed private banking interests in permanent structural influence over American monetary policy — a system in which the regional Federal Reserve Banks are owned by their member commercial banks, in which those banks appoint six of the nine directors of each regional bank, and in which the Chairman of the Federal Reserve is a presidential appointee who requires Senate confirmation but whose institution operates outside the annual appropriations process. Precision matters here: the Fed's financial statements are audited annually by an independent firm and the Government Accountability Office audits most of its operations — but its monetary policy deliberations are exempt from GAO review by statute, and its regional banks remain owned by the member banks they oversee. The carve-out is narrower than the slogan “audit the Fed” implies, and more revealing: the one function shielded from review is the one that moves trillions.

**The Federal Reserve is not a government agency in the way the Department of Education or the Department of Defense is a government agency. Its regional banks are privately owned. The arrangement's designers understood that if this were publicly known, it would not survive democratic scrutiny — which is why the meeting that created it was conducted under assumed names.**

*SOURCE: Vanderlip, F. (February 9, 1935). Farm Boy to Financier. Saturday Evening Post. | Greider, W. (1987). Secrets of the Temple: How the Federal Reserve Runs the Country. Simon & Schuster. | Federal Reserve Act legislative history (1913).*

## Haiti and the 122-Year Debt: What Financial Imperialism Looks Like

In 1804, Haiti became the first nation in history founded by people who had freed themselves from slavery through revolution. The slaveholders of Saint-Domingue lost their "property." France, which had owned the colony, demanded compensation.

In 1825, France sent warships to Port-au-Prince and offered a choice: pay reparations of 150 million gold francs — to the slaveholders, for the loss of the enslaved people Haiti's revolution had freed — or face a naval blockade and renewed warfare. Haiti paid. It borrowed from French banks to do so. Haiti finished paying this debt in 1947 — 122 years after the initial demand, and 143 years after the revolution that supposedly ended slavery on the island.

A New York Times investigation published in 2022 calculated the total value of these payments in contemporary terms at over $21 billion. The investigation documented that the debt payments directly constrained Haiti's ability to invest in infrastructure, education, and economic development for more than a century — and that the cycle of borrowing to make debt payments created subsequent debt cycles with American banks after France was paid off. The poorest nation in the Western Hemisphere is poor in large part because it was the first to free itself and was made to pay for that freedom for 122 years.

*SOURCE: New York Times Haiti investigation: "The Ransom" (May 20, 2022). | Dubois, L. (2012). Haiti: The Aftershocks of History. Metropolitan Books.*

## The Petrodollar: How Oil Keeps the Dollar Dominant and Wars Predictable

Following the collapse of the Bretton Woods gold standard in 1971, the Nixon administration negotiated agreements with Saudi Arabia in 1973-1974 establishing that Saudi oil — and subsequently all OPEC oil — would be priced exclusively in U.S. dollars. In exchange, the United States guaranteed Saudi security. The arrangement created permanent structural demand for the dollar: any nation that needs to purchase oil must first acquire dollars, creating a global captive market for American currency that enables deficit spending without the currency devaluation that would otherwise follow.

The intervention argument must be stated with its counterexamples, because critics will state them if this document does not. Iraq moved its oil sales to euros in 2000 and was invaded in 2003. Gaddafi promoted a gold-backed pan-African currency and was deposed in a 2011 NATO operation. But Iran has priced oil outside the dollar for years without invasion; Venezuela launched an oil-backed currency and met sanctions, not soldiers; Russia has aggressively de-dollarized its energy trade. Two confirming cases alongside three disconfirming ones do not establish that currency choice causes intervention — and this document does not claim it does.

**What the record does establish is the structural fact: every nation that buys oil must first hold dollars, the United States uniquely benefits from that arrangement, and American financial and military power are the arrangement's ultimate guarantors. Whether any single war was “about” the dollar is theory. Who benefits from the dollar's position, and who underwrites it, is not in question.**

*SOURCE: Spiro, D.E. (1999). The Hidden Hand of American Hegemony: Petrodollar Recycling and International Markets. Cornell University Press. | Greider, W. (1987). Secrets of the Temple.*

## Student Debt: The System Working as Designed

The American student loan system was restructured through a series of legislative changes beginning in the 1990s that removed standard consumer protections from student loans: they cannot be discharged in bankruptcy, they are subject to wage garnishment without court order, and the interest accrues during periods of deferment. These are not features of a lending system designed to help people access education. They are features of a lending system designed to ensure maximum extraction from people who borrowed at eighteen to access an economy that told them a degree was the entrance requirement.

A twenty-four-year-old in Chicago graduated from a state university in 2019 with $58,000 in student loan debt for a degree that qualified him for positions paying $35,000 per year. He is paying interest faster than principal. By the mathematical structure of his loan, he will be paying into his fifties for an education whose economic return was sold to him at eighteen on the basis of projections that did not hold. This is not personal failure. It is the designed output of a system in which the financial industry successfully lobbied to remove consumer protections from the one category of debt that accrues to people before they have the economic experience to evaluate the terms.

Total U.S. student debt: $1.77 trillion. Total annual interest revenue generated: approximately $85 billion. Total spent on lobbying to prevent bankruptcy protections from being restored to student loans: documented through FEC records at OpenSecrets.org. The arithmetic is public. The correlation is visible.

*SOURCE: Federal Reserve Student Debt Data (2024). | OpenSecrets.org student loan industry lobbying records. | Consumer Financial Protection Bureau annual reports.*

## The Compound Interest Trap and How It Scales

Compound interest is the mechanism by which debt grows faster than the ability to repay it when the interest rate exceeds income growth. At 7% interest on $58,000 of student debt with a $35,000 income, approximately $4,060 accrues in interest annually. A borrower paying $300 per month — which represents 10% of gross income, the standard "affordable" threshold — pays $3,600 per year. The debt grows. This is not an accident of math. It is math deployed deliberately against people whose income growth cannot outpace the interest rate.

The same mechanism operates in medical debt, credit card debt structured for minimum payments, and payday lending. The common feature: lending products designed so that the minimum viable participation level does not reduce principal. The architecture ensures that the most economically vulnerable participants — those who can only afford minimum payments — never escape the product. They are not customers in the normal sense. They are revenue streams.

*SOURCE: Federal Reserve Bank of New York (2024). Quarterly Report on Household Debt and Credit. | CFPB Payday Lending Research (2016).*

## What Can Actually Be Done

Three legislative changes would structurally alter the debt architecture without requiring constitutional amendment. First: restore standard bankruptcy protections to student loans. This single change — returning student debt to the same legal status it held before 1976 — would immediately alter the risk calculus of lenders and reduce predatory loan origination without costing the government a dollar. Second: allow Medicare to negotiate pharmaceutical prices. The CBO has estimated this saves hundreds of billions over a decade. The prohibition exists because of lobbying, not economics. Third: impose an interest rate cap on consumer lending products — the same cap that military families already receive under the Military Lending Act, which caps interest at 36% for servicemembers. Extending that cap to all consumers would end the most predatory lending products overnight.

None of these requires the abolition of capitalism or the Federal Reserve. All of them require organized political pressure sufficient to outweigh the lobbying investment of the industries that benefit from the current arrangement. That is a winnable fight — because the people harmed by the current arrangement vastly outnumber the people who benefit from it. The only thing that prevents the majority from winning it is the tribal division documented in the first paper of this series.
