# Choose Better

*A Structural Humanism Manifesto · Master Book Manuscript*

**Kai Jashon Price** · The Book Project · 2025–2026
— structuralhumanism.com —

---

-   Introduction — Choose Better

**Part One — How Control Operates**

-   Chapter 1 — The Oldest Trick

-   Chapter 2 — The Leash You Cannot See

-   Chapter 3 — The Permitted Narrative

-   Chapter 4 — The Great Consolidation

**Part Two — The History You Were Not Taught**

-   Chapter 5 — Sacred or Convenient

-   Chapter 6 — The Dollar and the Dead

-   Chapter 7 — Blowback and Immunity

-   Chapter 8 — September 11: The Documented Record

**Part Three — The Systems That Drain Us**

-   Chapter 9 — The Most Profitable Patient

-   Chapter 10 — The Accounting

-   Chapter 11 — The Relentless Current

-   Chapter 12 — The Men at the Controls

**Part Four — The Civilization We Could Be**

-   Chapter 13 — The Civilization We Could Be Choosing

-   Conclusion — We Are Not Stupid, We Are Managed

**Back Matter**

-   Five Things You Can Do This Week

-   Recommended Reading

-   Bibliography

-   Glossary

-   Index

-   A Final Note

**Choose Better**

*A Reckoning with the Systems That Divide Us*

*and the Civilization We Still Have Time to Build*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

**Author's Note and AI Drafting Disclosure**

This book was written by me. I conceived its argument, organized its structure, chose its sources, made its moral judgments, and bear sole responsibility for its claims. I also used artificial intelligence tools as drafting and editorial assistants — to compress passages from earlier essays, check phrasing, format citations, and pressure-test arguments against their strongest counterarguments. Every factual claim has been checked against a public, verifiable source. Where evidence is contested or partial, I say so in the text. Where my earlier drafts overreached, I have softened the claim or removed it. Where the evidence is stronger than I once thought, I have strengthened the claim.

I do not believe this disclosure damages the work. I believe the opposite. Readers deserve to know how a book was made. The argument stands on its sources, not on its author. If a reader disagrees, I want her to disagree with the sources I cite, not with anything I assert without them.

Two principles run through the chapters that follow. The first is that the target is the pattern, not the people. Concentrated power, weakly supervised, behaves predictably across regimes, religions, ethnicities, and parties. To describe that behavior is not an attack on any group; it is the precondition of self-government. The second is that the standard for what I include is documentary. I prefer declassified federal records, peer-reviewed scholarship, on-record statements by the people directly involved, and mainstream investigative journalism with sourcing I can read. Where I rely on inference, I name the inference as inference. Where I am uncertain, I say so.

The book is pro-accountability, pro-transparency, pro-democratic responsiveness, pro-human dignity. It is not anti-government, not anti-American, not anti-religious. It is a sustained argument that a country wealthy enough to behave better is morally obliged to choose to.

**Introduction**

*September 12, the Water, and the Argument of This Book*

**The water**

There is a parable David Foster Wallace told a graduating class at Kenyon College in 2005. Two young fish are swimming along and meet an older fish. The older fish nods and says, “Morning, boys. How is the water?” The two young fish swim on. Eventually one of them looks at the other and says, “What the hell is water?”

The parable is the precondition of this book. The water is what you do not see because you are inside it. The water is the assumption that the way things are is the way things have to be. The water is what makes the strangeness of being alive feel normal and what makes the cruelty of certain arrangements feel like weather rather than choice. The cost of an insulin vial does not feel like a political decision; it feels like the price of insulin. The way a single algorithm decides which neighbor you fear today does not feel like an editorial choice; it feels like what your neighbor is doing. The fact that three asset-management firms vote roughly a quarter of all shares at the largest American companies does not feel like an oligarchy; it feels like nothing at all, because nobody told you about it.

I am going to ask you to do one thing while you read what follows. I am going to ask you to notice the water. Not to escape it — you cannot escape it. To see it. Seeing it changes nothing externally. Seeing it changes everything internally. That is where the work of citizenship begins, and that is the only honest place to start a book of this kind.

◆ ◆ ◆

**September 12**

The clearest evidence about what Americans are capable of when the water is briefly disturbed is the morning of September 12, 2001.

By that morning, the World Trade Center had been a smoking ruin for less than twenty-four hours. The first thing many people did was line up at blood banks. The second thing was stop fighting strangers. The American Association of Blood Banks recorded an unprecedented surge in donations — so large that an estimated 250,000 of the 475,000 units collected in the days immediately after the attacks were ultimately unused and had to be discarded, because the wounded survivors of the towers were so few. The desire to help vastly exceeded the survivable injuries. People drove across state lines to give blood for the dead because they did not yet know the dead were dead, and because they needed to do something. Conservative congressmen stood on the Capitol steps singing “God Bless America” alongside the colleagues they had spent the previous summer accusing of treason. Strangers held strangers in train stations. The country I was later told was too divided to ever stand together — too racist, too partisan, too estranged across class and creed — stood together. Imperfectly, briefly, and not for every person; but unmistakably.

I am not romanticizing it. There were ugly responses on September 12, too — toward Muslims, toward Sikhs, toward anyone read as foreign. The Council on American-Islamic Relations documented 1,717 reported bias incidents against Muslims and people perceived as Muslim in the first six months following the attacks, including assaults, harassment, vandalism, and the murder of Balbir Singh Sodhi, a Sikh gas-station owner shot dead in Mesa, Arizona on September 15. The point is not that everyone behaved well. The point is that the dominant register of public life was solidarity, and that the solidarity was specifically wider than the tribes the political system normally trades in.

Eighteen months later, that solidarity had been converted into a war against a country that had not attacked us, on the basis of intelligence the Senate Select Committee on Intelligence in its July 2004 report, and the Robb–Silberman Commission in its March 2005 report, both later confirmed was either wrong at the time it was used or unsupported by the underlying intelligence the analysts had in front of them. The Senate report concluded that “most of the major key judgments in the Intelligence Community’s October 2002 National Intelligence Estimate either overstated, or were not supported by, the underlying intelligence reporting.” No senior policymaker faced criminal charges. By 2004 we hated each other again — more bitterly, with fewer shared facts and almost no curiosity about what had happened to the September 12 version of ourselves.

> *The September 12 version of America was the real one. The version we got back to was the managed one.*

That is the moral anchor of this book. I am not arguing that human beings have no real differences. We do. I am not arguing that every disagreement is artificial. Many are sincere. I am arguing that the level, texture, and persistence of hostility in American public life exceeds what ordinary disagreement, on its own, would produce — and that the gap between what we are capable of and what we settle for is not a natural fact about us. It is a managed condition. The management is documented. It is the subject of this book.

◆ ◆ ◆

**Structural humanism**

The framework I use to describe that management is structural humanism. Its core position is simple. Contemporary American crises are not isolated failures but interlocking systems of managed division, economic extraction, historical amnesia, and institutional impunity, and ordinary people are still capable of building something better before catastrophe forces the change on them. Structural humanism is not a partisan brand. It is a description of how power behaves when concentrated and weakly supervised, and a moral demand that a country wealthy enough to do better stop pretending it cannot.

I call it structural because the focus is on arrangements rather than on individuals. The Federal Reserve, the Telecommunications Act of 1996, the Bankruptcy Abuse Prevention and Consumer Protection Act of 2005, the Bork doctrine in antitrust, Section 230 of the Communications Decency Act, the Patriot Act, the post-Bork merger waves in airlines and banking, the index-fund revolution in asset management — these are not the names of villains. They are the names of legal and institutional structures within which villains and saints alike act, and within which the predictable outcome is the one we are now living through. Specific people made specific decisions to build each of these structures. Specific people benefit from them today. But the analysis that produces durable change is structural, not personal. You do not solve the problem of a poisoned river by punishing each fish.

I call it humanism because the test of every institution, every law, every system is the same: does it serve the dignity, agency, and material well-being of the actual human beings whose lives it touches, or does it serve something else? When a healthcare system bankrupts the patients it cures, it is failing the humanist test. When a media system rewards the content most likely to make a teenage girl hate her body, it is failing the humanist test. When a financial system collapses, gets bailed out by the public, distributes bonuses to the people who caused the collapse, and forecloses on the homes of the people who paid the bailout, it is failing the humanist test. When a foreign policy kills more people than the attack it was retaliating for and creates the next generation of attackers in the process, it is failing the humanist test. The test is not whether an institution is profitable, or efficient, or modern, or globally respected. The test is whether the human beings inside it are being treated as ends or as raw material.

Structural humanism is also constructive. The first half of this book is diagnostic — what the water is, how it was engineered, who pays the price. The second half is reconstructive — what a humane civilization actually looks like in practice, the evidence that comparable arrangements already function in other countries and in other American cities, and the concrete civic mechanisms ordinary citizens can use to move us toward them. The two halves are inseparable. Diagnosis without reconstruction breeds cynicism. Reconstruction without diagnosis breeds sentiment. The work requires both.

The destination of the argument is peaceful cooperation — within communities, across the historical fractures American power has refused to address honestly, and between nations that currently choose perpetual rivalry. Cooperation is not the same as agreement. It is the disciplined posture of people who have decided that human dignity, democratic accountability, and the survival of a livable civilization are worth more than the comforts of tribal grievance. The path is moral and practical at once. It is the only path the evidence, taken together, can support.

◆ ◆ ◆

**The architecture of this book**

The book has four parts. Part One maps the mechanisms of control — manufactured division, debt as governance, narrowed information, and the consolidation of corporate ownership into a small number of hands. Part Two revisits the historical record those mechanisms help obscure — the political histories of sacred texts, the petrodollar order, the long tail of covert intervention, and the documented public record of September 11. Part Three examines the domestic systems that drain us — extractive healthcare, militarized public finance, the civic toolkit citizens still hold, and the contemporary men consolidating technological power. Part Four describes the civilization we could be choosing, and is followed by a short conclusion and a practical back matter for readers who want to act this week.

Three things I will do consistently, and I want you to know about them in advance. First, I will pull citations into the prose so you can check them. The format is publication, year, author, finding. When I write that airline routes with common Big Three ownership exhibited price elevation of three to seven percent, I will tell you in the same sentence that the finding is from Azár, Schmalz, and Tecu, writing in the Journal of Finance in 2018. You will not need to flip to a footnote to know where a claim came from. Second, I will follow every major argument with an explicit COUNTERARGUMENT block and a WHY THIS DOES NOT SAVE THE FRAMING reply. The strongest version of the counterargument, not a straw man. The strongest version of the counterargument is what an honest book owes its reader. Third, I will use numerical tables, charts, and timelines so the quantitative scaffolding of the argument is visible to you, not just to me. The numbers do the load-bearing work in a book like this. They should be visible.

A related discipline of voice. I use the first person because this is, in the end, a book by a person rather than by an institution, and I would rather a reader know who is making the argument than be addressed by an anonymous “we.” I am not a credentialed scholar. I am an independent journalist who has spent more than a year reading the primary documents that fill the bibliography at the back of this book. The expertise here is not mine; it belongs to the historians, economists, jurists, doctors, and reporters whose work I cite. My job is to assemble their work into a coherent diagnosis and a constructive answer. The arguments stand on their evidence. They do not stand on me.

One thing I will not do. I will not flatter the reader. The argument of this book is that a public capable of seeing structural arrangements clearly is also a public capable of changing them, and that means I owe you the evidence and not the comfort. If a passage is difficult, it is difficult because the underlying fact is difficult. If a chapter is uncomfortable, the discomfort is the point. The water is uncomfortable. We have been pretending otherwise for a long time.

A word on standard. This book is journalistic. It is built on declassified federal records, peer-reviewed scholarship, on-record statements of the people directly involved, and mainstream investigative journalism whose sourcing you can audit. Where evidence is contested, I will say so. Where my earlier drafts overreached, I have softened or removed the claim. My ambition is for the book to be hard to dismiss — not because of rhetoric, but because the documentary record stands behind every major claim. If a reader disagrees, I want her to disagree with the sources I cite, not with anything I assert without them.

◆ ◆ ◆

**What is and is not in this book**

Because this is the consolidated edition of work that has been in development for more than a year, and because earlier drafts contained material I have since revised or removed, the reader is owed an explicit account of what is in this book and what is not.

What is in the book. The documented behavior of concentrated economic, political, military, and informational power in the contemporary United States, evaluated against the standard of human dignity. The historical record of how that power was assembled. The empirical evidence on what the present arrangement costs the people living under it. A constructive proposal for what a humane reordering would look like, modeled on arrangements that already function elsewhere. A practical civic toolkit for citizens who want to act.

What is not in the book. Three categories of material have been deliberately excluded. The first is the Lincoln Greenback theory of the American Civil War — the claim that Lincoln was assassinated for issuing fiat currency in defiance of foreign bankers. The historical record does not support the claim as fact. It appears in this book, where it appears at all, only labeled explicitly as a personal hypothesis I find compelling but cannot demonstrate. The second is the canonical antisemitic citation set of selected Talmudic passages — Sanhedrin 57a, Bava Kamma 113a, Soferim 15:10, Yebamoth 98a, Kerithoth 6b, and Gittin 57a as a combined set. That specific selection traces through Eisenmenger’s Entdecktes Judenthum of 1700, Elizabeth Dilling’s mid-twentieth-century compilations, and modern white-nationalist republications. I have written about religious manipulation — it is the subject of Chapter 5 — but the manipulation argument must be made through comparative-traditions framing, through the history of canonical formation across faiths, through the documented Zoroastrian sources of Second Temple apocalyptic literature per the scholar Mary Boyce, through David Norton’s textual history of the 1611 King James Bible as a state translation project, and through the archaeological record of the development of Israelite religion in William Dever’s and Mark S. Smith’s scholarship. To borrow the antisemites’ citation set is to inherit their argument. I will not. The third is the Rothschild–Balfour conspiracy framing. The correct historical fact is that Arthur Balfour addressed his November 1917 declaration to Lord Walter Rothschild because Rothschild was the recognized leader of the British Jewish community at the time, not because of any banking conspiracy. The declaration matters because of its political content, not because of the identity of its addressee.

I list these exclusions in the introduction because I believe a reader has a right to know, at the front of a book, what the author has chosen not to defend. There is a kind of writing that smuggles unprovable claims past the reader by burying them in apparently well-evidenced surrounding material. I have tried not to write that book. The evidence in this book is overwhelming without those three categories. Including them would weaken the work.

◆ ◆ ◆

**On the people who appear in these pages**

Specific people appear in this book by name. Some of them are dead. Some of them are alive, powerful, and well-resourced for litigation. I have tried throughout to apply the same standard: name the person where the public record names them, attribute the act to the documented record rather than to inference, distinguish allegation from finding of fact, and prefer the citation a reader can verify over the colorful detail a reader cannot. In the chapters dealing with active legal matters — the Annie Altman lawsuit in Chapter 12, the foreign-influence material in Chapter 7 — the discussion is framed inside a clear LEGAL DISCLAIMER box and inside the standard journalistic architecture of allegation, denial, procedural posture, and finding.

I have also tried throughout to honor a distinction the political class would prefer the public not draw clearly: the distinction between criticism of an institution’s documented behavior and prejudice against the people who happen to belong to that institution or to a group culturally associated with it. To write that the unregistered foreign-influence operation of the American Israel Public Affairs Committee, traced through the 1962–1963 Fulbright hearings and the 2008 declassification of relevant Foreign Agents Registration Act records, deserves the same enforcement attention as the foreign-influence operations of Saudi Arabia, Qatar, Turkey, the United Arab Emirates, the People’s Republic of China, and the Russian Federation, is not antisemitism. It is consistent application of the Foreign Agents Registration Act, 22 U.S.C. §§ 611–621, to all comparable conduct. The chapter is explicit about that distinction. I am explicit about it here.

◆ ◆ ◆

**A note on the moment we are in**

This book is being completed in 2026, in a moment of unusual public exhaustion. The second Trump administration is consolidating executive power in ways the post-Watergate framework was designed to prevent. The Federal Reserve is managing the aftermath of a multi-decade asset bubble. The Israeli–Palestinian war in Gaza continues to produce documented atrocities at a scale the international press has, after a long delay, begun to report honestly. The American press is contracting at a rate that has reduced full-time local newsroom employment by more than half since 2008, according to Pew Research Center figures. The leading frontier-AI laboratories are deploying systems whose downstream consequences neither their builders nor their critics can fully predict, and are doing so under a regulatory architecture that does not yet exist.

These are not separate stories. They are the same story. Concentrated power, weakly supervised, producing predictable outcomes. The most useful thing a reader can take from this book is not a list of villains. It is a method — a way of looking at the front page of any newspaper and asking, with the help of the historical and structural literature catalogued in the bibliography at the back, who benefits from the arrangement being described and who pays for it. That method does not require a credential. It requires only the willingness to notice the water.

> *We are not stupid. We are managed. The difference matters, because the first is fatal and the second is fixable.*

The book is long because the subject is large. It is documented because the subject is contested. It is constructive because the alternative is despair, and despair is the one response to the present arrangement that the present arrangement counts on. The argument of every chapter that follows reduces, in the end, to a single sentence. The water is not weather. It was built. It can be built differently.

What follows is how.

**Part One**

*How Control Operates*

Four chapters on the mechanisms of managed division, financial extraction, information control, and the consolidation of corporate ownership into a small number of hands. The structural logic that runs underneath everything that follows.

**Chapter 1**

*The Oldest Trick*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

**The question**

Every durable hierarchy in human history has had to solve the same problem. What happens when the people living under it begin to recognize their shared interests more clearly than the identities that divide them? The answer ruling classes have arrived at, in every era, is the same. You make sure they never do. You intensify the identities — tribe, nation, sect, race, party — that compete with shared interest. You organize conflict around those identities. Then you step back and let the public exhaust itself fighting while the decisions of lasting consequence happen elsewhere.

That is the oldest trick. It is older than the United States. It is older than capitalism. It is, on the documentary record, older than any political system that has left a written record. The Roman governors of Judea practiced it. The British colonial administration in India practiced it, as the Hindu–Muslim partition of 1947 made unforgettable. The Belgian colonial administration in Rwanda practiced it on Hutu and Tutsi populations, with consequences the world finally noticed in 1994. The United States Senate Select Committee to Study Governmental Operations — the Church Committee — documented in 1976 that the Federal Bureau of Investigation had practiced it against American citizens for fifteen years. Facebook’s own internal researchers documented in 2018 that the company’s ranking algorithm was practicing it on American voters, and that the company had been informed of the finding, and had chosen not to act.

The level of tribal hostility in contemporary American life is not the natural baseline of human nature. It is a managed condition. The management is documented. This chapter is about how.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: is the intensity of American polarization the natural state of a free society, or has it been cultivated by institutions that benefit from keeping people divided?

Thesis, in one sentence: a significant share of contemporary division is engineered, by state and corporate actors, through tools whose effects we can measure.

The strongest documentary evidence for the state actor is COINTELPRO, the FBI’s Counterintelligence Program. It ran from 1956 to 1971. Its existence and methods were officially confirmed by the U.S. Senate Select Committee to Study Governmental Operations — the Church Committee — which released its findings in 1976 across multiple volumes. The internal FBI memoranda are public and you can read them. They state explicitly that the program’s goal was to “prevent the rise of a ‘messiah’” who could “unify and electrify” Black-led movements, and to disrupt civil rights, antiwar, Black nationalist, American Indian, Puerto Rican independence, and women’s liberation organizations through forged letters, fabricated affairs, planted informants, anonymous tips to spouses and employers, and selective leaks to police. The primary source citation is the Church Committee’s Final Report, Book III, published in 1976 by the 94th Congress and archived by the Senate Select Committee on Intelligence.

Targets included Martin Luther King Jr., whose FBI file documents a sustained agency effort to drive him to suicide through anonymous mailings combining surveillance recordings with a suggestion that he kill himself before the recordings were released to his wife. The mailing is reproduced in the Senate Final Report. The Black Panther Party was infiltrated, and the infiltration produced documented internal violence in chapters across multiple cities; the killing of Chicago Panther leader Fred Hampton on December 4, 1969, by Chicago police, occurred after an FBI informant inside Hampton’s security detail provided a floor plan of his apartment to the agency. The American Indian Movement, the Puerto Rican independence movement, the Students for a Democratic Society, the National Lawyers Guild, the Women’s Strike for Peace, and an unknown but large number of smaller organizations were also infiltrated and disrupted.

The program was not exposed by institutional self-correction. It was exposed in March 1971, when eight ordinary Americans calling themselves the Citizens’ Commission to Investigate the FBI broke into a small FBI office in Media, Pennsylvania, removed every file in the office, and over the following weeks mailed copies to journalists. The break-in remains one of the most consequential acts of civil disobedience in American history; it produced the documentary record on which the subsequent Senate investigation and the modern American understanding of domestic surveillance entirely depend. The members of the Citizens’ Commission were not identified publicly until they chose to come forward in Betty Medsger’s 2014 book The Burglary. The statute of limitations had long since run.

I want you to sit with that fact, because it is unusual and the unusualness is important. The reason we know the federal government practiced manufactured division against its own citizens for fifteen years is not that the federal government told us. The reason we know is that eight people committed a felony to inform the public. Institutional self-correction did not produce the disclosure. Citizen disobedience produced the disclosure. Whether anything functionally similar continues today is, as a matter of strict documentary fact, unknowable in the same way: it would require another break-in to know definitively. I am not advocating for one. I am noting that the only documentary evidence we have ever obtained on this question was obtained by means the agency itself called illegal, and that the structural incentive that produced COINTELPRO — the incentive of an unaccountable security agency to disrupt domestic political organizing it finds inconvenient — has not been institutionally removed. Only the specific program was ended.

**Sidebar: COINTELPRO tactics, as documented**

<table>
<colgroup>
<col style="width: 34%" />
<col style="width: 44%" />
<col style="width: 20%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Tactic</strong></td>
<td><strong>Documented use</strong></td>
<td><strong>Source</strong></td>
</tr>
<tr class="even">
<td>Forged letters between organizations to provoke feuds</td>
<td>Letter to Black Panther Party leadership impersonating a rival faction</td>
<td>Church Committee, 1976, Book III</td>
</tr>
<tr class="odd">
<td>Fabricated evidence of romantic affairs</td>
<td>Used to break alliances among civil-rights and antiwar leaders</td>
<td>FBI memoranda released under FOIA</td>
</tr>
<tr class="even">
<td>Anonymous letters to spouses, employers, landlords</td>
<td>Used against MLK Jr., AIM organizers, antiwar activists</td>
<td>FBI file releases, 1976–present</td>
</tr>
<tr class="odd">
<td>Paid informants assigned to provoke internal violence</td>
<td>Black Panther chapters in multiple cities</td>
<td>Senate Final Report, Book III</td>
</tr>
<tr class="even">
<td>“Snitch jacketing” (false accusations of informing)</td>
<td>Used to isolate and discredit organizers</td>
<td>Church Committee, 1976</td>
</tr>
<tr class="odd">
<td>Selective leaks to police and prosecutors</td>
<td>Triggered arrests and criminal exposure</td>
<td>FBI memos, declassified</td>
</tr>
<tr class="even">
<td>Mailed surveillance recordings with suicide suggestion</td>
<td>Sent to Martin Luther King Jr.; reproduced in Senate Report</td>
<td>Senate Final Report, 1976</td>
</tr>
</tbody>
</table>

*Source: U.S. Senate Select Committee to Study Governmental Operations (Church Committee), Final Report, 94th Congress, Book III, 1976. Full text archived at intelligence.senate.gov.*

◆ ◆ ◆

**The contemporary update — algorithmic engagement**

The contemporary version of the same logic is algorithmic, and the documentary record on it is now extensive. The internal Facebook documents known as the Facebook Files were disclosed in 2021 by Frances Haugen, a former product manager on the company’s civic integrity team. Haugen copied the documents before her resignation and provided them to the Wall Street Journal and to the United States Senate. The Journal published an investigative series beginning September 13, 2021. Haugen testified to the Senate Subcommittee on Consumer Protection on October 5, 2021. Her testimony and the underlying documents are part of the official congressional record and partially searchable through the Securities and Exchange Commission whistleblower filing she submitted simultaneously.

Several findings inside those documents address, in Facebook’s own internal language, precisely the question this chapter is asking. The first is that a 2018 change to the platform’s ranking algorithm — marketed publicly under the slogan “meaningful social interactions” — had the measured effect of increasing the prevalence of divisive political content in user feeds, because divisive content produced higher engagement, and the company’s own data scientists could see the increase in their dashboards. Proposed fixes were rejected or watered down in product review because they reduced engagement. The second finding is that Instagram’s recommendation system, when a teenage user showed signs of body-image distress, was more likely — not less likely — to recommend additional content that intensified the distress. The third is that political parties in multiple European countries had told Facebook’s public-policy team that they were deliberately producing more inflammatory content because the algorithm rewarded it; the company logged the disclosure and did not act on it.

Haugen’s testimony to the Senate compressed the finding into a sentence anyone can verify in the official record. “Facebook’s products,” she told the subcommittee, “harm children, stoke division, weaken our democracy, and much more. The company’s leadership knows how to make Facebook and Instagram safer, but won’t make the necessary changes because they have put their astronomical profits before people.” Her testimony is dated October 5, 2021, and is archived in the public files of the Senate Committee on Commerce, Science, and Transportation.

None of this requires malice on the part of any individual Facebook engineer, and I want to be careful with the framing because the careful framing is what the evidence actually supports. The structural logic alone is sufficient. The platform is a publicly traded advertising business whose principal revenue source is selling attention. Attention is most reliably produced by emotionally activating content. The emotion most reliably activated by partisan political material is contempt. A ranking algorithm optimized for engagement will, in equilibrium, surface the content that produces contempt. That is not a conspiracy theory. That is the equilibrium behavior of any optimizer pointed at the wrong objective. What the Facebook Files added to the structural argument was internal confirmation that the company’s own data scientists had measured the equilibrium, identified it as a problem, and been overruled by leadership when they proposed reducing it.

The mechanism is not identical to COINTELPRO. The state was the actor in 1965; the platform is the actor in 2021. But the structural logic is the same. The behavior of an algorithm that consistently amplifies the content most likely to generate outrage, fear, and tribal performance because outrage holds attention and attention sells ads is functionally equivalent to a state program that pays informants to start internal feuds. Both convert a population’s capacity for solidarity into a managed resource. Neither requires the public to consent. Both work better when the public does not notice.

◆ ◆ ◆

**COUNTERARGUMENT**

The level of polarization we currently experience is real, organic, and rooted in genuine moral and material disagreements about abortion, race, immigration, religion, gun policy, and economic distribution. People disagree about these things sincerely. To call the disagreement engineered is to flatten serious disagreement into a conspiracy theory — and to imply that ordinary citizens who hold strong political views are passive dupes of a hidden manipulator, which is itself condescending.

**WHY THIS DOES NOT SAVE THE FRAMING**

Nothing in this chapter denies that genuine disagreement exists or that ordinary citizens are capable of holding views for sincere reasons. The claim is narrower and more specific. It is not that all polarization is engineered. It is that the intensification of disagreement, the redirection of disagreement away from class and structural questions, and the persistence of disagreement at levels that prevent broad coalitions — those three specific features are the parts that are managed. We have direct documentary evidence of state-sponsored manufactured division (COINTELPRO, confirmed by the Church Committee). We have internal corporate research confirming algorithmic amplification of divisive content (the Facebook Files, confirmed by Haugen’s testimony and the SEC filings). To grant that these mechanisms exist and then insist they explain nothing about contemporary polarization is to dismiss the documentary record by reflex. The honest position is the calibrated one: real disagreement plus engineered intensification. The first part keeps us from being condescending. The second part keeps us from being naïve.

◆ ◆ ◆

**What “divide and rule” actually does to a person**

The structural argument is easy to state. What it does to an individual person is harder to see, and the seeing is what makes the structural argument matter.

Consider what your media diet has taught you to feel, on any given day, about the people on the other side of whatever line is salient today. Take a moment with this. Try to be honest. When you imagine the people who voted for the candidate you did not vote for, what specific image comes to mind? Is it a person you know? Or is it a caricature you have absorbed from a media ecosystem whose business model is the production of caricatures? When you imagine the people who hold the religious or sexual or racial identity you find most personally alien, what specific image comes to mind? Is it a person you know? Or is it the worst representative of that group, surfaced on your phone yesterday by an algorithm whose internal documentation indicates that the worst representative is exactly the content most likely to hold your attention?

The damage of manufactured division is not primarily that it produces wrong opinions. It is that it produces a population that no longer recognizes its own neighbors as neighbors. The Black grandmother in Cleveland who clips coupons on Sunday and the white grandfather in West Virginia who clips coupons on Sunday are not, in any material sense, each other’s enemies. They share, between them, every measurable interest a working-class American holds against the asset-owning class: healthcare costs, housing costs, retirement security, the price of insulin, the price of a college education for a grandchild, the price of a funeral, the dignity of work performed for forty years. They are nevertheless, in the contemporary American media environment, persuaded by a steady drip of carefully selected content that their primary political opposition is each other. The arrangement is convenient for a small number of people who own a large number of things. It is not convenient for either grandmother.

I am not saying race, religion, and culture do not matter. They matter. They have produced documented atrocities across American history, and the legacy of those atrocities is a real political fact that this book does not minimize. I am saying that there is a difference between a population working honestly through real and painful differences in a context that allows it to perceive shared interests, and a population that has been administered — by states and platforms with documented incentives to administer it — toward a permanent emotional posture of mutual contempt. The first is the difficult and necessary work of democratic life. The second is what we currently have. Distinguishing the two is the precondition for doing the first.

> *The Black grandmother in Cleveland and the white grandfather in West Virginia are not, in any material sense, each other’s enemies. Someone benefits from their believing they are.*

◆ ◆ ◆

**The September 12 counterexample**

The clearest evidence that the current level of division is not natural is what happened when, briefly, the management failed.

On September 12, 2001, blood banks turned donors away because too many of us showed up. People drove across state lines to help strangers. Congressmen who had spent the previous summer accusing each other of treason sang together on the Capitol steps. The country was not less American on that morning. It was more. It was the version of itself it usually only believes in on holidays and in obituaries. It lasted, in any politically meaningful sense, for perhaps three weeks. Within eighteen months it had been converted into a war against a country that had not attacked us, on the basis of intelligence two separate official commissions — the Senate Select Committee on Intelligence (July 2004) and the Robb–Silberman Commission (March 2005) — later confirmed was either wrong or unsupported at the time it was used. The conversion was not natural either. It was managed too. The people who did the managing are still alive, still wealthy, still respected at the kinds of dinners where reputations are made and lost. None have faced criminal consequence.

The lesson of September 12 is not that catastrophe is unifying. Catastrophe is sometimes unifying and sometimes the opposite, and the question of which is determined less by the catastrophe itself than by what the political class does with the period that follows. The lesson is more specific. The American capacity for solidarity outside the tribes the political system normally trades in is real. It is recoverable. It is the resource the present arrangement most needs to discourage you from believing exists. The fact that you can probably remember, if you are old enough, a moment in your own life when the people around you behaved better than the media environment routinely tells you they are capable of is not nostalgia. It is evidence. The version of America that showed up on September 12 was not a fluke. It was a glimpse of the operating system underneath the user interface. The user interface has been telling you a different story since.

◆ ◆ ◆

**COUNTERARGUMENT**

September 12 is being romanticized. The unity of that morning was specifically a unity of grief and shock, which lasted only as long as the grief and shock lasted. To use it as evidence that Americans are capable of broad solidarity in normal times is to extract a single emotional moment from its specific context and to misuse it as a general claim about national character.

**WHY THIS DOES NOT SAVE THE FRAMING**

The romanticization charge would land if the chapter were arguing that September 12 was permanent, or that it was uncomplicated, or that everyone behaved well. It does not argue any of those things, and the text is explicit about the bias incidents against Muslims and Sikhs in the same period. The chapter’s claim is narrower: September 12 demonstrates that the American capacity for solidarity outside the normal tribal lines is real, that it is accessible under sufficiently disorienting conditions, and that the political class’s rapid conversion of that solidarity into a war of choice is itself the evidence of management. If solidarity were impossible in modern America, no conversion of it would be necessary. The conversion was necessary because the solidarity existed and threatened to do something other than what the political class wanted done with it. That is not romanticization. That is reading the documentary record.

◆ ◆ ◆

**A note on what is and is not engineered**

I want to be more careful than the polemical version of this argument typically is. Three claims about contemporary American polarization are routinely conflated. The first is that there is more disagreement than there used to be. The second is that disagreement is more bitter than it used to be. The third is that disagreement is more engineered than it used to be. The first claim is empirically dubious; the United States has been through episodes of mass political division far worse than the current one, including the Civil War. The second claim is empirically supported in the political-science literature; affective polarization — the degree to which partisans dislike the other side as people — has risen sharply in measured form since the 1980s. The third claim is the one this chapter is making, and the evidence for it is specifically the documentary record I have already cited: COINTELPRO at the state level, the Facebook Files at the platform level.

I am not arguing that engineered division explains everything. It does not. Some American political divisions are durable, deeply rooted, and would exist in some form regardless of what any algorithm did. The North–South cultural split, the rural–urban split, the racial line that runs through American history from 1619 onward — these are not artifacts of the Facebook News Feed. What the platforms and the security state add to those durable divisions is intensification, redirection, and persistence. The platforms amplify the most extreme versions of each side’s position. The security state, on the historical record, disrupts the cross-cutting coalitions that might have made progress on the underlying issues. The combined effect is a polarization that is more intense, more performative, and more durable than the underlying disagreement on its own would produce. The underlying disagreement is real. The intensification is engineered. Both can be true at the same time, and they are.

◆ ◆ ◆

**What it would take to disengineer it**

Because this book is constructive and not merely diagnostic, I want to end each chapter with an explicit indication of what reform of the system in question would actually look like. The book’s Part Four returns to these in detail. For now, the headline.

At the platform level, three reforms have been proposed in the legal and policy literature that bear directly on the manufactured-division problem. The first is algorithmic transparency — a legal requirement that large platforms disclose the inputs to their ranking systems and the measured effects of those systems on user behavior, in a form that independent researchers can audit. The European Union’s Digital Services Act, which took effect in 2023, includes a version of this requirement; American versions have been proposed in Congress but not enacted. The second is a reconsideration of Section 230 of the Communications Decency Act of 1996, which currently shields platforms from liability for user-generated content regardless of whether they algorithmically promote it. The case for reform is not that Section 230 should be eliminated — the law performs an important function in protecting open online speech — but that algorithmic promotion is meaningfully different from neutral hosting, and the liability regime should reflect the distinction. The third is a structural separation between platform hosting and advertising sales, on the theory that the conflict of interest produced by selling attention to advertisers is the underlying driver of the engagement-optimization problem. None of these reforms is easy. All three are achievable within the existing constitutional framework. The legal and policy scholarship is extensive. The bibliography at the back of this book points to the principal works.

At the state-security level, the reforms that would matter most are not new. They were proposed by the Church Committee itself in 1976, and they were partially enacted in the Foreign Intelligence Surveillance Act of 1978 before being substantially eroded in the post–9/11 period. Restoring meaningful judicial review of domestic surveillance, restoring the inspector-general structures that the second Trump administration has systematically gutted, and restoring whistleblower protections for intelligence-community employees who report constitutional violations are the obvious starting points. None of these requires constitutional amendment. All of them require a Congress willing to behave as a coequal branch of government rather than as a subordinate of the executive. The historical record suggests that Congress is occasionally capable of doing so. The Church Committee was a Congress doing so. The post-Watergate reforms were a Congress doing so. The capacity is not extinct. It is dormant.

I will return to all of this. For now, I want only to plant the flag that the analysis in this chapter is not a counsel of despair. Engineered division has been measured. It can be measured again. What can be measured can be regulated. What can be regulated can be reduced. The reduction will require sustained civic pressure on institutions that currently have no incentive to reduce it. The civic pressure will require a public willing to recognize that it has been managed. That is what the rest of this book is for.

◆ ◆ ◆

**Pattern**

The lesson is not that the public is helpless and not that every disagreement is suspect. It is more specific. When American hostility intensifies suddenly, when groups that share most material interests are told they are each other’s enemies, and when a third party — corporate, governmental, or both — quietly continues whatever it was doing before, the first question to ask is not which side is morally pure. The first question to ask is who benefits from the fight.

The September 12 version of America was the real one. The version we got back to was the managed one. The work of the rest of this book is to describe how the managing is done — not only in the manufactured-division case examined here, but in the financial, informational, religious, foreign-policy, healthcare, and technological cases that follow. The mechanisms differ. The structural logic does not.

> *The fight is real. The intensification is engineered. The first question to ask is who benefits from the fight.*

**Chapter 2**

*The Leash You Cannot See*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The second mechanism of control is debt.

The strength of debt as a form of social discipline is that it does not look like discipline at all. A person buried in medical bills, student loans, payday obligations, and insecure consumer credit is not in jail. No one is restricting her speech. No one is censoring her vote. She is simply busy in a particular way. She cannot afford a month off work to organize. She cannot afford to risk a lawsuit. She cannot afford the consequences of getting fired for telling the truth. She cannot move cities to take a better job if the better job pays the same but the moving costs are upfront. She cannot quit the abusive employer because the health insurance is attached to the job. She cannot sue the abusive landlord because the legal fees would exceed the rent she would recover. She is, in every legally meaningful sense, free. She is, in every materially meaningful sense, not. The leash is not visible. It does not need to be.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: what is debt actually for in a modern capitalist democracy, and how does it shape what citizens can do politically?

Thesis, in one sentence: in its modern form — abstracted from any reciprocal human obligation, interest-bearing, transferable, and enforced by institutions indifferent to the life of the debtor — debt is the most efficient instrument of compliance ever invented.

The anthropologist David Graeber, in Debt: The First 5,000 Years (Melville House, 2011), argued at book length that early human economies operated on flexible, socially embedded obligations — systems of mutual gift, deferred reciprocity, and personal credit rooted in long-standing community relationship — and that debt becomes politically decisive at the moment it is made impersonal and enforceable by violence. The historical record across Mesopotamian debt jubilees, medieval Europe, colonial India, post-revolutionary Haiti, and modern consumer finance supports the general pattern: convert dependence into paperwork, formalize the extraction, transfer the paper to an institution that has no relationship with the debtor and no incentive to behave with mercy, and then call the resulting subordination voluntary. The vocabulary the system uses for itself — credit, finance, leverage, structured products — is engineered to obscure the underlying social relationship. The vocabulary the debtor actually experiences — dunning calls, garnishment, denied housing applications, wage offsets, the inability to refuse the boss — is more honest.

The numbers in contemporary America are blunt. As of the Federal Reserve Bank of New York’s Quarterly Report on Household Debt and Credit for the fourth quarter of 2024, total United States household debt stood at approximately , an increase of more than $10 trillion since 2003. Student loan balances exceed $1.6 trillion. Auto loans are above $1.6 trillion. Credit card debt set a record above $1.21 trillion in late 2024. Mortgage debt accounts for the bulk of the total at roughly $12.6 trillion. These are not numbers that describe a population accumulating productive assets. They are numbers that describe a population financing the gap between what life costs and what work pays.

**Table 2-1. U.S. household debt by category, 2024**

<table>
<colgroup>
<col style="width: 40%" />
<col style="width: 22%" />
<col style="width: 36%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Debt category</strong></td>
<td><strong>Approximate Q4 2024 balance</strong></td>
<td><strong>Notes</strong></td>
</tr>
<tr class="even">
<td>Mortgage debt</td>
<td>$12.6 trillion</td>
<td>Largest single category; most strongly tied to housing-cost inflation</td>
</tr>
<tr class="odd">
<td>Student loan debt</td>
<td>$1.6 trillion</td>
<td>Mostly non-dischargeable under BAPCPA 2005</td>
</tr>
<tr class="even">
<td>Auto loan debt</td>
<td>$1.6 trillion</td>
<td>Average new-car loan term now 68+ months</td>
</tr>
<tr class="odd">
<td>Credit card debt</td>
<td>$1.21 trillion</td>
<td>Record nominal level; average APR above 20%</td>
</tr>
<tr class="even">
<td>Other (HELOC, retail, etc.)</td>
<td>~$0.9 trillion</td>
<td>Includes growing BNPL and medical-debt components</td>
</tr>
<tr class="odd">
<td>Total household debt</td>
<td>~$17.94 trillion</td>
<td>Up from ~$7.7T in 2003</td>
</tr>
</tbody>
</table>

*Source: Federal Reserve Bank of New York, Center for Microeconomic Data, Quarterly Report on Household Debt and Credit, Q4 2024. Categories rounded for clarity.*

Set those numbers next to wages. The Federal Reserve Bank of St. Louis publishes a real median weekly earnings series (FRED series LES1252881600Q) and a consumer price index (CPIAUCSL) that together describe the squeeze. Consumer prices since 1979 have nearly quintupled. Real median weekly earnings — wages adjusted for inflation, for the median full-time worker — have moved only slightly. The widening gap between what life costs and what work pays is exactly the space modern household debt has filled. Debt has not made Americans richer. It has made the gap survivable, day to day, on terms that the credit-extending industry has substantially designed.

> *Debt has not made Americans richer. It has made the gap between what life costs and what work pays survivable on terms the credit industry designed.*

◆ ◆ ◆

**The 2005 hinge: BAPCPA**

The legal architecture of the modern American leash was tightened with the Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 — BAPCPA — which made personal bankruptcy harder to obtain, imposed means testing on Chapter 7 filings, lengthened the look-back periods on transfers, and preserved the non-dischargeability of most student loans. The non-dischargeability point matters and is rarely explained in plain language, so let me state it plainly: in the United States, a debt incurred to obtain an education — even an education that did not lead to the promised employment, even an education at a for-profit institution that has since been sued for fraud — cannot generally be discharged in bankruptcy. That treatment is ordinarily reserved for debts produced by fraud and for unpaid child support. Education debt sits in the same legal category as those two.

The principal lobbyists for BAPCPA were the credit-card industry. The bill’s effect was to lock in the consumer-debt expansion of the previous twenty-five years against the legal mechanism that had historically been the safety valve. The ranking minority member of the Senate Judiciary Committee who voted for the bill was Joseph Biden of Delaware, then a senior senator from a state heavily dependent on credit-card-industry employment. I name him not to single him out partisanly — the BAPCPA vote was bipartisan; — but because the bipartisan structural pattern matters more than the brand. When both parties simultaneously vote for an industry-drafted bill, the partisan frame is not the useful frame. The structural frame is. The relevant question is not which party did this. The relevant question is which industry.

The medical-debt consequence is worth pausing on. A 2009 study by David Himmelstein and colleagues, published in the American Journal of Medicine and based on a sample of bankruptcy filings, found that 62.1 percent of all personal bankruptcies in the United States were medical in origin, and that 78 percent of the medically bankrupt had health insurance at the time of the illness that bankrupted them. The Himmelstein finding has been challenged on methodological grounds in the years since, and subsequent estimates have varied; what has not been seriously challenged is the underlying observation that the leading cause of personal financial collapse in the United States is the financial consequence of getting sick. No other wealthy democracy generates personal bankruptcy from medical bills at the American rate. The difference is not biological. It is structural. It is the consequence of a healthcare-financing architecture this book examines in detail in Chapter 9.

◆ ◆ ◆

**COUNTERARGUMENT**

Debt is a contract. People sign contracts voluntarily. If they regret the terms, the failure is theirs, not the system’s. Bankruptcy reform was needed because abuse of the bankruptcy code by sophisticated filers was real. Tightening the standard for discharge was a reasonable response to documented gaming of the prior regime.

**WHY THIS DOES NOT SAVE THE FRAMING**

The word “voluntary” is doing extraordinary work in this defense, and the work does not bear scrutiny. The seventeen-year-old asked to sign a non-dischargeable loan to enter the labor market is not negotiating from equal information; the lender has the actuarial data on default rates by degree and institution, the borrower does not. The patient signing an admission form during a heart attack is not pricing-shopping; the consent form is signed while she is being moved on a gurney. The household whose real wages have not kept up with prices for forty years is not exercising free preference when it puts groceries on a credit card; it is choosing the only mechanism the system has left available for closing the gap between income and survival. The legal architecture of modern American debt was lobbied for, by industries that benefit, and was tightened in 2005 specifically against the safety valve that historically protected the most vulnerable. The empirical record on BAPCPA after its passage — reduced filings, increased fees, longer time to discharge, no measurable reduction in the abuse it was nominally targeting — is documented in the legal scholarship; the Harvard Law Review, the American Bankruptcy Law Journal, and several Federal Reserve regional bank working papers have all addressed it. To insist this is a free market between equals is not a description. It is a slogan.

◆ ◆ ◆

**Jekyll Island and the design of the central bank**

Modern American debt did not invent itself. It has a legal architecture, and the architecture has a history. The contemporary American monetary system rests on the Federal Reserve Act of 1913, and the Federal Reserve Act has an unusual origin story that the principal architects of the act later acknowledged in their own words.

In November 1910, a small group of senior bankers and a Treasury official traveled in a private railcar from New Jersey to Jekyll Island, Georgia, under assumed names. They stayed for nine days and drafted what became the basis for the Federal Reserve Act. The primary source for this account is not a contemporary critic. It is one of the participants. Frank Vanderlip, then — the institution that became Citibank — wrote about the trip in the Saturday Evening Post on February 9, 1935. The relevant passage is brief and worth quoting at length, because the participant’s own characterization of the trip is more incriminating than any outside critic could make it: “Despite my views about the value to society of greater publicity for the affairs of corporations, there was an occasion, near the close of 1910, when I was as secretive — indeed, as furtive — as any conspirator. None of us who participated felt that we were conspirators; on the contrary we felt we were engaged in a patriotic work. We were trying to plan a mechanism that would correct the weaknesses of our banking system as revealed under the strains and pressures of the panic of 1907. I do not feel it is any exaggeration to speak of our secret expedition to Jekyll Island as the occasion of the actual conception of what eventually became the Federal Reserve System.” Vanderlip then describes the use of code names, the assumed identities on the train manifest, and the explicit understanding among the participants that if the public learned a small group of senior bankers had drafted the banking bill, the bill would have no chance of passage. The article is in the public domain and is reprinted in the appendices of Antony Sutton’s and G. Edward Griffin’s and a number of other histories of the Federal Reserve. The primary citation is Vanderlip, Saturday Evening Post, February 9, 1935.

I am not telling you this to relitigate the Federal Reserve. The Fed exists. It does important and often necessary work. The Volcker disinflation, the post-2008 emergency lending facilities, the post-2020 pandemic response — these are functions a modern economy needs. I am telling you the Jekyll Island story to make a narrower point. The institutional architecture that governs American money was designed under conditions its own architects believed could not survive public knowledge. That is a fact about how the system was built. It does not mean every Federal Reserve decision is illegitimate. It means American monetary governance is not the product of open democratic argument, and the structural insulation from democratic accountability that the original designers wrote in — a system of regional Federal Reserve banks privately owned by member banks, with a Board of Governors appointed for fourteen-year terms, deliberating in conditions of limited transparency — remains a real feature of how the system operates today. You can support the Federal Reserve as an institution while also acknowledging that its origin story is not what civics class told you it was. Both can be true.

◆ ◆ ◆

**Medical debt: Haiti at the household level**

The comparison to Haiti in this section’s title requires explanation. After the Haitian revolution of 1791–1804, France demanded that newly independent Haiti pay reparations — not to the formerly enslaved Haitians, but to the French slaveowners who had lost their human property. The debt, formally imposed by Charles X in 1825 under the threat of French naval bombardment, was 150 million gold francs, an amount . The New York Times published in 2022 a detailed investigation of the long-term consequences, drawing on French and Haitian archival records, and estimated the debt cost Haiti roughly $21 billion in lost economic growth; subsequent economic analyses have placed the total as high as $115 billion over the subsequent century and a half. \[FACT-CHECK NOTE: The NYT’s own estimate was ~$21B in lost growth; the $115B figure appears in subsequent advocacy and economic analyses, not in the Times investigation itself.\] The debt was not paid off until 1947. The Times investigation is searchable under the title “The Ransom” and is reproducible by any reader with a Times subscription.

The mechanism by which the Haitian debt operated is the mechanism by which modern American medical debt operates at the household scale. You owe an institution that has no relationship with you. The institution has the legal right to demand payment. The interest accumulates. The principal grows. Your productive capacity is diverted toward servicing the obligation rather than toward investment in your own life. Decades pass. The original injury — in Haiti’s case the original injury was being enslaved; in the medical-debt case the original injury is getting sick — has been compounded by the structural fact of the debt itself. The comparison is not metaphorical. The mechanism is identical. The only difference is scale.

Consider the actual American medical-debt experience, as documented in the 2022 report by the Kaiser Family Foundation “Health Care Debt in the U.S.”, which surveyed 1,592 U.S. adults and is the most comprehensive recent estimate of the household-level distribution of medical debt. The report finds that approximately 41 percent of U.S. adults — about 100 million people — currently have some form of medical debt. About 24 percent owe more than $1,000. About 12 percent owe more than $10,000. About 9 percent have declared bankruptcy in connection with medical bills. The distribution is racially uneven — Black and Hispanic adults are significantly more likely to hold medical debt than white adults — and the distribution is also heavily income-bottom-weighted, with households earning under $40,000 a year carrying the largest share of unpayable medical balances. None of this requires the U.S. healthcare system to be uniquely cruel. It requires only that the system bill at full retail rates, charge interest on unpaid balances, sell defaulted accounts to collections agencies that further mark up the balance, and report the unpaid debt to the credit bureaus that determine whether you can rent an apartment. The system does all of these things by design.

◆ ◆ ◆

**COUNTERARGUMENT**

Comparing American medical debt to the Haitian indemnity is hyperbole. Nobody in the United States is being threatened with naval bombardment to pay a hospital bill. The legal coercion involved is wage garnishment and credit reporting, not gunboats. To collapse the two cases is to flatten serious moral distinctions about state-imposed sovereign debt versus private commercial obligation.

**WHY THIS DOES NOT SAVE THE FRAMING**

The comparison is to the mechanism, not to the moral severity. The moral severity of the Haitian indemnity is, of course, vastly worse — it was imposed by a state under threat of military force on a population that had just escaped chattel slavery. The chapter is explicit about this. What the comparison does is illuminate the structural identity of the underlying mechanism: an obligation imposed by an outside institution that has no organic relationship with the obligated party, accumulating interest, diverting productive capacity, and reproducing itself across generations. That structural identity matters because it explains why personal financial decisions in the United States — “should I see a doctor about this pain?” — are now being made under the calculus of how much additional debt the visit will produce. That calculus is what the Haitian indemnity also produced at sovereign scale: a population deciding, year after year, what it could afford to do given the standing obligation. The argument is not that the moral cases are equivalent. The argument is that the structural mechanism is. Understanding the mechanism is what makes the structural humanism framework analytically useful.

◆ ◆ ◆

**Student debt as a forty-year experiment**

The American student-debt system is the cleanest case in any modern industrial democracy of policy choices producing the documented outcomes the policy choices were warned would produce.

In 1980, the average annual tuition at a public four-year university in the United States was approximately $2,550 in 2023 dollars. By 2023, the average had risen to approximately $11,260 in those same constant dollars. That is a roughly fourfold real increase, in a sector where the underlying production technology — a professor in a room with students — has not changed in any structural way. The Federal Reserve Bank of St. Louis tracks the relevant series. The College Board’s annual Trends in College Pricing report provides the institutional-level breakdown.

The composition of how that tuition is paid has changed even more sharply. State legislative support for public higher education, measured as a share of total operating revenue at public universities, has declined in every year of the last forty for which State Higher Education Executive Officers Association data are available. What the state once paid through general taxation, the student now pays through borrowed money. The borrowed money cannot be discharged in bankruptcy. The borrower is, on average, twenty-two years old at the moment of obligating herself for an amount equivalent to a starter house. This is not a free market in any defensible sense of the term. It is a system in which one party is a teenager with no comparable lifetime-debt experience, and the other party is a federal-government loan-origination system whose actuarial models include the precise probability the teenager will default.

The outcomes are now measurable. Outstanding federal student-loan debt has grown from roughly $0.5 trillion in 2007 to more than $1.6 trillion in 2024, an increase of more than threefold in seventeen years. The age of first-time home purchase has risen. The age of first marriage has risen. The age of first child has risen. The fertility rate has fallen. None of these correlations alone proves causation. Taken together, with the supporting demographic and survey literature, they describe a generational cohort whose life cycle has been measurably delayed by debt service. The Pew Research Center, the U.S. Census Bureau’s American Community Survey, and the National Center for Health Statistics all maintain the underlying series.

◆ ◆ ◆

**What it would take to disengineer this**

The reform agenda for the American debt system is well developed in the policy literature and modest by international standards. None of what follows is utopian. All of it is in active operation in some comparable democracy.

On medical debt, the simplest and most consequential reform is the one every other wealthy democracy already has: a financing architecture in which the underwriting unit is the entire risk pool rather than the individual patient, the negotiating unit is the entire national health authority rather than the individual hospital, and the bankruptcy mechanism is therefore unnecessary because medical bills do not accumulate to bankruptcy-triggering levels. The American debate over single-payer, all-payer, hybrid public-option, and reformed Medicaid expansion is the debate over what specific national architecture to adopt. The international evidence does not unanimously favor any one of these designs. It does unanimously favor every one of them over the status quo. Chapter 9 develops this in detail.

On student debt, the immediate reform is the restoration of bankruptcy dischargeability for educational debt, on the principle that a category of debt should not enjoy a stronger legal protection than the underlying social purpose justifies. The deeper reform is the rebuilding of public higher-education financing on the model the United States itself maintained from the postwar period through the 1970s: state legislative appropriations sufficient to keep public tuition close to nominal at flagship public universities, with means-tested federal grant programs for the rest. The legal scholar Elizabeth Warren’s academic work on bankruptcy law and consumer debt provides the principal framework; her 2003 book The Two-Income Trap, co-authored with Amelia Warren Tyagi, is the entry point.

On consumer credit, the reform agenda includes the restoration of meaningful state usury limits — most of which were preempted in the wake of the 1978 Supreme Court decision Marquette National Bank v. First of Omaha Service Corp., which allowed credit-card issuers to export the laws of their home states across state lines — the empowerment of the Consumer Financial Protection Bureau to act on the abusive collection practices documented in its own annual reports, and the imposition of plain-language disclosure standards on credit-card terms that would allow ordinary borrowers to perceive what they are agreeing to before they agree to it. The second Trump administration has moved aggressively to weaken the CFPB; the reform agenda on consumer credit is at this writing in active retreat, which is itself a fact worth noting and worth organizing against.

◆ ◆ ◆

**Pattern**

The leash is not a metaphor and it is not a conspiracy. It is the empirical condition of a population whose monetary architecture was designed under conditions its designers believed could not survive public knowledge, whose bankruptcy safety valve was tightened in 2005 by a credit-industry-drafted bill that both parties voted for, whose educational system has been converted over forty years from a publicly financed common good into a privately financed lifetime debt, and whose medical system charges its citizens for survival at a rate every other wealthy democracy has decided is morally indefensible.

The structural humanism reading of the situation is direct. Debt at this scale, in this form, with these legal protections for the creditor and these denials of remedy for the debtor, is not a financial fact. It is a political fact. It produces the specific compliance the political fact requires. The worker who cannot afford a month off cannot strike. The patient who cannot afford a deductible cannot sue. The student who cannot afford to refuse a job offer cannot organize. The household whose credit score determines whether it can rent an apartment cannot risk the late payment that telling the truth at work would produce. The leash is not visible because it does not need to be.

> *The leash is not visible because it does not need to be. The debt is the leash.*

The next chapter examines the information environment within which this arrangement is administered — the consolidation of American media into a handful of corporate hands, the surveillance architecture that observes the population without the population’s effective consent, and the documented mechanisms by which the range of acceptable public conversation is now narrower than the legal protection for free speech would, on paper, suggest. The debt chapter explains why citizens cannot afford to dissent loudly. The media chapter explains why dissent, when it does occur, has trouble reaching anyone.

**Chapter 3**

*The Permitted Narrative*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The third mechanism of control is the narrowing of what a population is permitted, in practice, to learn.

Americans live under the strongest formal free-speech protection of any major democracy on earth. The First Amendment is not a hedge. It is an absolute bar on most forms of government suppression of speech. And yet the practical experience of most Americans is that the range of perspectives they encounter in a given day on a given topic is narrow, that the framing of those perspectives is repetitive across nominally competing outlets, that consequential stories appear once and then disappear before they can reorganize public understanding, and that surveillance of their own communications by their own government — surveillance whose existence, until 2013, the government denied — has been documented by the government’s own oversight bodies. The First Amendment forbids most prior restraint. It does not, on its own, produce a diverse press, a curious press, or a press not owned by six corporations. The legal protection and the practical experience are not the same thing. This chapter is about the gap between them.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: in a society with strong formal free-speech protections, how is the practical range of acceptable public conversation narrowed, by whom, and through what documented mechanisms?

Thesis, in one sentence: the consolidation of American media ownership from roughly fifty independent companies in 1983 to six conglomerates by 2011 to a smaller number of platform and asset-management entities today, combined with the post–1996 deregulatory architecture and the post–9/11 surveillance architecture, produces an information environment in which dissent is legal but expensive, where consequential stories are reportable but disappearable, and where the line between journalism and public-relations management has been institutionally eroded — not by censorship in the prior-restraint sense, but by structural incentives that determine which stories get repeated and which do not.

The starting numerical fact is the consolidation itself. In 1983, the journalism scholar Ben Bagdikian, then dean of the Graduate School of Journalism at the University of California, Berkeley, published the first edition of The Media Monopoly. The book documented that fifty corporations controlled the majority of American mass media — newspapers, magazines, radio, television, and book publishing. Bagdikian updated the book five times. By the sixth edition in 2004, the number had fallen to five. By Business Insider’s 2012 reporting, drawing on industry filings and academic media-ownership studies, the working figure for control of approximately ninety percent of what Americans watched, read, and heard was six corporations: Comcast, the Walt Disney Company, News Corporation, Viacom, Time Warner, and CBS. The list has since reshuffled through additional mergers — Comcast’s 2011 acquisition of NBCUniversal, the 2018 merger of Disney and 21st Century Fox, the 2019 merger of CBS and Viacom — but the structural fact has not. American mass media is owned by a small number of large corporations, whose financial interests overlap substantially with the industries and political arrangements that vigorous journalism would examine.

**Table 3-1. The collapse of American media ownership**

<table>
<colgroup>
<col style="width: 23%" />
<col style="width: 25%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Year</strong></td>
<td><strong>Companies controlling majority of U.S. mass media</strong></td>
<td><strong>Source / context</strong></td>
</tr>
<tr class="even">
<td>1983</td>
<td>Approximately 50</td>
<td>Bagdikian, The Media Monopoly, 1st edition</td>
</tr>
<tr class="odd">
<td>1996</td>
<td>Approximately 14–20</td>
<td>Following Telecommunications Act of 1996</td>
</tr>
<tr class="even">
<td>2004</td>
<td>Approximately 5–6</td>
<td>Bagdikian, The New Media Monopoly, 6th edition</td>
</tr>
<tr class="odd">
<td>2011</td>
<td>6 (Comcast, Disney, News Corp, Viacom, Time Warner, CBS)</td>
<td>Business Insider analysis (Lutz, 2012); ~90% of consumption</td>
</tr>
<tr class="even">
<td>2020s</td>
<td>Further consolidated; platform layer now dominant</td>
<td>Platform consolidation (Meta, Alphabet, Amazon, X) has displaced legacy consolidation</td>
</tr>
</tbody>
</table>

*Source: Bagdikian, The Media Monopoly (multiple editions, Beacon Press); Ashley Lutz, “These 6 Corporations Control 90% Of The Media In America,” Business Insider, June 14, 2012; subsequent FCC and industry filings.*

Bagdikian’s argument across the editions was structural, not partisan. He was not claiming that any particular journalist was corrupt. He was claiming that ownership concentration at this scale, in any industry, produces predictable patterns: the range of stories told narrows, the perspectives reported converge, the topics most threatening to the owners’ other business interests recede, and the public conversation about what is happening to the country comes to be dominated by a small number of editorial cultures that mostly know one another. The propaganda model that the linguist Noam Chomsky and the economist Edward S. Herman published in their 1988 book Manufacturing Consent (Pantheon Books) described five structural filters — ownership concentration, advertising dependence, sourcing from official institutions, disciplinary responses to coverage that threatens powerful interests, and an ambient ideological framework that naturalizes the existing economic order — through which news production is shaped in ways that do not require any individual journalist to compromise her integrity. The filters operate prior to the journalism. They determine which assignments get made and which never do.

◆ ◆ ◆

**The 1996 Telecommunications Act: the regulatory hinge**

The most important single piece of legislation in the consolidation story is the Telecommunications Act of 1996. The bill passed the House 414–16 and the Senate 91–5. It was signed by President Bill Clinton on February 8, 1996. Its principal effects on media ownership were three. First, it lifted the cap on the number of radio stations a single company could own nationally and substantially raised the cap on the number of television stations whose audience a single company could reach. Second, it eliminated rules that had previously prevented cross-ownership of newspapers and broadcast stations in the same market. Third, it allowed long-distance and local telephone companies, and later cable and internet providers, to enter one another’s markets in ways the prior architecture had prohibited — a change that catalyzed the merger wave that produced the modern telecommunications-media-internet conglomerates.

The bill was sold to the public as deregulation that would increase competition. The empirical record of the following thirty years has not borne out the prediction. The number of independent newspaper-owning companies fell, the number of independent radio-station-owning companies fell, and the number of large telecommunications-internet-media conglomerates with assets in the hundreds of billions of dollars rose. The most aggressive single beneficiary in radio was the Clear Channel Communications corporation, which used the post-1996 rule changes to grow from owning approximately 40 radio stations to owning more than 1,200 by 2003, becoming the largest radio station owner in the United States. Clear Channel was later rebranded as iHeartMedia and remains the dominant U.S. radio owner today. The most aggressive beneficiary in local television has been the Sinclair Broadcast Group, which by 2017 owned or operated 173 television stations in 81 markets and used its scale to push centrally produced content — including the widely circulated 2018 “must-run” promotional segment in which Sinclair anchors at dozens of stations across the country read identical scripted language warning viewers about “one-sided news stories plaguing our country” — a segment whose simultaneous mass deployment Deadspin assembled into a single viral video that documented the scale of editorial centralization.

The Sinclair example is worth pausing on, because it makes the otherwise abstract argument viscerally legible. A viewer in Eugene, Oregon and a viewer in Mobile, Alabama and a viewer in Madison, Wisconsin tuning in to their local evening news in March 2018 saw their local anchors reading word-for-word identical talking points about media bias. The viewers had every reason to believe they were watching local journalism. They were not. They were watching a centrally produced corporate communication being delivered by local faces. None of this was illegal. None of this required any editorial misconduct by the local anchors, many of whom subsequently said they had been required by their contracts to read the script. It was the equilibrium behavior of a media architecture in which a single owner controls the editorial output of dozens of nominally local stations, and the architecture is what the 1996 Telecommunications Act made possible.

◆ ◆ ◆

**COUNTERARGUMENT**

The 1996 Telecommunications Act was a bipartisan modernization of a regulatory framework that predated the internet, and the consolidation that followed was driven primarily by technological and economic forces — the collapse of advertising revenue at independent newspapers, the rise of cable and then internet alternatives, the natural economies of scale in distribution — not by the legal changes themselves. Blaming consolidation on a single statute mistakes a market trend for a policy choice.

**WHY THIS DOES NOT SAVE THE FRAMING**

Technological change is real and the collapse of legacy advertising revenue is real. The framing this chapter is making, however, is not that the 1996 act caused the consolidation alone. It is that the act removed the legal barriers that would have meaningfully slowed the consolidation, against the documented warnings of dissenting commissioners at the Federal Communications Commission and outside scholars who told the Congress at the time exactly what would happen. The technological pressure existed in many countries; the legal architecture that determined what the pressure would do varied. Where the legal architecture preserved structural separations — as in much of continental Europe, where public-service broadcasting remained dominant and cross-ownership rules survived — the consolidation was substantially less severe. Where the legal architecture was systematically removed — as in the post-1996 United States — the consolidation went as far as physical possibility allowed. The market trend and the policy choice were not alternatives. They were inputs to the same outcome. Calling the policy choice irrelevant is not a description. It is the deregulation industry’s self-image, repeated as fact.

◆ ◆ ◆

**Operation Mockingbird and the question of legacy**

A complete picture of the modern American information environment has to include the historical fact that the Central Intelligence Agency, for a period of decades during the Cold War, ran a documented program of relationships with American journalists, news executives, and editors. The program was known internally by various names; in the public discourse it has come to be known as Operation Mockingbird, though the agency’s own internal terminology was more bureaucratic and varied across decades.

The two essential documentary sources are these. First, the Church Committee’s 1976 Final Report, Book I, included an extended discussion of CIA relationships with media organizations and journalists. The report stated that the agency had “some fifty journalists — not full-time correspondents, but stringers and contract employees” — on its payroll and acknowledged ongoing relationships with American news organizations including, by name, the New York Times, the Washington Post, Time, Newsweek, and several broadcast networks. Second, the journalist Carl Bernstein — by then well known as one of the two Washington Post reporters who had broken the Watergate scandal — published a long investigative piece in Rolling Stone on October 20, 1977 titled “The CIA and the Media,” in which he reported, based on agency files and interviews with intelligence officials, that the figure was substantially higher than the Church Committee had publicly acknowledged: more than four hundred American journalists had carried out assignments for the CIA over the preceding quarter century. Bernstein’s piece names specific publishers and editors who maintained relationships with the agency. The piece remains the most-cited journalistic primary source on the question and is in the public domain through the Rolling Stone archive.

I want to be careful with what I am and am not claiming with this material. I am not claiming that any specific contemporary American journalist is a CIA asset. I have no evidence of that and would not assert it without evidence. I am claiming three things that the documentary record supports. First, the relationship existed at scale during a specific historical period. Second, the public did not learn about it through institutional self-correction; it learned about it through a Senate investigation and a single dogged reporter. Third, the structural incentive that produced the relationship — the value to an intelligence agency of placing favorable narratives and suppressing inconvenient ones in influential publications — has not disappeared. The Church Committee’s recommendation was that the relationships be terminated. The CIA’s position, as recorded in the report, was that the agency had ended the practice. Whether the practice was actually ended, or merely renamed, is not a question I can answer definitively. It is a question to which the only honest answer is: we know what we know about Operation Mockingbird because of Carl Bernstein in 1977. We do not have a Carl Bernstein for 2026 yet. That should bother us more than it does.

◆ ◆ ◆

**Section 702 and the surveillance architecture**

The information environment is also shaped by what the government, the platforms, and the data brokers know about the population, because the asymmetry of knowledge between the watcher and the watched is itself a feature of the present arrangement. The single most important fact about contemporary American surveillance is that the population now lives under a regime of warrantless collection on a scale that the framers of the Foreign Intelligence Surveillance Act of 1978 did not contemplate, conducted under a statute — Section 702 of the FISA Amendments Act of 2008 — whose actual operational scope was concealed from the public until June 2013, when the contractor Edward Snowden disclosed it.

I will set Snowden himself to the side for a moment, because the legal and oversight record on Section 702 is now substantial and does not require relying on the disclosures alone. The Foreign Intelligence Surveillance Court — the secret federal court created in 1978 to review FISA applications — has, in opinions partially declassified across the 2013–2023 period, repeatedly documented that the FBI has used its access to the Section 702 database for queries on Americans in ways that exceed the legal limits Congress imposed. The most consequential of these declassifications was an opinion released by the Office of the Director of National Intelligence in May 2023, which documented that the FBI had performed more than 278,000 improper queries on the Section 702 database between 2020 and 2021, including queries on participants in the January 6, 2021 Capitol riot, on participants in the 2020 racial-justice protests, on donors to a congressional campaign, and on 19,000 individuals whose connection to a foreign-intelligence purpose was, in the court’s characterization, unsubstantiated. The opinion is publicly available through the Office of the Director of National Intelligence’s declassification web portal. It is signed by Judge Rudolph Contreras.

The point of citing Judge Contreras’s opinion specifically is that the misuse of the Section 702 database is not a critic’s allegation. It is a finding of the federal court whose entire function is to supervise the program. The federal government’s own designated oversight body has documented that the program has been systematically misused by the FBI. The misuse has continued across multiple administrations. The legislative response in the 2024 reauthorization was to renew the program for another two years without imposing the warrant requirement on U.S.-person queries that civil-liberties groups across the political spectrum, including the ACLU and the Cato Institute, had called for. The misuse is documented. The reform was rejected. The program continues.

◆ ◆ ◆

**COUNTERARGUMENT**

Section 702 is a foreign-intelligence collection program, not a domestic surveillance program. It is directed at non-U.S. persons reasonably believed to be located outside the United States, in support of authorized foreign-intelligence purposes. Incidental collection on Americans whose communications happen to be in contact with targeted foreign persons is unavoidable in any modern signals-intelligence program, and the FISC oversight regime is precisely the mechanism by which compliance is enforced. The 278,000 figure represents the system working as designed: the court identifying noncompliant queries and ordering correction.

**WHY THIS DOES NOT SAVE THE FRAMING**

The targeting requirement of Section 702 is on foreign persons abroad. The query regime is not. Once the underlying communications are in the database — a database that holds, on the program’s own scale, communications of and about an enormous number of Americans — the FBI may query that database for U.S. persons under standards that do not require an individualized judicial warrant. The 278,000 noncompliant queries are not the system working as designed; they are the FBI exceeding even the permissive standard the existing statute imposes. The FISC opinion is explicit about this distinction. The deeper structural point is that a collection regime built on the legal fiction of “incidental” collection, in a world of modern global communications in which essentially every consequential communication touches a foreign server somewhere, has produced a domestic-accessible database of a scale the 1978 FISA framework did not contemplate. The legal architecture is straining against its own original premises. The reform that civil-liberties advocates have requested is narrow and modest: require an individualized judicial warrant for queries on U.S. persons. That reform is opposed not because it would harm foreign-intelligence collection — the queries in question are on Americans — but because it would impose friction on a query regime the FBI has come to use as a domestic-investigative tool. Calling that incidental is technically defensible. Substantively, it is not.

◆ ◆ ◆

**The platforms as the new gatekeepers**

The legacy-media consolidation story interlocks with a newer story: the partial displacement of the legacy-media editorial function by a small number of platform companies whose algorithmic editorial choices reach larger audiences than any newspaper or broadcast network in American history.

The relevant facts: as of 2024, Meta’s Facebook and Instagram together reach approximately 3.2 billion monthly users worldwide; Alphabet’s YouTube reaches approximately 2.5 billion; TikTok reaches more than 1 billion; X (formerly Twitter) reaches approximately 500 million; and these platforms account for a substantial and rising share of where Americans encounter news — about half of U.S. adults get news from social media at least sometimes, per Pew Research Center’s 2023 News Platform Fact Sheet. The algorithmic ranking systems of these platforms do not function as neutral pipes. They are editorial systems that decide which stories you see and in what order. The decisions are made not by journalists working under professional norms but by optimization systems pointed at advertising engagement. Chapter 1 addressed what the Facebook Files documented about the consequences of that optimization for political division specifically. The broader point for this chapter is that the editorial function for a meaningful share of the American news experience has migrated from institutions with at least nominal journalistic accountability — newspaper publishers, broadcast networks — to platform companies whose internal review structures, content moderation policies, and editorial decisions are largely opaque to the public and largely unaccountable to anyone other than their advertisers and their boards.

Section 230 of the Communications Decency Act of 1996 is the legal pivot. The statute provides, in language famously condensed: “No provider or user of an interactive computer service shall be treated as the publisher or speaker of any information provided by another information content provider.” In its 1996 context, the law made enormous sense; it allowed early internet platforms to host user-generated content without facing the publisher liability that would have made any large-scale user-generated platform legally impossible. In its 2026 context, the law operates as a shield for platforms that perform substantial editorial functions — algorithmic ranking, amplification, suppression — while retaining the legal protection of a neutral pipe. The reform debate is over whether algorithmic promotion is meaningfully different from neutral hosting and whether the liability regime should reflect the distinction. The case for some reform has bipartisan support; the case for what specific reform is fiercely contested. None of this is settled. The structural fact — that a handful of platform companies are now the principal editorial gatekeepers for American news — is.

◆ ◆ ◆

**The local news collapse**

The least-discussed and most consequential fact about contemporary American journalism is the disappearance of local news. The Northwestern University Local News Initiative’s 2024 State of Local News Report, the most authoritative tracking of the underlying numbers, finds that the United States has lost roughly one-third of its newspapers since 2005 and that the country is now home to more than 200 counties — covering some 4 million Americans — with no local news outlet of any kind. The report calls these counties “news deserts.” The number is growing year over year. More broadly, an estimated 55 million Americans live in counties with limited or no local news access when the definition is extended to include counties served by only a single diminished outlet.

Local newspaper employment has fallen by more than half since 2008, per Pew Research Center figures on newsroom employment. The local-radio and local-television replacement that the optimistic reading of the 1996 deregulation predicted has not materialized at anything like the necessary scale. What has filled the void is national cable news, social-media commentary, and the algorithmic surfacing of nationalized political conflict in feeds curated by platforms with no interest in local accountability. The consequence is measurable. The political-science literature — Hayes and Lawless, News Hole (Cambridge University Press, 2018), among others — documents that voters in news-desert counties are less informed about local government, less likely to vote in local elections, more polarized along national lines, and more reliant on partisan national sources for political information. The structural humanism reading is direct: a country that has lost the journalism that watches its own city councils, school boards, county commissions, and small-claims courts has lost the layer of civic information on which democratic self-government most concretely depends. The First Amendment did not protect against this. The First Amendment protects against government suppression of speech. It does not produce, on its own, the financial conditions under which local journalism can survive.

> *The First Amendment forbids prior restraint. It does not produce a diverse press, a curious press, or a press that watches your city council.*

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for the American information environment has three layers.

At the ownership layer, the obvious reform is the restoration of meaningful media-ownership limits, on the model the United States itself maintained from the 1940s through the 1980s. The Federal Communications Commission has the legal authority to do most of this by rule, without new legislation; the rules were largely intact in 1995 and were systematically loosened in the post-1996 period. The political obstacle is that the largest beneficiaries of consolidation are among the most aggressive lobbyists against any rule change that would reverse it. The reform requires sustained political pressure from outside the industry.

At the platform layer, the reform agenda includes algorithmic transparency — a legal requirement that large platforms disclose, in a form independent researchers can audit, the inputs to their ranking systems and the measured effects of those systems on user behavior — and a recalibration of Section 230 to distinguish neutral hosting from algorithmic promotion. The European Union’s Digital Services Act and Digital Markets Act, which took effect in 2023 and 2024 respectively, embody versions of both reforms; American versions have been proposed in Congress in multiple sessions and have not passed.

At the surveillance layer, the immediate reform is a warrant requirement for U.S.-person queries of the Section 702 database. The deeper reform is the restoration of meaningful judicial review of all programmatic surveillance under the FISA architecture, including disclosure of the legal opinions on which the architecture rests. The Foreign Intelligence Surveillance Court has, since 2013, declassified an increasing share of its consequential opinions; the trajectory should continue. Whistleblower protections for intelligence-community employees who report constitutional violations should be restored to the standards that prevailed before the second Trump administration’s 2025 executive orders systematically gutting inspector-general independence.

At the local-news layer, the reform that the comparative international evidence most strongly supports is direct public subsidy of journalism through mechanisms that preserve editorial independence: refundable tax credits for newsroom employment, federal matching support for state-level journalism funds, the institutional structures pioneered by the BBC and the Canadian Broadcasting Corporation adapted to American First Amendment constraints. Several U.S. states have begun experimenting with versions of this. The principle is straightforward. A society that has decided journalism is a public good cannot leave its financing entirely to a market that has demonstrated, over thirty years, an inability to finance it.

◆ ◆ ◆

**Pattern**

The permitted narrative is not the only narrative. It is the narrative that the present configuration of ownership, regulation, platform incentives, and surveillance produces with greatest reliability. Other narratives exist. They are reported by independent journalists at small outlets, by academic specialists in peer-reviewed journals, by international press operating under different incentives. They occasionally reach mainstream attention, are reported once, and are then allowed to disappear before they can do the work in public memory that they should do. The structural humanism reading of the situation is direct: the documentary record on which the rest of this book draws is, for the most part, public. The Senate Intelligence Committee report on prewar Iraq intelligence is public. The 28 Pages on Saudi connections to the September 11 attacks are public, declassified in 2016. The Facebook Files are public. The FISC opinions documenting Section 702 abuse are public. The Costs of War Project at Brown University publishes its estimates openly. The Kaiser Family Foundation publishes its medical-debt data openly. The Federal Reserve Bank of New York publishes the household-debt data openly. The CORPNET research is openly accessible.

The information is public. It is the integration and the repetition that have been managed. A story that appears once and is then not pursued effectively does not exist in the political memory of a society whose attention span has been algorithmically shortened. The work of citizenship in this environment is not access to information. The information is right there. The work of citizenship is the assembly of the public record into a coherent picture, and the willingness to do that assembly even when no major outlet is doing it for you. The chapters that follow attempt that assembly. They draw entirely on materials a determined reader could verify herself. The argument is that the assembled picture is so different from the picture the permitted narrative typically presents that the gap between the two is itself the most important fact about contemporary American public life.

> *The information is public. The integration of it is what has been managed.*

**Chapter 4**

*The Great Consolidation*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The most important fact about the contemporary American economy is the one almost nobody talks about: three companies own much of it.

I do not mean this metaphorically. I mean that BlackRock, the Vanguard Group, and State Street Global Advisors — the three largest passive-investment asset managers in the world — are , that Vanguard alone is the single largest institutional shareholder in 422 of those 505 companies, and that the proxy votes attached to those shareholdings are cast not by the millions of underlying retail savers whose retirement accounts own the dollars, but by a small set of corporate-governance staff inside three companies. A few hundred people in three corporate-governance departments cast roughly a quarter of all votes at the largest American companies. That is the new political economy. It is not capitalism as it was described in the economics textbooks of fifty years ago. It is something else, and naming it accurately is the prerequisite to doing anything about it.

Most of this chapter is documentation. The arrangement I am about to describe is so far outside the conventional civic picture of American capitalism that I am going to slow down, name the sources, and let the numbers do the work. The story has five components: the legal abandonment of structural antitrust in 1978, the rise of the Big Three asset managers, the operating-economy consolidation that took place under the new permissive regime, the tobacco industry’s capture of American food after 1985, and the resulting macroeconomic signature — rising corporate profits, falling reinvestment, stagnant wages — that runs across the whole picture. By the end I will ask the question that the picture forces: is this still a market economy in the conventional sense, and if not, what would we have to do to make it one again?

◆ ◆ ◆

**The question antitrust stopped asking**

In May 1911, the United States Supreme Court ordered the breakup of Standard Oil. The company had used preferential railroad rebates, predatory pricing, and secret holding-company structures to control roughly 90 percent of American oil refining. The Court ruled that combinations of this kind violated the Sherman Antitrust Act of 1890. Over the next sixty years, that doctrine — that excessive economic concentration was itself a public harm, separable from any specific abuse — was the load-bearing principle of American competition law. The Justice Department’s Antitrust Division blocked or unwound mergers in industries from steel to aluminum to automobiles to telecommunications. The result was an economy in which most consequential industries had at least four to six independent operating firms competing meaningfully with one another.

That doctrine was abandoned, deliberately, by a particular school of legal thought that gained ascendancy beginning in the late 1970s. The intellectual hinge was Robert Bork’s 1978 book The Antitrust Paradox (Basic Books). Bork argued that antitrust enforcement had become incoherent and that the law should be reoriented around a single empirical test: short-run consumer prices. If a merger did not demonstrably raise consumer prices in the short term, the merger should be permitted, regardless of the market structure it produced, regardless of the political power it concentrated, regardless of what it did to wages, suppliers, communities, or long-run innovation. The argument was elegant. It was also wrong in its central empirical premise, as the subsequent forty-five years have demonstrated: the consumer-welfare standard turned out to permit precisely the merger waves that have produced the concentration the Sherman Act was originally written to prevent.

The Reagan administration adopted Bork’s doctrine in 1981. The Justice Department’s 1982 Merger Guidelines reframed antitrust analysis around the consumer-welfare test. Both parties have largely accepted the framework since. The intervening forty-five years produced the economy we now have. That economy is not the result of natural market forces operating freely. It is the result of a specific legal doctrine, adopted at a specific moment, championed by a specific intellectual movement — the Chicago School of law and economics, headquartered at the University of Chicago Law School and richly funded by foundations whose principal beneficiaries were the corporate sectors most poised to consolidate — and applied across both parties’ administrations since.

I am stating this with directness because the polite version of this history makes it sound like the consolidation just happened, the way weather happens. It did not. It was a policy choice. The names of the architects are in the public record. The intellectual lineage runs from the University of Chicago Law School through the 1982 Merger Guidelines through the major appellate antitrust decisions of the 1980s and 1990s through the merger waves they enabled. The Antitrust Division did not lose the cases it stopped bringing. It stopped bringing them. That is the central fact, and it forces the next set of questions: who benefited, and what did the benefit look like in practice?

◆ ◆ ◆

**The Big Three: who owns the owners**

The most consequential consolidation of the last twenty years did not happen in any operating industry. It happened in asset management. Three firms — BlackRock, Vanguard, and State Street — now collectively hold ownership stakes in nearly every publicly traded American corporation of meaningful size.

The numbers, drawn from the work of Jan Fichtner, Eelke Heemskerk, and Javier Garcia-Bernardo at the University of Amsterdam’s CORPNET project, and from continuing analysis of Securities and Exchange Commission filings, are these. As of 2025, BlackRock manages roughly $10.5 trillion in assets, Vanguard manages roughly $9.3 trillion, and State Street manages roughly $4.3 trillion. Together they manage approximately $24 trillion. For scale, U.S. gross domestic product in 2024 was approximately $28 trillion. These three firms manage assets equivalent to almost the entire annual output of the American economy. The CORPNET researchers’ 2017 paper in Business and Politics established the structural finding: BlackRock, Vanguard, and State Street together constitute the largest shareholder in 88 percent of S&P 500 firms, and Vanguard alone is the single largest institutional shareholder in 422 of the 505 firms in the index. BlackRock or Vanguard ranks among the top three institutional investors in 100 percent of S&P 500 firms. The primary citation is Fichtner, Heemskerk, and Garcia-Bernardo, “Hidden Power of the Big Three? Passive Index Funds, Re-concentration of Corporate Ownership, and New Financial Risk,” Business and Politics, volume 19, number 2, in 2017.

**Table 4-1. The Big Three asset managers, 2025**

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 48%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Firm</strong></td>
<td><strong>Assets under management</strong></td>
<td><strong>Position in S&amp;P 500</strong></td>
</tr>
<tr class="even">
<td>BlackRock</td>
<td>$10.5 trillion</td>
<td>Top-3 institutional investor in 100% of S&amp;P 500</td>
</tr>
<tr class="odd">
<td>Vanguard</td>
<td>$9.3 trillion</td>
<td>Largest single shareholder in 422 of 505 firms (84%)</td>
</tr>
<tr class="even">
<td>State Street</td>
<td>$4.3 trillion</td>
<td>Among top voters in nearly every major U.S. public company</td>
</tr>
<tr class="odd">
<td>Combined</td>
<td>~$24 trillion</td>
<td>Largest shareholder of 88% of S&amp;P 500; ~25% of all proxy votes</td>
</tr>
</tbody>
</table>

*Source: CORPNET project, University of Amsterdam (Fichtner, Heemskerk, Garcia-Bernardo, 2017); company 10-K filings; SEC 13F filings, 2024 update. AUM figures rounded to nearest $100B.*

I want to be precise about what these numbers mean and what they do not mean. The dollars under management at these firms are not owned by the firms. They are owned by the underlying beneficiaries — pension funds, sovereign wealth funds, university endowments, and individual retail 401(k) holders. Vanguard is structured as a mutual: the fund-holders technically own the parent company. BlackRock and State Street manage money on behalf of beneficiaries who, in aggregate, are tens of millions of ordinary Americans saving for retirement. In the strict economic sense — who is entitled to the dividends, who bears the losses — the ownership is dispersed across all of those beneficiaries. The Big Three are custodians.

The mechanism that matters, however, is not strict economic ownership. The mechanism that matters is voting power. When a corporate board votes on executive compensation, on a merger, on a strategic direction, on a CEO succession, the shares held in BlackRock, Vanguard, and State Street index funds are voted by those firms’ corporate-governance departments, not by the underlying beneficiaries. Those departments employ a few hundred people in total. They cast roughly one-quarter of all votes at shareholder meetings of S&P 500 firms. This is the empirical fact the CORPNET researchers have characterized, and that the Big Three themselves do not contest. The dispute is about what it means.

◆ ◆ ◆

**The price-effect evidence**

If common ownership did not change firm behavior, we would not need to worry about it. But the empirical evidence indicates it does.

In a 2018 paper in the Journal of Finance, the economists José Azár of the IESE Business School, Martin Schmalz of the University of Oxford, and Isabel Tecu of Charles River Associates found that airline routes whose carriers were commonly owned by the same set of large institutional investors exhibited price elevation of approximately 3 to 7 percent relative to similar routes with more diverse ownership. The full citation is Azár, Schmalz, and Tecu, “Anticompetitive Effects of Common Ownership,” Journal of Finance, volume 73, number 4, August 2018. The methodology controlled for route distance, demand, fuel costs, and a range of other determinants of airline pricing. The remaining 3-to-7-percent effect was attributable, on the authors’ analysis, to the common-ownership structure of the major U.S. carriers.

A subsequent paper by Azár with Sahil Raina and Schmalz extended the finding to U.S. banking, where common ownership was associated with higher fees on deposit accounts and reduced rate competition for retail deposits. The citation is Azár, Raina, and Schmalz, “Ultimate Ownership and Bank Competition,” Financial Management, volume 51, number 1, 2022. Subsequent literature has extended the finding, with varying methodological choices and resulting estimates, to U.S. pharmaceutical companies and to several other industries with documented common-ownership concentration.

The mechanism is not collusion in any conspiratorial sense, and the conspiracy theory is not what the peer-reviewed literature is claiming. The argument is structural. When a single set of large shareholders is the largest owner of multiple competing firms in the same industry, the rational profit-maximizing posture of any one of those firms’ managers shifts. Aggressive price competition against firms whose shareholders overlap with one’s own reduces the joint profits accruing to common owners. Managers — paid in stock, evaluated on shareholder returns, replaceable by boards that the same shareholders elect — do not need a phone call to internalize that logic. The result is observable in the data: prices are systematically higher on routes, in industries, and at fee schedules where common-ownership concentration is most severe. The Open Markets Institute, which has tracked this empirical literature closely, has summarized the implication directly: the contemporary common-ownership structure of major American industries is, functionally, the structure that the investment-banking trusts of the late nineteenth century imposed on the railroads, accomplished through a different legal mechanism.

**Table 4-2. Common ownership across selected industries**

<table>
<colgroup>
<col style="width: 32%" />
<col style="width: 28%" />
<col style="width: 39%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Industry</strong></td>
<td><strong>Approximate Big Three combined share</strong></td>
<td><strong>Documented effect</strong></td>
</tr>
<tr class="even">
<td>U.S. domestic airlines</td>
<td>~20–25% of major carriers</td>
<td>Price elevation of 3–7% on commonly owned routes (Azár et al., 2018)</td>
</tr>
<tr class="odd">
<td>Large U.S. banks</td>
<td>~20% of major holding companies</td>
<td>Deposit fee elevation; reduced rate competition (Azár, Raina, Schmalz, 2022)</td>
</tr>
<tr class="even">
<td>U.S. pharmaceutical companies</td>
<td>~20% of S&amp;P 500 pharma</td>
<td>Higher gross margins; reduced generic price competition (literature review)</td>
</tr>
<tr class="odd">
<td>U.S. food and beverage giants</td>
<td>~20% of S&amp;P 500 food/CPG</td>
<td>Common ownership across competing branded categories</td>
</tr>
<tr class="even">
<td>U.S. tech platform companies</td>
<td>~15–20% of Alphabet, Meta, Microsoft, Amazon</td>
<td>Concurrent equity in competing AI-deploying firms</td>
</tr>
</tbody>
</table>

*Source: CORPNET project (Fichtner, Heemskerk, Garcia-Bernardo, 2017); company proxy filings (Definitive 14A); industry-specific empirical literature including Azár, Schmalz, Tecu (2018) and Azár, Raina, Schmalz (2022).*

◆ ◆ ◆

**COUNTERARGUMENT**

The asset managers are custodians, not owners. The real economic interest is dispersed across millions of pension holders and retail investors. Index funds democratized investing. Anyone with a 401(k) is a part-owner of BlackRock-held companies. The concentration of ownership is the byproduct of millions of ordinary savers choosing low-fee diversified products. Calling that an oligarchy is misreading what it actually is.

**WHY THIS DOES NOT SAVE THE FRAMING**

The defense conflates two distinct things: economic ownership and voting power. Economic ownership of these portfolios is, indeed, dispersed across millions of beneficiaries. The savers own the dollars. They do not own the votes. The proxy votes attached to those shares are cast by a small set of corporate-governance staff inside three companies. The CORPNET research and subsequent industry analysis estimate that a few hundred people inside the Big Three exercise roughly 25 percent of all proxy votes at the largest American companies. That is not democratization of ownership. It is democratization of the funding of ownership while the exercise of ownership consolidates. Those are very different things. The beneficiaries do not vote their shares; the asset managers do, on executive compensation, on mergers, on strategic direction, on every consequential corporate decision. It is voting power, not economic interest, that determines corporate behavior. The relevant policy question is not whether to outlaw indexing. Indexing has produced enormous welfare gains for ordinary savers. The question is whether the voting power that comes attached to those shares should be exercised in the same concentrated fashion in which it is currently held, or whether the underlying beneficial owners should have more direct say. BlackRock and Vanguard have, under public pressure, begun to offer some institutional clients the option of directing their own proxy votes; the question is whether such pass-through voting should be extended to retail savers. That is a regulatory question. It is not anti-market. It is the application of one-person-one-vote logic to economic governance.

◆ ◆ ◆

**Sector by sector: what concentration looks like in 2026**

The Big Three asset managers sit at the top of an operating economy that has itself become dramatically more concentrated since the early 1980s. The clearest single piece of empirical evidence on this is the paper by David Autor, David Dorn, Lawrence Katz, Christina Patterson, and John Van Reenen, “The Fall of the Labor Share and the Rise of Superstar Firms,” published in the Quarterly Journal of Economics, volume 135, number 2, in May 2020. Using U.S. Census Bureau data covering the full American economy, the authors documented that the share of industry sales captured by the top four firms in each industry has risen across most sectors over roughly the past forty years, with the largest increases in retail, wholesale, finance, and services. The Federal Reserve Bank of San Francisco has tracked the retail figure separately: the top 20 retail firms went from under 30 percent of sales in the early 1980s to over 50 percent by 2012. The pattern is broad; specific sectors are extreme.

**Table 4-3. Concentration in selected U.S. industries, latest available data**

<table>
<colgroup>
<col style="width: 51%" />
<col style="width: 23%" />
<col style="width: 25%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Industry</strong></td>
<td><strong>Top firms</strong></td>
<td><strong>Share</strong></td>
</tr>
<tr class="even">
<td>U.S. airlines (American, Delta, United, Southwest)</td>
<td>Top 4</td>
<td>76%</td>
</tr>
<tr class="odd">
<td>U.S. corn seed</td>
<td>Top 2</td>
<td>72%</td>
</tr>
<tr class="even">
<td>Global pesticides</td>
<td>Top 4</td>
<td>70%</td>
</tr>
<tr class="odd">
<td>U.S. soybean seed</td>
<td>Top 2</td>
<td>66%</td>
</tr>
<tr class="even">
<td>U.S. beer</td>
<td>Top 4</td>
<td>71%</td>
</tr>
<tr class="odd">
<td>Global commercial seeds</td>
<td>Top 4</td>
<td>56%</td>
</tr>
<tr class="even">
<td>U.S. retail</td>
<td>Top 20</td>
<td>50%</td>
</tr>
<tr class="odd">
<td>U.S. banking assets (top 25 of 4,462)</td>
<td>Top 25</td>
<td>~50% (top 4 alone hold $11.5T)</td>
</tr>
</tbody>
</table>

*Source: OAG Aviation Market Insights, May 2026 (airlines); USDA Economic Research Service, 2018–2020 (seeds); ETC Group / PAN-AP, 2023 (global agriculture); Brewers Association (beer); S&P Global Market Intelligence, Q4 2025 (banks); SF Federal Reserve / Autor et al., 2020 (retail).*

**Airlines**

The four largest U.S. carriers — American, Delta, United, and Southwest — controlled approximately 76 percent of U.S. domestic capacity as of May 2026, according to OAG Aviation Market Insights. This arrangement is the direct product of three megamergers permitted under the post-Bork antitrust framework: Delta’s acquisition of Northwest in 2008, the United–Continental merger of 2010, and the American–US Airways merger of 2013. In each case, the Justice Department’s Antitrust Division either approved the merger outright or extracted minor concessions on slot allocations at specific airports. The 1956 antitrust environment can be used as a benchmark. The major carriers of that era — American, United, Trans World, and Eastern — also held roughly 80 percent of premium passenger miles. The structural difference between 1956 and 2026 is that those four firms in 1956 did not share their largest institutional shareholders. The four major carriers today do. BlackRock, Vanguard, State Street, and PRIMECAP rank among the largest holders of all four. This is the empirical situation that produced the Azár–Schmalz–Tecu finding on airfares.

**Banking**

As of the fourth quarter of 2025, S&P Global Market Intelligence reports the following. JPMorgan Chase holds approximately $4.4 trillion in assets, Bank of America approximately $2.6 trillion, Wells Fargo approximately $1.7 trillion, and Citigroup approximately $1.7 trillion. Together: more than $11.5 trillion, which is more than half of the combined assets of the top 25 U.S. banks. The Federal Deposit Insurance Corporation reported 4,462 commercial banks in the United States as of March 2025, down from 4,715 in December 2022 and from approximately 14,400 in 1985. The trend has one direction. Each loss of a community bank is a transfer of relationship banking, small-business lending discretion, and local credit allocation upward to a centralized institution where loan decisions are made algorithmically and at scale.

The Gramm-Leach-Bliley Act of 1999, which repealed the relevant portions of the Glass-Steagall Act of 1933, permitted the combination of commercial banking, investment banking, and insurance that produced Citigroup in its modern form and made the Bank of America-Merrill Lynch and JPMorgan-Bear Stearns combinations possible during the 2008 financial crisis. The post-crisis Dodd-Frank Act of 2010 imposed capital requirements but did not unwind the structural consolidation. The 2018 partial rollback of Dodd-Frank under the Economic Growth, Regulatory Relief, and Consumer Protection Act reduced the asset threshold at which enhanced regulatory scrutiny applied, allowing regional banks to grow without triggering the additional oversight that had applied to firms over $50 billion. The 2023 failures of Silicon Valley Bank, Signature Bank, and First Republic — — occurred at firms that had been beneficiaries of the 2018 rollback. The structural lesson is direct: the architects of the 2018 rollback predicted that loosening oversight on midsize banks would have no consequences. Five years later it had three of the largest consequences in the history of American banking. The architects faced no professional consequence.

**Agriculture and seeds**

The cleanest concentration story in any sector is agriculture, and the mechanism is documented by the United States Department of Agriculture’s own Economic Research Service in plain language. “The concentration,” the ERS writes in its summary of structural change in the seed and crop-protection industries, “can be traced to the expansion of intellectual property rights to private companies for seed improvements in the 1970s and 1980s, creating an incentive to research and develop new biotechnology seed traits and seed varieties. Mergers occurred between companies that produced and sold pesticides, seed treatments, crop seeds, and seed traits.” Congress changed the intellectual-property rules; consolidation followed.

The trajectory: in 1994, the top four pesticide firms controlled approximately 29 percent of the global market. By 2018, they controlled approximately 70 percent. Seeds rose over the same period from approximately 21 percent to approximately 57 percent. Two firms now provide more than half of all corn, soybean, and cotton seed planted in the United States. The same firms typically also sell the herbicides matched to those seed traits, which means a farmer choosing a Roundup Ready variety is locked into the herbicide as well — a vertical bundling arrangement that competition law in earlier eras would have scrutinized aggressively, and that the post-Bork framework has not.

**Sidebar: How the Big Six became the Big Four**

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 85%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Year</strong></td>
<td><strong>Event</strong></td>
</tr>
<tr class="even">
<td>1996</td>
<td>Roundup Ready soybeans launch. Patent-protected seed plus matching proprietary herbicide creates the modern lock-in business model in commercial agriculture.</td>
</tr>
<tr class="odd">
<td>2015</td>
<td>Six firms lead global seed and ag-chemical markets: Monsanto, DuPont, Syngenta, Dow Chemical, Bayer, and BASF.</td>
</tr>
<tr class="even">
<td>2017</td>
<td>ChemChina acquires Syngenta for $43 billion. State-owned Chinese chemical conglomerate absorbs the Swiss agrochemical leader.</td>
</tr>
<tr class="odd">
<td>2018</td>
<td>Bayer acquires Monsanto for $63 billion. Dow Chemical and DuPont merge, then spin out the combined agricultural division as Corteva Agriscience. The Big Six is now the Big Four.</td>
</tr>
<tr class="even">
<td>2023</td>
<td>The Big Four control 56% of global commercial seeds and 61% of global pesticides. In the United States: Bayer and Corteva alone account for 72% of corn acres planted and 66% of soybean acres.</td>
</tr>
</tbody>
</table>

*Source: ETC Group, ETC Concentration Reports; USDA Economic Research Service; Pesticide Atlas (Heinrich Böll Foundation, 2022); contemporaneous SEC merger filings.*

I want you to notice what the agricultural consolidation has done to the American farm. The farmer who, in 1980, could choose among dozens of independent seed companies, negotiate seed price against pesticide price, save seed from her own harvest for next year’s planting, and select inputs from competing suppliers, now negotiates with effectively two firms. The patents on most major crop varieties are held by those two firms. Saving seed is, for patented varieties, legally restricted by the seed-purchase contract. The independent feed-and-seed store that was the relational layer of every small American farming community has been substantially eliminated. The structural humanism reading of this is direct: the agricultural consolidation has not produced cheaper food, has not produced more resilient supply chains, and has not produced healthier rural economies. It has produced higher input costs for farmers, vertically integrated dependence on a small number of patent-holding firms, and the steady transfer of rural America’s economic vitality upward to corporate headquarters in St. Louis and Wilmington and Basel. That is the policy outcome. It was a choice.

◆ ◆ ◆

**When big tobacco industrialized American food**

One specific consolidation episode deserves its own treatment because the documentary trail is unusually clean, the policy implications run directly into present-day public health, and the case demonstrates how methodology developed for one product category was transferred wholesale to another.

Beginning in November 1985, Philip Morris — then the largest cigarette manufacturer in the United States — acquired General Foods Corporation for $5.8 billion, the largest non-oil acquisition in U.S. history at the time. The deal brought Maxwell House coffee, Jell-O, Kool-Aid, Tang, Post Cereals, Shake ’n Bake, Oscar Mayer meats, and dozens of other shelf-stable brands under the same corporate umbrella as Marlboro and Virginia Slims. In December 1988, Philip Morris acquired Kraft Foods for $12.9 billion. In 1990 the two were combined as Kraft General Foods, then the largest food company in America. In 2000, Philip Morris added Nabisco for $18.9 billion, becoming the largest consumer-products company in the United States, surpassing Procter & Gamble. In June 1985, in a parallel transaction, R. J. Reynolds — the second-largest cigarette manufacturer — merged with Nabisco Brands in a $4.9 billion cash transaction to form RJR Nabisco. By 1990, tobacco-owned firms controlled the dominant share of America’s shelf-stable processed-food category. The acquisition history is in SEC filings; the Wall Street Journal’s contemporaneous reporting documents the public-relations choreography around each deal.

**Sidebar: The tobacco-food pipeline**

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 85%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Year</strong></td>
<td><strong>Event</strong></td>
</tr>
<tr class="even">
<td>1985 (Nov.)</td>
<td>Philip Morris buys General Foods for $5.8 billion. Largest non-oil acquisition in U.S. history at that point. Maxwell House, Jell-O, Kool-Aid, Post Cereals, Oscar Mayer all now sit alongside Marlboro.</td>
</tr>
<tr class="odd">
<td>1985 (June)</td>
<td>R. J. Reynolds and Nabisco merge to form RJR Nabisco. Oreo, Ritz, Planters, Chips Ahoy now sit alongside Camel and Winston in one company.</td>
</tr>
<tr class="even">
<td>1988</td>
<td>Philip Morris buys Kraft for $12.9 billion. Merged with General Foods to form Kraft General Foods, then the largest food company in America.</td>
</tr>
<tr class="odd">
<td>2000</td>
<td>Philip Morris buys Nabisco for $18.9 billion. Tobacco-owned firms now control the dominant share of America's shelf-stable processed food category.</td>
</tr>
<tr class="even">
<td>2023</td>
<td>Peer-reviewed study (Fazzino et al., Addiction): tobacco-owned foods from 1988 to 2001 were 29% more likely to be fat-and-sodium hyperpalatable, and 80% more likely to be carbohydrate-and-sodium hyperpalatable, than non-tobacco-owned foods, controlling for category.</td>
</tr>
</tbody>
</table>

*Source: SEC merger filings; Wall Street Journal contemporaneous reporting; Fazzino et al., “U.S. Tobacco Companies Selectively Disseminated Hyper-Palatable Foods into the U.S. Food System,” Addiction, volume 119, number 1, September 2023.*

The most important single piece of evidence in this story is the 2023 paper by Tera Fazzino and colleagues at the University of Kansas, published in the journal Addiction in September 2023. The full citation is Fazzino et al., “U.S. Tobacco Companies Selectively Disseminated Hyper-Palatable Foods into the U.S. Food System.” The study used internal tobacco-industry documents released under the 1998 Master Settlement Agreement — the same archive of documents that has produced most of what we now know about tobacco-industry behavior in the twentieth century — to identify which food brands had been owned by Philip Morris and R. J. Reynolds at which times. Cross-referenced with the U.S. Department of Agriculture’s Food and Nutrient Database for Dietary Studies, the analysis found that during the period of tobacco ownership, the foods produced under those brands were substantially more likely to be formulated in the specific fat–sugar–salt combinations that food-science research associates with elevated rates of compulsive eating. The earlier work of Laura Schmidt and colleagues at the University of California, San Francisco, drawing on the same archival source, established that R. J. Reynolds directly applied cigarette-marketing techniques to the launch of Hawaiian Punch and other sugary-drink products targeted at children, and that Philip Morris transferred ethnic-marketing strategies — originally developed to push menthol cigarettes into Black communities — onto its Kool-Aid and Tang businesses.

This is not metaphor. The companies that had spent the twentieth century learning how to engineer chemical compulsion in cigarettes bought the country’s food brands and applied the same research-and-development logic. The methodology transfer is documented in the internal documents themselves. The 2023 study’s finding that tobacco-owned brands remained more hyperpalatable than competitors as of 2018 — fifteen years after the post-2003 corporate spinoffs that separated tobacco from food on paper — indicates that the formulations themselves outlived the corporate boundary.

> *The companies that spent the twentieth century engineering chemical compulsion in cigarettes bought the country’s food brands and applied the same research-and-development logic.*

◆ ◆ ◆

**COUNTERARGUMENT**

Tobacco companies were not uniquely guilty. Food scientists at Coca-Cola, PepsiCo, General Mills, and Kellogg’s were heading in the same direction throughout the 1980s and 1990s. Correlation is not causation; maybe tobacco firms acquired companies whose products were already trending toward hyperpalatability. Singling out tobacco-owned brands when the trend was industry-wide is statistical overreach.

**WHY THIS DOES NOT SAVE THE FRAMING**

The Fazzino study and the antecedent Schmidt work do not rely on outcome correlations alone. They rely on internal tobacco-industry documents released through the 1998 Master Settlement Agreement — documents in which tobacco executives discussed, in their own words, the application of cigarette-marketing methodology to food brands. Schmidt’s team established that R. J. Reynolds was directly involved in developing and heavily marketing sugary drinks to children. Schmidt also established that Philip Morris directly transferred its tobacco-marketing strategies targeting racial and ethnic minority communities to its food products. That is documented intent and transferred methodology, not coincidence. The honest concession the framing must make is that tobacco firms accelerated and refined a trend that was already underway in the broader industry. They did not invent processed food. What they did is industrialize addictive formulation at scale, using research infrastructure originally built for cigarettes. The post-2003 divestitures — Altria spinning off Kraft, RJR selling Nabisco — did not undo the formulations. The 2023 study found tobacco-owned-era brands remained more hyperpalatable than competitors fifteen years after divestiture. That is the empirical finding. The defense survives the question “Did tobacco firms invent the trend?” and fails the question “Did tobacco firms make the trend systematically worse using cigarette-research methodology?” That second question is the relevant one.

◆ ◆ ◆

**The macro accounting**

The micro picture I have described — sector-by-sector concentration, common ownership across competing firms, tobacco methodology in food, agricultural seed lock-in — has a macroeconomic signature visible in the national accounts. The signature is direct: corporate profits as a share of national output have risen, reinvestment of those profits has fallen, and the difference shows up as wage stagnation.

The numbers, drawn from the Bureau of Economic Analysis National Income and Product Accounts tables and synthesized by the economist William Lazonick in his September 2014 Harvard Business Review piece “Profits Without Prosperity” and in his subsequent work: corporate after-tax profit’s share of U.S. gross domestic product averaged roughly 7 percent from 1970 to 2002 and has averaged closer to 10 percent from 2002 to the present. Over the same period, the share of corporate profits being reinvested in plant, equipment, research and development, and workforce has fallen — from roughly 30 cents on the dollar to roughly 20 cents. The difference has been distributed primarily through stock buybacks and dividends, with the largest single use of corporate cash flow at S&P 500 companies in the post-2002 period being the repurchase of the company’s own shares.

The pattern is, in clean empirical terms, the cash signature of rent extraction. Firms in genuinely competitive markets cannot sustain it; they would lose market share to entrants who reinvested. The fact that it has been sustained for more than two decades is the answer to the question of whether American markets remain competitive in the textbook sense. They are not. The fact that this dynamic has produced rising shareholder returns alongside stagnant median wages, falling labor share of national income, and the widening wealth gap that has become a defining feature of American social life is the cash-flow consequence.

**Table 4-4. The cash signature of concentration**

<table>
<colgroup>
<col style="width: 44%" />
<col style="width: 26%" />
<col style="width: 28%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Measure</strong></td>
<td><strong>1970–2002</strong></td>
<td><strong>2002–present</strong></td>
</tr>
<tr class="even">
<td>Corporate after-tax profit / GDP</td>
<td>~7%</td>
<td>~10%</td>
</tr>
<tr class="odd">
<td>Reinvestment per $1 of profit</td>
<td>~$0.30</td>
<td>~$0.20</td>
</tr>
<tr class="even">
<td>S&amp;P 500 share buybacks / earnings</td>
<td>Modest</td>
<td>Often 80–90%+ in recent years</td>
</tr>
<tr class="odd">
<td>Real median wage growth</td>
<td>Moderate</td>
<td>Near-stagnant</td>
</tr>
<tr class="even">
<td>Labor share of national income</td>
<td>~65%</td>
<td>~58–60%</td>
</tr>
</tbody>
</table>

*Source: U.S. Bureau of Economic Analysis NIPA tables; William Lazonick, “Profits Without Prosperity,” Harvard Business Review, September 2014, and subsequent updates; Federal Reserve Bank of St. Louis FRED series.*

◆ ◆ ◆

**Naming the arrangement accurately**

What I have described in this chapter is not, in the strict legal sense, monopoly. There are typically four to six operating firms in each of the concentrated sectors, not one. The Sherman Antitrust Act of 1890 was written to address combinations like Standard Oil that held 90 percent or more of a single market. Most contemporary American industries are not in that posture. A sharp opponent of the framing in this chapter will use the technical inaccuracy of the word “monopoly” to dismiss the substantive concern, and I want to take that move off the table by naming the arrangement accurately.

The accurate term is concentrated oligopoly with common institutional ownership. It is uglier than “monopoly,” and it is the term the economic literature uses. It points to a structure in which three to six firms control most of an industry, in which those firms share their largest institutional shareholders, and in which the antitrust architecture as currently interpreted regulates none of the dynamics that result. The Sherman Act addresses the visible combination of competitors. It does not, as currently interpreted, address the invisible coordination produced by common ownership of competitors. The Clayton Act addresses mergers that substantially lessen competition. It does not, as currently interpreted, address the cumulative effect of dozens of smaller mergers that, taken together, produce structural concentration. The Federal Trade Commission Act addresses unfair methods of competition. It does not, as currently interpreted, address the systematic underinvestment that concentrated firms display once they no longer face meaningful competitive pressure.

Three layers, taken together, describe the new political economy. The first is horizontal concentration: serial mergers permitted under the post-Bork framework have reduced the number of operating firms in airlines, banking, telecommunications, food, media, defense, agricultural chemicals, eyewear, and beer to a small fraction of what it was in 1980. The second is vertical integration: within those mega-firms, conflicts of interest that competition law was designed to surface as conflicts between firms are now internal to single firms. Amazon is simultaneously seller, marketplace operator, and logistics provider. Live Nation is simultaneously venue owner, concert promoter, and ticket vendor. The conflicts have not disappeared; they have moved inside the corporate boundary, where antitrust has weaker visibility. The third is common institutional ownership: the same three asset managers are the largest shareholders of supposedly competing firms across nearly every concentrated sector — dampening competitive pressure at the ownership level in a way current antitrust law does not reach. Together, these three layers describe an economy in which the trust-like outcomes the Sherman Act was written to prevent are produced by mechanisms the Sherman Act, as currently interpreted, does not regulate. The arrangement is technically not monopoly. It functions, for the consumer and the worker, the way monopoly functions.

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for American competition law is well developed in the legal scholarship, and none of it requires overthrowing market economics. The reforms address specific mechanisms that current doctrine declines to see.

Restore structural antitrust analysis. The Bork consumer-welfare standard, narrowly focused on short-run prices, should be supplemented or replaced by a structural-power standard that treats market concentration itself as a competitive harm regardless of current pricing. The Federal Trade Commission and Department of Justice 2023 merger guidelines moved in this direction; they should be codified by statute so they survive administration changes. The legal scholar Lina Khan’s 2017 Yale Law Journal article “Amazon’s Antitrust Paradox” is the entry point to the scholarly case for the broader reform.

Address common ownership directly. The legal scholars Eric Posner and Glen Weyl, in their 2018 book Radical Markets and in subsequent law-review work, have proposed two specific reforms: limiting institutional investors to holding shares in only one firm per concentrated industry, or requiring them to vote their shares proportionally to underlying beneficiaries rather than through centralized governance departments. Either reform would address the specific airline-airfare and bank-fee findings documented in the peer-reviewed common-ownership literature. Neither requires the abolition of indexing.

Reverse Gramm-Leach-Bliley. The structural separation of commercial banking, investment banking, and insurance was maintained from the Glass-Steagall Act of 1933 through the Gramm-Leach-Bliley Act of 1999 without observed harm to the financial system. Its repeal contributed directly to the 2008 financial crisis. Restoring the separation would force the breakup of the largest universal banks and substantially reduce the systemic-risk concentration documented in the post-2008 stress-testing record.

Address platform gatekeeping by structural separation. Amazon as marketplace and Amazon as seller of products on that marketplace should not be the same firm. Apple’s App Store and Apple’s first-party applications should not be governed by the same firm. The European Union’s 2022 Digital Markets Act began this approach; the United States has not yet enacted a comparable structural framework.

Strengthen FTC and DOJ enforcement budgets and shorten merger-review timelines. Enforcement weakness has been driven partly by doctrine and partly by sustained underfunding of the agencies relative to the volume and complexity of mergers proposed. Restoring the Antitrust Division’s staffing to its 1980 levels, adjusted for the size and complexity of the modern economy, would be a low-controversy step.

None of these reforms are radical. Each was understood as necessary at moments when the public was paying attention — in the original Progressive-era trust-busting period, during the New Deal, after the 2008 financial crisis. Each has been allowed to fade once public attention moved on.

◆ ◆ ◆

**Pattern**

Three firms. A few hundred people in corporate-governance departments. Roughly a quarter of all votes at the largest American companies. Concentrated oligopoly across most major operating industries. Common ownership across the supposedly competing firms in each of those industries. A legal framework that, after forty-five years of the Bork doctrine, no longer treats market concentration itself as a public harm. A macroeconomic signature of rising profits, falling reinvestment, stagnant wages, and a labor share of national income at a multi-decade low. That is the new political economy. It is not capitalism as it was described in the textbooks. It is something else.

The deepest lesson of the consolidation record is not that any specific firm is uniquely guilty. It is that the public has been trained to absorb each merger, each acquisition, each consolidation episode as an isolated business-news event, to mourn the loss of competition in the abstract, and to forget. Forgetting is the load-bearing pillar of the entire structure. Documentary memory — named firms, named regulators, named decisions, named dates — is what makes the structure harder to sustain. The bibliography at the back of this book points to the principal works. The legal scholarship exists. The economic literature exists. The reform agenda exists. The political coalition to enact any of it does not yet exist at the scale required, and the project of building one is part of what the second half of this book is for.

> *The arrangement is technically not monopoly. It functions, for the consumer and the worker, the way monopoly functions. The Sherman Act was written to prevent its outcomes. The Sherman Act, as currently interpreted, does not reach its mechanisms.*

The next part of this book turns from the mechanisms of control to the history those mechanisms have helped obscure: the political histories of sacred texts, the petrodollar order, the long tail of covert foreign intervention, and the documented public record of September 11. The structural humanism reading of those histories is that the same logic that runs through the mechanisms of control — concentrated power, weakly supervised, producing the outcomes the supervision was designed to prevent — runs through the historical record as well. The chapters that follow show how.

**Part Two**

*The History You Were Not Taught*

Four chapters on the historical record that the mechanisms of control help obscure. The political histories of sacred texts, the petrodollar order, the long tail of covert intervention, and the documented public record of September 11. The same structural logic runs through all four cases. What changes is the institutional setting in which it operates.

**Chapter 5**

*Sacred or Convenient*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The most delicate chapter in this book is the one on religion, and the most important sentence in it is this: serious faith should be able to survive honest history.

I am not arguing in this chapter that scripture is fake, that revelation is impossible, or that the religious experience of billions of people is a category error. I am not writing as a hostile outsider trying to embarrass anyone’s tradition. I am arguing something narrower and more defensible. The institutional forms through which sacred texts have been transmitted — councils, canons, translations, liturgies, schools, ecclesiastical hierarchies, royal patronage, missionary enterprises — were assembled by human beings under specific political pressures, in particular places and times. To recognize this is not an attack on faith. It is the precondition of a faith mature enough not to be embarrassed by its own history. The chapter argues that the recognition is, in fact, an act of religious seriousness, not its opposite.

I want to state this as plainly as I can at the beginning, because the chapter is in danger of being misread in two opposite directions if I do not. It can be misread as a hostile rationalist takedown of religion in general, which it is not; the structural humanism framework of this book is not a secularist one, and the work of the prophetic religious traditions has been one of the most consistent sources of moral pressure against concentrated power in human history. It can also be misread as an apologetic that softens uncomfortable historical findings to protect believers from them, which it is also not; the historical record is the historical record, and a faith that needs to be protected from facts is not a faith that deserves the loyalty of serious people. The chapter takes a middle path. It treats the documented history of how sacred texts and religious institutions developed as the work of religious seriousness rather than its enemy. It distinguishes between the spiritual claims of a tradition and the institutional uses to which the tradition has been put. It applies the same standard across faiths. And it argues that this approach immunizes a believer against the manipulation of her tradition far more effectively than refusing to examine its history.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: how have the major living religious traditions actually been transmitted across history, and what does the documentary and archaeological record show about the relationship between the spiritual claims of those traditions and the political conditions under which they were institutionalized?

Thesis, in one sentence: across every major living tradition, the process of canon formation, doctrinal stabilization, and institutional transmission was a human process — contested, shaped by political circumstance, and producing texts and institutions that bear the marks of the historical settings in which they were assembled — and the recognition of this process is the foundation of mature religious literacy rather than its abandonment.

The scholarship I am drawing on here is, almost entirely, the work of religious scholars working inside their own traditions. The historian Mary Boyce, whose work I will cite extensively on Zoroastrianism and on the Zoroastrian sources of Second Temple Jewish apocalyptic literature, was the foremost scholar of her field at the University of London until her death in 2006; her work is the principal authority in religious-studies departments worldwide. The biblical scholar William G. Dever, whose work I will cite on the archaeology of early Israelite religion, is a former director of the W. F. Albright Institute of Archaeological Research in Jerusalem and held endowed chairs at the University of Arizona; his work was published by Eerdmans, a Christian press. Mark S. Smith, whose work on the origins of biblical monotheism I cite, is the Skirball Professor of Bible and Ancient Near Eastern Studies at New York University and was, at the time of the relevant publications, on the faculty of a Catholic institution. David Norton, whose textual history of the 1611 King James Bible I cite, is a former professor at Victoria University of Wellington with a sustained career inside the textual scholarship of the Anglican tradition. None of the principal sources for this chapter is a hostile outsider. They are the inside historians of the traditions whose histories I am about to summarize.

◆ ◆ ◆

**Comparative traditions**

Across the major monotheisms and the major non-monotheistic traditions, the process of canon formation looks similar in structure even where it differs in content. I want to walk through this in five cases, briefly, because the comparative shape of the picture is the picture.

The Hebrew Bible’s textual stability emerged through centuries of scribal work, with the Masoretic tradition — the standardization of pronunciation, vocalization, and consonantal text by Jewish scholars working primarily in Tiberias and Babylon — reaching its mature form only in the early medieval period, roughly the seventh through tenth centuries of the common era. The Hebrew Bible we have in modern editions is, in its specific textual form, the work of a particular Masoretic scribal tradition operating more than a thousand years after the events it narrates. This does not make the text less Jewish; it makes it more historically situated. The Dead Sea Scrolls, discovered between 1947 and 1956 at Qumran, revealed earlier Hebrew text traditions that differ in specific readings from the later Masoretic standard, and the scholarship comparing these traditions is one of the most active fields in contemporary biblical studies. The Israel Antiquities Authority’s Leon Levy Dead Sea Scrolls Digital Library has made the principal Scrolls publicly available; readers who want to see the textual variants for themselves can do so.

The New Testament canon was not finalized in a single moment but stabilized through fourth-century church councils, with disputed books — the Letter to the Hebrews, the Book of Revelation, the Catholic Epistles — debated for centuries before achieving canonical status, and with several gospels and letters circulating widely in the early church that were ultimately excluded. The Gospel of Thomas, the Gospel of Mary, the Apocalypse of Peter, the Didache, the Shepherd of Hermas, and many other texts were read as scripture by significant Christian communities in the second and third centuries before the standard fourth-century canon was assembled. The textual scholar Bart Ehrman’s work, particularly his Lost Christianities (Oxford, 2003), surveys this material in the popular register; the academic primary source is Bruce M. Metzger’s The Canon of the New Testament: Its Origin, Development, and Significance (Clarendon, 1987), a work by an evangelical Christian biblical scholar at Princeton Theological Seminary that documents the same process from inside the tradition.

The Quran’s textual stabilization under the Caliph Uthman in the mid-seventh century produced an official recension and the destruction of variant manuscripts. The history is documented in the standard Islamic theological literature and is not, within Islamic scholarship, a controversial fact. What is contested is the theological interpretation of it. Many Muslim scholars hold that the Uthmanic recension preserves the divinely revealed text without alteration; the variant manuscripts destroyed were considered erroneous copies. Western secular scholarship, beginning with John Wansbrough’s Quranic Studies (Oxford, 1977) and continuing through the work of Patricia Crone and others, has proposed a more complex developmental history. I do not need to adjudicate this dispute. I need only note that the Uthmanic recension is historically documented, that the destruction of variant manuscripts is historically documented, and that the question of textual transmission is a question Islamic theology has had to address from inside its own tradition. The standard introductory text is Frederik Leemhuis’s entry on “Codices of the Qur’an” in the Encyclopaedia of the Qur’an (Brill, 2001–2006), a multi-volume reference work assembled by international Islamic-studies scholars.

The Buddhist Pali Canon — the Theravada Buddhist scriptural corpus — was preserved orally for centuries after the death of the Buddha (traditionally placed in the fifth or fourth century before the common era) before being committed to writing in Sri Lanka in the first century before the common era, at the Aluvihara monastery, under conditions of political instability and famine that the monastic community feared would result in the loss of oral memorization. The Theravada tradition itself records this event. The Mahayana traditions of East Asia developed substantially later and produced their own canonical formations under the patronage of Chinese, Korean, and Japanese imperial dynasties, with the choice of which sutras to translate and propagate often reflecting the religious and political priorities of the dynasties involved. The standard introductory work is Donald Lopez’s Buddhism: An Introduction and Guide (Penguin, 2001) and his subsequent The Story of Buddhism (HarperOne, 2001).

The Hindu textual tradition presents the most complex case of the five, because there is no single canonical text. The Vedas, the Upanishads, the Mahabharata (which contains the Bhagavad Gita as a sub-component), the Ramayana, the Puranas, the Tantras, and the Dharma Shastras each developed over centuries through processes of oral transmission, ritual codification, sectarian elaboration, and eventually written compilation. The legal scholar and historian Wendy Doniger’s The Hindus: An Alternative History (Penguin, 2009) provides one accessible scholarly survey; her work has been controversial among Hindu nationalist critics, which is itself part of the contemporary politics of how religious history is told and to whom it belongs.

In each of these five cases, the process by which a living religious tradition arrived at its contemporary textual and institutional form was a human process. Councils met. Decisions were made. Variant texts were preserved or destroyed. Particular schools won the doctrinal disputes their politically empowered patrons preferred them to win. The traditions did not fall from heaven in their finished form. They were assembled, contested, refined, and transmitted by communities whose internal politics are documented in the historical record. Stating this is not an attack on any of the five traditions. It is a description of how all of them got here.

◆ ◆ ◆

**The Zoroastrian sources of Second Temple apocalyptic**

One specific case deserves extended treatment because it illuminates the broader pattern with unusual clarity and because the scholarly record on it is unusually robust.

The Zoroastrian religion, founded by the prophet Zarathustra (Zoroaster) in northeastern Iran sometime between approximately 1500 and 1000 before the common era, was the state religion of the Achaemenid Persian Empire from the sixth century before the common era through the empire’s fall to Alexander in 330 BCE, and again of the Sasanian Persian Empire from the third century of the common era through the Arab conquests of the seventh century. For roughly twelve hundred years, Zoroastrianism was the religion of the political power that controlled most of the territory between the Mediterranean and the Indus Valley. During the Achaemenid period specifically, this included Jerusalem, Babylon, and the major Jewish diaspora communities of the ancient Near East.

The historian Mary Boyce’s A History of Zoroastrianism, published in three volumes by Brill between 1975 and 1991, and her shorter widely used textbook Zoroastrians: Their Religious Beliefs and Practices (Routledge, 1979), trace how a specific cluster of theological concepts — a final judgment of individual souls, a bodily resurrection of the dead, a cosmic struggle between a personified force of good and a personified force of evil, an end of history followed by a renewed creation, and a moral framework in which human action contributes to the final victory of good — developed within Zoroastrianism and then entered Second Temple Jewish apocalyptic literature during the Persian period. The Jewish biblical literature before the Persian period — the historical and prophetic books — contains essentially none of these concepts. The Jewish apocalyptic literature of the Persian and post-Persian period — the Book of Daniel, the intertestamental apocalyptic texts, and the Dead Sea Scrolls material — contains all of them. The Christian New Testament inherits the apocalyptic framework directly from this Jewish material. Modern Christian eschatology — the doctrines of heaven, hell, final judgment, the resurrection of the dead, and the second coming — are, in their developed form, the inheritance of Persian-period Zoroastrian theological influence working through Second Temple Jewish apocalyptic mediation.

I want to be careful with what I am and am not claiming here. I am not claiming that Zoroastrianism is the “real” source of Christianity or Judaism, in the sense that those traditions are reducible to derivative borrowing from an external source. The Jewish prophetic tradition, the messianic hope, the covenantal framework, the ethical monotheism that Boyce herself credits Zarathustra with originating but that Hebrew prophets developed in their own distinctive form — these are not Persian imports. They are integral to the Jewish tradition. What I am claiming is that the specific apocalyptic framework — the cosmic dualism, the final judgment, the resurrection, the end of history — entered Jewish and then Christian thought during a period of Persian political dominance, that the scholarly record on this is robust, and that the recognition of it makes Jewish and Christian eschatology more historically situated rather than less Jewish or less Christian. The standard academic source is Boyce; the popular synthesis is Norman Cohn’s Cosmos, Chaos, and the World to Come (Yale, 1993), a work by a Jewish historian writing in a popular register. None of this is fringe. It is the consensus inside the relevant scholarly field.

> *Modern Christian eschatology is, in its developed form, the inheritance of Persian-period Zoroastrian theological influence working through Second Temple Jewish apocalyptic mediation. None of this makes the traditions less authentic. It makes them more historically situated.*

◆ ◆ ◆

**The 1611 King James Bible as a state project**

The English Bible most Anglophone Protestants encountered for three centuries, the version whose cadences shaped Anglophone literary English from Milton through Lincoln through Faulkner, the version many readers still consider when they say “the Bible,” was a state translation project commissioned by James I of England in 1604. The full title of the first edition makes the political character of the project explicit: “The Holy Bible, Conteyning the Old Testament, and the New: Newly Translated out of the Originall tongues: & with the former Translations diligently compared and revised, by his Maiesties speciall Comandement.”

The textual history of the translation, documented in David Norton’s A Textual History of the King James Bible (Cambridge University Press, ), shows that James convened the translation specifically as a project of religious unification — against the Geneva Bible favored by English Puritans, which contained marginal notes James found politically objectionable — and that the translators worked under explicit instructions that included a directive to preserve traditional ecclesiastical vocabulary that supported the structure of episcopal church government. The instruction is documented in the Hampton Court Conference records of 1604 and reproduced in Norton. The translators were directed, in plain English, to use the word “church” rather than “congregation,” to use the word “bishop” rather than “overseer,” and to follow the existing English ecclesiastical pattern wherever the Greek and Hebrew permitted. These were not neutral lexical choices. They were choices that strengthened the legitimacy of the established Church of England against Puritan and Presbyterian alternatives. Norton documents the same pattern across multiple specific passages.

I am not saying the King James Bible is fake, untrustworthy, or inferior as a literary or spiritual document. It is one of the great works of the English language and has carried real religious meaning for millions of believers across four centuries. I am saying that the specific English Bible that has shaped Anglophone Christianity from 1611 forward is a particular translation, made at a particular political moment, under instructions that included explicit ecclesiastical-political considerations, by translators working under royal commission. A believer who knows this is, in my view, a better-equipped believer than one who does not. She can read the King James version and notice when its ecclesiastical vocabulary is doing political work that the underlying Greek or Hebrew does not require. She can compare it to other translations — the New Revised Standard Version, the English Standard Version, the New International Version, modern Jewish translations of the Hebrew Bible, modern Catholic translations — and form judgments. The translation question is not a trick. It is the ordinary work of literate religious life.

◆ ◆ ◆

**The archaeology of early Israelite religion**

The biblical narrative of the history of Israel describes a strict monotheism, given by direct revelation at Sinai, from which the Israelite people repeatedly fell away into idolatry under the influence of surrounding Canaanite religions, only to be corrected by prophetic voices calling them back to the worship of the one God. That is the internal narrative of the Hebrew Bible itself. The archaeological record of early Israelite religion, examined in two major scholarly works by William G. Dever and Mark S. Smith, tells a more complex story.

Dever’s Did God Have a Wife? Archaeology and Folk Religion in Ancient Israel (Eerdmans, 2005) documents the substantial archaeological evidence that early Israelite religion was, for much of the period the Hebrew Bible covers, henotheistic rather than strictly monotheistic. Many Israelites worshipped YHWH alongside other deities, including, notably, a divine consort named Asherah whose iconography appears in figurines, household shrines, and inscriptions across the Iron Age archaeological record of the southern Levant. The Kuntillet Ajrud inscriptions — inscribed pottery found at a Sinai caravan station, dating to roughly the eighth century before the common era — include the phrase “YHWH and his Asherah,” in clear epigraphic Hebrew. The Khirbet el-Qom inscription, found in a Judean burial cave, includes a similar formulation. These are not fringe artifacts. They are part of the standard corpus discussed in Iron Age Levantine archaeology, and they indicate that the strict monotheism the Hebrew Bible presents as ancient and original was, in fact, the achievement of a long historical development — a development the Hebrew prophets themselves were waging when they denounced their contemporaries’ religious practices.

Mark S. Smith’s The Origins of Biblical Monotheism: Israel’s Polytheistic Background and the Ugaritic Texts (Oxford University Press, 2001) extends the analysis to the Late Bronze Age Canaanite religious context out of which early Israelite religion emerged. The Ugaritic texts — a corpus of religious tablets — document the Canaanite pantheon: El, the high god; Baal, the storm god; Asherah, El’s consort; Anat, the warrior goddess; Yam, the sea; Mot, death. Smith traces specific theological motifs from the Ugaritic material into the biblical psalter, into the biblical creation traditions, and into the developing monotheism of the prophets. The God of the Hebrew Bible, on Smith’s reading, inherits attributes from the Canaanite high god El and from the storm god Baal, even as the prophetic tradition denounces the worship of those other gods in their own names.

Again, I am not arguing that this scholarship invalidates the religious meaning of the Hebrew Bible. I am arguing that the scholarship situates the Hebrew Bible historically. The Israelite religion that emerges in the historical record was a developmental process out of a complex Bronze Age and Iron Age Levantine religious environment. The strict monotheism that the post-exilic editors of the Hebrew Bible read backward into the patriarchal narratives was not the lived religion of most ancient Israelites for most of the period in question; it was the achievement of a specific prophetic and priestly tradition that eventually won the doctrinal argument. The recognition of this process is not anti-Jewish. It is Jewish history.

◆ ◆ ◆

**COUNTERARGUMENT**

Historical-critical scholarship of the kind you are summarizing here is just a fancy way of dressing up unbelief. To say the canon was assembled by councils, that translations were political projects, that early Israelite religion was henotheistic, and that Christian eschatology has Persian-period sources is to drain scripture of its authority and to substitute the authority of academic historians for the authority of revelation. The faithful reader does not need any of this.

**WHY THIS DOES NOT SAVE THE FRAMING**

The councils existed. The translations existed. The Kuntillet Ajrud inscriptions exist. The Persian-period influence on Second Temple apocalyptic literature is documented. The historical record I am summarizing here is the historical record produced, in large part, by religious scholars working in good faith inside the traditions themselves — Bruce Metzger at Princeton Theological Seminary, William Dever as a Methodist with deep ties to American Christian institutions, Mark Smith on the faculty of a Catholic university at the time of the relevant publications. To call the documentary record “unbelief” is to make the tradition fragile in a way the tradition need not be. A faith that survives history is a stronger faith than one that fears it. The deeper move I want to make is this: the believer who has done the historical work is harder to manipulate. She can recognize when a politician is using her tradition for purposes the tradition itself does not endorse. She can distinguish what is sacred in the tradition from what is convenient about it for some political faction. She is, in short, a more dangerous opponent to bad-faith religious instrumentalization than the believer who refuses to look at the history. The structural humanism argument is not that faith should be abandoned. It is that faith should be the kind of faith that cannot be used against the people it is supposed to serve.

◆ ◆ ◆

**How power uses religion**

Religion has been used, repeatedly and across traditions, to bless arrangements of power. The pattern is not unique to any one faith, which is what makes it a structural rather than a sectarian observation.

The Roman Catholic Church’s adjustment to imperial Rome after the conversion of Constantine in the early fourth century is one of the most thoroughly studied cases. The Christianity that emerged from the Council of Nicaea in 325 of the common era, called and politically managed by Constantine himself, was a Christianity that had moved decisively from a persecuted minority sect of the eastern Mediterranean to a state religion of the Roman imperial order. The doctrinal disputes the council resolved — the Arian controversy, the relationship of the Son to the Father — were settled in a particular direction. The losers became heretics. The winners became orthodox. The historian Bart Ehrman’s How Jesus Became God (HarperOne, 2014), drawing on the standard academic scholarship, summarizes the politics of the period. The traditional Christian historian Robert Louis Wilken’s The First Thousand Years: A Global History of Christianity (Yale University Press, 2012) covers the same material from inside the tradition. Both are valuable. Both describe a Christianity whose doctrinal stabilization was inseparable from the imperial politics that produced it.

The biblical justification for American chattel slavery in the antebellum South is the cleanest American case of religious instrumentalization. Southern theologians, preachers, and seminary professors produced an extensive nineteenth-century literature arguing that slavery was scripturally sanctioned, that the curse of Ham in Genesis 9 applied to Africans, that the household codes of the Pauline epistles required slave obedience to masters, and that Northern abolitionism was a heretical deviation from biblical norms. The historian Mark Noll’s The Civil War as a Theological Crisis (University of North Carolina Press, 2006), a work by an evangelical Christian historian at Notre Dame, traces this literature in detail. The antebellum proslavery theological consensus was not a fringe phenomenon. It was the working religious culture of much of white Southern Christianity, supported by the seminaries, the publishing houses, and the denominational structures. It was also wrong. Noll’s conclusion is that the American Civil War was, among other things, a theological crisis that the antebellum proslavery hermeneutic could not survive. The lesson is not that Christianity is uniquely susceptible to instrumentalization. The lesson is that religious institutions are susceptible to instrumentalization in the same way every other institution is susceptible, and that the recognition of this susceptibility is the precondition of doing better.

The deployment of religious nationalism in contemporary politics — American Christian nationalism, Hindu nationalism in India, Buddhist nationalism in Sri Lanka and Myanmar, settler-religious nationalism in Israel, Islamist political movements across the Muslim world — follows the same pattern. A religious tradition’s resources for collective identity, sacred legitimacy, and moral certainty are mobilized by political movements to authorize the political program of those movements, often against minorities within the same society and often in tension with the central ethical teaching of the tradition the movement claims to represent. The work of the political scientist Robert P. Jones at the Public Religion Research Institute documents the American case in depth; his White Too Long: The Legacy of White Supremacy in American Christianity (Simon & Schuster, 2020) is the entry point. The historian of religion Mark Juergensmeyer’s Terror in the Mind of God: The Global Rise of Religious Violence (University of California Press, fourth edition 2017) provides the cross-cultural framework.

And the opposite pattern is just as documented. The prophetic traditions inside Judaism, Christianity, Islam, and the indigenous religious traditions of the Americas, Africa, and Asia have repeatedly produced sustained moral pressure against injustice. The American civil-rights movement was a religious movement, led by Black Christian clergy who understood themselves as standing in the prophetic tradition. The Latin American liberation theology movement of the 1960s through 1980s, suppressed by both Roman authorities and U.S.-allied military regimes, drew its resources from inside the Catholic tradition. The Buddhist resistance to the Vietnam War, the Quaker resistance to the antebellum Fugitive Slave Act, the Sufi resistance to colonialism in North Africa, the Hindu resistance to British rule under Gandhi — all of these were religious movements drawing on the resources of their traditions to oppose the political arrangements of their time. Religion is one of the most powerful instruments of legitimacy human beings have ever developed. It can legitimate empire. It can legitimate resistance to empire. Which use it serves depends substantially on which believers do the work of recognizing how their tradition has been used — and who is doing the using — in the present moment.

◆ ◆ ◆

**What this chapter explicitly refuses**

The honest reading of religious history that this chapter is arguing for has, over the centuries, been frequently contaminated by hostile traditions of writing whose purpose was not religious literacy but the production of ethnic and religious hatred. I want to address this directly, because the contamination is the principal reason the comparative-traditions approach this chapter takes is necessary.

There is a specific antisemitic literary genre, traceable through Johann Andreas Eisenmenger’s Entdecktes Judenthum (“Judaism Unmasked”), published in 1700 in Frankfurt and reissued repeatedly in German and other European languages, through Elizabeth Dilling’s mid-twentieth-century compilations published in the United States, and through contemporary white-nationalist republications, that purports to expose Judaism by selectively quoting Talmudic passages out of their interpretive context. The genre relies on a stable set of approximately a dozen passages — Sanhedrin 57a, Bava Kamma 113a, Soferim 15:10, Yebamoth 98a, Kerithoth 6b, Gittin 57a are the most-cited — each of which has, in its actual Talmudic context, a meaning meaningfully different from the meaning the antisemitic compilations assign to it. The Talmudic passages discuss legal hypotheticals, intra-Jewish ritual law, the conduct of specific historical disputes, or the moral obligations between Jews and non-Jews in particular institutional settings. The antisemitic genre strips these passages of their context, presents them as if they expressed a unified contemporary Jewish hostility to non-Jews, and infers from the selective compilation a conspiratorial picture of Judaism as a hidden anti-gentile religion. The picture is wrong as Talmudic scholarship and is the lineage of a literary tradition whose downstream consequences include some of the worst events of the twentieth century.

I will not write within that genre. The argument of this chapter is structural: every religious tradition has developed under political pressure, every religious tradition contains the resources for both moral seriousness and political instrumentalization, and the literacy required to distinguish them is the same kind of literacy across traditions. The Jewish tradition has the same internal complexity as the Christian and Islamic and Buddhist and Hindu traditions, and the same internal resources for self-correction. The Talmudic literature is a vast and complex body of work spanning more than a thousand years of rabbinic discussion across multiple cultural settings; it cannot be summarized through six selectively quoted passages any more than the Christian New Testament can be summarized through six selectively quoted passages chosen by a hostile outsider. The serious work on the Jewish tradition is being done, today, by Jewish scholars writing for academic and religious audiences inside the tradition; the historian Daniel Boyarin’s work, the work of the scholars at the Hebrew University and the Jewish Theological Seminary, the publications of the Jewish Publication Society — these are the sources a reader interested in the tradition should consult. The same standard applies to every other tradition this chapter has discussed. Each tradition’s history is best told by its own historians, supplemented by the work of comparative-religion scholars across traditions, read with the same standards of critical sympathy that any honest reading of religious history requires.

◆ ◆ ◆

**COUNTERARGUMENT**

Stating that all religious traditions are equally susceptible to instrumentalization is a false equivalence. Some traditions have, in their core texts and practices, more resources for legitimating violence and domination than others. To treat them all as morally equivalent in their susceptibility to political abuse is to refuse the distinctions that careful moral analysis requires.

**WHY THIS DOES NOT SAVE THE FRAMING**

The chapter is not claiming that all traditions are morally equivalent. It is claiming that the structural process by which a tradition becomes instrumentalized is recognizable across traditions, and that the literacy required to resist instrumentalization is recognizable across traditions. Specific traditions, in specific historical moments, have produced more or less violence than others. The Christianity of the medieval Crusades, the Christianity of the Spanish Inquisition, the Christianity of antebellum American slavery, the Christianity of Rwanda in 1994 — these are real historical phenomena, and the responsibility for them belongs partly to the religious resources the tradition made available to its political instrumentalizers. The same is true of every other major tradition in some moment of its history. The structural humanism argument is not that the cases are interchangeable. It is that the literacy required to recognize what is happening in any of these cases — to ask whether a religious claim is being made in the service of the people it is supposed to serve or in the service of someone using the people it is supposed to serve — is the same literacy. A believer who has cultivated that literacy in her own tradition can recognize the equivalent pattern when she sees it in another. That is the value of the comparative move. It is not moral equivalence. It is shared diagnostic capacity.

◆ ◆ ◆

**Comparative humility**

It is worth saying directly. The comparative move in this chapter is not a ranking. I am not arguing that one tradition is more truthful than another, or that all traditions are equally true, or that the underlying spiritual reality of religious experience is reducible to historical sociology. I am arguing something narrower. Every major living tradition contains within itself the resources for both moral seriousness and political instrumentalization, and the literacy required to distinguish them is the same kind of literacy across traditions.

The Quaker meeting in the antebellum North that voted to refuse cooperation with the Fugitive Slave Act used the same kind of scriptural reading the slaveholder used to defend the institution. What differed was whose suffering they took seriously. The Catholic Worker movement and the Spanish Inquisition both claimed continuity with the same scripture. They cannot both be right about everything, and the choice between them is not a choice between believing and not believing. It is a choice between two ways of using a text. The Israeli rabbi who, in 2024, publicly opposes the violence of his own state against Palestinian civilians and the Israeli rabbi who calls for that violence are reading the same Torah. The choice between them is not a choice about Judaism. It is a choice about what use is being made of Judaism in the present moment. The Muslim cleric who teaches the prohibition against killing innocents in Islamic ethics and the Muslim cleric who blesses the violence of an extremist movement are reading the same Quran. The choice between them is not a choice about Islam. It is a choice about what use is being made of Islam in the present moment.

This is the structural humanism reading of religion. It does not abandon faith. It refuses to let faith be used. A reader who already has a tradition is invited not to leave it but to take it more seriously — which, in the end, requires looking at the history of how it has been used by power and asking, in the present, whether the use is sacred or convenient.

◆ ◆ ◆

**Pattern**

Religion is one of the most powerful instruments of legitimacy human beings have ever developed. That is precisely why the use to which it is put deserves moral and political attention. The structural humanism reading is not that religion is the problem. The structural humanism reading is that religion, like every other powerful institution, is subject to capture by concentrated power, and that the capture is most effective when the believer has not done the historical work that would let her recognize the capture when it is happening to her.

A believer who has read the canon-formation history of her tradition knows that the tradition’s contemporary form was the work of human councils and human politics. A believer who has read the textual history of her scripture knows that the translation she is using is a particular translation made under particular conditions. A believer who has read the comparative history of religious institutions knows that the pattern of instrumentalization is not unique to her tradition. A believer who has done all three is better equipped to recognize when a politician, a media network, a religious authority, or an ideological movement is using her tradition for purposes the tradition itself does not endorse. She is, in short, harder to manipulate. The structural humanism argument is that the cultivation of this kind of religious literacy is one of the most important pieces of civic infrastructure a democratic society can have. The argument is not against faith. It is for the kind of faith that cannot be used against the people who hold it.

> *There is what is sacred and there is what is convenient, and one of the durable forms of literacy a self-governing citizen can develop is the capacity to tell them apart in the moment.*

The next chapter turns from the political uses of sacred language to the political uses of monetary architecture. The petrodollar arrangement, the post-Bretton-Woods global financial order, and the wars whose actual causes have not coincided with their public justifications. The structural logic is the same. Concentrated power, weakly supervised, producing the outcomes the supervision was designed to prevent. The institutional setting changes. The pattern does not.

**Chapter 6**

*The Dollar and the Dead*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

American military power and American monetary power are not two stories. They are one.

This chapter argues that the United States dollar’s position as the world’s reserve currency is not a neutral accomplishment of American economic productivity. It is a constructed arrangement, designed in specific years by specific people, maintained by specific commitments of force, and producing specific patterns of human cost that the public has not been given a clear accounting of. The arrangement is not a conspiracy. It is documented economic and foreign policy. What has been managed is not the existence of the arrangement — it is open in the scholarly record — but the public’s integration of it into a clear picture of how foreign-policy decisions have actually been made. This chapter does that integration.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: what is the actual structural relationship between U.S. monetary power and U.S. foreign-policy decisions, and what costs has the maintenance of that relationship imposed on populations the public is rarely told are paying it?

Thesis, in one sentence: the post-1971 petrodollar arrangement, which converted demand for U.S. Treasury securities into a structural feature of the global oil trade, has shaped American foreign-policy choices in ways that the public justifications for those choices have systematically not acknowledged, and the documented human cost of maintaining the arrangement — in Iraq, in Libya, in Venezuela, in Afghanistan, and across the broader sanctions regime — is now substantial enough that an honest national accounting is overdue.

I want to be careful with what I am and am not claiming. I am not claiming that every American war is reducible to a monetary motive. That would be a bad argument. American foreign policy has many drivers — alliance commitments, counterterrorism objectives, regional balance-of-power considerations, congressional politics, defense-industrial-base interests, humanitarian rhetoric of varying degrees of sincerity. The argument is narrower. It is that the monetary dimension is a real and underdiscussed dimension of the policy, that specific recurring patterns become harder to dismiss as coincidence once that dimension is named, and that the public deserves to have the dimension named alongside the other public justifications.

◆ ◆ ◆

**The petrodollar arrangement**

On August 15, 1971, President Richard Nixon announced that the United States was suspending the convertibility of the U.S. dollar into gold. The announcement effectively ended the post-war Bretton Woods system, under which the dollar had been pegged to gold at $35 per ounce and the major currencies of the capitalist world had been pegged to the dollar. The immediate question facing the international monetary system was what would replace the gold anchor as the basis for international demand for dollars. The functional answer that emerged over the following three years was oil.

In 1973 and 1974, in a series of negotiations whose principal architects on the American side included Treasury Secretary William Simon and Secretary of State Henry Kissinger, the United States and the Kingdom of Saudi Arabia reached a working arrangement under which Saudi Arabia would price its oil exports in U.S. dollars and would recycle a substantial portion of its dollar earnings into U.S. Treasury securities and U.S. arms purchases, in exchange for U.S. security guarantees of the Saudi state against external threat. The arrangement was not embodied in a single signed treaty; it was a working understanding among Treasury officials, the Saudi finance ministry, and the major banks. The principal scholarly source on the negotiations is David E. Spiro’s The Hidden Hand of American Hegemony: Petrodollar Recycling and International Markets, published by Cornell University Press in 1999. Spiro’s work, based on Treasury Department archives and contemporaneous diplomatic correspondence, is the standard reference.

Other OPEC producers followed the Saudi lead. The result was the petrodollar system: a structural source of demand for dollars among every nation that imported oil — because oil was priced in dollars, every importer needed dollars to pay for it — and a structural source of financing for U.S. fiscal deficits among the major oil exporters, who recycled their dollar earnings primarily into U.S. Treasury securities. The arrangement has had consequences whose magnitudes are not contested. It is one of the reasons the United States has been able to run persistent trade deficits and persistent fiscal deficits without suffering the kind of currency crisis other countries running comparable imbalances would have faced. It is one of the reasons Treasury yields have remained low even during prolonged fiscal expansion. And it is one of the reasons the U.S. security commitment to the Saudi state has remained largely insulated from the kind of public democratic scrutiny that would normally attach to an alliance with a non-democracy whose internal governance bears almost no resemblance to American constitutional norms.

I want to underline the last point because it is the one most directly relevant to this chapter’s argument. The American alliance with the Kingdom of Saudi Arabia has continued, with minor modulations, across every administration since Nixon. The alliance has continued through Saudi support for Wahhabi religious networks that have produced violent extremism globally, through the Saudi conduct of the war in Yemen since 2015 (which the United Nations has repeatedly characterized as a humanitarian catastrophe), through the 2018 murder and dismemberment of the Washington Post columnist Jamal Khashoggi inside the Saudi consulate in Istanbul — a killing the U.S. Office of the Director of National Intelligence concluded, in a February 2021 declassified assessment, was approved by Crown Prince Mohammed bin Salman — and through every other documented departure of Saudi conduct from American stated values. The alliance has continued because the petrodollar arrangement makes the alliance valuable in ways the public discussion of the alliance rarely names. That is the operational fact. It is not a conspiracy theory. It is the structural reality of post-1971 American foreign policy, and it is reported in the scholarly literature whenever the scholarly literature is permitted to engage it.

◆ ◆ ◆

**Iraq, 2003**

The 2003 invasion of Iraq is the case in which the gap between public justification and post-war documentary record is widest, and the case from which everything that follows in American foreign policy of the past two decades has to be evaluated.

The official justifications for the invasion were three. First, that Iraq possessed weapons of mass destruction — chemical, biological, and possibly nuclear — in violation of post-1991 disarmament obligations and constituting an imminent threat to U.S. national security. Second, that the regime of Saddam Hussein maintained an operational link to al-Qaeda and bore some measure of responsibility for the September 11 attacks. Third, that the removal of the regime would advance the cause of democracy in the broader Middle East and produce a stable, pro-American Iraqi state.

Each of these claims was investigated, after the war, by official bodies whose conclusions are part of the public record. The Senate Select Committee on Intelligence Report on the U.S. Intelligence Community’s Prewar Intelligence Assessments on Iraq, published in July 2004, concluded in its principal finding that “most of the major key judgments in the Intelligence Community’s October 2002 National Intelligence Estimate either overstated, or were not supported by, the underlying intelligence reporting.” The Report of the Commission on the Intelligence Capabilities of the United States Regarding Weapons of Mass Destruction — known as the Robb-Silberman Commission — published in March 2005, reached substantially the same conclusion through an independent investigation. The two reports together establish, as the considered finding of the federal government’s own oversight processes, that the central WMD claims used to justify the war were unsupported by the intelligence available at the time of their use.

The operational link between Saddam Hussein and al-Qaeda, which the Bush administration officials promoted in public statements throughout 2002 and 2003 and which Vice President Dick Cheney specifically asserted in repeated interviews, was also evaluated in the post-war investigations. The 9/11 Commission, in its 2004 final report, concluded that it had found no evidence of a collaborative operational relationship between the Iraqi regime and al-Qaeda. The Senate Intelligence Committee’s 2006 follow-on report on prewar intelligence about Iraqi links to terrorism reached the same conclusion. The democracy-promotion justification for the war has been evaluated by twenty years of subsequent Iraqi political history; the present moment is the appropriate one to ask whether the post-invasion Iraqi political order constitutes the stable pro-American democracy the architects of the invasion promised. I will let the reader form her own judgment.

The human and financial cost of the war has been the subject of the most rigorous available accounting, conducted by the Costs of War Project at Brown University’s Watson Institute for International and Public Affairs since 2011. The project’s most recent comprehensive estimate, last updated in 2023, places the total U.S. military, security, and veterans-care expenditures attributable to post-9/11 wars — Iraq, Afghanistan, and related operations — at approximately $8 trillion through fiscal year 2050, with the figure including obligated future veterans’ care for the soldiers wounded in those wars. The same project estimates direct violent deaths from the post-9/11 wars at more than 900,000 across all participating countries, with Iraqi civilian deaths alone running into the high hundreds of thousands. The estimates are conservative by the methodology of academic conflict research; the household-survey-based estimates published in The Lancet have produced higher figures. The principal point for the purposes of this chapter is that the public was not given an accurate accounting of the war’s human cost while the war was being conducted, has not been given a clear accounting since, and continues to absorb the financial cost through tax obligations and through opportunity costs that the next chapter on the federal budget will examine in detail.

**Table 6-1. Post-9/11 war cost accounting**

<table>
<colgroup>
<col style="width: 47%" />
<col style="width: 21%" />
<col style="width: 31%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Cost category</strong></td>
<td><strong>Magnitude</strong></td>
<td><strong>Source</strong></td>
</tr>
<tr class="even">
<td>Total U.S. spending, post-9/11 wars (through FY 2050)</td>
<td>~$8 trillion</td>
<td>Costs of War Project, Brown Univ., 2023 update</td>
</tr>
<tr class="odd">
<td>U.S. military deaths, post-9/11 wars</td>
<td>~7,000</td>
<td>Department of Defense casualty data</td>
</tr>
<tr class="even">
<td>U.S. military wounded in action</td>
<td>~53,000+</td>
<td>Department of Defense casualty data</td>
</tr>
<tr class="odd">
<td>Direct violent deaths, all post-9/11 war zones</td>
<td>~900,000+</td>
<td>Costs of War Project, 2023</td>
</tr>
<tr class="even">
<td>Iraqi civilian deaths (Iraq Body Count, direct violent)</td>
<td>~200,000+</td>
<td>Iraq Body Count Project, ongoing</td>
</tr>
<tr class="odd">
<td>Iraqi excess deaths (Lancet 2006 household estimate)</td>
<td>~600,000+</td>
<td>Burnham et al., The Lancet, 2006</td>
</tr>
<tr class="even">
<td>Veterans care obligated through 2050</td>
<td>~$2.5 trillion</td>
<td>Costs of War Project, included in $8T total</td>
</tr>
</tbody>
</table>

*Source: Costs of War Project, Watson Institute, Brown University (2023 update); Department of Defense casualty statistics; Iraq Body Count Project; Burnham et al., “Mortality after the 2003 invasion of Iraq: a cross-sectional cluster sample survey,” The Lancet, volume 368, 2006.*

The financial accountability for any of this has not occurred. No senior policymaker has faced criminal charges for the dissemination of intelligence the federal government’s own oversight bodies later concluded was unsupported. No cabinet official lost a pension. George Tenet, the Director of Central Intelligence who told President Bush the WMD case was a “slam dunk,” received the Presidential Medal of Freedom in December 2004. The architects of the war moved to think tanks, foundation boards, paid speaking circuits, and prestige media platforms, from which several of them continue to provide foreign-policy commentary on subsequent conflicts. This is the precedent. It is the principal piece of context within which every subsequent question about American foreign-policy honesty has to be evaluated.

> *If the public can be moved into a war on false premises and no accountability follows, the question is no longer whether other foreign-policy catastrophes were also produced by deception. The question is which ones, and what the pattern shows.*

◆ ◆ ◆

**COUNTERARGUMENT**

The 2003 Iraq War was a serious policy decision made under conditions of genuine uncertainty about Iraqi WMD capabilities, in the aftermath of an attack that had killed nearly 3,000 Americans on American soil. Intelligence is necessarily imperfect. The administration made the best judgment available with the information it had. To frame the war as a lie is to substitute hindsight bias for honest assessment of the decision-making environment in 2002 and 2003.

**WHY THIS DOES NOT SAVE THE FRAMING**

The Senate Intelligence Committee’s 2004 report and the Robb-Silberman Commission’s 2005 report did not conclude that the intelligence was imperfect. They concluded that the key public assertions made by senior administration officials were unsupported by the underlying intelligence at the time the assertions were made. That is a different finding. The Senate Intelligence Committee’s 2008 follow-up report specifically addressed the question of whether administration officials had misrepresented the intelligence they had received, and found in multiple specific cases that they had — that statements made publicly about Iraqi nuclear capabilities, biological weapons, and links to al-Qaeda were not supported by the classified intelligence the same officials were receiving. The hindsight-bias defense does not engage this finding. It treats the war as a tragic miscalculation when the public record indicates it was substantially a manufactured case. The narrower defensible position is that some senior officials genuinely believed the WMD case while others did not; the Senate report distinguishes between these. The categorical defense that everyone acted in good faith on the best available information is contradicted by the federal government’s own subsequent investigations. And the deeper point about consequences stands regardless: no senior architect has faced legal accountability, the same individuals continue to shape American foreign-policy commentary, and the public has not been given the kind of after-action accounting that a democratic society owes its citizens after a war launched on the premises this one was launched on.

◆ ◆ ◆

**Libya, 2011**

The 2011 NATO intervention in Libya is one of the cases the public was given the most morally straightforward framing for and the least documentary follow-up. The official justification was the protection of Libyan civilians in Benghazi from imminent slaughter by the forces of Muammar Qaddafi. U.N. Security Council Resolution 1973, passed on March 17, 2011, authorized a no-fly zone and “all necessary measures” to protect civilians. The NATO intervention that followed lasted seven months, ended with the killing of Qaddafi on October 20, 2011, and left Libya in a state of civil war, fragmented governance, and humanitarian crisis that has continued in various forms to the present.

The post-intervention assessment of the Libya operation has been less favorable than the pre-intervention rhetoric. President Barack Obama himself, The Libya intervention has been studied extensively in subsequent scholarship; the Stimson Center, the Brookings Institution, and the U.S. Institute of Peace have all published critical assessments of the planning gap between the kinetic phase of the operation and the political stabilization that did not follow.

A specific element of the documentary record deserves a careful citation, because it is in the record and was not part of the public discussion of the intervention while the intervention was happening. The publicly available email correspondence between Sidney Blumenthal, an informal adviser to Secretary of State Hillary Clinton, and Clinton herself, released by the State Department through the Freedom of Information Act process in 2015 (FOIA case F-2014-20439), includes an email from Blumenthal dated April 2, 2011, reporting on Qaddafi’s holdings of gold and silver. The email reports a planned move by Qaddafi to create a pan-African dinar backed by Libyan gold to compete with the CFA franc — the post-colonial French-backed currency used in francophone Africa — and cites French government concerns about this initiative as a motivation for French enthusiasm for the intervention. The Blumenthal email exists in the State Department’s declassified files. It is searchable through the State Department’s FOIA reading room.

I want to be very careful here about what I am and am not claiming. I do not claim, and the email itself does not establish, that the Libya intervention was primarily about Qaddafi’s gold-dinar plan. The intervention had multiple drivers, including genuine concern about civilian protection, regional alliance management, the Arab Spring dynamic across the broader region, and the political calculations of the French government under Nicolas Sarkozy. I cite the Blumenthal email because it is in the documentary record, because it was not part of the public discussion of the war while the war was happening, and because — once it is part of the record — the public is entitled to ask whether the official justifications were the whole story. The asking is what democratic accountability looks like. The answer in this case is the same answer that applies to most foreign-policy decisions: motives are mixed, justifications are partial, and the integration of the full picture is what the public is supposed to be permitted to do but rarely is.

◆ ◆ ◆

**Venezuela, sanctions, and dollar discipline**

Venezuela holds the largest proven oil reserves in the world. Its socialist governments under Hugo Chávez and then Nicolás Maduro repeatedly experimented with denominating oil contracts in non-dollar currencies and with creating non-dollar regional clearing arrangements. Chávez specifically promoted the use of euros and other currencies for Venezuelan oil exports in the early 2000s and was a public advocate of the Banco del Sur project to create a South American alternative to the International Monetary Fund. Maduro’s government, after Chávez’s death in 2013, continued the experimentation and attempted in 2017 to denominate Venezuelan oil contracts in yuan and in the regime’s own short-lived oil-backed cryptocurrency, the petro.

The U.S. response over the same period has included successive rounds of unilateral sanctions targeting the Venezuelan oil industry, the Venezuelan central bank, the state oil company PDVSA, the gold sector, and named officials. The principal Executive Orders implementing the sanctions are 13808 (August 2017), 13827 (March 2018), 13835 (May 2018), 13850 (November 2018), and 13884 (August 2019), with implementation managed through the Department of the Treasury’s Office of Foreign Assets Control. The sanctions are documented on OFAC’s public Venezuela sanctions page; the principal Executive Orders are in the Federal Register.

The Venezuelan regime is corrupt, authoritarian, and has produced one of the worst non-war humanitarian collapses of the contemporary period. I do not want to romanticize it. The point of citing the Venezuelan case in this chapter is narrower. There is independent humanitarian evidence — including a 2019 report by Jeffrey Sachs of Columbia University and Mark Weisbrot of the Center for Economic and Policy Research, titled “Economic Sanctions as Collective Punishment: The Case of Venezuela” — that the U.S. sanctions contributed to elevated mortality in Venezuela through their effects on imported medicine and food, even granting the corruption and misgovernance of the Venezuelan state. The Sachs-Weisbrot report estimated attributable to the sanctions in the 2017–2018 period alone. The methodology has been contested; the underlying point that the sanctions imposed substantial humanitarian costs on civilians distinct from the misconduct of the regime they targeted has not been seriously refuted.

The pattern across Iraq, Libya, and Venezuela is not that every American intervention is monetary in motive. It is that interventions and sanctions regimes have, with notable frequency, targeted governments that were attempting in some specific way to challenge the post-1971 dollar-denominated oil-trade architecture. The pattern does not prove that monetary motives are the principal driver of policy. It does indicate that monetary motives are part of the relevant analytical landscape, and that any analysis of American foreign-policy decisions that excludes the monetary dimension is incomplete in a way that the public discussion routinely is.

◆ ◆ ◆

**COUNTERARGUMENT**

The 2003 invasion of Iraq, the 2011 intervention in Libya, and U.S. sanctions on Venezuela can each be defended on humanitarian or counterterror or regional-stability grounds without reference to the dollar. Reducing them all to monetary motives is conspiratorial, ignores the genuine complexity of foreign-policy decision-making, and trivializes the underlying humanitarian or strategic concerns each intervention was framed around.

**WHY THIS DOES NOT SAVE THE FRAMING**

No single motive explains every intervention; that would be a bad argument and the chapter does not make it. The narrower claim is that once the structural importance of dollar-denominated oil is recognized, certain recurring patterns become harder to dismiss as coincidence. Public justifications vary by case. The strategic beneficiary of the monetary architecture often looks similar. Treating that as relevant context for foreign-policy analysis is not conspiracy theory. It is the literal job of strategic analysis. The structural humanism reading is that the public has been given partial accounts of why specific interventions occurred when they occurred and against the specific targets they targeted, and that the missing piece is reliably the monetary dimension. Naming the missing piece does not require imposing a single-cause theory on the cases. It requires only insisting that the analysis be complete.

◆ ◆ ◆

**Sanctions as the quieter intervention**

Sanctions are the foreign policy that does not make the front page on most days. The Treasury Department’s Office of Foreign Assets Control administers more than thirty active sanctions programs, restricting U.S. persons from financial dealings with designated individuals, entities, and in some cases entire countries. The mechanisms range from targeted asset freezes against named individuals to broader sectoral sanctions that prohibit transactions in entire categories of industry.

The growth has been dramatic. The number of names on OFAC’s Specially Designated Nationals and Blocked Persons List has more than doubled in the last fifteen years, and the share of global gross domestic product under some form of U.S. or U.S.-allied sanctions is at a historic high. The Global Sanctions Database project, maintained by researchers at the Drexel University LeBow College of Business and several European institutions, provides the principal academic tracking of the trend. The figures are publicly available.

The humanitarian record of broad sanctions on civilian populations is the part of the policy that is rarely accounted for honestly in mainstream discussion, and it deserves an honest accounting because the cumulative human cost is substantial.

The classic case study, predating the cases discussed above, is Iraq under the 1990s U.N. sanctions regime. The U.N. Office for the Coordination of Humanitarian Affairs, UNICEF, and the World Health Organization all documented elevated child mortality in Iraq during the sanctions period, with various estimates of excess deaths attributable to the sanctions running from the high tens of thousands to the high hundreds of thousands depending on methodology. UNICEF’s 1999 survey, conducted in cooperation with Iraqi authorities, estimated approximately 500,000 excess deaths of children under five during the sanctions decade. The figure has been contested; subsequent reanalyses have produced lower estimates. What has not been seriously contested is that the sanctions imposed substantial humanitarian costs distinct from those imposable on the Hussein regime itself. The most consequential American public response was the response of then-Secretary of State Madeleine Albright, who, when asked in a 1996 CBS Sixty Minutes interview by Lesley Stahl whether the resulting child deaths were “worth it,” replied: “We think the price is worth it.” Albright later wrote in her 2003 memoir Madam Secretary that she regretted the answer; the answer itself is part of the public record.

The post-2017 Venezuela sanctions, as discussed above, have produced documented humanitarian costs. The Afghan central bank reserves frozen by the United States after the 2021 Taliban takeover — approximately $7 billion in Afghan central bank holdings at the Federal Reserve Bank of New York — contributed, according to UN OCHA and World Bank reporting, to the humanitarian crisis that followed, in a country whose entire economy had been built around foreign aid flows and whose central bank could no longer function to stabilize the currency or manage liquidity. The 2022 freezing of Russian foreign-exchange reserves following the invasion of Ukraine was an unprecedented act of monetary statecraft whose long-term effects on the global financial architecture are still developing. The Iranian sanctions regime, in place in various forms since 1979 and significantly intensified since 2018, has imposed substantial costs on Iranian civilians, including in the form of restricted access to medicine and medical equipment that the sanctions formally exempt but that the secondary-sanctions environment makes practically difficult to import.

I do not argue that sanctions are never justified. They are sometimes the least bad available tool against a regime engaged in atrocity, and a well-designed targeted sanctions regime aimed at specific officials and entities can be a legitimate instrument of foreign policy. I argue that the public is rarely given a clear accounting of who pays the humanitarian cost when sanctions extend beyond the targeted officials to the civilian population, and that a serious foreign policy would not treat that cost as politically free. The cost is real. The deaths it causes are real. The civilians it impoverishes are real. The accounting is owed.

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for American monetary-military entanglement has two layers: an honest accounting layer and a structural reform layer.

On honest accounting: every major sanctions program should be subject to mandatory periodic humanitarian-impact assessment by an independent body, with the results made public and reviewable by Congress. The current sanctions architecture provides essentially no formal mechanism for evaluating the humanitarian cost of programs that have been in place for decades. The Costs of War Project model — an academic accounting that the federal government has not produced for itself — should be institutionalized as a permanent function, with adequate funding and access to relevant federal data, so that the public has a continuously available accounting of the human and financial costs of ongoing American foreign-policy commitments.

On structural reform: the question of the dollar’s reserve-currency status is one of the most important and least-discussed strategic questions in American public life. The arrangement has produced specific benefits to the United States — cheap borrowing, persistent trade deficits without currency crisis — and specific costs that fall disproportionately on the populations most affected by the sanctions regime and the wars the arrangement helps enable. The serious question is whether the benefits can be retained while the costs are reduced. The economic literature on alternative monetary arrangements — a multipolar reserve-currency order, a Special Drawing Rights-based system, a commodity-anchored arrangement — has developed substantially over the past decade. The political conversation in the United States has not. The first reform is the willingness to have the political conversation. The serious starting points are the work of the economist Barry Eichengreen at the University of California, Berkeley, particularly his Exorbitant Privilege (Oxford, 2011), and the more critical analyses of the Bank for International Settlements economist Hyun Song Shin and the historian Adam Tooze.

And on the use of force: the constitutional framework for the use of American military force has, since the 2001 Authorization for the Use of Military Force, been substantially detached from the constitutional design that placed the war-making power with Congress. The reform of the AUMF framework has been proposed in multiple Congresses across both parties and has not been enacted. Repeal of the 1991 and 2002 Iraq AUMFs, replacement of the 2001 AUMF with a more narrowly drawn authorization with explicit sunset and reporting requirements, and a serious congressional reassertion of the War Powers Resolution’s requirements would together return the war-making decision to something closer to the constitutional design. The proposal is not radical. It is the application of the existing constitutional framework. The political will to enact it has been absent. The cost of the absence is on the record.

◆ ◆ ◆

**Pattern**

A monetary order maintained by force is not a free market. The dollar’s global position is not a natural product of American economic excellence. It is a constructed arrangement, designed by specific people at a specific moment, maintained by specific commitments of force and specific patterns of foreign-policy decision-making, and producing specific human costs that the populations bearing those costs have not been politically represented in any deliberation about. The arrangement has produced real benefits for the United States. It has also produced the deaths of large numbers of people whose lives the public was rarely told were being traded for the price of dollar dominance.

I am not arguing that the dollar should be abandoned or that American foreign policy should retreat from the world. I am arguing that the public deserves a clear accounting of how the monetary architecture and the military architecture are structurally connected, that the human costs of the arrangement should be a matter of public record rather than of academic obscurity, and that the foreign-policy decisions made in the name of the American people should be made with the full picture available to the public in whose name they are made. The cost of the arrangement is on the record. The accounting is what is missing. The next chapter — on blowback and the long tail of covert intervention — extends the analysis from the monetary architecture to the specific covert operations whose consequences have shaped a generation of American foreign policy and whose architects have largely escaped accountability for the consequences they produced.

> *The dead pay the bill for the price of the dollar, and the public is rarely told they are doing so.*

**Chapter 7**

*Blowback and Immunity*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

This chapter is the most sensitive in the book and the one I have most carefully tried to ground in the documentary record. Before any of its specific arguments, I want to be explicit about three governing principles.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><strong>Three principles that govern this chapter</strong></p>
<p><strong>First, anti-antisemitism.</strong> Antisemitism is real, ancient, has produced unimaginable evil, and is not a tool I have any use for. Conspiracy theories that attribute world events to “the Jews” — as an undifferentiated category, or as a hidden agency behind otherwise inexplicable historical outcomes — are not historical arguments. They are bigotry, and they are wrong as factual claims about who actually holds power. Where I discuss foreign-state lobbying or specific government actions, the target is the documented behavior of states and institutions, not “the Jews,” any more than discussion of Saudi influence operations targets “the Muslims” or discussion of Chinese influence operations targets “the Chinese.”</p>
<p><strong>Second, the consistent application principle.</strong> The Foreign Agents Registration Act applies — and should be enforced — equally against Israeli, Saudi, Qatari, Turkish, Chinese, Russian, and any other foreign-state-tied influence operation in the United States. Any of these states’ operations is fair game for democratic scrutiny on the same terms. If I am willing to discuss Saudi influence in U.S. foreign policy, I should be willing to discuss the others, and I am.</p>
<p><strong>Third, the distinction between criticism and bigotry.</strong> The State of Israel is a state. Criticism of state policy — Israeli, American, Saudi, Iranian, Russian — is the ordinary work of democratic argument. Antisemitism is hatred of Jewish people. Conflating the two protects neither Jews nor honest argument.</p></td>
</tr>
</tbody>
</table>

With those principles stated, the chapter.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: how does the documented covert and quasi-covert foreign-policy record of the United States and its closest allies — from the late 1970s to the present — illuminate the recurring pattern by which concentrated power produces the conditions it later asks the public to fear, and what does the systematic absence of accountability for the architects of these policies tell us about the structural design of the system within which they operate?

Thesis, in one sentence: concentrated power, operating through secrecy and weakly supervised by the elected branches of government, repeatedly produces the conditions it later asks the public to fund the response to, and then absorbs essentially no professional or legal consequence when those conditions metastasize — a pattern documented across the cases this chapter examines, and structural rather than coincidental.

I examine five cases. The CIA’s covert war in Afghanistan and its long tail. The dissolution of Iraq’s army and the creation of the organizational space ISIS would later fill. The documented Israeli policy of facilitating Qatari transfers to Hamas as part of a divide-and-manage strategy. The unresolved attack on the USS Liberty. And the 1962 Justice Department effort to require the American Zionist Council to register under the Foreign Agents Registration Act, an effort that was abandoned after the lobbying organization reconstituted itself as the American Israel Public Affairs Committee. The cases differ in their specifics. The structural pattern across them is consistent. I will name the consistency at the end.

◆ ◆ ◆

**Afghanistan: the trap that was set**

The conventional public story of CIA support for the Afghan mujahideen places it in the years after the Soviet invasion of December 1979. The actual record is different, and the person who established it was Zbigniew Brzezinski, Jimmy Carter’s National Security Advisor.

In an interview with the French magazine Le Nouvel Observateur, published January 15–21, 1998, Brzezinski stated that Carter signed the first presidential finding authorizing covert aid to anti-government forces in Kabul on July 3, 1979 — almost six months before the Soviet invasion. The interviewer, Vincent Jauvert, pressed him on whether the United States had deliberately provoked the Soviet intervention. Brzezinski’s reply, in the published transcript: “We didn’t push the Russians to intervene, but we knowingly increased the probability that they would.”

When asked whether he regretted the decision in light of subsequent Islamist radicalization, Brzezinski’s answer is on the record verbatim: “Regret what? That secret operation was an excellent idea. It had the effect of drawing the Russians into the Afghan trap and you want me to regret it? The day that the Soviets officially crossed the border, I wrote to President Carter: We now have the opportunity of giving to the USSR its Vietnam war.” The interviewer followed up: did he not regret arming and training what became the international jihadist movement? Brzezinski: “What is most important to the history of the world? The Taliban or the collapse of the Soviet empire? Some stirred-up Moslems or the liberation of Central Europe and the end of the Cold War?”

These quotations were corroborated independently by Robert Gates, former Director of Central Intelligence and later Secretary of Defense, in his 1996 memoir From the Shadows (Simon & Schuster), in which Gates confirmed both the July 3, 1979 finding and the “almost six months before the Soviets invaded” timeline. The Brzezinski interview was published in the French edition of Nouvel Observateur but, according to multiple researchers including the historian William Blum, the version distributed for English-language audiences differed in its retention of the most candid passages. The French transcript is the primary source. It is reproduced in Blum’s Rogue State (Common Courage Press, 2000) and is searchable through the Nouvel Observateur archive.

Operation Cyclone, the program that followed the July 1979 finding, By the mid-1980s the CIA was channeling roughly $600 million per year through Pakistan’s Inter-Services Intelligence directorate to the seven Afghan mujahideen factions designated by Islamabad, with matching Saudi funding bringing the annual total above $1 billion at peak. The selection of which factions received weapons and money was controlled almost entirely by Pakistani ISI, which favored the most Islamist groups, including Gulbuddin Hekmatyar’s Hezb-i-Islami, over more nationalist Afghan commanders. Steve Coll’s Ghost Wars: The Secret History of the CIA, Afghanistan, and Bin Laden, from the Soviet Invasion to September 10, 2001 (Penguin, 2004), is the principal scholarly history of the operation; Coll’s account is the basis for most subsequent journalism on the subject.

The infrastructure built under Cyclone — recruitment networks pulling foreign fighters into Pakistan and Afghanistan, training camps, weapons pipelines, financial conduits, and the ideological framing of the conflict as global jihad — did not dissolve when the Soviets withdrew in 1989. The same logistical and personnel network produced the foreign-fighter cohort from which al-Qaeda would recruit. Osama bin Laden’s own trajectory ran directly through the Peshawar-based Maktab al-Khidamat, the foreign-fighter recruitment office founded by his mentor Abdullah Azzam in the mid-1980s. The infrastructure outlived its sponsor’s intent.

**Sidebar: Operation Cyclone, key dates**

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 85%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Date</strong></td>
<td><strong>Event</strong></td>
</tr>
<tr class="even">
<td>July 3, 1979</td>
<td>President Carter signs first presidential finding authorizing covert aid to anti-government forces in Kabul. Confirmed by Gates (1996) and Brzezinski (1998).</td>
</tr>
<tr class="odd">
<td>December 1979</td>
<td>Soviet Union invades Afghanistan. Brzezinski writes to Carter: “We now have the opportunity of giving to the USSR its Vietnam war.”</td>
</tr>
<tr class="even">
<td>1980s</td>
<td>CIA channels ~$600M/year through Pakistan’s ISI to seven Afghan mujahideen factions. Saudi matching funds bring annual total above $1B at peak.</td>
</tr>
<tr class="odd">
<td>1984–1989</td>
<td>Maktab al-Khidamat, Peshawar-based foreign fighter recruitment office, operates as the network bin Laden later draws on for al-Qaeda.</td>
</tr>
<tr class="even">
<td>1989</td>
<td>Soviet withdrawal from Afghanistan. Operation Cyclone formally ends. Recruitment, training, and ideological infrastructure remains.</td>
</tr>
<tr class="odd">
<td>1996</td>
<td>Robert Gates memoir From the Shadows confirms the pre-invasion timeline.</td>
</tr>
<tr class="even">
<td>1998 (Jan.)</td>
<td>Brzezinski interview in Le Nouvel Observateur publishes the on-record quotes above.</td>
</tr>
</tbody>
</table>

*Source: Brzezinski, Le Nouvel Observateur, January 15–21, 1998; Robert Gates, From the Shadows (Simon & Schuster, 1996); Steve Coll, Ghost Wars (Penguin, 2004); William Blum, Rogue State (Common Courage Press, 2000).*

◆ ◆ ◆

**COUNTERARGUMENT**

Operation Cyclone bled the Soviet Union, hastened the collapse of the USSR, and the September 11 attacks cannot be traced cleanly to any single covert program. The Saudis, the Pakistanis, the Egyptian Islamists who founded al-Qaeda’s intellectual core, and bin Laden himself all bear their own moral and operational responsibility. The case against Cyclone is that the CIA created al-Qaeda from nothing, which is not true.

**WHY THIS DOES NOT SAVE THE FRAMING**

The case is narrower than the strongest version of it. A policy was undertaken to deliberately increase the probability of a Soviet invasion (Brzezinski’s own words), then expanded into the largest covert operation in CIA history, with weapons and money flowing through an intelligence service that systematically favored the most extreme factions, building an international infrastructure for armed Islamist mobilization that long outlived its sponsor’s intent. The public was not told this was happening at the time. When it produced consequences, those consequences were narrated to the public as if they had no prior American causal contribution. And nobody in the chain of command faced consequences for any of it. The Soviet Union did exit Afghanistan demoralized; the disintegration that followed had many causes. And the moral responsibility for al-Qaeda’s subsequent actions belongs to al-Qaeda. The structural humanism reading of Cyclone is not that the CIA created bin Laden. It is that a covert program was undertaken whose downstream consequences included the radicalization infrastructure from which September 11 would draw, that the decision was made without public deliberation, and that the public was subsequently asked to fund the response without being given a clear accounting of how the original conditions had been produced. That is blowback in its operative form: a strategic decision made in secret, generating a long-term threat, with the costs of confronting that threat falling on a public never consulted about the original decision.

◆ ◆ ◆

**Iraq: how an occupation built its own successor enemy**

If Afghanistan illustrates blowback through covert action, Iraq illustrates blowback through publicly made occupation decisions whose disastrous consequences were predicted, ignored, and never reckoned with.

On May 16, 2003, Coalition Provisional Authority Administrator L. Paul Bremer issued CPA Order 1, “De-Ba’athification of Iraqi Society,” removing the top four ranks of Ba’ath Party members from public employment and barring them from future government positions. On May 23, 2003, he issued CPA Order 2, “Dissolution of Entities,” which formally disbanded the Iraqi army, the Republican Guard, and the entire Ministry of Defense apparatus.

The numbers matter. The Iraqi security forces dissolved by CPA Order 2 included approximately 385,000 in the armed forces, 285,000 in the Interior Ministry police, and 50,000 in presidential security units — roughly 720,000 men, most of them armed, trained, suddenly unemployed, humiliated in their professional identity, and now barred by CPA Order 1 from civilian government employment if they had been senior Ba’athists.

The decisions reversed prior planning. As the public-administration scholar James Pfiffner documented in his 2010 article “U.S. Blunders in Iraq: De-Baathification and Disbanding the Army,” published in Intelligence and National Security, volume 25, number 1, the Bush administration’s National Security Council had concluded before the invasion that the Iraqi army should be retained for reconstruction. Retired General Jay Garner, initially in charge of postwar Iraq under the Office of Reconstruction and Humanitarian Assistance, had briefed Condoleezza Rice on plans to retain the army on February 19, 2003. President Bush had been briefed in an NSC meeting on March 12, 2003, with general consensus that the army would be kept. Pfiffner concluded, after extensive interviews with the principals, that “the most likely decision maker” who overrode that consensus “was the Vice President.”

Why this matters operationally: ISIS, in its origins, was not a movement of religious volunteers. Its command structure was disproportionately staffed by former Iraqi military and intelligence officers from Saddam Hussein’s army. A 2015 Der Spiegel investigation by Christoph Reuter, drawing on captured ISIS internal documents recovered in northern Syria, traced the organization’s intelligence and security architecture directly to the work of Samir Abd Muhammad al-Khlifawi (known by his alias Haji Bakr), a former colonel in Saddam’s air-defense intelligence service. The article, “Secret Files Reveal the Structure of Islamic State,” was published April 18, 2015. The Wilson Center, the Brookings Institution, and the West Point Combating Terrorism Center have all published parallel analyses showing that roughly one-third to one-half of ISIS’s senior leadership in its rise to power had served in Saddam Hussein’s military or intelligence services before being thrown into the street by CPA Order 2.

The Atlantic Council, hardly a fringe outlet, has acknowledged the link plainly in its institutional analysis: “The de-Baathification order also created a cadre of former regime elites with the connections, experience, and political savvy to coordinate resistance to the new American project almost instantly. Indeed, there was good evidence that some of these same regime elites and soldiers wound up helping to generate the Islamic State of Iraq and al-Sham (ISIS), an existential threat to the Iraqi state.”

◆ ◆ ◆

**COUNTERARGUMENT**

Bremer has maintained that the Iraqi army had effectively self-demobilized by May 2003, that the formal dissolution merely ratified an existing reality, and that the alternative — reconstituting a Ba’athist-officered army under American occupation — would have been politically untenable in a country whose Shia and Kurdish majority had suffered under that very institution.

**WHY THIS DOES NOT SAVE THE FRAMING**

The army’s collapse during the invasion did not require permanent dissolution; reconstitution under new leadership was an option that had been actively planned, was being implemented on the ground by Garner’s team, and was being negotiated with senior Iraqi officers who had begun to come forward. CPA Order 2 closed that door deliberately. And the political-untenability argument cuts the other way: the United States chose to invade and occupy a country it did not understand, then chose to dissolve the only Iraqi institution capable of providing security in the resulting vacuum. The deeper objection is structural. A war launched on false premises was followed by occupation decisions made over the objections of senior military and intelligence professionals, with predictable consequences that arrived on schedule. The public was then asked to fund and fight a second war — against ISIS — to address conditions the first war had created. The same architects, the same think tanks, the same media voices that sold the original war moved seamlessly into selling its sequel. Once again, no consequences flowed upward.

◆ ◆ ◆

**Hamas: manage the enemy you prefer**

The pattern of covert American action is matched by an openly acknowledged Israeli strategy. From roughly 2012 forward, the government of Benjamin Netanyahu pursued a policy of facilitating Qatari cash transfers to Hamas in Gaza while keeping the Palestinian Authority in the West Bank politically and financially constrained. The strategic objective, articulated repeatedly by senior Israeli officials, was to prevent the emergence of a unified Palestinian negotiating partner capable of advancing a two-state framework.

The documentation comes from Israeli sources, not from external critics. Three pieces of evidence are central, and I will cite each carefully.

First, the 2019 Likud-faction quotation. According to reporting in Haaretz, the Israeli biographer Ben Caspit, and a Politico account drawing on Likud insiders, at a March 2019 Likud parliamentary-faction meeting, Netanyahu told colleagues: “Anyone who wants to thwart the establishment of a Palestinian state has to support bolstering Hamas and transferring money to Hamas. This is part of our strategy: to isolate the Palestinians in Gaza from the Palestinians in the West Bank.” Netanyahu denied the quote to Time magazine in a 2024 interview. Time’s fact-check noted that the quote was reported by multiple Israeli sources and that Netanyahu had reportedly said the same in a 2012 interview with the journalist Dan Margalit. Israeli Finance Minister Bezalel Smotrich also articulated the same strategic logic in a 2015 interview. The reader does not need to accept the verbatim Likud quote to evaluate the policy. The policy itself is documented in multiple corroborating sources.

Second, the Qatari cash transfers themselves. From late 2018 onward, with formal Israeli approval, Qatar sent monthly cash payments to Gaza, frequently delivered in suitcases moved through Israeli territory under Israeli intelligence escort. The New York Times reported in December 2023, drawing on Israeli and American officials, that “Israeli intelligence officers even escorted a Qatari official into Gaza, where he doled out money from suitcases filled with millions of dollars.” Estimates of the total Qatari cash transfer to Gaza during the Netanyahu-approved period run above $1 billion. In February 2020, then-Mossad Director Yossi Cohen and IDF Southern Command chief Major General Herzi Halevi traveled to Qatar at Netanyahu’s instruction to persuade Qatari officials to continue the cash payments after Doha had signaled it might end them — a trip publicly reported by then-Defense Minister Avigdor Liberman to Channel 12 News and not subsequently denied.

Third, the contemporaneous testimony of senior Israeli officials. Former Prime Minister Ehud Barak said on Israeli Army Radio in August 2019 that Netanyahu’s main strategy was to keep Hamas “alive and kicking” in order to weaken the Palestinian Authority. Former Prime Minister Ehud Olmert told Politico in 2023: “In the last fifteen years, Israel did everything to downgrade the Palestinian Authority and to boost Hamas. Gaza was on the brink of collapse because they had no resources, they had no money, and the PA refused to give Hamas any money. Bibi saved them. Bibi made a deal with Qatar and they started to move millions and millions of dollars to Gaza.” Israeli Major General Gershon Hacohen, an associate of Netanyahu, stated in a 2019 Israeli television interview: “Netanyahu’s strategy is to prevent the option of two states, so he is turning Hamas into his closest partner. Openly Hamas is an enemy. Covertly, it’s an ally.”

On October 7, 2023, Hamas executed the deadliest single-day attack on Jewish people since the Holocaust, killing approximately 1,200 Israelis and taking more than 240 hostages. The military and financial capacity built up during the Qatari cash-transfer period was central to the operational scale of the attack. Israeli intelligence officials have since acknowledged, in reporting by Reuters, the New York Times, and Haaretz, that the funds were a significant input to Hamas’s operational buildup. The editorial board of Haaretz itself, on October 9, 2023, named the containment policy as a strategic failure that contributed to the conditions under which the October 7 attack became possible.

The point I am making is not that Israel created Hamas. Hamas exists. Its founding ideology is its own. Its actions are its own. The October 7 attack was the act of Hamas, and the moral responsibility for the deaths in southern Israel that morning belongs to the people who committed the killings. The point is narrower. A documented containment policy was pursued by a state allied with the United States, the policy was articulated to internal Israeli audiences in strategic terms by the politicians who designed it, and the structural logic of containment-by-tolerated-rival is a recurring pattern across U.S. and U.S.-allied foreign policy — not a unique feature of any one state.

◆ ◆ ◆

**COUNTERARGUMENT**

Defenders of the Qatari-cash policy, including some who were not Netanyahu allies, argued at the time that the Qatari money was humanitarian — it paid civil servants, fueled the Gaza power plant, and prevented humanitarian collapse that would have produced a far bloodier war sooner. The Haaretz defense editor Amos Harel made exactly this case in 2018: “Continued pressure on the Strip will lead to an explosion. If Israel has nothing to gain by invading Gaza, it ought to try any other possible solution before going to war.”

**WHY THIS DOES NOT SAVE THE FRAMING**

The humanitarian framing is not separable from the strategic framing. Netanyahu, Barak, Olmert, Hacohen, and Smotrich all described the policy in strategic terms — as a method of preventing Palestinian political unification and foreclosing a two-state framework — and senior Israeli officials traveled to Doha to lobby for the cash transfers to continue. The humanitarian justification was the public face; the strategic logic, articulated repeatedly to internal audiences, was that a divided Palestinian polity served Israeli political objectives. The policy was, in other words, both things at once. And what it produced was October 7. The Israeli public is now living with the consequences of decisions made, defended internally as strategic, and now disavowed by the same political leadership that authored them. The Palestinian civilian population is paying a substantially higher cost. Both populations were poorly served by a strategy designed for political durability rather than for the underlying problem.

◆ ◆ ◆

**The USS Liberty: an investigation that was not permitted**

On June 8, 1967, the fourth day of the Six-Day War, Israeli aircraft and torpedo boats attacked the USS Liberty, an unarmed U.S. Navy signals-intelligence vessel cruising in international waters off the Sinai coast. The attack killed 34 American servicemen and wounded 171. The combined air and sea assault lasted approximately seventy-five minutes — the air attack alone ran about twenty-five minutes, followed by torpedo-boat attacks. The Israeli government formally apologized, characterized the attack as a tragic mistake of identification, and paid compensation. The official U.S. Navy Court of Inquiry, convened within days, returned a finding consistent with the Israeli account.

The accident framing has been disputed since the day it was issued, but the most consequential testimony came decades later from inside the original investigation.

On October 22, 2003, retired Navy Captain Ward Boston Jr., who had served as senior legal counsel to the 1967 Court of Inquiry, signed a sworn affidavit. The document was released at a Capitol Hill press conference by an independent commission led by retired Admiral Thomas Moorer, former Chairman of the Joint Chiefs of Staff. Boston stated, in the language of the affidavit, that he had known “from personal conversations with the late Admiral Isaac C. Kidd — president of the Court of Inquiry — that President Lyndon Johnson and Secretary of Defense Robert McNamara ordered him to conclude that the attack was a case of ‘mistaken identity’ despite overwhelming evidence to the contrary.” Boston’s affidavit also stated that “Admiral Kidd and I were given only one week to gather evidence for the Navy’s official investigation, though we both estimated that a proper Court of Inquiry would take at least six months,” and that the released transcript of the Court of Inquiry was not the same one he had certified — that pages he had hand-corrected and initialed were missing, and that the testimony of Lieutenant Lloyd Painter regarding Israeli torpedo boats machine-gunning the Liberty’s life rafts had been removed.

Boston’s explanation for his decades of silence: “I am a military man, and when orders come, I follow them.” He cited the publication of A. Jay Cristol’s 2002 book The Liberty Incident (Brassey’s), which defended the accident finding, as what compelled him to speak. The full Boston affidavit is archived by the USS Liberty Veterans Association at gtr5.com and is in the public record.

The Moorer commission of 2003–2004 included, in addition to Admiral Moorer, retired Marine General Ray Davis (former Assistant Commandant of the Marine Corps and Medal of Honor recipient); retired Rear Admiral Merlin Staring (former Judge Advocate General of the Navy, who in 1967 had actually been assigned to review the Court of Inquiry record and had refused to endorse it before being removed from the review); and Ambassador James Akins (former U.S. Ambassador to Saudi Arabia). The commission’s findings, entered into the Congressional Record on October 11, 2004 by Representative Cynthia McKinney, concluded that “Israel committed an act of war against the United States” and called for a congressional investigation. No such investigation has ever occurred. The Liberty remains the only major attack on a U.S. naval vessel in the modern era that has never received a full congressional inquiry.

I cite this material with the standard journalistic discipline. The official U.S. government finding remains mistaken identity. The Israeli government continues to characterize the attack as a tragic error. Senior Navy personnel directly involved in the original Court of Inquiry have stated under oath that they believed the finding was wrong and were prevented from reaching the conclusion they thought the evidence supported. James Bamford’s Body of Secrets (Doubleday, 2001), a history of the National Security Agency by one of its most respected outside scholars, and James Ennes’s Assault on the Liberty (Random House, 1979), a memoir by a Liberty officer present during the attack, present additional documentary and testimonial material consistent with Boston’s account. The official record and the on-the-record contradictions of the official record are both part of the public documentary archive. The reader is entitled to evaluate them.

◆ ◆ ◆

**Fulbright, the AZC, and FARA**

In 1962 and 1963, Senator J. William Fulbright, then chairman of the Senate Foreign Relations Committee, held a series of hearings on the activities of the American Zionist Council and the question of whether the AZC should be required to register under the Foreign Agents Registration Act on the basis of its receipt of funds from the Jewish Agency, an organ of the Israeli government. The Justice Department issued a determination in 1962–1963 that the AZC should register. The AZC reconstituted its primary lobbying functions under the new umbrella of the American Israel Public Affairs Committee — AIPAC — which has, since that time, lobbied as a domestic organization not registered under FARA.

The hearings, published as Senate Foreign Relations Committee, “Activities of Nondiplomatic Representatives of Foreign Principals in the United States,” in 1963, and the underlying Justice Department correspondence, were declassified through a series of releases including a substantial 2008 disclosure. The full primary materials are available through the National Archives and through the Institute for Research: Middle Eastern Policy, which has compiled them in searchable form. The principal documentary fact is straightforward: the Justice Department determined that an organization receiving foreign-government funds for U.S. lobbying purposes should register under FARA. The organization restructured to avoid the registration requirement. The restructured organization has since become one of the most influential lobbying operations in Washington, by most observers’ measure, and it does so without the disclosure obligations that would apply to a registered foreign agent.

I name this case on the consistent-application principle. I am willing to discuss it because I am willing to discuss the parallel cases on the same terms. The Saudi-influence case in the United States is, in operational terms, the largest of the comparable foreign-influence operations. The Department of Justice has registered numerous lobbying firms under FARA for Saudi-government-related work; declassified materials related to the 28 Pages and the Moussaoui v. Kingdom of Saudi Arabia litigation document the scope of Saudi-state-connected activity inside the United States in the years before September 11; multiple subsequent investigative reports have documented the Saudi state’s investments in U.S. think tanks, universities, and political action committees. The Qatari case includes documented funding to U.S. universities, think tanks, and policy-adjacent institutions in amounts that have at times approached or exceeded those of other Gulf states. The Turkish case involves documented influence operations connected to the Gulen movement and to the Erdoğan government’s relationships with U.S. political figures. The Chinese case involves the Confucius Institute network on American university campuses, documented United Front Work Department activity, and the well-documented intellectual-property and technology-transfer concerns that have driven much of the U.S.-China policy debate of the last decade. None of these countries’ operations is uniquely benign. The honest standard is the same standard for all of them.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><strong>LEGAL DISCLAIMER — Foreign Influence Section</strong></p>
<p>The material above describes documented policies of governments and lobbying organizations. It is not a claim about the loyalty, opinions, or activities of any private citizen or any community. Antisemitism is hateful and false. The American Jewish community, like every community, is morally and politically heterogeneous and does not bear collective responsibility for the actions of a foreign state. Criticism of any government’s policy is the ordinary work of democratic argument and is to be sharply distinguished from bigotry against any people.</p></td>
</tr>
</tbody>
</table>

◆ ◆ ◆

**Funding flows and the documentary record**

A narrower datum from the public record, frequently misquoted and worth stating precisely. On October 2, 2014, then-Vice President Joseph Biden, in remarks to students at the Harvard Kennedy School’s Institute of Politics, stated that during the early Syrian civil war, “our allies in the region” — he named the Turks, the Saudis, and the United Arab Emirates — had been “so determined to take down Assad” that they had “poured hundreds of millions of dollars and tens of thousands of tons of weapons into anyone who would fight against Assad,” including “al-Nusra and al-Qaeda and the extremist elements of jihadis coming from other parts of the world.” Biden later qualified the framing under diplomatic pressure. The on-record statement is part of the public record either way; the Harvard Kennedy School Institute of Politics archives the full video.

The WikiLeaks-released August 17, 2014 email from Hillary Clinton, then no longer Secretary of State, to John Podesta, found in the publicly released Podesta correspondence and indexed by WikiLeaks as document ID 3774, contained an attachment characterized as a strategic memo on Iraq and Syria. The memo discussed pressuring “the governments of Qatar and Saudi Arabia” over “clandestine financial and logistic support to ISIL and other radical Sunni groups in the region.” The authenticity of the Podesta release was confirmed by the principals; the substantive claim about state-funding of regional jihadist groups, made by U.S. officials in U.S. internal correspondence, is part of the documentary record.

Neither datum proves that the United States directly funded ISIS. The narrower documented claim — that close U.S. allies are alleged, in on-record U.S. statements and U.S. internal correspondence, to have funded extremist groups during the Syrian conflict, with the U.S. government’s contemporaneous knowledge — is what the record supports. The longer pattern is what this chapter is documenting. Allies funded extremists. The U.S. government knew. The funding continued. The extremism produced consequences whose American costs are documented in the Costs of War accounting cited in the previous chapter. No senior architect of the broader regional posture has faced legal or professional accountability.

◆ ◆ ◆

**COUNTERARGUMENT**

Calling out the foreign-policy mistakes of allied states is a slippery slope toward antisemitism, anti-Muslim bigotry, or other forms of group hatred. The safer rule is to be quiet about state behavior we find uncomfortable. Singling out specific lobbying organizations or specific allied governments creates a permission structure that bad-faith actors will use to target communities.

**WHY THIS DOES NOT SAVE THE FRAMING**

Silence is its own moral position, and a bad one. A democratic public unable to evaluate the conduct of its own government’s allies cannot perform self-government. The right discipline is not silence. It is precision: target the documented behavior of states and institutions; refuse the move from state behavior to ethnic or religious essentialism; apply the same scrutiny consistently across allies and adversaries; and explicitly reject the bigoted framings that have historically attached to this material. The Foreign Agents Registration Act applies to all foreign-government-tied lobbying. The Saudi case, the Qatari case, the Turkish case, the Chinese case, the Russian case, the Israeli case — each deserves the same evidentiary standard and the same enforcement discipline. The chapter applies that standard. The disclaimer in this chapter is not decorative. It is a working component of the analysis. Anyone who wants to use the documentary record this chapter cites to target the loyalty, opinions, or activities of private American citizens of any background — Jewish, Muslim, Chinese-American, Russian-American, Saudi-American — is misusing the record, and I name the misuse here so the misuse cannot be done in this chapter’s name.

◆ ◆ ◆

**Pattern**

The covert decisions that produce future enemies and present immunity are made in rooms whose contents are routinely declassified twenty or thirty years later. By then the wars have been fought, the dead have been buried, and the architects have moved to think tanks. The five cases in this chapter span more than four decades, four governments, four institutional settings. What unites them is structural rather than ideological. In each case, a concentrated decision-making body operating in conditions of restricted public scrutiny made choices whose downstream consequences harmed populations the decision-makers did not have to face, whose costs were absorbed by publics that were not consulted, and whose architects faced essentially no professional or legal consequence.

The chapter title is the diagnosis. Blowback is real. Immunity is structural. Both are policy choices. The reform agenda follows from the diagnosis. Restore meaningful congressional oversight of covert action under the National Security Act of 1947. Require declassification timelines that allow the relevant decisions to be evaluated by the public within the political lifetimes of the people who made them. Apply the Foreign Agents Registration Act consistently across all foreign-state-tied lobbying. Conduct congressional inquiries into the cases that have never received them, the Liberty among them. Treat war-making decisions as the constitutional acts of Congress they were designed to be, not as the discretionary acts of an executive that the post-2001 AUMF framework has allowed them to become. None of these reforms is radical. All of them are within the existing constitutional architecture. The political will to enact them has been absent for sustained periods across both parties. The cost of that absence is on the record, in the deaths the chapter has documented and in the wars whose architects are still respected at the kinds of dinners where reputations are made and lost.

> *Blowback is real. Immunity is structural. Both are policy choices.*

The next chapter turns from the broader foreign-policy record to the single event whose documented public record is widest and whose unresolved questions are most consequential for everything that has followed: September 11, 2001. The chapter does not advance a single grand theory of what happened. It walks through the elements of the public documentary record that the official narrative has not absorbed cleanly, and it grades each element on the evidence available. The discipline of evidence-grading is what makes the chapter responsible. The willingness to integrate the gradings into a coherent picture of unresolved questions is what makes it useful.

**Chapter 8**

*September 11: The Documented Record*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

This chapter does not advance a single grand theory of September 11, 2001. It does something narrower and, I think, more useful. It walks through the elements of the public documentary record that the official narrative has not absorbed cleanly, and it grades each element on the evidence available.

I use a simple three-tier scheme that I will apply consistently throughout the chapter. “Documented” means a federal record, official report, or comparable primary source establishes the fact. “Inferred” means the documentary record is incomplete but the inference is supported by the available evidence. “Open question” means the public evidence is real but not sufficient to settle the matter, and I will name it as open. The point of the scheme is to keep separate from one another things that are routinely conflated in popular discussion of September 11 — facts that are settled, inferences that are supported but not proven, and questions that remain genuinely open and deserve continued investigation. A serious citizen does not need to resolve every question to act seriously on the chapter. She needs to be able to tell the three kinds of claim apart.

Their families are entitled to a complete public accounting of what happened. The principal plaintiffs in the ongoing civil litigation against the Kingdom of Saudi Arabia are 9/11 victims’ families. The 9/11 Commission itself, in its 2004 final report, recommended further declassification. The Joint Inquiry of the House and Senate Intelligence Committees, completed in December 2002, identified additional information that warranted disclosure but was withheld. Senator Bob Graham, co-chair of the Joint Inquiry, spent the subsequent fourteen years publicly fighting for the declassification of the section of that report known as the 28 Pages, which finally occurred on July 15, 2016. The position of this chapter is not that the official account is necessarily wrong. The position is that the documented public record is wider than the public narrative, that the gap is itself a fact about American political memory, and that the appropriate response to the gap is continued declassification under the standards of an open society rather than the imposition of any competing certainty.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: what is the actual state of the public documentary record on September 11, what elements of that record remain unresolved or in tension with the official account, and what is the appropriate citizen posture toward the remaining questions?

Thesis, in one sentence: the public documentary record on September 11 contains multiple elements that the official account has not absorbed cleanly — the prior warnings, the declassified 28 Pages on Saudi-state-affiliated contacts with hijackers, the documented engineering disagreement about Building 7, the operational difficulties of the 9/11 Commission itself — and the appropriate response to those elements is more declassification, not less, and the continued willingness of civic institutions to evaluate the evidence the federal government’s own oversight bodies have already developed.

◆ ◆ ◆

**Documented: warnings before the attack**

The federal government’s own records establish that specific warnings of the September 11 attacks circulated within the intelligence community in the months preceding the attacks and that the warnings did not produce a coordinated response sufficient to interdict the plot. Two documents are central to this finding.

The Phoenix Memo, July 10, 2001. \[Documented.\] FBI Special Agent Kenneth Williams sent a memorandum to the bureau’s headquarters and to the bureau’s New York field office warning that “Usama Bin Laden” had a “coordinated effort” to send students to U.S. civil aviation universities, specifically naming the Embry-Riddle program in Prescott, Arizona, and recommending that the FBI compile a national list of Middle Eastern aviation students. The memo’s substance and existence were confirmed by the FBI and discussed publicly in the report of the Joint Inquiry of the Senate and House Intelligence Committees, completed in December 2002 and partially declassified in subsequent years. The memo was not acted upon at headquarters. The Phoenix Memo is now in the public record, archived through the Federation of American Scientists’ intelligence-resource collection and through the 9/11 Commission’s document releases.

The August 6, 2001 Presidential Daily Brief. \[Documented.\] Titled “Bin Ladin Determined to Strike in U.S.,” declassified at the request of the 9/11 Commission in April 2004, the PDB stated explicitly that bin Laden was determined to attack the United States, that the FBI was investigating “patterns of suspicious activity” including “preparations for hijackings or other types of attacks,” and that approximately seventy full investigations of bin Laden-related activities were underway at the time of the briefing. The declassified PDB is publicly available through the National Archives’ Information Security Oversight Office. President George W. Bush received the briefing at his ranch in Crawford, Texas, on August 6, 2001, thirty-six days before the attacks. The standard subsequent commentary, including by 9/11 Commission staff, has been that the PDB constituted a strategic warning rather than a specific tactical one. The strategic warning was sufficient to indicate that the threat was active and U.S.-directed. The operational response within the government during the thirty-six days that followed has been the subject of extensive subsequent scholarly and journalistic examination.

I cite these two documents not to allege that the federal government knew the specifics of the attacks in advance — the documentary record does not establish that claim — but to establish what the federal government’s own oversight processes have concluded the federal government did know. The Joint Inquiry’s 2002 report and the 9/11 Commission’s 2004 report both characterized the prewar warning record as substantial. The systemic failures the reports identified — informational siloing between the FBI and the CIA, the underweighting of the threat in the senior policy councils of the new administration, the bureaucratic dysfunction that prevented the Phoenix Memo from producing the operational response Williams had recommended — are documented and are not contested in mainstream historical accounts.

◆ ◆ ◆

**Documented: the 28 Pages**

The so-called 28 Pages — the previously classified section of the December 2002 Joint Inquiry report — were declassified and released on July 15, 2016, after a fourteen-year public campaign for their release led by Senator Bob Graham, the Joint Inquiry’s co-chair, and joined by 9/11 victims’ families. \[Documented.\] The release was authorized by the Office of the Director of National Intelligence and is publicly available through the ODNI’s declassification web portal.

The 28 Pages document specific contacts between two of the September 11 hijackers — Nawaf al-Hazmi and Khalid al-Mihdhar — and Omar al-Bayoumi, a Saudi national who was, at minimum, a Saudi consular employee, and Fahad al-Thumairy, an accredited diplomat at the Saudi consulate in Los Angeles. The 28 Pages also reference financial flows from members of the Saudi royal family to entities and individuals connected to the hijackers. The 28 Pages do not, in their declassified form, establish that the Saudi state, as an institution, authorized these contacts or knew their purpose. They establish that the contacts existed and that U.S. investigators believed the contacts warranted further investigation.

In September 2021, in connection with Moussaoui v. Kingdom of Saudi Arabia — the civil litigation brought by 9/11 families against the Kingdom of Saudi Arabia under the Justice Against Sponsors of Terrorism Act of 2016 — the FBI released previously withheld investigative files relating to al-Bayoumi and the Saudi consulate. \[Documented.\] Those files, while heavily redacted, are part of the public record and are accessible through the FBI’s Vault and through court filings in the Southern District of New York. The litigation is ongoing as of this writing.

The Kingdom of Saudi Arabia has consistently denied that the Saudi state directed or authorized any element of the September 11 plot. The 9/11 Commission’s 2004 stated conclusion was that it had “found no evidence that the Saudi government as an institution, or senior Saudi officials individually, funded al-Qaeda.” The 28 Pages, the 2021 FBI releases, and the ongoing civil litigation contain evidence — partial, contested, and the subject of continuing legal process — that some Saudi-state-affiliated individuals provided support to specific hijackers. The accurate one-sentence summary remains: the documentary record contains evidence of involvement by some Saudi-state-affiliated individuals; the Saudi state denies institutional responsibility; the litigation is ongoing. \[Documented; institutional responsibility: contested in active litigation.\]

**Table 8-1. Status of major 9/11 documentary releases**

<table>
<colgroup>
<col style="width: 32%" />
<col style="width: 16%" />
<col style="width: 51%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Document / source</strong></td>
<td><strong>Date</strong></td>
<td><strong>Status</strong></td>
</tr>
<tr class="even">
<td>Phoenix Memo (FBI Agent K. Williams)</td>
<td>July 10, 2001</td>
<td>Declassified; in public record</td>
</tr>
<tr class="odd">
<td>August 6, 2001 PDB “Bin Ladin Determined”</td>
<td>Aug. 6, 2001</td>
<td>Declassified April 2004; National Archives</td>
</tr>
<tr class="even">
<td>Joint Inquiry Report</td>
<td>Dec. 2002</td>
<td>Released with redactions; section now known as the 28 Pages withheld</td>
</tr>
<tr class="odd">
<td>9/11 Commission Report</td>
<td>July 2004</td>
<td>Public; some sections referenced classified annexes</td>
</tr>
<tr class="even">
<td>NIST NCSTAR 1A (WTC 7)</td>
<td>Nov. 2008</td>
<td>Public; data underlying model partially restricted</td>
</tr>
<tr class="odd">
<td>The 28 Pages</td>
<td>Joint Inquiry, 2002 / released July 15, 2016</td>
<td>Declassified after 14-year public campaign</td>
</tr>
<tr class="even">
<td>Moussaoui v. KSA FBI files</td>
<td>Released Sept. 2021</td>
<td>Partial release; heavily redacted; litigation ongoing</td>
</tr>
</tbody>
</table>

*Source: Office of the Director of National Intelligence declassification releases; National Archives ISOO; FBI Vault; U.S. District Court for the Southern District of New York case docket.*

◆ ◆ ◆

**Documented disagreement: Building 7 and NIST NCSTAR 1A**

The collapse of World Trade Center Building 7 at approximately 5:21 p.m. on September 11, 2001, was the subject of the National Institute of Standards and Technology’s NCSTAR 1A report, published in November 2008. The NIST conclusion was that WTC 7 collapsed primarily because of fires ignited by debris from WTC 1, leading to thermal expansion that buckled a critical column on the east side of the building and triggered progressive collapse. NIST published the engineering analysis and the model files that underlie the conclusion. \[Documented: official conclusion.\]

A subsequent independent structural reevaluation by Leroy Hulsey and colleagues at the University of Alaska Fairbanks, conducted between 2015 and 2019 and published in March 2020 as A Structural Reevaluation of the Collapse of World Trade Center 7, used finite-element modeling to argue that the NIST scenario did not produce the observed collapse pattern in their analysis. The UAF authors do not assert what alternative mechanism produced the collapse; they argue the NIST scenario is not sufficient to explain the observed collapse pattern. The Hulsey report is available through the University of Alaska Fairbanks Scholarworks digital archive. \[Documented: peer-publishable structural critique of the official model.\]

I cite both. The NIST report is the official conclusion. The UAF reanalysis is a documented engineering critique by structural engineers operating outside the federal investigative process, published with the supporting computational work available for evaluation. The public record contains both the official finding and the documented engineering disagreement with it. That is the honest summary. The deeper engineering questions are not within my competence to adjudicate; I am a journalist, not a structural engineer. The relevant point for the chapter’s argument is that the documented professional disagreement exists, that it has not been resolved through subsequent NIST review, and that the resolution of the disagreement would benefit from continued public engineering analysis of the kind the UAF group has conducted. \[Cause of collapse: NIST finding stands as the official conclusion; engineering disagreement is documented; final adjudication: open question within the engineering literature.\]

◆ ◆ ◆

**COUNTERARGUMENT**

Raising any engineering question about Building 7, or about any element of the official September 11 account, is “9/11 truth” territory and dishonors the dead. The official investigations were thorough; the dissenting analyses are fringe; the responsible posture is to accept the consensus finding and stop reopening settled questions.

**WHY THIS DOES NOT SAVE THE FRAMING**

Senator Bob Graham, co-chair of the Joint Inquiry that produced the 28 Pages, spent fourteen years fighting to declassify them and considers their disclosure central to honoring the 9/11 victims, not contrary to it. Families of the dead are the principal plaintiffs in Moussaoui v. Kingdom of Saudi Arabia. The 9/11 Commission itself recommended further declassification in its final report, and the commission’s co-chairs Thomas Kean and Lee Hamilton wrote in their 2006 book Without Precedent (Knopf) that the commission had been “set up to fail” in important respects and that further investigation, particularly into Saudi connections, was warranted. The UAF Hulsey study is an engineering analysis by a structural engineer at a state university with the supporting computational work available for evaluation. None of this is fringe. Demanding access to the documentary record about an attack that killed nearly three thousand people, and that has been used to justify trillions of dollars in spending and the deaths of hundreds of thousands more, is not disrespect to the dead. It is what citizens are supposed to do.

◆ ◆ ◆

**Documented, interpretation contested: put options**

Footnote 130 on page 499 of the 9/11 Commission Report addresses the question of unusual pre-9/11 trading in put options on the stocks of United Airlines and American Airlines — the two airlines whose aircraft were used in the attacks. A put option is a financial instrument whose value rises if the underlying stock price falls; large pre-attack put-option purchases on the relevant airline stocks would have been positioned to profit from the stock-price decline that the attacks were likely to produce. The Commission investigated the trades and concluded that they had benign explanations not connected to advance knowledge of the attacks. The footnote names specific trading entities and their stated rationales. The 9/11 Commission Report is publicly available; the footnote is on page 499. \[Documented: trades occurred; Commission conclusion: benign explanations.\]

The trades themselves are a documented fact. The Commission’s exoneration of them is also a documented fact. Both belong in the record. Whether the Commission’s investigation was sufficient to resolve the question definitively is contested in the subsequent literature; the academic finance scholar Allen Poteshman published a 2006 paper in The Journal of Business analyzing the trading patterns and concluding that they were statistically unusual in ways the Commission’s explanations did not fully address. The Poteshman paper is in the peer-reviewed literature; the Commission’s conclusion is the official finding. \[Trades: documented. Interpretation: contested in the peer-reviewed finance literature.\]

◆ ◆ ◆

**Documented institutional difficulties of the investigation**

The 9/11 Commission Report itself names elements of the operational record that have remained the subject of investigatory disagreement. The Commission documented that the North American Aerospace Defense Command and the Federal Aviation Administration provided incomplete, and in some material instances inaccurate, accounts of the morning’s events to the Commission. The Commission’s general counsel referred the inaccuracies to the Department of Defense Inspector General and to the Department of Transportation Inspector General for further investigation. The journalist Michael Bronner’s August 2006 Vanity Fair reconstruction “9/11 Live: The NORAD Tapes,” drawing on NORAD’s own audio recordings, documented the operational confusion of the morning in detail. The subsequent IG reports, partially declassified, found significant errors in the NORAD and FAA accounts but did not reach a finding of intentional deception. \[Documented: account inaccuracies. Inferred: institutional rather than intentional source.\]

The Commission was also constrained in ways the Commission itself documented in subsequent statements by its co-chairs Thomas Kean, the Republican former governor of New Jersey, and Lee Hamilton, the Democratic former Indiana congressman. Their 2006 book Without Precedent: The Inside Story of the 9/11 Commission (Knopf) discusses interview-access disputes — the Commission was initially denied access to senior officials and was limited in the scope and recording of the interviews it was permitted to conduct — document-access disputes, and the late provision of materials by the FAA and the Pentagon. Kean and Hamilton’s own conclusion was that the Commission had been “set up to fail” in important respects and that further investigation — particularly into Saudi connections — was warranted. \[Documented institutional difficulties of the investigation; documented co-chair recommendation for further investigation.\]

I present these as documented institutional difficulties of the investigation, not as evidence of any specific alternative theory. They are part of why I treat the 28 Pages declassification, the Moussaoui-related FBI releases, and continued litigation as legitimate steps in an ongoing process of public accounting rather than as illegitimate intrusions on a settled conclusion.

◆ ◆ ◆

**The Saudi connection in narrower terms**

Because the Saudi-related material in the public record is where most of the documentary developments of the last decade have come from, let me set its current state cleanly, with the evidence-grading the chapter has been applying.

The 28 Pages, declassified in 2016, document that two of the hijackers — Nawaf al-Hazmi and Khalid al-Mihdhar — received assistance after their arrival in San Diego from individuals connected to the Saudi consulate in Los Angeles, including Omar al-Bayoumi (then formally employed as a Saudi consular employee) and Fahad al-Thumairy (then an accredited diplomat at the Saudi consulate). \[Documented.\] The 28 Pages do not establish that the Saudi state, as an institution, authorized these contacts or knew their purpose. They establish that the contacts existed and that U.S. investigators believed the contacts warranted further investigation.

The September 2021 FBI releases in connection with Moussaoui v. Kingdom of Saudi Arabia extend the documentary record. \[Documented.\] The releases include FBI interviews and investigative summaries that reference additional Saudi-state-affiliated individuals and additional financial flows. The releases are heavily redacted; the unredacted portions are part of the public docket.

The litigation — a civil suit brought by 9/11 victims’ families against the Kingdom of Saudi Arabia under the Justice Against Sponsors of Terrorism Act of 2016 — is active in the U.S. District Court for the Southern District of New York. The Kingdom of Saudi Arabia denies institutional responsibility. \[Active litigation; institutional responsibility: contested.\]

The accurate one-paragraph summary remains: the documentary record contains evidence of contacts between specific Saudi-state-affiliated individuals and specific hijackers; the Saudi state denies institutional involvement; the litigation is in progress.

◆ ◆ ◆

**COUNTERARGUMENT**

Even granting the documented contacts between Saudi-state-affiliated individuals and the hijackers, the leap from those contacts to any inference about higher-level Saudi state direction is unsupported. Diplomatic personnel maintain wide social and religious-community contacts in their host countries; some of those contacts will, in retrospect, turn out to have been with people who later commit terrorism. The documented contacts do not establish institutional Saudi responsibility, and inferring institutional responsibility from the contacts is the kind of inference the documentary record does not support.

**WHY THIS DOES NOT SAVE THE FRAMING**

The chapter does not infer institutional Saudi responsibility from the documented contacts. The chapter says, in language as careful as I can make it, that the contacts are documented, that some Saudi-state-affiliated individuals provided support to specific hijackers, and that the question of whether the Saudi state as an institution authorized or knew of this support remains contested in active litigation. The counterargument is correct that the leap to institutional responsibility is not supported by the documentary record currently available. The chapter does not make that leap. What the chapter does insist on is that the documentary record currently available exists, that it is the result of fourteen years of public-records campaigning by families and senators, that it indicates the existence of facts the 9/11 Commission’s public report did not fully integrate, and that the appropriate response to the gap is continued declassification rather than the closure of the inquiry. The civil litigation is the proper forum for the question of institutional Saudi responsibility. The 9/11 families are pursuing that question through that forum. The chapter respects the litigation process and reports its current status.

◆ ◆ ◆

**What I will not do**

I am not going to argue, in this book, that any specific alternative theory of September 11 is correct. The documentary record I have walked through here contains real anomalies. It also contains the official explanation. A serious citizen’s posture toward the events of September 11 should be that the documented anomalies are part of the public record, the official conclusions are also part of the public record, and the appropriate response to the gaps is more declassification — not the imposition of a competing certainty.

Specifically, I will not argue that the World Trade Center towers or Building 7 were brought down by controlled demolition. The engineering literature on the Twin Towers’ collapse, while not without its critics, broadly supports the structural mechanism described in NIST NCSTAR 1A for the towers themselves: aircraft impact damage combined with widespread fires producing progressive collapse. The Building 7 case is, on the documented professional record, more contested, and I have reported the contestation. I will not argue that the federal government had advance specific knowledge of the attacks beyond the strategic warnings the federal government’s own oversight bodies have already documented. The 9/11 Commission’s account of pre-attack institutional failure is, in the existing documentary record, the strongest available explanation of the gap between what the intelligence community knew strategically and what it failed to operationalize tactically.

What I will continue to argue is that the documentary record on September 11 remains incomplete in ways that warrant continued declassification, that the unresolved questions — about the Saudi state’s knowledge, about Building 7’s collapse mechanism, about the financial transactions in the days preceding the attacks, about the Commission’s institutional constraints — are real and not the inventions of bad-faith critics, and that the appropriate civic posture is the one Senator Graham modeled: sustained public pressure for the release of relevant records, support for the 9/11 families’ civil litigation, and refusal to treat the official account as a closed question simply because powerful institutional actors would prefer it to be.

◆ ◆ ◆

**What it would take to clarify the record**

The reform agenda for the September 11 documentary record is procedural rather than substantive. It does not require any commitment to a particular theory of what happened. It requires only a commitment to the procedural standards a democratic society should apply to the historical record of an event that has shaped American foreign and domestic policy for a generation.

First, complete declassification of the remaining classified materials related to the 9/11 investigations, with redactions limited to genuinely current operational sources and methods rather than to the protection of foreign-state relationships. The 28 Pages were classified for fourteen years and, when released, contained almost nothing whose disclosure plausibly compromised current operations. The pattern across the relevant declassifications has been consistent: the classification has protected diplomatic relationships and reputational interests, not operational security. The Justice Department should apply the same standard to the remaining classified Moussaoui-related materials and to the underlying Joint Inquiry materials that the Commission’s co-chairs have called for. The framework already exists; the Mandatory Declassification Review process under Executive Order 13526 is the mechanism. What is required is the political will to use it.

Second, continued judicial process in Moussaoui v. Kingdom of Saudi Arabia and the related cases under the Justice Against Sponsors of Terrorism Act of 2016. The families pursuing the litigation are entitled to the discovery process the law authorizes. The federal government should not interpose state-secrets privilege claims that prevent the families from obtaining materials the federal government’s own investigators have produced. The Justice Department’s posture in the litigation has, at various points, sought to limit discovery in ways that exceed the legitimate interests the state-secrets doctrine was designed to protect. The reform is the application of the existing doctrine within its proper scope, not the creation of new law.

Third, an independent engineering review of the Building 7 collapse mechanism, with full access to the underlying NIST modeling files and to the Hulsey UAF analysis, conducted by structural engineers without prior commitment to either conclusion. The technical resolution of the Building 7 question is a problem the engineering profession can address if the federal government provides the necessary access to the underlying data. The professional engineering societies — the American Society of Civil Engineers, the Structural Engineering Institute — are the appropriate institutional sponsors. The reform requires that the federal government make the relevant materials available to such a review, which has not yet occurred.

Fourth, a sunset on the Authorization for the Use of Military Force passed by Congress on September 18, 2001, and the replacement of the open-ended authorization with a more narrowly drawn framework that requires periodic congressional re-authorization for ongoing combat operations. The 2001 AUMF has been the legal basis for U.S. military action across multiple countries against multiple groups for more than two decades. The AUMF’s reform was discussed in the previous chapter. It bears repeating in this one because the AUMF is the legal architecture through which the foreign-policy consequences of September 11 have been institutionalized. The reform of the AUMF and the clarification of the historical record on September 11 are connected. Both require sustained civic pressure on institutions that have, by default, preferred the existing arrangements.

◆ ◆ ◆

**Pattern**

The public record is wider than the public narrative. The gap is itself a fact about the political economy of memory. The chapter has not argued for any particular alternative theory of September 11. It has argued that the elements of the public documentary record that the official narrative has not absorbed cleanly are real, that they are documented through the work of senators, victims’ families, structural engineers, journalists, and the federal government’s own declassification processes, and that the appropriate response to the unresolved questions is the continued application of the procedural standards a democratic society should apply to the historical record of any consequential event.

I want to close with a sentence that I hope captures the chapter’s posture. The serious citizen does not need to settle the September 11 question to act seriously on it. She needs to insist that the documentary record be made accessible, that classified material in matters of this gravity be subject to continuous declassification review, and that the families pursuing civil remedies be permitted to pursue them under the standards of the legal system. None of that requires endorsing any particular alternative theory of the attack. All of it requires the willingness to treat the public documentary record as the public’s property, to be evaluated by the public on the public’s own terms, rather than as the closed property of the institutions whose conduct the record bears on. That distinction is the distinction between democratic memory and managed memory. The structural humanism argument is that democratic memory is the precondition of democratic accountability, and that the absence of one is the institutional protection of the other.

> *The public record is wider than the public narrative. The gap is itself a fact about the political economy of memory.*

Part Two of this book has examined four cases in which the historical record diverges substantially from the public narrative — the political histories of sacred texts, the petrodollar arrangement, the long tail of covert intervention, and the documented record on September 11. In each case, the structural humanism reading is the same. The information is public. The integration of it has been managed. The work of democratic citizenship is the assembly of the public record into a coherent picture, and the willingness to do that assembly even when no major institution is doing it for you. Part Three turns from the historical record to the domestic systems that drain the people living under them in the present. Healthcare. The federal budget. The civic toolkit. And the contemporary men consolidating technological power. The mechanisms differ. The structural logic does not.

**Part Three**

*The Systems That Drain Us*

Four chapters on the domestic systems that absorb the time, money, attention, and life of the people living under them. Extractive healthcare, militarized public finance, the civic toolkit citizens still hold, and the contemporary men consolidating technological power. The structural logic is the same one Part One described. The institutional settings have shifted from foreign policy and history to the daily mechanics of American life. The question of who pays and who benefits remains the load-bearing question.

**Chapter 9**

*The Most Profitable Patient*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The American healthcare system is the clearest single illustration of what happens when an institution that should serve human flourishing is restructured to extract revenue from human vulnerability.

I want to be precise with the framing because the polite version of this argument typically misses what is most important about it. The American healthcare system is not failing. It is succeeding at what it has been organized to do. Hospitals, insurance companies, pharmaceutical manufacturers, pharmacy benefit managers, medical device companies, and physician staffing groups in the United States generate, in aggregate, the highest healthcare-derived revenue per capita of any country in the developed world. The system’s investors are paid. Its executives are well compensated. Its consultants are richly engaged. Its lobbyists are continuously funded. By every measure of institutional self-reproduction, the system is working. What is not working — what is, in fact, failing in ways the comparable systems of every other wealthy democracy do not fail — is the relationship between the institutional output and the human beings it is supposed to serve. That is the gap this chapter examines.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: why does the United States spend approximately twice as much per capita on healthcare as the median wealthy democracy and produce worse health outcomes across the major comparable measures, and what does the documentary record show about who profits from the gap?

Thesis, in one sentence: the American healthcare system is best understood not as a market that incidentally produces high prices, but as a political economy whose legal architecture was designed and is maintained to extract revenue from human vulnerability, with the documentary record on insulin pricing, the regulatory delay on trans fats, the opioid crisis, and the statutory prohibition on Medicare drug-price negotiation each constituting one face of the same structural arrangement.

The empirical baseline is the comparative international data, which has been tracked for decades by the Organisation for Economic Co-operation and Development and synthesized periodically by the Commonwealth Fund. The Commonwealth Fund’s most recent comparative analysis, Mirror, Mirror 2024: A Portrait of the Failing U.S. Health System, ranks the United States last among ten wealthy democracies on overall health-system performance, despite spending substantially more per capita than any of the comparison countries. American per capita healthcare spending in 2023 was approximately $13,400, compared to roughly $7,000 in the Netherlands, $6,600 in Germany, $5,900 in France, $5,400 in Canada, $5,300 in the United Kingdom, and $4,800 in Japan, according to the OECD Health Statistics 2024 release. American life expectancy at birth in 2023 was approximately 78.4 years, the lowest among the comparison group. American maternal mortality is approximately three times the OECD average. American infant mortality is approximately twice the OECD average. None of these comparison countries achieves its results through magic. They achieve them through the structural design choice that healthcare financing is a public-utility function that should be organized to deliver care rather than to extract revenue.

**Table 9-1. American healthcare spending vs. peer democracies, 2023**

<table>
<colgroup>
<col style="width: 34%" />
<col style="width: 23%" />
<col style="width: 42%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Country</strong></td>
<td><strong>Per capita health spending (USD)</strong></td>
<td><strong>Life expectancy at birth</strong></td>
</tr>
<tr class="even">
<td>United States</td>
<td>~$13,400</td>
<td>78.4 years</td>
</tr>
<tr class="odd">
<td>Switzerland</td>
<td>~$8,900</td>
<td>84.0 years</td>
</tr>
<tr class="even">
<td>Germany</td>
<td>~$7,400</td>
<td>81.4 years</td>
</tr>
<tr class="odd">
<td>Netherlands</td>
<td>~$7,000</td>
<td>81.7 years</td>
</tr>
<tr class="even">
<td>France</td>
<td>~$5,900</td>
<td>82.5 years</td>
</tr>
<tr class="odd">
<td>Canada</td>
<td>~$5,400</td>
<td>82.6 years</td>
</tr>
<tr class="even">
<td>United Kingdom</td>
<td>~$5,300</td>
<td>80.7 years</td>
</tr>
<tr class="odd">
<td>Japan</td>
<td>~$4,800</td>
<td>84.3 years</td>
</tr>
<tr class="even">
<td>OECD average</td>
<td>~$6,200</td>
<td>81.0 years</td>
</tr>
</tbody>
</table>

*Source: OECD Health Statistics 2024 release; Commonwealth Fund, Mirror, Mirror 2024: A Portrait of the Failing U.S. Health System; CDC National Center for Health Statistics. Per capita figures rounded; life expectancy figures from each country’s most recent reported year.*

The simple two-sentence summary of the comparative data: the United States pays roughly twice as much per person, on average, for measurably worse outcomes than every other wealthy democracy. The gap between what we pay and what we get is the institutional space within which the extraction happens. The chapters that follow walk through specific cases, each one a face of the same structural arrangement.

◆ ◆ ◆

**Insulin: the cleanest case**

If a single illustration of American healthcare extraction were available, it would be the price of insulin. The drug was discovered in 1921 by Frederick Banting and Charles Best at the University of Toronto. The discoverers, on the principle that no one should profit from a discovery that would save the lives of children with type 1 diabetes, sold the original patent to the University of Toronto for one Canadian dollar in 1923. The patent expired in the 1940s. The active pharmaceutical ingredient has been

Despite this, three companies — Eli Lilly, Novo Nordisk, and Sanofi — collectively control approximately 90 percent of the global insulin market, and the price of insulin in the United States rose from approximately $20 per vial in 1996 to a peak of more than $300 per vial in the late 2010s. A vial costs approximately $10 to manufacture. The mechanism by which the three firms have maintained pricing power on an off-patent drug is well documented in the legal and policy literature. They patent the delivery systems and the specific molecular variants — insulin analogs such as Humalog (Eli Lilly), Novolog (Novo Nordisk), and Lantus (Sanofi) — rather than the underlying molecule, and they iterate on the delivery and analog patents to maintain a continuous patent runway. They negotiate exclusive formulary placement with pharmacy benefit managers, who collect rebates that flow back through the insurance system rather than to the patient at the pharmacy counter. They maintain the price of legacy human insulin formulations at levels that make the newer analogs the only practical option for most patients. The Journal of the American Medical Association published in March 2016 a detailed analysis by William Cefalu and colleagues documenting the price escalation; subsequent congressional investigations under both the 116th and 117th Congresses produced internal corporate documents showing the pricing was coordinated rather than independently determined.

The Inflation Reduction Act of August 2022 imposed a $35-per-month cap on insulin for Medicare beneficiaries, beginning in January 2023. The cap applies only to Medicare. It does not apply to commercial insurance. It does not apply to the uninsured. The three manufacturers have since announced their own voluntary $35 caps for some patient populations under public pressure, but the legal architecture that produced the pricing in the first place — the patent system on delivery devices and analogs, the PBM rebate structure, the absence of any general U.S. drug-price negotiation — remains in place. The reform was narrow. The structure that produced the underlying pricing remains.

The human cost has been measured. A 2019 study in JAMA Internal Medicine by Darby Herkert and colleagues at Yale found that one in four patients with type 1 diabetes had rationed insulin — deliberately taken less than prescribed, or skipped doses, because of cost — in the preceding twelve months. Insulin rationing is medically dangerous. It produces diabetic ketoacidosis, hospitalizations, and in some cases death. The American Diabetes Association has documented multiple cases of patients dying from rationing. The system’s position is that the prices reflect the market. The empirical record is that a substantial share of the population that requires the drug to live cannot afford the drug at its market price, and is medically harmed as a consequence. Both are facts. Reconciling them requires choosing which to weight more.

◆ ◆ ◆

**COUNTERARGUMENT**

Drug pricing reflects the cost of research and development. New analog insulins are genuinely better than legacy formulations — they produce more predictable blood glucose control with fewer hypoglycemic episodes. The patents on those improvements are the legal mechanism by which the pharmaceutical industry recovers its research investment, and undermining the patent system would undermine the incentive to develop better drugs. The price of insulin in the United States is high because Americans pay the marginal cost of pharmaceutical innovation that the rest of the world free-rides on.

**WHY THIS DOES NOT SAVE THE FRAMING**

The free-rider argument is the pharmaceutical industry’s standard defense, and it has surface plausibility, but the empirical record does not support its strong version. The major insulin manufacturers conduct research in multiple countries and recover their research costs across multiple markets. The premium American insulin pricing is not principally directed back to research; it is directed to marketing, executive compensation, share buybacks, and shareholder dividends. The 2021 analysis by the House Committee on Oversight and Reform documented this in detail, with primary access to internal company documents from Eli Lilly, Novo Nordisk, and Sanofi. The committee’s majority staff report found that the three companies’ combined spending on share buybacks and dividends exceeded their combined spending on research and development by a substantial margin across the relevant decade. The argument is also undermined by the structural fact that the three companies have been able to coordinate pricing increases without antitrust enforcement — the Federal Trade Commission has not seriously pursued the insulin market under the Bork-doctrine framework discussed in Chapter 4 — and by the negative comparative case: every other wealthy democracy obtains the same analog insulins at substantially lower prices, by negotiating with the manufacturers as a single national purchaser. The mechanism for lower prices exists. American law forbids it for the largest American purchaser. The narrower defense — that some premium pricing is justified to fund research — has merit. The strong defense, that the current pricing structure is what research requires, is unsupported by the documentary record.

◆ ◆ ◆

**Trans fats: the slow violence of regulatory delay**

The insulin case illustrates extraction through pricing. The trans-fats case illustrates extraction through regulatory delay. The mechanism is different. The structural logic is identical.

Partially hydrogenated vegetable oils — the industrial source of artificial trans fats — entered the American food supply at scale in the 1910s and 1920s as a cheap, shelf-stable substitute for animal fats. By the 1990s, the cardiovascular harm of artificial trans fats was well established in the peer-reviewed literature. A 1993 paper by Walter Willett and colleagues at the Harvard School of Public Health, published in The Lancet, found that artificial trans fats elevated LDL cholesterol and reduced HDL cholesterol — the precise lipid profile most strongly associated with coronary heart disease — at levels that the authors estimated produced thousands of excess deaths per year in the American population. The finding was replicated repeatedly across the 1990s and 2000s in major journals. The mechanism was understood. The mortality estimates were available.

The Food and Drug Administration did not require the listing of trans fats on the Nutrition Facts label until January 1, 2006. The agency did not formally remove the “generally recognized as safe” designation for partially hydrogenated oils until 2015, requiring industry compliance by June 2018. The interval between the peer-reviewed scientific consensus that trans fats were producing excess cardiovascular mortality and the agency’s effective regulatory removal of trans fats from the food supply was, by the most conservative measure, more than two decades. By the higher-end estimate of the Center for Science in the Public Interest, the delay was responsible for somewhere in the range of 100,000 to 200,000 excess American deaths.

I want to be careful with the causal language here, because regulatory analysis is not the same as criminal indictment. The FDA did not affirmatively decide to allow people to die. What it did was decline to act on the established science for decades, in a regulatory environment in which the food industry was the principal political actor pressing against action, and in which the agency’s leadership and staff routinely moved back and forth between the regulated industry and the regulator. The economist George Stigler’s 1971 framework on regulatory capture — the proposition that regulatory agencies, over time, come to be dominated by the industries they nominally regulate — was developed at the University of Chicago and has been applied repeatedly to the FDA in the public-policy literature. The Stigler analysis does not require malice on the part of any individual regulator. It requires only that the institutional structure of regulation produce, over time, a posture of caution toward industry interests and aggression toward consumer-protection interests. That posture is what produced the trans-fats delay. The structural arrangement is what produced the human cost.

◆ ◆ ◆

**The opioid case**

If the insulin case illustrates pricing extraction and the trans-fats case illustrates regulatory delay, the opioid case illustrates what happens when a pharmaceutical manufacturer applies the full marketing infrastructure of a major drug launch to a substance the underlying science has known to be addictive for thousands of years.

OxyContin, the brand-name extended-release oxycodone formulation manufactured by Purdue Pharma, was approved by the FDA in December 1995 and launched in 1996. The drug was marketed to physicians on the basis of representations that the extended-release formulation produced lower abuse potential than other opioids. The representations were not supported by the clinical evidence. They were the product of a marketing campaign that included, as later litigation established, the sponsoring of supportive medical-society publications, the funding of patient-advocacy groups that lobbied for liberalized opioid prescribing, the targeted marketing of high-prescribing physicians, and the deployment of a sales force that promoted OxyContin for indications and dosing regimens the manufacturer’s own internal data did not support.

The documentary record on Purdue’s conduct is now extensive and was developed primarily through multidistrict litigation. In May 2007, Purdue Pharma and three of its top executives — Michael Friedman, Howard Udell, and Paul Goldenheim — pleaded guilty in the United States District Court for the Western District of Virginia to felony charges of misbranding OxyContin. The corporation paid approximately $635 million in fines. The executives paid personal fines and received no prison time. The plea was the first major federal acknowledgment of corporate wrongdoing in the marketing of OxyContin. The drug continued to be marketed. The prescribing continued to climb. The Centers for Disease Control and Prevention’s WONDER mortality database documents the resulting overdose mortality with unusual clarity. Annual American drug overdose deaths rose from approximately 17,000 in 1999 to , with the majority of those deaths involving opioids and, after roughly 2014, the majority of opioid deaths involving synthetic opioids primarily produced and imported through international illicit channels.

The 2007 plea was not the end of Purdue’s legal exposure. In October 2020, Purdue Pharma pleaded guilty to federal criminal charges including conspiracy to defraud the United States, conspiracy to commit kickbacks, and other charges, and agreed to a total resolution of approximately $8.3 billion in criminal and civil penalties. The Sackler family, which owned Purdue, in connection with the company’s subsequent bankruptcy reorganization. The Supreme Court ruled in June 2024, in Harrington v. Purdue Pharma, that the bankruptcy plan as structured — which would have released the Sackler family from future civil liability in exchange for the settlement — was not authorized under the bankruptcy code. The Sackler family’s personal wealth, estimated at the time of the litigation at approximately $11 billion, was largely preserved through asset structures established during the period when Purdue was being investigated.

The asymmetry of consequence is the central fact of the opioid case. Patients, families, and communities absorbed somewhere between 500,000 and 800,000 American deaths over the relevant period, depending on how the cause-of-death classification handles synthetic-opioid co-involvement. The manufacturer’s executives paid fines and faced no incarceration. The owning family preserved most of its wealth through structured settlements. The corporate entity that produced the marketing campaign was dissolved through bankruptcy reorganization. The institutional consequences for the conduct were substantial in financial terms. They were proportionate only by the standard of a system that prices human life at the rates the American legal system currently does.

**Table 9-2. American opioid overdose deaths, selected years**

<table>
<colgroup>
<col style="width: 23%" />
<col style="width: 25%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Year</strong></td>
<td><strong>Total drug overdose deaths</strong></td>
<td><strong>Notes</strong></td>
</tr>
<tr class="even">
<td>1999</td>
<td>~17,000</td>
<td>OxyContin launched 1996; prescribing accelerating</td>
</tr>
<tr class="odd">
<td>2007</td>
<td>~36,000</td>
<td>Purdue executives plead guilty to felony misbranding</td>
</tr>
<tr class="even">
<td>2014</td>
<td>~47,000</td>
<td>Synthetic opioid (fentanyl) era begins</td>
</tr>
<tr class="odd">
<td>2017</td>
<td>~70,000</td>
<td>Public-health emergency declared by Trump administration</td>
</tr>
<tr class="even">
<td>2020</td>
<td>~93,000</td>
<td>Purdue pleads guilty to federal criminal charges</td>
</tr>
<tr class="odd">
<td>2023</td>
<td>~110,000</td>
<td>Peak year; figures begin to decline in 2024</td>
</tr>
<tr class="even">
<td>Cumulative, 1999–2023</td>
<td>~1,000,000</td>
<td>All drug overdose deaths combined; majority opioid-involved</td>
</tr>
</tbody>
</table>

*Source: Centers for Disease Control and Prevention WONDER mortality database; National Center for Health Statistics provisional drug overdose mortality reports. Cumulative figure rounded; not all overdose deaths are opioid-involved but the majority across the period are.*

> *Patients absorbed somewhere between 500,000 and 800,000 American deaths. The owning family preserved most of its wealth. The proportionality is determined by what the legal system has been built to do.*

◆ ◆ ◆

**Price by law: the Medicare non-negotiation prohibition**

The single most consequential piece of evidence that high American drug prices are produced by law rather than by market mechanism is the statutory prohibition on Medicare drug-price negotiation.

Medicare Part D, the prescription-drug benefit added to Medicare under the Medicare Modernization Act of 2003 signed by President George W. Bush, contains in Section 1860D-11(i) a provision known in the policy literature as the “non-interference clause.” The provision states that the Secretary of Health and Human Services “may not interfere with the negotiations between drug manufacturers and pharmacies and PDP sponsors” and “may not require a particular formulary or institute a price structure for the reimbursement of covered Part D drugs.” The plain English of the provision is that Medicare — the largest single purchaser of prescription drugs in the United States, covering more than 60 million beneficiaries — was statutorily prohibited from negotiating drug prices with manufacturers for nearly two decades after the program’s creation.

The Department of Veterans Affairs, which has long been permitted to negotiate drug prices, has historically obtained prices for the same drugs at approximately 50 percent of the prices Medicare Part D pays. The Congressional Budget Office, in multiple analyses over the 2003–2022 period, estimated that the federal government could save tens to hundreds of billions of dollars over decade-long budget windows by permitting Medicare to negotiate. The pharmaceutical industry, through PhRMA and its constituent member companies, opposed every legislative proposal to repeal the non-interference clause across multiple Congresses. The industry employed, by the OpenSecrets tracking of lobbying expenditures, more federal lobbyists than any other industry across most years of the 2003–2022 period.

The Inflation Reduction Act of August 2022 partially repealed the non-interference clause for a narrow set of drugs. The act authorized Medicare to negotiate prices on ten high-cost drugs beginning in 2026, expanding to fifteen in 2027 and twenty in 2028. The negotiation authority remains restricted in scope, restricted in timing, and subject to ongoing litigation by the affected manufacturers. The structural prohibition on broader Medicare negotiation has been narrowed. It has not been removed. The substantive shift from a no-negotiation regime to a meaningful-negotiation regime would require additional legislation that the pharmaceutical industry continues to oppose. The political fight is ongoing. The empirical baseline — that American drug prices are higher than peer-country prices substantially because American law has prohibited the largest American purchaser from doing what every peer-country purchaser does — is documented and is not seriously contested in the policy literature.

◆ ◆ ◆

**COUNTERARGUMENT**

Permitting Medicare to negotiate drug prices on a wide scale would amount to price controls, would reduce industry investment in research and development, would shift research investment to other markets, and would ultimately produce fewer new drugs reaching patients. The non-interference clause was a recognition that government bulk purchasing distorts pharmaceutical markets in ways that reduce long-term innovation. The Inflation Reduction Act’s narrow negotiation authority is already raising concerns about reduced investment in the relevant drug categories.

**WHY THIS DOES NOT SAVE THE FRAMING**

The pharmaceutical-research argument has serious advocates and serious literature, and I want to engage it on its merits. The strongest version of the argument is that bulk negotiation, applied without nuance, could reduce the expected return on novel-mechanism drug development and shift research investment toward incremental rather than transformative products. The empirical literature on this question is more mixed than the strong version of the argument suggests. Patricia Danzon’s work at the Wharton School, the standard pharmaceutical-economics scholarship, indicates that the relationship between prices in any single major market and total industry research investment is not as direct as the industry’s public position implies. The companies that develop drugs operate in dozens of markets simultaneously. Substantial cuts in the highest-priced market may reduce returns in that market but do not eliminate the underlying research economics. The narrower and more defensible version of the industry’s argument is that some negotiation mechanism is preferable to a blunt price-cap. That version is precisely what every other wealthy democracy already does and what the Inflation Reduction Act of 2022 began. The non-interference clause as a statutory bar on any negotiation at all was indefensible on the industry’s own logic. It existed because the industry’s political power was sufficient to prevent its removal, not because the underlying economic argument required it. The fact that the prohibition was a political achievement rather than an economic necessity is the structural humanism reading of the case.

◆ ◆ ◆

**The downstream: medical debt and the household**

The extraction at the institutional level produces an extraction at the household level. Chapter 2 established the macroeconomic shape of American household debt. The medical-debt component deserves its own treatment here because the mechanism is unique to the American healthcare system.

The Kaiser Family Foundation’s 2022 report Health Care Debt in the U.S., which surveyed 1,592 U.S. adults, found that approximately 41 percent of U.S. adults — about 100 million people — currently have some form of medical debt. About 24 percent owe more than $1,000. About 12 percent owe more than $10,000. About 9 percent have declared bankruptcy in connection with medical bills. The distribution is racially uneven, with Black and Hispanic adults significantly more likely to hold medical debt than white adults, and is heavily income-bottom-weighted, with households earning under $40,000 a year carrying the largest share of unpayable medical balances.

The Himmelstein finding cited in Chapter 2 — that 62.1 percent of personal bankruptcies in the United States in 2007 were medical in origin and that 78 percent of the medically bankrupt had health insurance at the time of the illness that bankrupted them, per Himmelstein et al. in the American Journal of Medicine in 2009 — has been challenged on methodological grounds in subsequent literature, and the precise percentages should be treated as approximate. What has not been seriously challenged is the underlying observation that medical bills are the leading cause of personal financial collapse in the United States and that no other wealthy democracy generates personal bankruptcy from medical bills at the American rate. The Consumer Financial Protection Bureau’s 2022 analysis found that medical debt accounted for $88 billion of debt on consumer credit reports, was the most common form of debt in collections, and was disproportionately likely to be collected from individuals who did not actually owe the amount claimed because of medical-billing errors. The Bureau’s subsequent rulemaking removed certain medical debts from credit reports beginning in 2023. The Bureau itself has been substantially gutted by the second Trump administration, and the durability of the medical-debt credit-reporting reform is uncertain at this writing.

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for American healthcare is the most developed reform agenda in any chapter of this book, for the simple reason that every other wealthy democracy has already demonstrated the alternative arrangements that work.

On drug prices: extend Medicare negotiation authority to all drugs, not the narrow set the Inflation Reduction Act addressed. Permit the U.S. Department of Health and Human Services to negotiate as the national purchaser the way every peer-country health authority already does. The expected savings, per Congressional Budget Office analyses, are in the hundreds of billions of dollars over a decade-long budget window. The expected reduction in pharmaceutical research investment, per the peer-reviewed economics literature, is modest and concentrated in the lowest-value drug categories. The arithmetic favors the reform by a substantial margin.

On hospital pricing: require all hospitals to publish, in machine-readable form, the actual prices they charge for every service and the actual prices they have negotiated with every insurer and self-funded employer. The Hospital Price Transparency Rule, finalized by the Centers for Medicare and Medicaid Services in 2019 and effective January 2021, requires this in principle. Compliance has been weak and enforcement has been minimal. Strengthening enforcement — fining noncompliant hospitals at meaningful rates and barring them from federal-program reimbursement until they comply — would, on the projections from the policy literature, substantially reduce the price dispersion that current hospital billing exploits.

On medical debt: restore the bankruptcy protections that the Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 weakened. Remove medical debt from credit reports as a categorical matter; the Consumer Financial Protection Bureau began this and the reform should be codified by statute to survive administration changes. Limit the interest rates and collection practices applied to medical debt, which is uniquely involuntary in its origin and uniquely punitive in its compounding under the current architecture.

On the underlying financing architecture: the policy literature is divided between several reform models. Single-payer designs — a single national health insurer, on the Canadian, British, or Australian model — are favored by some advocates and have the strongest comparative evidence for cost control and equity. Multipayer regulated models — on the German, Dutch, or Swiss model, with multiple insurers operating under strict regulatory constraints and universal coverage requirements — are favored by others and produce more pluralistic provider arrangements. Hybrid public-option designs — a public insurance option competing alongside private insurance within a regulated marketplace — have substantial domestic political support and produce some of the cost-control benefits of single-payer without the full transition disruption. The international evidence does not unanimously favor any one of these designs. It does unanimously favor every one of them over the American status quo. The choice among them is a political choice the American polity has not yet seriously made. The structural humanism reading is that the choice should be made on the basis of which design best serves the human beings inside the system, and that the avoidance of the choice is itself a political fact whose principal beneficiaries are the institutions that profit from the absence of any of the designs.

◆ ◆ ◆

**Pattern**

The American healthcare system is not a market that has failed. It is a system that has been organized, through specific legal and regulatory choices, to extract revenue from human vulnerability. Each face of the system documented in this chapter — the price of insulin, the regulatory delay on trans fats, the marketing of OxyContin, the statutory prohibition on Medicare drug-price negotiation — is a single illustration of the same structural arrangement. The insulin is patented around the molecule. The regulator is captured by the regulated industry. The marketing apparatus is deployed for the addictive substance. The largest purchaser is statutorily prevented from negotiating. The architecture is consistent. The architects are named in the public record. The reform agenda is developed in the policy literature and operating in every other wealthy democracy.

What is missing is the political coalition large enough to enact the reforms over the opposition of the industries that profit from the current arrangement. Building that coalition is the work of Chapters 11 and 13. For the moment, the empirical foundation is what matters: the gap between what Americans pay for healthcare and what Americans get from healthcare is not a market outcome. It is a political outcome. It can be changed by political action. The barrier is not technical. The barrier is the durability of the political arrangement that produces the extraction.

> *The price of being sick in America is not a market price. It is a political price. It can be changed by political action.*

The next chapter turns from healthcare extraction to the related but distinct question of where the federal budget actually goes — the Pentagon’s unfinished audits, the contractor cost overruns that exceed the budgets of entire federal agencies, the Gilens-Page finding on whose policy preferences move legislation, and the opportunity cost of the spending priorities the political class has chosen. Healthcare extraction operates at the household level. The budget extraction operates at the level of what the country, collectively, has chosen not to build.

**Chapter 10**

*The Accounting*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

There is a sentence buried in the Department of Defense’s annual financial-statement audit reports that should be the most consequential sentence in American public life. The Department of Defense has never passed a clean financial audit.

I want to be precise about what that sentence means, because it is easy to misread. The Department of Defense has been formally required to undergo an annual financial-statement audit since the Chief Financial Officers Act of 1990, with the full audit requirement consolidated under the Government Performance and Results Modernization Act of 2010. The first full audit of the Department of Defense was conducted for fiscal year 2018, twenty-eight years after the original statutory requirement, and resulted in a disclaimer of opinion — the auditors’ formal statement that they could not gather sufficient evidence to render any opinion at all on the accuracy of the Department’s financial statements. Every subsequent annual audit, through the fiscal year 2024 audit released in November 2024, has produced the same outcome. The Department of Defense, the recipient of approximately $850 billion in annual appropriations and the largest single line item in the federal discretionary budget, cannot tell its own appropriator what it has spent the money on, in a form that meets the standards of a professional financial audit. This chapter is about what that fact means and what it tells us about how American public money actually moves.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: where does American federal spending actually go, who actually determines what gets spent on what, and what is the opportunity cost of the spending priorities the political system has converged on across the last quarter century?

Thesis, in one sentence: the federal budget reveals, more cleanly than any other public document, the gap between what the American electorate consistently tells pollsters it wants its government to do and what the government actually does — and the empirical political-science literature on whose policy preferences move legislation, combined with the institutional record on defense-budget audit failures and contractor cost overruns, indicates that the gap is the product of a documented imbalance in whose preferences elected officials actually respond to.

◆ ◆ ◆

**The audit failure**

The annual Department of Defense financial-statement audit, conducted by the Office of Inspector General for the Department of Defense in conjunction with independent public accounting firms, is the largest financial audit ever attempted of any organization in human history. The fiscal year 2024 audit, released by the Office of the Comptroller of the Department of Defense in November 2024, was the seventh full DoD audit. The audit covered approximately $4.1 trillion in assets and $4 trillion in liabilities, encompassing more than 200 separate audit units across the Army, Navy, Air Force, Marine Corps, and Defense Agencies.

Of those audit units, the fiscal year 2024 audit produced clean opinions on nine of the smaller defense-agency-level audits and a disclaimer of opinion on the consolidated financial statements as a whole, marking the seventh consecutive year of failure at the consolidated level. The specific findings, summarized in the Department’s own audit report, include material weaknesses in internal control over financial reporting, weaknesses in the management of approximately $3.5 trillion in physical assets, weaknesses in the tracking of inventory and operating materials, and weaknesses in the financial systems that produce the consolidated statements. The Department’s public position, articulated by successive Comptrollers, is that the audit is an enormous undertaking, that progress is being made, and that achieving a clean opinion will require additional years of financial-systems modernization. The Department’s position has remained substantially the same across every audit cycle since 2018.

The Government Accountability Office, in its January 2024 report High-Risk Series: An Update, has listed the Department of Defense’s financial management on the federal High Risk List continuously since 1995. The GAO’s analysis indicates that the Department’s financial-systems weaknesses are sufficiently severe that the Department cannot reliably trace specific appropriated dollars to specific expenditures, cannot reliably produce a complete inventory of its physical assets, and cannot reliably aggregate program-level cost data across services in ways that would allow Congress to evaluate the cost-effectiveness of major spending categories. The arithmetic implications are blunt. Congress appropriates approximately $850 billion a year to a Department that, on the federal government’s own oversight reports, cannot tell Congress where the money goes.

**Table 10-1. Department of Defense annual audit results, FY 2018–2024**

<table>
<colgroup>
<col style="width: 17%" />
<col style="width: 38%" />
<col style="width: 44%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Fiscal year</strong></td>
<td><strong>Opinion on consolidated statements</strong></td>
<td><strong>Annual appropriation (approx.)</strong></td>
</tr>
<tr class="even">
<td>FY 2018</td>
<td>Disclaimer of opinion</td>
<td>~$685 billion</td>
</tr>
<tr class="odd">
<td>FY 2019</td>
<td>Disclaimer of opinion</td>
<td>~$716 billion</td>
</tr>
<tr class="even">
<td>FY 2020</td>
<td>Disclaimer of opinion</td>
<td>~$738 billion</td>
</tr>
<tr class="odd">
<td>FY 2021</td>
<td>Disclaimer of opinion</td>
<td>~$753 billion</td>
</tr>
<tr class="even">
<td>FY 2022</td>
<td>Disclaimer of opinion</td>
<td>~$782 billion</td>
</tr>
<tr class="odd">
<td>FY 2023</td>
<td>Disclaimer of opinion</td>
<td>~$816 billion</td>
</tr>
<tr class="even">
<td>FY 2024</td>
<td>Disclaimer of opinion</td>
<td>~$850 billion</td>
</tr>
</tbody>
</table>

*Source: Department of Defense Office of Inspector General annual audit reports, FY 2018–2024; Government Accountability Office High-Risk Series report, January 2024. Appropriation figures rounded; “disclaimer of opinion” is the auditor’s formal statement that insufficient evidence was available to render any opinion.*

> *Congress appropriates roughly $850 billion a year to a Department that, on the federal government’s own oversight reports, cannot tell Congress where the money goes.*

◆ ◆ ◆

**The contractor cost overruns**

The audit failure operates at the consolidated-statement level. The downstream record on specific major defense programs is more granular and shows the same structural pattern. The Government Accountability Office’s annual Assessments of Major Weapon Programs report tracks cost and schedule performance for the largest Department of Defense acquisition programs. Across the past two decades, the cumulative pattern has been consistent. Major programs are approved on the basis of projected costs. Costs grow substantially during development. The original projected costs are exceeded, in the aggregate across the major programs, by hundreds of billions of dollars. The programs are largely completed despite the overruns because the prime contractors have built sufficient political support across congressional districts where their facilities are located that termination is politically prohibitive.

The F-35 Joint Strike Fighter program, the largest defense acquisition program in American history, illustrates the dynamic with unusual clarity. The program was launched in 2001 with an original projected cost of approximately $233 billion across the planned production of 2,866 aircraft. The Government Accountability Office’s 2023 update placed the projected total program cost, including operations and sustainment across the planned 66-year service life of the fleet, at approximately $1.7 trillion. That figure is more than seven times the original projection. The Lockheed Martin Corporation, the prime contractor, has supplier relationships in 48 of 50 American states. The political base for the program is therefore distributed across essentially every congressional delegation. The program’s technical issues — documented across multiple GAO reports and Director of Operational Test and Evaluation annual reports — have been substantial but have not prevented continued funding.

Other major programs show similar trajectories. The Ground Based Strategic Deterrent program — the planned replacement for the Minuteman III intercontinental ballistic missile, now known as the Sentinel program — was estimated at the time of the 2020 contract award at approximately $96 billion. A January 2024 program review breached the Nunn-McCurdy threshold for cost growth and led to a Department of Defense restructuring announcement in July 2024 that placed the projected total program cost at approximately $141 billion, . The Constellation-class frigate program of the Navy, the V-22 Osprey, the Littoral Combat Ship, the Zumwalt-class destroyer — each followed a similar pattern of original projection, substantial cost growth, partial program restructuring, and continued funding under modified terms. The pattern is not the exception. It is the operating mode. The pattern is sustained by an institutional architecture in which prime contractors influence the cost projections that justify program initiation, the change orders that drive cost growth, and the political coalitions that prevent termination. The architecture is the subject of a substantial scholarly literature; the political scientist Theodore Lowi’s The End of Liberalism (Norton, 1969) and the more recent work of the historian Andrew Bacevich at Boston University provide the intellectual framework.

◆ ◆ ◆

**The Boeing KC-46 tanker: a single case at full resolution**

The pattern is easier to see at the level of a single program examined in detail than in the aggregate. The Boeing KC-46 Pegasus aerial-refueling tanker, intended to replace the aging KC-135 fleet that has been the backbone of American aerial refueling since the 1950s, is a useful case because the program’s development history is now sufficiently extensive that the relevant patterns are fully documented in the public record.

Boeing won the KC-46 contract in February 2011, with the bid submitted at approximately $4.4 billion below the competing Northrop Grumman / EADS offering. The Boeing bid was structured as a fixed-price-incentive-fee contract, which placed the cost-overrun risk on Boeing rather than on the taxpayer in the development phase. The Government Accountability Office’s repeated subsequent assessments documented that Boeing had, in effect, underbid the program in order to win it, knowing that the inevitable cost growth during development would be absorbed under the fixed-price terms. The strategic calculation was that the long-term production and sustainment revenue would exceed the development losses. The calculation was rational from Boeing’s standpoint. It was structurally damaging from the taxpayer’s standpoint, because the development losses produced an institutional pressure to corner-cut on the technical specifications in ways that the subsequent operational record documented.

By the 2024 GAO Assessments of Major Weapon Programs update, Boeing had absorbed approximately $7 billion in pre-tax charges on the KC-46 program. The aircraft has been delivered to Air Mobility Command but operates under multiple Category I deficiencies — the Air Force’s designation for the most serious operational deficiencies, those that may cause death or grave damage. The Remote Vision System used by the boom operator to guide aerial refueling has been the subject of multiple redesigns; deliveries continued throughout the period even as the system was identified as not meeting specification. The Stiff Boom problem — the aerial refueling boom striking aircraft being refueled with sufficient force to damage them — was identified during testing and was not fully resolved in the production aircraft. The Air Force accepted delivery of aircraft known to have these deficiencies in order to begin retirement of the KC-135 fleet, which had reached the end of its design service life decades earlier.

The institutional pattern is what matters more than the technical specifics. A prime contractor wins a fixed-price contract through aggressive bidding. The development encounters substantial cost growth. The contractor absorbs the development losses as the price of program continuity. The Air Force accepts delivery of aircraft with documented operational deficiencies because the alternative — program termination, restart, or extended delay — carries political and operational costs that exceed the costs of accepting the deficient aircraft. The deficiencies are addressed through subsequent contract modifications, each negotiated under conditions of asymmetric information that favor the prime contractor. The total cost of the program, measured across development, production, and the cost of the modifications required to address the deficiencies, substantially exceeds what a clean program-design process would have produced. The taxpayer pays for the gap. No senior executive at the prime contractor faces personal consequences. No senior official at the Air Force’s procurement command faces personal consequences. The institutional incentives that produced the dynamic remain in place for the next program. The cycle continues.

◆ ◆ ◆

**The revolving door**

The structural mechanism that sustains the cost-overrun pattern is the revolving door between senior Department of Defense positions and senior positions at the major defense contractors. The pattern is documented continuously by the Project on Government Oversight, a nonpartisan watchdog founded in 1981 that has produced the most sustained empirical tracking of the dynamic. The mechanism is straightforward. Senior military officers and senior civilian Department of Defense officials, on retirement or resignation, accept positions on the boards or in the executive leadership of the prime contractors whose programs they previously oversaw. The financial incentive for senior officials to make decisions favorable to the contractors during their government service is structural rather than explicit; they will be evaluated, on entering the private sector, on the relationships they brought from public service.

The Project on Government Oversight’s 2018 report Brass Parachutes documented that, of the 645 retired three- and four-star generals and admirals who retired between 2008 and 2017, more than 380 — nearly 60 percent — took jobs in the defense industry, primarily with the prime contractors. The pattern across senior civilian Department of Defense officials is comparable. The GAO’s 2008 report on the revolving door identified at least 52 contractors that had hired more than 2,400 former Department of Defense employees, including 422 former senior officials, in fiscal year 2006 alone. The Department’s own ethics rules impose cooling-off periods of one to two years for direct lobbying of the government employee’s former agency. The cooling-off periods do not prevent the broader pattern; they only constrain its most visible form.

The downstream consequence of the revolving door is the soft capture of the procurement function. Senior officials negotiating with prime contractors during the contracting phase know the potential prime contractors as the future employers of their post-government careers. Senior contractor executives know the procurement officials as former colleagues and as potential future colleagues. The relationships are personal rather than institutional. The decisions are made within a relational frame that systematically advantages the contractors over the taxpayer. The pattern is documented in the procurement literature; the political scientist Daniel Wirls’s Buildup: The Politics of Defense in the Reagan Era (Cornell, 1992) and the more recent work of William Hartung at the Quincy Institute for Responsible Statecraft trace the mechanism in detail.

The federal statute on the revolving door is principally the Procurement Integrity Act, codified at 41 U.S.C. § 2104, and the related provisions of 18 U.S.C. § 207. The statutes are limited in scope, restrict only the most direct forms of post-government activity, and are enforced through the agency-level ethics offices whose institutional independence has been a recurring subject of inspector-general critique. The reform agenda for the revolving door has been developed in the legal scholarship; the principal proposals include extended cooling-off periods, lifetime bans on lobbying the former agency for senior officials, mandatory disclosure of post-government employment compensation for senior officials, and the broader structural reform of separating the procurement function from career-track positions that incentivize industry-favorable decisions. None of these reforms is technically difficult. All of them face institutional opposition from the constituencies that benefit from the current arrangement.

◆ ◆ ◆

**The reconstruction record: SIGIR and SIGAR**

The longest-running and most systematic federal documentation of the cost-overrun and contract-fraud pattern is the work of two special inspectors general established by Congress in connection with the Iraq and Afghanistan reconstruction efforts. The Special Inspector General for Iraq Reconstruction (SIGIR) operated from 2004 through 2013. The Special Inspector General for Afghanistan Reconstruction (SIGAR), established in 2008, continues to operate. Both offices have produced detailed quarterly reports and final assessments that constitute, taken together, the most extensive federal documentation of reconstruction-contract fraud and waste in American history.

SIGIR’s final report, Learning from Iraq, published in March 2013 under Inspector General Stuart Bowen, concluded that approximately $60 billion in U.S. funds spent on Iraqi reconstruction had produced “limited or no benefit,” with approximately $8 billion specifically identified as lost to waste, fraud, or abuse. The principal patterns identified in the SIGIR final report were: contracts awarded without adequate competition; contractors paid for services or infrastructure that were not delivered; physical infrastructure built and then abandoned because the operating capacity to sustain it did not exist; payments made to subcontractors who were subsequently identified as having connections to the insurgent forces the broader reconstruction effort was nominally directed against; and pervasive billing irregularities that the limited audit capacity available in the conflict environment was unable to fully document. Bowen’s testimony before Congress on the final report was direct: “We could have built that program much smarter, and we wouldn’t have wasted $8 billion.”

SIGAR’s quarterly reports, issued continuously from 2008 through the present, have documented a comparable pattern in the Afghanistan reconstruction at substantially larger scale. The cumulative U.S. spending on Afghanistan reconstruction reached approximately $146 billion by the 2021 collapse of the Afghan government, with substantial portions of that funding identified across the SIGAR quarterly reports as wasted, unaccounted for, or diverted. The most consequential single case may be the construction of the gas station in Sheberghan, Afghanistan, documented in a 2015 SIGAR report: a single compressed-natural-gas filling station built at a cost of approximately $43 million, in a country where the comparable Pakistani facility cost approximately $500,000. SIGAR Inspector General John Sopko’s testimony before Congress on the case noted that the Department of Defense had been unable to provide a credible explanation for the cost. The broader pattern was that contracting officers in the conflict environment were operating under pressure to move money rapidly, with limited oversight, in conditions where the contractors had significantly better information than the contracting officers about local costs.

Neither SIGIR nor SIGAR was able to produce, through investigation alone, any substantial recovery of the funds identified as wasted. The Department of Justice prosecutions that flowed from the inspector-general investigations resulted in a small number of convictions of mid-level contracting personnel and contractor employees. No senior executive of any major contractor and no senior Department of Defense or State Department official was prosecuted in connection with the reconstruction failures. The institutional pattern was therefore the same pattern the chapter has documented at the level of weapons procurement: extensive documented waste, modest individual accountability at the mid-level, no consequences at the senior level, and continued institutional posture that the next reconstruction effort would do better. The empirical record of subsequent reconstruction efforts — the more limited efforts in Syria, Libya, and elsewhere — does not support the institutional optimism.

◆ ◆ ◆

**COUNTERARGUMENT**

The Department of Defense audit failures reflect the sheer scale and complexity of military operations across the world, not the absence of financial control. Major defense programs experience cost growth because they involve unprecedented technical challenges — the F-35 is the most complex weapons platform ever built, and projecting its cost over a 66-year service life was inherently uncertain. The pattern of cost growth is what happens when a sophisticated military pushes the technical state of the art. The alternative — limiting acquisitions to mature, off-the-shelf systems — would leave the United States technologically behind its adversaries.

**WHY THIS DOES NOT SAVE THE FRAMING**

Scale and technical complexity are real factors, and the defense of the audit posture would be more credible if the federal government’s own oversight bodies had not identified specific, addressable institutional weaknesses that the Department has been on notice about since 1995. The Government Accountability Office’s High-Risk Series has documented, year after year, that the financial-systems weaknesses are within the Department’s capacity to address — the issue is not the difficulty of auditing complex operations in principle, but the absence of integrated financial systems, the persistent use of incompatible legacy accounting platforms across services, and the structural disincentives within the procurement architecture for transparent cost accounting. The Department of Energy and the Department of Veterans Affairs operate complex, technically sophisticated programs and have achieved clean audit opinions on their consolidated financial statements. The difficulty of auditing defense operations is not infinite. It is contingent on institutional choices about how to organize financial management. The audit-failure record reflects those choices, not the inherent ungovernability of the underlying activity. On the cost-growth question, the defense is equally weakened by the comparative record. The same prime contractors that produce systematic cost growth on American programs produce, in some cases, more controlled costs on programs sold to other allied buyers, which suggests the pricing dynamics are responsive to the buyer’s structure of incentives and oversight rather than to inherent technical uncertainty. The argument that high cost growth is the unavoidable price of technological leadership is contradicted by the existence of programs in which the same firms deliver to specification. The structural reading is that American defense procurement is organized to permit cost growth because the political architecture rewards permissiveness.

◆ ◆ ◆

**Gilens and Page: whose preferences move legislation**

The empirical political-science finding that gives the budget pattern its sharpest interpretation was published in September 2014, in the journal Perspectives on Politics, by the political scientists Martin Gilens of Princeton University and Benjamin Page of Northwestern University. The paper is titled “Testing Theories of American Politics: Elites, Interest Groups, and Average Citizens.”

Gilens and Page assembled a dataset of approximately 1,779 policy issues for which both reliable national survey data on public preferences and clear policy outcomes were available, spanning 1981 to 2002. They modeled the relationship between four sets of preferences — average citizens, economic elites, business-oriented interest groups, and mass-membership citizen interest groups — and policy outcomes. The principal finding, in the authors’ own language: “Multivariate analysis indicates that economic elites and organized groups representing business interests have substantial independent impacts on U.S. government policy, while average citizens and mass-based interest groups have little or no independent influence.” The numerical finding was that when the preferences of economic elites and average citizens diverged, policy outcomes correlated strongly with elite preferences and essentially not at all with average citizen preferences. Average citizen preferences had “near-zero, statistically non-significant” effect on policy when the analysis controlled for elite preferences.

I want to be careful with what this finding does and does not establish. Gilens and Page were measuring a particular operationalization of public influence on policy, on a specific dataset, with a specific methodology, over a specific period. The paper has been challenged in the subsequent literature on its methodology, its operationalization of “elites,” and the extent to which the average-citizen and elite preferences in the dataset actually diverged on most issues (they often did not). Several published critiques — by Omar Bashir in 2015, by Peter Enns in 2015, and by J. Alexander Branham, Stuart Soroka, and Christopher Wlezien in 2017 — argued that the strong reading of the Gilens-Page finding overstates the case, that on most issues average citizens and elites agree, and that the divergent cases on which policy tracks elites are not necessarily representative of American politics as a whole.

I cite the critiques because the honest reading of the political-science literature includes them. The narrower defensible reading of the Gilens-Page finding is that on the specific class of policy issues where average citizen preferences and economic-elite preferences diverge, the policy outcomes track elite preferences substantially more than average citizen preferences. The federal budget, and particularly the budget categories where average citizens consistently prefer more spending (healthcare, education, public infrastructure) and elites consistently prefer less, and the budget categories where elites consistently prefer more spending (defense procurement, financial-sector regulatory exemptions, fossil-fuel subsidies) and average citizens consistently prefer less, is precisely the class of policy area where the Gilens-Page finding is most directly applicable. The budget is the place where divergence between average citizen preferences and elite preferences is most measurable, where the policy outcomes are most observable, and where the empirical finding maps most cleanly onto the institutional behavior the previous sections of this chapter have documented.

The structural humanism reading of the Gilens-Page finding is therefore narrower than the popular reading but not less consequential. American democracy does not, on the political-science evidence, produce policy outcomes that track average citizen preferences on the issues where average citizens and elites disagree. On those issues — and budget allocation is the central one of those issues — the political system functions, in measurable empirical terms, as an oligarchy with democratic procedural features rather than as a democracy with oligarchic distortions. The procedural features are real and matter. The substantive outcomes track the preferences of a smaller set of actors than the procedural features would suggest. The combination is what the federal budget reveals.

◆ ◆ ◆

**Opportunity cost: what the spending priorities have not built**

The most useful way to read the federal budget is as a statement of what the country has chosen, on the margin, to build and not to build. Every dollar spent on one priority is a dollar not available for another. The opportunity-cost accounting of the budget choices of the past quarter century is, by the comparable democracy benchmark, sobering.

The Costs of War Project at Brown University, cited extensively in Chapter 6, places total U.S. spending on post-9/11 wars at approximately $8 trillion through 2050, with the figure including obligated future veterans’ care. That spending was authorized by Congress through specific votes that are part of the public record. The same Congress was simultaneously declining to authorize, over the same period, the spending that would have closed the American public-infrastructure gap. The American Society of Civil Engineers’ quadrennial Report Card for America’s Infrastructure, most recently issued in 2025, grades the overall condition of American infrastructure at C and estimates that the gap between current spending levels and the spending required to bring American infrastructure to acceptable condition is approximately $2.6 trillion across the next decade. That figure is approximately one-third of what was spent on post-9/11 wars. The infrastructure spending would have produced measurable improvements in American economic productivity, household welfare, and physical safety. The war spending produced the consequences documented in Chapter 6.

Similar comparisons can be made on essentially every category of public investment Americans tell pollsters they want their government to undertake. The National Bureau of Economic Research has documented the macroeconomic returns to public investment in research and development, education, and infrastructure as substantially positive across most categories. The empirical case for higher public investment in those categories is robust in the economic literature. The political case for the alternative spending patterns has been won not on economic grounds but on political grounds — specifically, the structural Gilens-Page dynamic in which the preferences of organized economic interests have consistently outweighed the preferences of average citizens on the budget allocation. The defense industrial base is an organized economic interest with strong representation in essentially every congressional district. American school children, American public-transit riders, American patients waiting for clinical trials, and American researchers seeking grant funding are not, in the same way, organized economic interests. The asymmetry is the asymmetry of representation.

**Table 10-2. Selected federal opportunity-cost comparisons**

<table>
<colgroup>
<col style="width: 40%" />
<col style="width: 27%" />
<col style="width: 31%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Comparison</strong></td>
<td><strong>Approximate cost</strong></td>
<td><strong>Time frame</strong></td>
</tr>
<tr class="even">
<td>Total post-9/11 war spending (through 2050)</td>
<td>~$8 trillion</td>
<td>FY 2001–2050</td>
</tr>
<tr class="odd">
<td>Estimated U.S. infrastructure gap</td>
<td>~$2.6 trillion</td>
<td>Next decade</td>
</tr>
<tr class="even">
<td>Cost of universal pre-K for U.S. (CEPR estimate)</td>
<td>~$100 billion / yr</td>
<td>Recurring</td>
</tr>
<tr class="odd">
<td>Federal student loan debt (currently outstanding)</td>
<td>~$1.6 trillion</td>
<td>Cumulative</td>
</tr>
<tr class="even">
<td>Cost of forgiving full federal student loan debt</td>
<td>~$1.6 trillion</td>
<td>One-time</td>
</tr>
<tr class="odd">
<td>Annual U.S. defense appropriation, FY 2024</td>
<td>~$850 billion</td>
<td>Recurring</td>
</tr>
<tr class="even">
<td>NIH annual appropriation, FY 2024</td>
<td>~$48 billion</td>
<td>Recurring</td>
</tr>
<tr class="odd">
<td>SIGIR-identified Iraq reconstruction waste</td>
<td>~$8 billion</td>
<td>FY 2003–2013</td>
</tr>
<tr class="even">
<td>Cumulative U.S. spending on Afghan reconstruction</td>
<td>~$146 billion</td>
<td>FY 2002–2021</td>
</tr>
</tbody>
</table>

*Source: Costs of War Project, Watson Institute, Brown University; American Society of Civil Engineers Report Card 2025; Center for Economic and Policy Research; Federal Reserve Bank of New York Quarterly Report on Household Debt; Congressional Research Service appropriations summaries; SIGIR Learning from Iraq (March 2013); SIGAR quarterly reports through 2021. Figures rounded; recurring vs. one-time spending categorizations approximate.*

◆ ◆ ◆

**COUNTERARGUMENT**

The comparison between defense spending and domestic-program spending is not as direct as the opportunity-cost framing implies. Defense spending serves national security functions that are not substitutable with domestic investments. American military commitments to NATO, Pacific allies, Middle East partners, and global maritime security do not become unnecessary because American bridges need repair. Framing the choice as a simple trade-off ignores the strategic functions defense spending performs.

**WHY THIS DOES NOT SAVE THE FRAMING**

The counterargument is correct that defense spending and domestic investment serve different functions and are not perfectly substitutable. The chapter does not argue that they are perfectly substitutable. What the chapter argues is narrower: that the marginal additional defense dollar appropriated above the level that would adequately fund the legitimate national-security commitments could, in principle, be reallocated to other public priorities, and that the political-science evidence indicates American budget allocation does not currently optimize that trade-off in the way that the average-citizen preferences in the public-opinion data would suggest. The strong version of the counterargument — that current defense spending levels are precisely what national security requires, no more and no less — is not seriously defensible. The Department of Defense’s own audit record demonstrates that the Department itself cannot tell its appropriators what specific defense outcomes specific dollars are producing. The reform that the chapter’s argument supports is not the abolition of defense spending. It is the rationalization of defense spending against measurable national-security outcomes, the closing of the audit-failure gap that prevents Congress from doing meaningful oversight, and the restoration of the budget-deliberation process to one in which the public’s preferences register more clearly than the political-science evidence indicates they currently do.

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for the federal budget has five layers.

On the audit failure: Congress should condition continued Department of Defense appropriations on measurable progress toward a clean audit, with specific intermediate benchmarks and a hard deadline for the consolidated clean opinion. The Department’s position that achieving a clean audit will require additional years has been the same position across every audit cycle since 2018. The pattern indicates that internal departmental motivation alone is not producing the required progress. External pressure — the linking of appropriations to audit performance — is the institutional mechanism that the structural-incentive literature suggests would produce the required change. The reform is not radical. It is the application of the standard accountability mechanism Congress applies to other agencies.

On contractor cost overruns: tighten the Nunn-McCurdy reporting thresholds, require independent cost estimates for major programs at multiple decision gates, restructure fixed-price-incentive contracts to prevent the underbidding-then-overrunning pattern the KC-46 case illustrated, and impose meaningful consequences — program restructuring under independent oversight, executive accountability at prime-contractor leadership, financial penalties that cannot be passed through to subsequent contracts — for cost growth above specified percentage thresholds. The current system treats cost growth as a feature to be managed rather than as a failure to be corrected. The reform is to change the incentive structure so that the prime contractor’s upside on a successful program is sufficient to motivate good performance and the downside on a runaway program is sufficient to motivate accurate initial estimates.

On the revolving door: extend the cooling-off periods for senior Department of Defense officials moving to defense contractors, impose lifetime bans on direct lobbying of the former agency for the most senior positions, require comprehensive financial disclosure of post-government employment compensation, and consider the broader structural reform of separating the procurement function from career-track positions that incentivize industry-favorable decisions. The Project on Government Oversight’s reform proposals provide the principal framework. The reform agenda is well developed in the legal scholarship. The principal obstacle is the resistance of the constituency that benefits from the current arrangement.

On the Gilens-Page dynamic itself: the structural reforms that would address the documented divergence between average-citizen preferences and policy outcomes are the reforms of Chapters 1 through 4 of this book, applied to the political process. Campaign-finance reform that reduces the systematic over-representation of organized economic interests. Lobbying reforms that close the revolving door between regulatory agencies and the regulated industries. Antitrust enforcement that reduces the political weight of consolidated corporate sectors. Media and information-environment reforms that improve the public’s capacity to evaluate budget-allocation choices. None of these reforms operate directly on the federal budget. All of them, over time, would shift the structural conditions within which budget choices are made.

On opportunity-cost accounting: institutionalize the comparative opportunity-cost analysis that the Costs of War Project produces ad hoc. The Congressional Budget Office should be funded and directed to produce, for every major appropriations bill and every major budget-reconciliation package, an explicit opportunity-cost analysis identifying what alternative public investments could be funded at the same fiscal cost. The accounting should be public. It should be referenced in the legislative debate. It should make the trade-offs visible in a form that average citizens can evaluate. The reform is informational rather than directly substantive, but the political-economy literature on transparency interventions indicates that informational reforms of this kind can shift downstream political behavior.

◆ ◆ ◆

**Pattern**

The federal budget is the clearest single document the American polity produces about what it has decided is worth doing. The decisions have been made through legitimate procedural mechanisms. The Department of Defense cannot tell its appropriator what it spent the money on. The major weapons programs experience cost growth measured in trillions of dollars across the past two decades. The KC-46 program illustrates, at single-program resolution, the institutional mechanism by which the cost growth is sustained. The revolving door between senior Department of Defense positions and the major contractors illustrates the structural incentive that sustains the dynamic across program cycles. The SIGIR and SIGAR reconstruction documentation establishes that the same patterns operate in conflict-zone contracting at scales of tens of billions of dollars. The political-science evidence indicates that the preferences of average citizens have, on the budget-allocation questions where their preferences diverge from elite preferences, a near-zero independent influence on policy outcomes. The opportunity cost of the budget choices is measurable and is, by every standard public-investment metric, substantial.

None of this is hidden. The audit reports are public. The GAO cost-growth analyses are public. The POGO revolving-door reports are public. The SIGIR final report and the SIGAR quarterly reports are public. The Gilens-Page paper is in a peer-reviewed journal. The opportunity-cost comparisons are in the standard public-policy literature. What is missing is not the information. What is missing is the political coalition large enough to act on the information against the structural interests that benefit from the current arrangement. The work of building that coalition is the work of the next chapter, which examines what the available civic toolkit actually contains, what mechanisms ordinary citizens can deploy, and how the cumulative effect of sustained civic pressure can shift outcomes in directions the current political equilibrium does not produce.

> *The federal budget is the clearest single document the American polity produces about what it has decided is worth doing. The Defense Department cannot tell its appropriator what it spent the money on.*

**Chapter 11**

*The Relentless Current*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

Everything in this book to this point has been diagnostic. This chapter is operational. It describes, with specific legal citations, the constitutional tools American citizens already hold for changing the institutional arrangements the previous chapters have documented. The tools are real. They are legal. They are underused. They are what distinguishes a citizen in a democratic republic from a subject in a managed state.

The chapter is organized around four tiers. The first tier is what a citizen can do today, alone, for free. The second is what citizens can do collectively, at the local level, with sustained organization. The third is what citizens can do as movement-level pressure, with national coordination. The fourth is what citizens can do across decades, to alter the constitutional architecture itself. All four tiers are necessary. None is sufficient alone. The cumulative pressure across the four tiers, sustained over time, is what has produced every meaningful institutional reform in American history. The reforms documented in the previous chapters — the Pure Food and Drug Act, the Sherman Antitrust Act, the Sixteenth Amendment, the Nineteenth Amendment, the Civil Rights Act, the Voting Rights Act, the Clean Air Act, the Endangered Species Act — were all produced through some combination of these tools. The tools work when used. They produce nothing when left on the table.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: what specific constitutional and legal mechanisms exist for ordinary American citizens to alter the institutional arrangements the previous chapters have documented, what is the empirical record on which mechanisms have actually produced change, and how should a citizen acting today allocate her finite time and energy across the available options?

Thesis, in one sentence: every consequential reform in American history has been produced through some combination of fifteen specific mechanisms that the Constitution and federal statute already grant to ordinary citizens, and the present moment’s peculiar combination of acute institutional drift and abundant documentary evidence creates a window in which the deliberate, sustained, non-violent use of those mechanisms is both more necessary and more likely to produce institutional response than at most other moments in recent American history.

I want to address one objection at the front of this chapter, because it is the objection most often used to discourage civic action and it deserves to be answered directly. The objection is that the system is too large, too captured, and too well-defended for individual action to matter. The empirical answer is that this is the same argument that was made in 1773, in 1861, in 1903, in 1955, and in 1989. It has never once been correct as a reason to stop. The British East India Company had a monopoly on tea trade backed by the most powerful navy in the world; the colonists dumped the tea. The Bourbon dynasty had governed France for centuries; the National Assembly drafted the Declaration of the Rights of Man. The Montgomery bus company had the protection of municipal government and state law; the boycott lasted 381 days and broke the bus company’s revenue model. The East German Communist Party had the protection of the Soviet Union and the apparatus of one of the most thoroughly developed surveillance states in human history; the Berlin Wall fell in November 1989, weeks after sustained public pressure made continued maintenance of the wall politically impossible. The argument that the system is too big has been used against every successful reform in history. It has never once been correct as a reason to give up. It has only ever been correct as a guide to being strategic rather than impulsive. That is what this chapter is for.

◆ ◆ ◆

**Tier One: what you can do today, alone, for free**

These tools require nothing but the citizen’s time and willingness. They are the foundation. They are also the most consistently underused tools in the democratic toolkit, because the managed-consent system works by making participation feel futile before it begins. It is not futile. The empirical record indicates that it is the only thing that has ever worked.

**Tool 1. Freedom of Information Act requests**

Legal authority: 5 U.S.C. § 552. Every federal agency is required by statute to respond to written requests for records that fall within the agency’s holdings, with statutory exemptions for nine specifically defined categories. The agency must respond within twenty business days. The requester has the right to administrative appeal of denials and the right to federal-court review of those appeals. The cost to file is generally zero for non-commercial requesters making first-page requests under search-and-review thresholds.

The empirical record on FOIA effectiveness is extensive. The Federation of American Scientists’ Project on Government Secrecy, the National Security Archive at George Washington University, and the muckraking publication MuckRock have, between them, produced thousands of significant disclosures through FOIA over the past two decades. The Phoenix Memo discussed in Chapter 8 was disclosed primarily through journalistic and congressional pressure on the FBI. The August 6, 2001 Presidential Daily Brief was declassified at the request of the 9/11 Commission. The 28 Pages were declassified after fourteen years of campaigning. None of these would have been disclosed without sustained legal pressure originating in FOIA-style requests. The pattern recurs: a determined requester, working through the procedural machinery, can extract documents the government would not voluntarily release. The work is slow. The work is constitutional. The work produces the documentary record on which subsequent reform can be built.

**Tool 2. Administrative Procedure Act public comment**

Legal authority: 5 U.S.C. § 553. Federal regulatory agencies are required, before issuing most rules, to publish proposed rules in the Federal Register and to accept written comments from the public during a designated comment period (typically thirty to ninety days). The agency must consider all timely comments and must address the substantive comments in the preamble to the final rule. Failure to do so is grounds for judicial review under the Administrative Procedure Act’s arbitrary-and-capricious standard.

The empirical record on APA comment effectiveness is mixed but real. Industry comments dominate the regulatory record in most rulemakings, often by hundreds-to-one ratios over public-interest comments. But the substantive quality of public-interest comments — their grounding in the regulatory record, their specific identification of statutory or factual errors in the proposed rule, their proposal of specific alternative formulations — has been shown in the legal-scholarship literature to influence final-rule outcomes more reliably than comment volume alone. Wendy Wagner’s work at the University of Texas School of Law and Cary Coglianese’s work at the University of Pennsylvania document the empirical patterns. A single well-crafted comment from a specialized public-interest organization can shift a final rule. A flood of identical form-letter comments rarely does.

**Tool 3. Constituent contact at volume and specificity**

Legal authority: First Amendment right to petition government for redress of grievances; congressional and state legislative correspondence procedures. Every congressional office tracks constituent correspondence. The internal categorization typically distinguishes between unique substantive contacts and form-letter contacts. The Congressional Management Foundation’s 2017 report “Communicating with Congress” found that congressional staff members rated personalized constituent communications as substantially more influential than form-letter mass-contact campaigns, and rated communications from constituents with demonstrated district-level connection (specific addresses, references to local issues, identified employer or community role) as more influential still.

The mechanism is simple. Call. Write. Identify yourself as a constituent. Reference the specific bill number or policy decision. Articulate, in your own words, what position you want your representative to take and why. Repeat across multiple decision cycles. The empirical record indicates that as few as a dozen substantive, specific, constituent-identified contacts on a single policy question can shift the office’s posture on that question in marginal cases. Most congressional offices receive far fewer substantive contacts on most issues than constituents imagine. The marginal contact is more influential than most citizens believe.

**Tool 4. Public-meeting participation**

Legal authority: Federal Advisory Committee Act for federal advisory bodies; state open-meetings laws (every state has one) for state and local bodies; specific statutory comment opportunities at state public-utility commissions, planning boards, school boards, county commissions, and city councils.

The empirical record on public-meeting participation is the most local of the Tier One tools and the most reliably effective at the local scale. School-board meetings, zoning hearings, planning-commission meetings, and county-commission meetings are open to public comment by statute in essentially every American state. The decisions made at those meetings shape the immediate conditions of community life. Attendance is consistently low. A citizen who shows up regularly, comments substantively, and develops a relationship with the staff and elected officials becomes one of the principal voices the body hears on its issues. The mechanism is unglamorous. The mechanism is also the most reliable way for an ordinary citizen to shape immediate governance decisions in her community.

◆ ◆ ◆

**Tier Two: what citizens can do collectively, at the local level**

These tools require organization beyond the individual but operate within the existing legal framework of state and local governance. They are the workhorses of American civic reform.

**Tool 5. Recall campaigns**

Legal authority: state constitutions and statutes; nineteen states permit recall of state-level officials, and additional states permit recall of local officials. The procedural requirements vary substantially by state — petition-signature thresholds, time windows, grounds requirements — but the basic mechanism exists in some form for many of the elected positions most directly affecting local life.

The empirical record on recall campaigns is mixed. Many initiated recalls fail to qualify for the ballot. Most that qualify fail at the polls. But the cases where recall campaigns have produced substantive accountability — the 2003 recall of California Governor Gray Davis, the 2018 recall of Wisconsin Supreme Court Justice Michael Gableman through the related judicial process, multiple successful local-official recalls — establish that the mechanism, when employed against an official whose conduct has produced sufficient genuine constituent grievance, can produce removal. The mechanism’s value is also indirect. Officials who know recall is procedurally available behave differently from officials who do not. The threat shapes conduct even when not exercised.

**Tool 6. Primary challenges against captured officials**

Legal authority: state election codes; political-party rules; primary-election procedures established under federal and state law. Every elected official, at every level, faces a primary election before facing the general election. Primary turnout is typically a small fraction of general-election turnout. Primary electorates are typically more ideologically committed and more engaged than general electorates. The mathematics of primary challenge are accordingly more favorable to organized minority preferences than the mathematics of general-election challenge.

The empirical record on primary challenges is well documented in the political-science literature. Successful primary challenges against incumbents are rare but consequential when they occur — the 2018 defeat of Joseph Crowley by Alexandria Ocasio-Cortez in New York’s 14th congressional district, the 2010 defeat of Michael Castle by Christine O’Donnell in the Delaware Republican Senate primary, multiple state-legislative primary defeats. The deeper effect is, again, indirect. An incumbent who knows she may face a credible primary challenger from her own party’s base behaves differently from an incumbent who does not. The Tea Party movement of 2009–2012 and the progressive movement of 2018–2022 each shifted the policy posture of substantial portions of their respective parties primarily through credible primary-challenge threats, not through frequent actual defeats.

**Tool 7. Coordinated FOIA documentary campaigns**

Legal authority: 5 U.S.C. § 552 (federal); state public-records laws (every state has one). The individual FOIA request of Tool 1 becomes substantially more powerful when coordinated across a documentary campaign — multiple requesters, multiple agencies, simultaneous public-records requests at the state level, sustained over time, with each disclosure feeding the next set of requests.

The empirical record on coordinated FOIA campaigns is best illustrated by the MuckRock model, the National Security Archive’s case-specific declassification projects, and the work of organizations like the Center for Investigative Reporting and ProPublica. The campaign against the Tuskegee syphilis study, the campaign for declassification of Vietnam-era documents, the campaign for COINTELPRO documents in the 1970s, the campaign for the 28 Pages — each was a coordinated FOIA-style effort sustained across years. The work is slow. The work is reliably productive when sustained.

**Tool 8. Ballot initiative campaigns**

Legal authority: state constitutions and statutes; twenty-six states permit citizen ballot initiatives in some form. The procedural requirements vary — petition-signature thresholds, geographic-distribution requirements, single-subject rules — but the basic mechanism is that citizens can place legislation directly on the ballot for popular vote, bypassing the state legislature.

The empirical record on ballot initiatives is one of the strongest in the Tier Two toolkit. The 2016 California initiative for prescription-drug-price reform, the 2018 Florida initiative restoring voting rights to felons, multiple state-level minimum-wage increases, multiple state-level marijuana legalizations, multiple state-level Medicaid expansions — the ballot-initiative mechanism has produced substantive policy change in jurisdictions where the state legislature was unable or unwilling to act. The work is expensive (signature-gathering campaigns and ballot campaigns each cost millions of dollars at the state scale) but the policy yield, when the campaign succeeds, is large.

◆ ◆ ◆

**Tier Three: movement-level pressure, national coordination**

These tools operate at the scale where national institutional change becomes possible. They are slower, more expensive, and more procedurally complex than the Tier One and Tier Two tools, but they are the mechanisms by which the most consequential federal reforms have been achieved.

**Tool 9. False Claims Act qui tam whistleblower suits**

Legal authority: 31 U.S.C. § 3730. The False Claims Act, originally enacted in 1863 to address Civil War procurement fraud and substantially modernized in 1986, permits private citizens to file federal lawsuits on behalf of the United States alleging fraud against federal programs. If the suit succeeds, the citizen-plaintiff (the relator) receives between 15 and 30 percent of the recovered funds.

The empirical record on qui tam is substantial. Department of Justice annual data indicate that qui tam suits have produced more than $50 billion in federal recoveries since the 1986 modernization. The highest-yield areas have been pharmaceutical fraud, defense-contractor billing fraud, and Medicare/Medicaid fraud. The mechanism is the principal tool through which corporate fraud against the federal government is detected and remedied. The structural humanism reading is that qui tam works because it aligns the citizen’s incentive (financial recovery) with the federal government’s interest (recovery of defrauded funds), and because the procedural protections for the relator make the mechanism legally viable for individual professionals with direct knowledge of fraud.

**Tool 10. State Attorney General antitrust actions**

Legal authority: state antitrust statutes; federal antitrust statutes (15 U.S.C. §§ 1–38) under state-AG parens patriae authority; Hart-Scott-Rodino Antitrust Improvements Act of 1976 enforcement participation.

State attorneys general have, particularly since the early 2000s, become important antitrust enforcement actors, often more aggressive than the federal Antitrust Division under the Bork-doctrine framework discussed in Chapter 4. The 1998 state-AG settlement with the major tobacco companies, the multi-state antitrust litigation against Google for both ad-tech and search monopolization, the multi-state opioid settlements, and multiple ongoing technology-platform investigations all illustrate the mechanism. The legal scholar Tim Wu and the political economist Lina Khan have argued that the state-AG bench is, at present, the more reliable antitrust-reform actor at the federal level. Citizen pressure on state attorneys general — through public comment, through electoral accountability in states with elected AGs, through coordinated advocacy — is a Tier Three mechanism with documented institutional response.

**Tool 11. Administrative law challenges — judicial review of agency action**

Legal authority: 5 U.S.C. §§ 701–706. Federal court review of final agency action under the Administrative Procedure Act’s arbitrary-and-capricious standard, or under the substantial-evidence standard for adjudicatory proceedings. Citizens with standing — a concrete and particularized injury traceable to the agency action and redressable by the court — can challenge final agency rules and major adjudicatory decisions in the federal courts.

The empirical record on APA judicial review is the area of administrative law most reshaped by the Supreme Court’s 2024 decision in Loper Bright Enterprises v. Raimondo, which overruled the Chevron deference doctrine that had governed agency interpretation of ambiguous statutes for forty years. The post-Loper Bright environment has substantially expanded the scope of judicial review of agency action, with consequences that cut in multiple directions — favoring regulated industries against rules they disagree with, but also favoring public-interest challengers of agency rules they consider insufficient. The mechanism is procedurally complex and typically requires legal counsel, but organizations like Earthjustice, the Natural Resources Defense Council, the Institute for Justice, and Public Citizen Litigation Group maintain capacity for citizen-initiated APA challenges. The mechanism is one of the principal levers through which citizen pressure becomes institutional consequence at the federal level.

**Tool 12. Shareholder activism and proxy campaigns**

Legal authority: Securities Exchange Act of 1934, Section 14(a); SEC Rule 14a-8 governing shareholder proposals; state corporate-law provisions on shareholder voting rights. The mechanism is the use of shareholder voting power, including proxy proposals submitted under SEC rules, to influence corporate governance at publicly traded companies.

The empirical record on shareholder activism has been substantially developed by the rise of environmental, social, and governance investing and by the systematic activist work of pension funds, mutual funds, and specialized activist investors. The 2021 proxy campaign by Engine No. 1 that replaced three ExxonMobil board members with climate-credentialed alternatives, the multiple successful campaigns at Disney by activist investors, and the consistent campaigns for executive-compensation reform across major American corporations all illustrate the mechanism. The structural humanism reading of shareholder activism is the same as the Chapter 4 analysis of the Big Three asset managers: voting power exists, the question is who exercises it. The reform agenda includes pass-through voting that would allow underlying beneficial owners to direct their own proxy votes — a reform that BlackRock and Vanguard have begun to offer for institutional clients but not for retail savers. The empirical case for extending it is straightforward.

◆ ◆ ◆

**Tier Four: across decades, altering the architecture itself**

These tools operate across electoral and political-generational time. They are the longest-time-horizon mechanisms and the most consequential when they succeed. The American constitutional architecture itself has been altered through these mechanisms multiple times in American history, and the conditions under which alteration becomes possible recur.

**Tool 13. State legislation as policy laboratory**

Legal authority: state legislative powers, except as preempted by federal law or restricted by the federal Constitution. The states have, since the founding, been laboratories of policy experimentation, with successful state-level reforms eventually adopted federally through the political diffusion process documented in the political-science literature.

The empirical record is extensive. Workmen’s compensation, women’s suffrage, the direct primary, the secret ballot, the minimum wage, unemployment insurance, motorized-vehicle regulation, environmental protection, marijuana legalization, marriage equality, gun-permit-and-licensing regimes — each began at the state level and eventually shaped federal policy. The mechanism operates through credible state-level demonstration that a contested reform produces administrable, beneficial outcomes. The federal political consensus follows demonstrated state success. The work is slow. The work is the durable mode of American policy change.

**Tool 14. Antitrust legislative reform campaign**

Legal authority: congressional power to regulate interstate commerce under Article I, Section 8 of the Constitution; existing antitrust statutory framework (Sherman, Clayton, FTC Acts). The mechanism is the legislative replacement or supplementation of the Bork-doctrine consumer-welfare standard with a structural-power standard that treats market concentration itself as a competitive harm.

The empirical case for this reform is the case Chapter 4 of this book has assembled. The legal-scholarship case has been developed by Lina Khan, Tim Wu, the Open Markets Institute, the Roosevelt Institute, and the American Economic Liberties Project. The 2023 FTC and DOJ merger guidelines moved in this direction administratively; codification by statute is the next required step. The legislative vehicle is straightforward in design — a Competition Reform Act that supplements the Sherman, Clayton, and FTC Acts with structural-power criteria — and difficult only politically, because the principal beneficiaries of consolidation are among the most aggressive opponents of any reversal. The mechanism is multi-decade. The political conditions for its enactment build gradually.

**Tool 15. Constitutional amendment campaigns**

Legal authority: Article V of the United States Constitution. Two routes are available. The first requires a proposing two-thirds vote in each house of Congress and ratification by three-fourths of the state legislatures (or three-fourths of state ratifying conventions). The second requires the call of a constitutional convention by two-thirds of the state legislatures, followed by ratification by three-fourths of the state legislatures or ratifying conventions. The first route has been used to enact every existing amendment after the original Bill of Rights. The second route has never been used to enact an amendment, though state-legislative calls for a convention on various subjects have approached the two-thirds threshold.

The empirical record on constitutional amendment campaigns is the longest-horizon of the Tier Four mechanisms. The Sixteenth Amendment (federal income tax), Seventeenth Amendment (direct election of senators), Eighteenth Amendment (Prohibition), Nineteenth Amendment (women’s suffrage), Twenty-first Amendment (repeal of Prohibition), Twenty-fourth Amendment (poll-tax prohibition), and Twenty-sixth Amendment (voting age) all required sustained multi-decade campaigns. The amendment that is currently under most active discussion — a Twenty-eighth Amendment addressing campaign finance and the corporate-personhood doctrine reaffirmed by Citizens United v. FEC (2010) — has been the subject of organized campaigning since the Citizens United decision. The campaign is at the multi-decade stage. The empirical record on amendment campaigns indicates that they succeed when sustained across electoral generations and when the underlying political conditions reach a level of acuity sufficient to overcome the procedural supermajority requirements. The conditions are not yet there. They may approach in the coming decades.

◆ ◆ ◆

**Table 11-1. The fifteen tools, four tiers**

<table>
<colgroup>
<col style="width: 14%" />
<col style="width: 47%" />
<col style="width: 38%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Tool</strong></td>
<td><strong>Legal authority</strong></td>
<td><strong>Typical time horizon</strong></td>
</tr>
<tr class="even">
<td>1. FOIA</td>
<td>5 U.S.C. § 552</td>
<td>Months to years</td>
</tr>
<tr class="odd">
<td>2. APA comment</td>
<td>5 U.S.C. § 553</td>
<td>Weeks to months</td>
</tr>
<tr class="even">
<td>3. Constituent contact</td>
<td>First Amendment petition right</td>
<td>Immediate to months</td>
</tr>
<tr class="odd">
<td>4. Public meeting</td>
<td>FACA; state open-meetings laws</td>
<td>Recurring, ongoing</td>
</tr>
<tr class="even">
<td>5. Recall</td>
<td>State constitutions / statutes</td>
<td>Months to a year</td>
</tr>
<tr class="odd">
<td>6. Primary challenge</td>
<td>State election codes</td>
<td>1–2 years</td>
</tr>
<tr class="even">
<td>7. Coord. FOIA campaign</td>
<td>5 U.S.C. § 552; state PR laws</td>
<td>Years</td>
</tr>
<tr class="odd">
<td>8. Ballot initiative</td>
<td>State constitutions / statutes</td>
<td>1–2 years</td>
</tr>
<tr class="even">
<td>9. FCA qui tam</td>
<td>31 U.S.C. § 3730</td>
<td>Years</td>
</tr>
<tr class="odd">
<td>10. State AG antitrust</td>
<td>State + federal antitrust statutes</td>
<td>Years</td>
</tr>
<tr class="even">
<td>11. APA judicial review</td>
<td>5 U.S.C. §§ 701–706</td>
<td>Years</td>
</tr>
<tr class="odd">
<td>12. Shareholder activism</td>
<td>Securities Exchange Act § 14(a)</td>
<td>Years</td>
</tr>
<tr class="even">
<td>13. State legislation</td>
<td>State legislative powers</td>
<td>Years to decades</td>
</tr>
<tr class="odd">
<td>14. Antitrust legislative reform</td>
<td>Article I, § 8</td>
<td>Decades</td>
</tr>
<tr class="even">
<td>15. Constitutional amendment</td>
<td>Article V</td>
<td>Multi-generational</td>
</tr>
</tbody>
</table>

*Source: Compiled from cited statutes; time horizons drawn from the empirical political-science literature on each mechanism’s historical record.*

◆ ◆ ◆

**COUNTERARGUMENT**

This chapter presents the civic toolkit as if these mechanisms are routinely available to ordinary citizens, but the practical reality is that meaningful use of FOIA, APA judicial review, qui tam litigation, ballot initiatives, or constitutional amendment campaigns requires substantial resources, legal expertise, and organizational capacity that most ordinary citizens do not have. The chapter’s framing risks producing false optimism by suggesting that individual action against the institutions documented in Chapters 1 through 10 is more accessible than it actually is.

**WHY THIS DOES NOT SAVE THE FRAMING**

The counterargument is partly correct, and the chapter should not be read as denying the resource asymmetries. The Tier Three and Tier Four mechanisms do require organizational capacity beyond what an individual citizen can produce alone. The chapter’s deeper claim is that the Tier One mechanisms — FOIA requests, APA comments, constituent contact, public-meeting participation — are accessible to essentially every American citizen and that the cumulative effect of their use, combined with the organizational capacity that Tier Two builds and that Tier Three and Tier Four mobilize, is what produces institutional change. No individual reformer in American history has worked across all fifteen tools alone. Every successful reform has involved a coalition: individuals using the Tier One tools to build the documentary record and the constituent pressure, local organizations using the Tier Two tools to build credibility and political voice, national organizations using the Tier Three tools to translate pressure into institutional consequence, and the broader political movement deploying the Tier Four tools to alter the architecture across decades. The accessibility argument cuts the chapter’s way, not against it. The Tier One tools are accessible. The other tiers are accessible to those who build the organizational capacity. The capacity-building is itself part of the work.

◆ ◆ ◆

**A note on non-violence**

Everything in this chapter is non-violent. This is not a pragmatic concession to political reality. It is a strategic and moral position grounded in the empirical record on what produces durable institutional change.

The political scientist Erica Chenoweth’s research at Harvard, published in book form as Why Civil Resistance Works (Columbia, 2011, co-authored with Maria Stephan) and extended in her 2021 Civil Resistance: What Everyone Needs to Know (Oxford), assembled the largest cross-national dataset on resistance movements ever compiled. The empirical finding is that non-violent civil-resistance movements have succeeded in achieving their stated objectives at roughly twice the rate of violent movements over the past century. The mechanism, in Chenoweth’s analysis, is that non-violent movements draw participation from across a broader cross-section of society, are harder for the targeted regime to delegitimize through public rhetoric about violence, and produce political coalitions sufficient for durable change once the targeted regime accommodates or falls.

I am not arguing for non-violence on grounds of personal pacifism. I am arguing for non-violence on grounds of empirical effectiveness. The American historical record — the abolitionist movement, the women’s suffrage movement, the labor movement’s most durable wins, the civil-rights movement — supports the cross-national pattern. The non-violent tactics of the civil-rights movement produced the Civil Rights Act of 1964 and the Voting Rights Act of 1965. The violent splinter tactics that emerged later in the same decade produced no comparable legislative achievement and made the broader movement easier for political opponents to delegitimize. The empirical case for non-violence is the case for what works. Citizens who care about the institutional reforms documented in the previous chapters should use the tools this chapter has described. They should use them sustainedly, strategically, and non-violently. The combination is what has produced every reform worth keeping.

> *Non-violent civil-resistance movements have succeeded at roughly twice the rate of violent movements. The argument for non-violence is the argument for what works.*

◆ ◆ ◆

**COUNTERARGUMENT**

The non-violence argument is selective in its history. The American Revolution was a violent revolution. The Civil War was a violent civil war. The decolonization movements of the twentieth century included substantial armed components. The claim that non-violent resistance is always more effective ignores the cases where violence was, on the historical record, necessary to overcome regimes that would not yield to non-violent pressure.

**WHY THIS DOES NOT SAVE THE FRAMING**

Chenoweth’s finding is not that non-violent resistance has worked in every case or that violent resistance has worked in no case. The finding is that the success rate, across the full cross-national dataset of resistance movements over the past century, is substantially higher for non-violent than for violent movements. The historical cases the counterargument cites are real, and the chapter does not argue that no historical situation has ever justified violent resistance. The argument is narrower. The conditions facing American citizens in 2026 are not the conditions facing American colonists in 1775 or the conditions facing the slaves under chattel slavery in 1860. The constitutional framework exists. The mechanisms in this chapter exist. The political space for non-violent organized pressure exists. The case for violent action in present-day American politics does not pass the threshold that historical cases of legitimate violent resistance have passed: the absence of all available non-violent alternatives, the exhaustion of all procedural remedies, the explicit closure of the political process by force. Those conditions do not currently apply. The non-violence argument in this chapter is not a categorical philosophical position; it is an empirical argument about the present moment in American political life. If those conditions were to change — if the procedural mechanisms documented in this chapter were systematically closed, if elections were suspended, if mass political imprisonment of organizers began — the calculus would change. The argument for non-violence is the argument for what works in the present institutional conditions, not the argument for what would be required in conditions the present moment does not impose.

◆ ◆ ◆

**A practical sequencing**

If a single reader were to ask, having read this chapter, where to start — the honest answer is the Tier One tools, applied to one issue she cares about, sustained over a year. Pick an issue. File the FOIA requests. Read the documents. Comment on the relevant agency rulemakings. Contact the constituent offices. Attend the public meetings. Document what you learn. Share the documentation with neighbors. Build the organizational connections that make Tier Two action possible. The year of sustained Tier One work on a single issue is what produces the conditions under which the Tier Two, Three, and Four mechanisms become accessible and effective.

The Tier One tools are the principal entry point because they are what is universally available, because they build the documentary and constituent records that make the higher-tier tools effective, and because the discipline of using them is the civic muscle that has atrophied in the American polity across the past several decades. The reform agenda of this book — the antitrust reform, the healthcare reform, the campaign-finance reform, the foreign-policy reform, the surveillance reform — all become possible only when a sufficient share of the American polity has rebuilt the civic muscle of sustained institutional pressure. The muscle is built one Tier One action at a time. The chapter is, in the end, an invitation to begin.

◆ ◆ ◆

**Pattern**

The mechanisms exist. The legal authority is in the statutes and the Constitution. The empirical record on what each mechanism has produced is in the political-science and legal-scholarship literature. The barrier is not the absence of tools. The barrier is the cultivation of the citizen capacity to use them — the time, the attention, the organizational connection, the patience for institutional change that operates across years and decades rather than across news cycles. That capacity is what the present arrangement most works to discourage. That capacity is what this chapter is meant to encourage.

A single citizen using a single tool produces a single document. A hundred citizens using the same tool on the same issue produce a documentary record sufficient to change institutional behavior. A million citizens using the full toolkit across coordinated campaigns produce the institutional reforms this book has argued the political moment requires. The arithmetic is real. The barrier is whether enough citizens decide to act on it. The next chapter, on the contemporary men consolidating technological power, illustrates the institutional opposition the toolkit will be deployed against. The opposition is concentrated. The toolkit is broad. The asymmetry of resources is real and substantial. The asymmetry of legitimacy is the opposite — the citizens are the legitimate sovereign in the American constitutional design, and the institutions documented in Chapter 12 are the constituents who answer to the sovereign rather than the other way around. Restoring the relationship to its constitutional design is the work.

> *The mechanisms exist. The legal authority is in the statutes. The barrier is the cultivation of the citizen capacity to use them. That capacity is what this chapter is meant to encourage.*

**Chapter 12**

*The Men at the Controls*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The chapter you are about to read is the most legally sensitive in this book, and it begins with a piece of self-disclosure I owe the reader before any of its specific arguments.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><strong>Author’s disclosure on the writing of this chapter</strong></p>
<p>I disclosed in the Introduction that I have used artificial-intelligence tools as drafting and editorial assistants on this book. Among those tools is Claude, produced by Anthropic. This chapter examines Anthropic by name as one of the firms now consolidating technological power. The reader should know that a chapter about Anthropic was drafted with the assistance of a product made by Anthropic, and that I have made specific editorial efforts to ensure the chapter does not soften its claims about Anthropic relative to the comparable claims it makes about OpenAI and Palantir. Where the documentary record supports a claim, the claim stands regardless of which firm it is about. The chapter’s editorial test, applied to every paragraph that discusses Anthropic, has been: would I write this sentence the same way if the firm were Microsoft, or Google, or any other technology company in which I had no working relationship? Where the answer was no, I revised. The disclosure is the structural humanism standard applied to my own composition. The reader is entitled to know how the work was made.</p></td>
</tr>
</tbody>
</table>

The contemporary American technology sector is the institutional setting in which the Bork-doctrine framework of Chapter 4, the surveillance architecture of Chapter 3, the foreign-policy entanglement of Chapters 6 and 7, and the broader question of who holds power in the early twenty-first century all converge. The firms are new. The structural logic is the same one that runs through every other chapter of this book. Concentrated power, weakly supervised, producing predictable outcomes. The chapter examines three men and the institutions they have built. The institutional analysis is the work. The individuals are the entry points into the institutional analysis.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: who are the principal individual decision-makers at the contemporary frontier technology firms whose products shape American public and private life, what are the documented institutional positions of those firms, and how should the public evaluate the concentration of decision-making authority over technologies of this consequence in the hands of so small a set of individuals?

Thesis, in one sentence: the contemporary American technology frontier is dominated by a small set of firms whose principal decision-makers have, by virtue of their position, accumulated more concentrated power over consequential technological infrastructure than any comparable set of private actors in American history, and the public has been given little structural opportunity to evaluate or influence the decisions those individuals make on its behalf.

I examine three principals: Alex Karp of Palantir, Sam Altman of OpenAI, and Dario Amodei of Anthropic. The selection is not exhaustive. Larry Ellison of Oracle, Elon Musk across multiple firms, Mark Zuckerberg of Meta, and Sundar Pichai of Alphabet each warrant their own treatment, and parts of this chapter’s framework apply to them as well. The three I have chosen are the principals whose firms occupy the specific frontier-AI and intelligence-contracting space that has, in 2025 and 2026, become the most consequential single sector in the American economy. The cases I examine are drawn from the public documentary record — SEC filings, court filings, contemporaneous reporting in major outlets, official agency statements, and judicial opinions. Where allegations have been made that have not been adjudicated, I use the allegation’s actual procedural posture and clearly distinguish allegation from finding.

◆ ◆ ◆

**Alex Karp and Palantir Technologies**

Palantir Technologies was founded in 2003 by Peter Thiel, Alex Karp, Joe Lonsdale, Stephen Cohen, and Nathan Gettings, with early funding from In-Q-Tel, the Central Intelligence Agency’s venture-capital arm. The firm took its name from the seeing-stones of J. R. R. Tolkien’s Lord of the Rings — a literary reference whose implications about the relationship between surveillance and power the company has, across two decades of public communication, never disclaimed. Karp has been the chief executive throughout. Thiel remained chairman through 2025 and has been the firm’s most influential outside political voice.

Palantir’s two principal product lines, Gotham and Foundry, are data-integration and analytics platforms deployed across federal intelligence agencies, the Department of Defense, federal civilian agencies including U.S. Immigration and Customs Enforcement and the Department of Health and Human Services, multiple state and local police departments, and a growing list of corporate clients. The firm went public on the New York Stock Exchange in September 2020 through a direct listing. Its market capitalization in 2026 has fluctuated between approximately $300 billion and $500 billion, placing it among the most valuable American companies. Federal contracts account for a substantial share of revenue. The firm’s 10-K filings with the Securities and Exchange Commission document the contract structure publicly.

The relevant facts about Palantir’s institutional position are these. The firm’s technology has been documented, through reporting by the Intercept, the Washington Post, ProPublica, and other outlets, to be in use by ICE for the construction of comprehensive profiles of undocumented immigrants and individuals associated with them — family members, employers, landlords, friends — to facilitate enforcement operations. The firm’s technology has been documented to be in use by multiple police departments, including the Los Angeles Police Department, the New Orleans Police Department, and others, for predictive-policing applications whose accuracy and civil-liberties implications have been the subject of substantial ACLU and academic critique. The firm’s technology has been deployed in support of military targeting operations, including, per reporting by 972 Magazine and the Guardian, the Israeli Defense Forces’ targeting operations in Gaza beginning in October 2023, under a contract Palantir announced publicly in January 2024.

Karp’s public defense of the firm’s posture has been notably uncircumspect. In a January 2024 interview with the Atlantic and in subsequent public statements, Karp has argued that the West is engaged in a civilizational struggle against adversaries that requires the deployment of advanced technology in service of state power, that the firm’s critics fundamentally misunderstand the nature of that struggle, and that the relevant moral choice is between effective deployment of American technological capability and submission to authoritarian alternatives. His January 2025 book, The Technological Republic: Hard Power, Soft Belief, and the Future of the West, co-authored with Nicholas Zamiska, articulates this position at length. The book is in the public record. The reader is invited to evaluate it on its own terms.

The structural humanism reading of Palantir’s position is direct. The firm has built deep institutional integration with American federal security agencies, with state and local law enforcement, and with allied foreign militaries, on the basis of a technology platform that aggregates personal data on a scale the Foreign Intelligence Surveillance Act framework was not designed to govern. The firm’s products operate, by design, in the space where the surveillance architecture of Chapter 3 meets the foreign-policy architecture of Chapter 7 meets the consolidation dynamic of Chapter 4. The firm’s public defense of its posture is, in Karp’s own articulated framework, a defense of consolidated technological power deployed in service of state security objectives. The reader is entitled to evaluate whether the resulting institutional architecture is consistent with the constitutional design of a democratic republic. The chapter’s position is that it is not, and that the empirical case for reform of the regulatory architecture surrounding mass data aggregation — a federal privacy statute analogous to the European Union’s General Data Protection Regulation, meaningful limits on federal-agency procurement of aggregated personal data, restoration of the Fourth Amendment protections the third-party doctrine has progressively eroded — is now substantial.

◆ ◆ ◆

**Sam Altman and OpenAI**

OpenAI was founded in December 2015 as a non-profit research laboratory by a group including Sam Altman, Elon Musk, Greg Brockman, Ilya Sutskever, John Schulman, and Wojciech Zaremba, with the stated mission of “ensuring that artificial general intelligence benefits all of humanity.” The structure was, from the start, unusual; the founders argued that the safest path to powerful AI was to develop it inside a non-profit committed to the technology’s broad public benefit rather than inside a corporation primarily accountable to shareholders. The original organization was capitalized through pledges of approximately $1 billion from the founding donors.

The structure has evolved substantially. In 2019, OpenAI created OpenAI LP, a “capped-profit” subsidiary that permitted equity investment from outside parties while nominally preserving the original non-profit’s governance authority. Microsoft invested approximately $1 billion in 2019 and substantially more in 2023, in transactions that gave Microsoft preferential access to OpenAI’s technology and a substantial economic stake in the capped-profit entity. The November 2023 board crisis, in which the original non-profit board attempted to remove Altman as chief executive and was reversed within days under pressure from employees, Microsoft, and major investors, exposed the gap between the formal governance structure and the operational reality. The non-profit board’s authority, on paper substantial, did not survive contact with the commercial and political forces aligned around Altman’s continued leadership. The board members who attempted the removal were themselves removed or marginalized in the resolution. The episode is documented in contemporaneous reporting by the New York Times, the Wall Street Journal, the Information, and Bloomberg.

Two specific elements of the public record concerning Altman and OpenAI warrant the careful procedural treatment that this chapter applies to all unadjudicated allegations against named individuals. The first concerns the death of the OpenAI researcher Suchir Balaji in November 2024. The second concerns the federal civil litigation brought by Annie Altman against Sam Altman beginning in January 2025.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><strong>Documentary record: the death of Suchir Balaji</strong></p>
<p>Suchir Balaji, a former OpenAI researcher who had publicly accused his former employer of violating United States copyright law in the training of its AI models, was found dead in his San Francisco apartment on November 26, 2024, at age 26. He was scheduled to be a witness in pending litigation. The San Francisco Police Department and the San Francisco Office of the Chief Medical Examiner conducted investigations and concluded that the death was a suicide by self-inflicted gunshot wound to the head. The medical examiner’s final report, released in February 2025, found “no evidence or information to establish a cause and manner of death for Mr. Balaji other than a suicide.” Balaji’s parents, Poornima Ramarao and Balaji Ramamurthy, have publicly contested the official ruling, commissioned independent forensic reviews, and called for the FBI to investigate. The reviews they commissioned have raised questions about the scene and the timeline. The official ruling remains suicide. The parents’ contestation is part of the public record. This chapter reports both without endorsing either as the final answer. The procedural posture, as of this writing, is that the official investigation is closed and the family’s civil-procedural attempts to reopen it are ongoing.</p></td>
</tr>
</tbody>
</table>

The structural humanism reading of the Balaji case is procedural and narrow. I am not arguing that the official ruling is wrong. I am not arguing that any specific alternative explanation is correct. I am observing that a young researcher who had publicly accused his former employer of legal violations, and who was scheduled to be a witness in pending litigation, died in his apartment under circumstances his family has publicly contested. The American media environment has paid the case substantially less sustained attention than would be expected of a death of comparable salience involving a critic of any other institution of comparable stature. That asymmetry of attention is itself a fact about the political economy of memory that earlier chapters of this book have examined. The case deserves more journalistic and forensic attention than it has received, regardless of which conclusion the additional attention ultimately supports.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><strong>LEGAL DISCLAIMER — Annie Altman federal litigation</strong></p>
<p>Annie Altman filed a civil lawsuit against her brother Sam Altman in the United States District Court for the Eastern District of Missouri on January 6, 2025, alleging acts of sexual abuse occurring at the family home in Clayton, Missouri, between approximately 1997 and 2006, beginning when she was three years old and her brother was twelve. The complaint sought damages in excess of $75,000, plus punitive damages, for alleged injuries including post-traumatic stress disorder, severe emotional distress, mental anguish, and depression. Sam Altman, his mother Connie Altman, and his brothers Jack and Max Altman issued a joint denial of the allegations on the social-media platform X on January 7, 2025, characterizing the allegations as “deeply hurtful and entirely untrue.” Sam Altman filed a defamation counterclaim against his sister. On March 20, 2026, United States District Judge Zachary Bluestone dismissed Annie Altman’s original complaint on statute-of-limitations grounds, while permitting her to refile under Missouri’s Childhood Sexual Abuse Act, which provides an extended limitations period for such claims; the same order permitted Sam Altman’s defamation counterclaim to proceed. Annie Altman filed an amended complaint on April 1, 2026 under the Childhood Sexual Abuse Act. The litigation, as of this writing, is in active discovery. None of the allegations has been adjudicated. The reporting in this paragraph is drawn from court filings in U.S. District Court for the Eastern District of Missouri, contemporaneous reporting by Reuters, NBC News, and Business Insider, and the public statements of the parties.</p></td>
</tr>
</tbody>
</table>

I want to be precise about why this litigation appears in this chapter and how I am handling it. The litigation is a matter of public record. It involves the chief executive of one of the most consequential firms in contemporary technology. The allegations are serious. The denial is unequivocal. The defamation counterclaim has been permitted to proceed by the court. None of the underlying allegations has been adjudicated by a finder of fact, and this chapter does not adjudicate them. What the chapter does is acknowledge that the litigation exists, report its procedural posture accurately, and note that the public is entitled to know that the chief executive of a major American technology firm is engaged in active civil litigation involving allegations of this nature. The further evaluation of the allegations is a matter for the federal court conducting the litigation and ultimately, if the case goes to trial, for a jury. The chapter’s position is the procedural one: the litigation should proceed under the standards of the legal system, the parties should be permitted to make their cases, and the public reporting on the litigation should adhere to the disciplined standards of legal journalism. The legal system is the appropriate forum. The chapter respects that.

◆ ◆ ◆

**COUNTERARGUMENT**

The inclusion of unadjudicated civil allegations against Sam Altman in a chapter that is nominally about institutional power inappropriately mixes personal allegations with institutional analysis. The allegations may be true; they may be false. Their inclusion in a chapter about technology-sector power risks suggesting that personal allegations are evidence of institutional misconduct, which is a category error.

**WHY THIS DOES NOT SAVE THE FRAMING**

The counterargument is partly correct: personal allegations are not, on their own, evidence of institutional misconduct, and the chapter does not argue that they are. What the chapter does argue is that when an individual holds concentrated decision-making authority over a technology consequential to public life, the public is entitled to know what civil and criminal allegations are pending against that individual and what the procedural status of those allegations is. The chapter handles the Annie Altman litigation under the same standard that responsible legal journalism applies to comparable cases involving chief executives of comparable firms: the allegations are reported, the denial is reported, the procedural posture is reported, and the underlying merits are left to the legal system. The same chapter has reported, with the same procedural discipline, allegations against Karp’s firm regarding ICE deployments and against Anthropic regarding the Department of Defense dispute. The standard is consistent across the three principals. Excluding the Altman litigation from the chapter while including comparable institutional reporting on Karp and Amodei would itself be a category error — a selective application of the journalistic standard. The chapter applies the standard uniformly. The reader is entitled to the information; the reader is entitled to evaluate it within the procedural framing the chapter applies.

◆ ◆ ◆

**Dario Amodei and Anthropic**

Anthropic was founded in 2021 by Dario Amodei, Daniela Amodei, Tom Brown, Chris Olah, Sam McCandlish, Jack Clark, Jared Kaplan, and several others who had previously held senior positions at OpenAI. The founders’ stated rationale for the departure and the new firm’s founding was a disagreement with OpenAI’s direction regarding the safety and governance of frontier AI development. Anthropic positioned itself, in its initial public communications and in subsequent corporate posture, as a frontier AI laboratory with explicit safety commitments. The firm has been substantially capitalized through investment from Google, Amazon, and other major technology and financial-sector investors. Its principal product is Claude, the AI assistant whose various versions have been deployed across consumer, developer, and enterprise contexts.

I should disclose, again, that the present chapter has been drafted with the assistance of Claude. The reader has the right to know that the chapter is being written about the firm that produced the drafting tool that helped write it. The editorial discipline I have applied to this section is to write it under the same standard as the Karp and Altman sections — to neither soften nor harshen the relevant claims relative to what the documentary record supports, and to apply the same procedural framing to active disputes.

The relevant documentary record on Anthropic’s institutional position, as of this writing, has two principal components. The first is the firm’s commercial trajectory, including its substantial capitalization, its deployment of Claude across consumer and enterprise markets, its scientific publications on AI safety and interpretability, and its public commitments to specific safety constraints on the use of its products. The second, more publicly contentious component is the firm’s 2025–2026 dispute with the United States Department of Defense, which produced one of the more significant public confrontations between a frontier AI laboratory and a federal client in the history of the sector.

◆ ◆ ◆

**The Anthropic–Department of Defense dispute**

In July 2025, the Department of Defense awarded contracts to four frontier AI companies — Anthropic, Google, OpenAI, and xAI — at a ceiling of up to $200 million each, to develop and deploy frontier AI capabilities in support of national-security applications. The contracts, on Anthropic’s side, were structured around the deployment of Claude for what the Department later described as “intelligence analysis, modeling and simulation, operational planning, cyber operations, and more.” Anthropic’s standard usage policy, in place before and after the contract award, prohibited the use of Claude for the development or design of weapons, for incitement to violence, for mass surveillance of civilian populations, and for the operation of fully autonomous lethal weapons systems.

The contract’s execution produced friction in January 2026 when reports surfaced — corroborated in subsequent congressional analysis and in the Congressional Research Service’s April 2026 issue brief Pentagon-Anthropic Dispute over Autonomous Weapon Systems — that Claude had been used in the January 2026 operation that captured Venezuelan President Nicolás Maduro. Anthropic objected to elements of that operational use as inconsistent with its usage policy. The dispute escalated through February. On February 24, 2026, Secretary of Defense Pete Hegseth issued a deadline to Anthropic’s chief executive Dario Amodei: relent by February 27 and permit unrestricted use of Claude “for all lawful purposes,” or face contractual and procurement consequences. Anthropic released a public statement on February 26 indicating it would not modify its usage policy. On February 27, President Donald Trump directed federal agencies to immediately cease use of Anthropic technology, and Secretary Hegseth designated Anthropic a “supply chain risk” under defense procurement regulations, a designation historically applied only to foreign adversaries such as the Chinese telecommunications firm Huawei.

On March 9, 2026, Anthropic filed two civil complaints in federal court. The first, in the Northern District of California, challenged the supply-chain-risk designation as exceeding statutory authority. The second, in a related action, alleged that the designation violated the First Amendment as retaliation for Anthropic’s protected refusal to relinquish its usage-policy restrictions on the use of its product. On March 26, 2026, United States District Judge Rita Lin in the Northern District of California granted Anthropic’s motion for a preliminary injunction, citing what the court characterized as “First Amendment retaliation” in the executive’s posture toward the firm. On April 8, 2026, a federal appeals court denied Anthropic’s request for a stay of the supply-chain-risk designation in the parallel action. The litigation is, as of this writing, in active proceedings.

Amodei’s public position throughout the dispute, articulated in interviews and in statements to Anthropic employees, has been that the firm’s usage-policy restrictions are central to its institutional identity and that the dispute is, in his own characterization, a matter of “safety theater” and “straight up lies” — the latter terms applied to OpenAI’s parallel willingness to enter a less restrictive Department of Defense contract. Department of Defense officials, including Pentagon advisor Emil Michael, have publicly criticized Amodei. The public record of the dispute includes substantial mutual recrimination on both sides. The narrower documentary fact is that Anthropic’s position has been that some uses of frontier AI — specifically mass surveillance of civilian populations and fully autonomous lethal-weapons deployment — are categorically inconsistent with the firm’s product policy, that the Department of Defense has demanded the relaxation of that policy, and that the firm has refused. The federal courts are now adjudicating the legality of the executive’s response.

The structural humanism reading of the Anthropic–DoD dispute is genuinely complex, and I want to handle it carefully because the temptation to read it through the lens of which side’s position I find more sympathetic is real. The narrow defensible reading is this. The firm has taken a public position constraining the use of its product in ways that the federal contracting client has objected to. The executive branch has responded by designating the firm a supply-chain risk, an action federal courts have at least preliminarily characterized as constitutionally problematic. The question of whether a private firm should have the authority to constrain how the federal government uses its products is itself a contested question of administrative law and constitutional theory. The Electronic Frontier Foundation’s March 2026 analysis of the dispute, cited by the federal court, made the broader point that the dispute reveals the structural problem of having privacy protections “depend on the decisions of a few powerful people” — the AI laboratory executives — rather than on durable statutory and constitutional protections that apply regardless of which firm holds the relevant contract. The structural reform the dispute most strongly supports is the codification, by Congress, of substantive limits on federal-government uses of frontier AI technology that do not depend on the policy choices of individual contractors. Anthropic’s position in the dispute aligns with a particular set of those substantive limits; the broader public-policy question is whether limits of that kind should be in statute rather than in individual-firm usage policies.

◆ ◆ ◆

**COUNTERARGUMENT**

The chapter’s treatment of Anthropic is structurally favorable in ways the Karp and Altman sections are not. The Anthropic section emphasizes the firm’s safety commitments, its principled stand against the Department of Defense, and the federal-court preliminary finding of First Amendment retaliation. The reader could reasonably suspect that the disclosure of Claude’s use in drafting the chapter has not fully neutralized the conflict of interest the disclosure identifies.

**WHY THIS DOES NOT SAVE THE FRAMING**

The counterargument has force, and I want to engage it directly. The chapter’s Karp and Altman sections each present significant unflattering documentary material, and the Anthropic section’s framing of the DoD dispute is largely a description of the documented public record — the contract award, the dispute escalation, the executive actions, the federal-court rulings. The documentary record favors no particular outcome of the substantive analysis. What I can do, having now identified the structural risk, is name explicitly the elements of the Anthropic position that warrant continued scrutiny regardless of the DoD dispute’s legal outcome. The firm has taken substantial commercial investment from major technology and financial-sector investors whose long-term interests in the firm’s posture are unlikely to be perfectly aligned with the firm’s stated safety mission. The firm’s usage policies are determined by the firm’s own leadership, not by external regulatory authority, and the durability of those policies depends on the continued commitment of that leadership rather than on statutory protection. The firm’s frontier AI development continues to advance capabilities whose downstream risks the firm’s own published safety research has identified as substantial. The narrower defensible reading is therefore that the Anthropic-DoD dispute is a case in which the firm’s usage policies happened to align with broader public-interest concerns about specific federal applications of AI, but that the broader question — whether the public interest in AI governance should rest on individual-firm policy choices — is the structural reform question the chapter has identified. Anthropic’s position in the dispute does not make the firm exempt from the broader analysis. It is one data point within it. The disclosure at the front of the chapter, and the explicit naming of this counterargument now, are the working components of how the conflict of interest has been managed.

◆ ◆ ◆

**The institutional pattern across the three firms**

The specific cases differ. The institutional pattern is consistent. In each of Palantir, OpenAI, and Anthropic, a small set of individual decision-makers has accumulated, by virtue of position, control over a technology of consequential public significance. The decision-makers operate within corporate governance structures that include boards of directors and senior management but that, on the documentary record, have been substantially shaped by the founders’ continued influence. The corporate-governance theory under which boards of directors provide meaningful checks on executive decision-making is, in the frontier-AI sector specifically, weaker in practice than the formal architecture would suggest. The November 2023 OpenAI board crisis demonstrated this in real time. The 2024 Palantir corporate-restructuring decisions, the post-IPO concentration of voting power, and the Karp-Thiel alignment on strategic direction demonstrate it in slower form. The Anthropic founder-led governance structure, the firm’s public-benefit-corporation designation under Delaware law, and the firm’s Long-Term Benefit Trust governance arrangement represent an attempt to address the structural problem, but the effectiveness of those arrangements remains contingent on the continued commitment of the founding leadership.

The public has not yet developed the legal and political architecture necessary to govern the consequential decisions these firms’ leaders make on its behalf. The Federal Trade Commission’s authority over AI-sector competition, the Federal Communications Commission’s authority over information-platform regulation, the Securities and Exchange Commission’s authority over public-company governance, and the Federal Privacy Act’s coverage of personal-data aggregation are each, in their current form, insufficient to address the structural questions the technology now raises. The European Union’s AI Act, which took effect in stages beginning in 2024, represents one model. The Chinese regulatory framework, with its substantive limits on generative AI deployment, represents another. The United States has not yet enacted comparable legislation. The vacuum is the structural problem. The vacuum is what the individual-firm policy choices documented in this chapter currently operate to fill.

◆ ◆ ◆

**What it would take to disengineer it**

The reform agenda for the contemporary American technology sector has three layers.

First, federal privacy legislation. The United States is the only major democracy without a comprehensive federal data-protection statute. The American Data Privacy and Protection Act, introduced in multiple Congresses, would provide the basic legal architecture for individual rights over personal data, regulatory authority over mass data aggregation, and meaningful enforcement mechanisms. The proposed statute has had bipartisan support but has not been enacted, primarily because of disagreements over preemption of state-level privacy laws (notably the California Consumer Privacy Act) and the scope of private rights of action. Resolution of those disagreements should be a priority of the next congressional session.

Second, AI governance legislation. The European Union’s AI Act’s tiered-risk framework, which distinguishes between low-risk applications subject to transparency requirements and high-risk applications subject to substantive limits on deployment, provides one institutional model. The Biden administration’s 2023 executive order on AI — substantially rescinded by the second Trump administration in 2025 — represented an attempt to address some of the same issues at the executive level. The durable solution is legislative. A comprehensive AI Governance Act, addressing the specific applications the chapter’s analysis of Palantir, OpenAI, and Anthropic has identified as most concerning — mass surveillance, fully autonomous weapons, predictive law enforcement, deepfake political communication — is the institutional architecture the public most urgently needs.

Third, antitrust enforcement applied to the frontier-AI sector specifically. The Federal Trade Commission’s into the AI investments of major incumbents — Microsoft’s relationship with OpenAI, Amazon’s and Google’s investments in Anthropic, the broader pattern of incumbent-startup capital flows — is the appropriate institutional starting point. The Bork-doctrine consumer-welfare standard, as Chapter 4 documented, is inadequate to the structural questions the frontier-AI sector raises. The reform agenda of Chapter 4 — the structural-power antitrust standard, the address of common ownership, the strengthening of FTC and DOJ enforcement — applies directly to the AI sector. The AI sector should not be a separate reform agenda. It should be the application of the structural-antitrust reform agenda to the specific sector most consolidating power in the present moment.

◆ ◆ ◆

**Pattern**

Three men. Three firms. Hundreds of billions of dollars in combined market value. Substantial integration with federal intelligence, defense, law-enforcement, and civilian-agency operations. Active civil litigation. Active federal-court constitutional disputes. Substantial public reporting on disputed elements of each principal’s personal and institutional conduct. And essentially no comprehensive federal legal architecture to govern the consequential decisions these firms’ leaders make on the public’s behalf. That is the technology-sector situation, in 2026, at the level of empirical fact.

The structural humanism reading is the same as the reading of every earlier chapter of this book. The mechanisms exist for the public to engage these institutions through the constitutional toolkit Chapter 11 documented. The political will to enact the statutory reforms that would alter the structural conditions has not yet been mobilized at the necessary scale. The barrier is not technical. The barrier is the cultivation of the citizen capacity Chapter 11 examined. The technology-sector situation does not require new constitutional theories. It requires the application of existing constitutional and regulatory authority to a new institutional setting, by a citizenry sufficiently organized to insist on the application.

> *The public has not yet developed the legal and political architecture necessary to govern the consequential decisions these firms’ leaders make on its behalf. The vacuum is what their individual policy choices currently fill.*

Part Three has examined the domestic systems that drain the people living under them — healthcare extraction, militarized public finance, the civic toolkit citizens still hold, the contemporary men consolidating technological power. The diagnostic work of the book is now substantially complete. Part Four turns to the reconstruction. The civilization we could be choosing. What a humane reordering would look like in practice. The evidence that comparable arrangements already function in other countries and in other American cities. The concrete civic mechanisms ordinary citizens can use to move us toward them. The final chapter and the conclusion that follows it close the argument the book began with: that the present arrangement is not the limit of what is possible, that the alternative is documented in the comparative international record and in the cumulative American policy literature, and that the work of construction is the work that diagnosis was always for.

**Part Four**

*The Civilization We Could Be*

One chapter on the alternative. The arrangements that already function in other wealthy democracies and in other American cities. The constructive answer the diagnostic chapters have been making space for. The case that the present arrangement is not the limit of what is possible, and the documented evidence that the better arrangements have been built before and can be built again.

**Chapter 13**

*The Civilization We Could Be Choosing*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

Twelve chapters of diagnosis are the longest setup any constructive argument can fairly impose on a reader. The setup ends here. This chapter is the constructive answer the book has been building toward.

The argument is not utopian. I am not proposing the abolition of property, the dissolution of nations, the perfection of human nature, or the arrival of a political order without conflict, corruption, or sin. Every one of those proposals has been tried, in some form, by people more eloquent than I am, and every one of those proposals has produced consequences whose costs were paid by the people they were supposed to liberate. The argument of this chapter is narrower and more defensible. A humane reordering of American institutions does not require the invention of any new political philosophy. It requires the application of arrangements that are already operating, successfully, in comparable democracies and in some American jurisdictions, to the institutional settings this book has documented. The evidence that the alternative works is empirical. The evidence is in the comparative international record, in the state-level American experiments, in the historical record of past American reforms, and in the cumulative cost-benefit analyses the academic policy literature has produced.

◆ ◆ ◆

**Hard frame, thesis, evidence**

The question this chapter takes seriously: what would a humane reordering of American institutions actually look like in practice, what is the empirical evidence that comparable arrangements function elsewhere, and what is the realistic political pathway from the present arrangement to the alternative?

Thesis, in one sentence: the institutional reforms required to produce a substantially more humane American political economy are documented in the comparative-international and American-historical record, are operating successfully in arrangements that already exist, and do not require new political philosophies but only the political coalition large enough to enact and defend the existing reform agenda over the institutional opposition that currently prevents it.

◆ ◆ ◆

**What other wealthy democracies already do**

Every wealthy democracy other than the United States has solved the principal first-order institutional problems the previous chapters have documented. The arrangements vary. The outcomes converge. The convergence is the empirical evidence.

On healthcare, every peer democracy has a financing architecture in which the underwriting unit is the entire risk pool rather than the individual patient, in which the negotiating unit is the entire national health authority rather than the individual hospital or insurer, and in which the bankruptcy mechanism is therefore unnecessary because medical bills do not accumulate to bankruptcy-triggering levels. The specific designs differ — single-payer in Canada, the United Kingdom, and Australia; multi-payer with regulated universal coverage in Germany, the Netherlands, Switzerland, and Japan; mixed public-private with public-option dominance in France — but the universal feature is that the financing architecture is designed to deliver care rather than to extract revenue. The Commonwealth Fund’s comparative data, cited in Chapter 9, document the outcomes. The OECD Health Statistics 2024 release documents the costs. Every comparison country pays less per capita and delivers better outcomes on the standard measures.

On higher education, every peer democracy has a financing architecture in which the principal cost is borne by general taxation rather than by individual student debt. The specific arrangements vary — tuition-free at point of use in Germany, Norway, Denmark, France, and Sweden; means-tested fees in Australia, the United Kingdom, and the Netherlands — but the universal feature is that the obligation of an eighteen-year-old to incur thirty years of non-dischargeable debt as the condition of entering the professional labor market does not exist outside the United States. The OECD Education at a Glance annual reports document the comparative tuition levels and student-debt burdens. The American outlier status is not accidental. It is the product of the specific public-financing retreat documented in Chapter 2.

On paid family leave, paid sick leave, and basic worker protections, every peer democracy has statutory minimums substantially above the American baseline. The International Labour Organization’s comparative data document the patterns. Paid parental leave at the time of childbirth is statutory in essentially every peer democracy, with durations ranging from twelve weeks (the OECD minimum) to fifty-two weeks (Sweden). The United States has no statutory paid parental leave. Paid sick leave is statutory in essentially every peer democracy. The United States has no statutory paid sick leave at the federal level. Annual paid vacation is statutory in essentially every peer democracy, with minimums ranging from twenty days (most of continental Europe) to thirty days (some Scandinavian countries). The United States has no statutory minimum paid vacation. These are not preferences. They are the empirical baseline of comparable democracies. The American absence of them is the outlier.

On gun deaths, on incarceration rates, on infant mortality, on maternal mortality, on life expectancy, on educational outcomes adjusted for socioeconomic background, on intergenerational mobility, on subjective measures of life satisfaction — the comparative international data point in the same direction. The United States, on the measures the political philosophy of human dignity would treat as central, performs worse than peer democracies that spend less to achieve their results. The comparison countries do not have superior natural endowments. They have different institutional arrangements, produced by different political histories, sustained by different political coalitions. The arrangements are not magic. They are choices. Other societies have made them. The United States has, on the most consequential of those choices, made the opposite ones.

**Table 13-1. Selected comparative-democracy outcomes, latest available data**

<table>
<colgroup>
<col style="width: 32%" />
<col style="width: 17%" />
<col style="width: 19%" />
<col style="width: 19%" />
<col style="width: 12%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>Measure</strong></td>
<td><strong>United States</strong></td>
<td><strong>Germany</strong></td>
<td><strong>Canada</strong></td>
<td><strong>Japan</strong></td>
</tr>
<tr class="even">
<td>Life expectancy at birth</td>
<td>78.4 yrs</td>
<td>81.4 yrs</td>
<td>82.6 yrs</td>
<td>84.3 yrs</td>
</tr>
<tr class="odd">
<td>Infant mortality (per 1,000)</td>
<td>5.4</td>
<td>3.3</td>
<td>4.4</td>
<td>1.9</td>
</tr>
<tr class="even">
<td>Maternal mortality (per 100,000)</td>
<td>32.9</td>
<td>3.5</td>
<td>8.4</td>
<td>4.4</td>
</tr>
<tr class="odd">
<td>Incarceration rate (per 100,000)</td>
<td>664</td>
<td>70</td>
<td>85</td>
<td>33</td>
</tr>
<tr class="even">
<td>Firearm deaths (per 100,000)</td>
<td>13.7</td>
<td>1.0</td>
<td>2.1</td>
<td>0.2</td>
</tr>
<tr class="odd">
<td>Statutory paid parental leave</td>
<td>0 weeks</td>
<td>58 wks</td>
<td>55 wks</td>
<td>52 wks</td>
</tr>
<tr class="even">
<td>Statutory paid vacation</td>
<td>0 days</td>
<td>20 days</td>
<td>10–20 days</td>
<td>10–20 days</td>
</tr>
</tbody>
</table>

*Source: OECD Health Statistics 2024; World Prison Brief, Institute for Crime & Justice Policy Research; Small Arms Survey 2024; ILO and national labor statistics agencies. Figures rounded to most recent reported year for each measure.*

◆ ◆ ◆

**Five democracies in detail**

The comparative summary is useful at the macroeconomic level. The deeper instructive cases are at the level of specific institutional designs that produce specific outcomes. Five examples illustrate the range.

**Germany: codetermination and the social-market economy**

The German Mitbestimmung system — codetermination — requires that companies above specified employment thresholds reserve up to half of supervisory-board seats for worker representatives elected by the company’s workforce. The system was institutionalized in the post-war period under the Codetermination Act of 1976 and the earlier Montan-Mitbestimmung law of 1951 covering the coal and steel industries. The structural effect is that the corporate governance of major German firms includes, by statute, the voices of the workforce in strategic decisions about investment, restructuring, plant closures, and executive compensation. The institutional consequence is a different equilibrium in the relationship between firms and the communities in which they operate.

The empirical record on German codetermination is mixed in the academic literature but consistent in its broader pattern. The economist Simon Jäger and colleagues at MIT and the University of California, Berkeley, published in 2021 in the American Economic Review the most rigorous recent evaluation, which found that codetermination has modest effects on firm performance, small and statistically insignificant effects on wage levels, and substantial effects on the distribution of corporate value between shareholders and workers. The system has not produced the economic catastrophe that its American critics have warned it would produce since its institutionalization seven decades ago; the German economy remains one of the strongest in the OECD, with unemployment tracking at or below American rates across most of the post-2008 period, with substantially lower income inequality, and with sustained advanced manufacturing employment that the United States has substantially lost over the same period. The point is not that German codetermination would transfer directly to the American context. The point is that a major comparable democracy has, for seventy years, institutionalized worker voice in corporate governance and has produced economic outcomes that no serious economic comparison can characterize as failure.

**Denmark: flexicurity and the active labor market**

The Danish flexicurity model, developed across the 1990s and consolidated by the early 2000s, combines three institutional features that the American policy debate typically treats as incompatible. The first is flexible labor markets: Danish employers can hire and fire with substantially less procedural constraint than employers in most continental European systems. The second is generous unemployment insurance: Danish unemployment benefits, traditionally at approximately 90 percent of prior wages for lower-income workers and lower replacement rates for higher-income workers, are among the most generous in the OECD. The third is active labor-market policy: extensive publicly funded retraining, education subsidies, and job-placement services that move displaced workers into new employment relatively rapidly.

The empirical record on Danish flexicurity is documented across the OECD’s annual employment and labor-market reports, the European Commission’s annual Employment and Social Developments in Europe reports, and a substantial academic literature including the work of Per Kongshøj Madsen at Aalborg University, who is among the principal scholars of the model. The Danish unemployment rate has tracked or undercut the American rate across most of the post-2000 period. Danish labor-market mobility — the rate at which workers move between firms and sectors — is among the highest in the OECD. Danish public spending on active labor-market policy is approximately 2 percent of GDP, compared to less than 0.1 percent in the United States. The Danish model is not transferable in detail, but its institutional logic — flexibility in the labor market combined with strong social insurance and active state investment in worker transitions — is the institutional logic that addresses the dynamic the American economy is currently failing to address. American workers displaced by trade, automation, or industrial restructuring have, on the comparative evidence, substantially fewer institutional resources to transition to new employment than Danish workers in equivalent positions.

**Mondragon: the worker-cooperative federation**

The Mondragon Corporation, headquartered in the Basque region of Spain, is the world’s largest federation of worker-owned cooperatives. Founded in 1956 by Father José María Arizmendiarrieta, the corporation has grown to encompass , employing roughly 70,000 people across manufacturing, finance, retail, and education. The cooperatives operate under one-member-one-vote governance regardless of capital contribution. Executive compensation is constrained to a maximum ratio of approximately 6-to-1 with the lowest-paid workers in the same cooperative, compared to American CEO-to-worker pay ratios that routinely exceed 300-to-1 at major public companies. Profits are distributed substantially to worker-owners rather than to outside shareholders.

The empirical record on Mondragon is substantial and is summarized in the work of the economist Sharryn Kasmir at Hofstra University, the comparative cooperative-economics literature, and the long-running journalism in The Nation, Yes! Magazine, and the academic Journal of Co-operative Studies. The federation has survived multiple economic cycles, including the Spanish financial crisis of 2008–2012, with substantially lower unemployment in its host region than the surrounding Spanish economy experienced. The Cleveland Foundation’s Evergreen Cooperatives initiative, launched in 2009 in partnership with the Cleveland Clinic, Case Western Reserve University, and University Hospitals, explicitly used the Mondragon model as its institutional template. The Evergreen initiative has produced worker-owned laundry, greenhouse, and energy-services cooperatives serving anchor-institution purchasing in low-income Cleveland neighborhoods. The American sub-national experiment is, in its early-stage form, evidence that the Mondragon institutional logic can be partially transferred to the American context.

**Costa Rica: abolition of the army and what followed**

Costa Rica abolished its standing army on December 1, 1948, under President José Figueres Ferrer, in a constitutional reform that codified the abolition in the 1949 constitution. The decision was made in the aftermath of a brief but bloody civil war and was justified, in Figueres’s public framing, as a decisive break with the militarized political culture that had produced the war. The funds that had previously gone to military expenditure were reallocated to education, healthcare, and infrastructure. The decision was, in its institutional context, radical.

Seven decades later, the outcomes are documented across the comparative-development literature. Costa Rica . Its literacy rate exceeds 97 percent. Its healthcare system, structured around the Caja Costarricense de Seguro Social, provides universal coverage with outcomes that compare favorably to American outcomes despite per-capita spending at a small fraction of American levels. The country has not been invaded. The Inter-American Court of Human Rights and the United Nations University for Peace are both headquartered in Costa Rica, reflecting the country’s diplomatic reputation as a model of peaceful self-governance. The Costa Rican case is a single small country and is not directly transferable to the American context. What the case demonstrates is that a country can, deliberately, choose to redirect substantial resources from militarized public spending to human-development public spending, and that the long-term outcomes can be substantially positive on the measures the structural humanism framework would treat as central. The choice was a political choice. The political coalition for it was assembled by a specific president at a specific moment. The institutional infrastructure that has sustained the choice for seven decades is what comparable democracies, including the United States in a substantially reformed configuration, could in principle build.

**Singapore: public housing as social infrastructure**

The Singaporean Housing and Development Board, established in 1960, is the institutional architecture through which approximately 80 percent of Singapore’s population lives in publicly built housing that residents typically own through long-term leases. The HDB system has produced, on the comparative housing-policy evidence, the most successful sustained mass public-housing program in any high-income economy. Singaporean homeownership rates exceed 90 percent. The system is financed through a combination of mandatory savings under the Central Provident Fund and government subsidies, structured to make ownership of HDB units accessible to essentially the entire Singaporean workforce.

The Singaporean political system is, separately, an authoritarian-leaning electoral autocracy whose broader governance arrangements the structural humanism framework would substantially reject. I cite the case not as an endorsement of Singaporean political governance but as a demonstration that mass public housing of high quality is a soluble policy problem when a state chooses to solve it. The American policy debate about housing affordability has been substantially shaped by the assumption that public housing is, on the basis of mid-twentieth-century American failures, an inherently flawed institutional form. The Singaporean record, the Viennese social-housing record (over 60 percent of Vienna’s population lives in social housing managed by the municipal government, with documented outcomes the comparative housing-policy literature consistently rates as among the best in Europe), and the broader continental European public-housing record together establish that public housing can be successfully built and operated at scale by competent institutions with sustained political support. The American failure is not technical. The American failure is institutional, and the institutional design choices that produced the failure are reversible.

◆ ◆ ◆

**COUNTERARGUMENT**

Comparative-international evidence does not transfer cleanly to the American context because the United States is structurally different from the comparison countries — larger, more diverse, more federalist, more culturally heterogeneous, more economically dynamic. The reforms that work in Denmark or the Netherlands cannot simply be imported. The reform agenda derived from comparative evidence ignores the specific American institutional and cultural conditions that have produced the present arrangement.

**WHY THIS DOES NOT SAVE THE FRAMING**

Some elements of the counterargument are correct. American scale, diversity, and federalism are real institutional features that affect the specific implementation of any reform agenda. What the counterargument exaggerates is the implication that those features make the underlying policy goals unattainable. Canada is geographically larger and federally structured, and operates a universal health system. Germany is industrially complex and federally structured, and operates a multi-payer universal-coverage system. The United Kingdom, France, and Australia are each large, heterogeneous, and culturally complex — and each operates the policy arrangements the chapter has described. The American comparative-evidence problem is not the absence of comparable cases. It is the absence of political will to enact the implementations of the policy goals that the comparable cases demonstrate are achievable. The deeper structural humanism reading is that the cultural-exceptionalism argument has been used, repeatedly across American political history, to defend the status quo against reforms that subsequently turned out to be both achievable and beneficial. The same argument was made against women’s suffrage, against civil-rights legislation, against Medicare, against environmental protection, against marriage equality. The cultural-exceptionalism argument has a poor empirical track record as a predictor of what is and is not politically possible in the United States.

◆ ◆ ◆

**What American jurisdictions already do**

The comparative case is not only international. Within the United States, the federalist architecture has produced specific state and local jurisdictions in which substantial elements of the humane-reordering agenda have been enacted and have produced measurable outcomes that the rest of the country could learn from.

**Massachusetts: near-universal coverage as proof of concept**

Massachusetts adopted near-universal healthcare coverage under the 2006 reform signed by then-Governor Mitt Romney, which became the structural template for the federal Affordable Care Act of 2010. The Massachusetts reform reduced the state’s uninsured rate from approximately 11 percent to under 3 percent within several years and produced measurable improvements in self-reported health status and financial security among previously uninsured residents. The empirical literature on the Massachusetts reform is extensive; the work of Jonathan Gruber at MIT, Amy Finkelstein and colleagues at MIT, and Sherry Glied at New York University documents the outcomes. The Massachusetts reform demonstrated, in a major American state with characteristics comparable to multiple peer democracies, that universal coverage was achievable within the existing American insurance and provider architecture. The federal Affordable Care Act extended the basic structural logic nationally, with the substantial limitations the political compromise required.

**North Dakota: the public bank in operation since 1919**

The Bank of North Dakota, established by the state legislature in 1919, is the only state-owned bank in the United States. Its founding mission was to serve as the depository for state revenues and to support agricultural credit in a state then dominated by out-of-state commercial banks whose lending practices the state’s farmers viewed as predatory. The bank operates as the depository for essentially all state-government funds, partners with private community banks rather than competing directly with them, and provides lending capacity that has been measurably countercyclical to the broader commercial-banking sector. During the 2008 financial crisis, North Dakota community banks accessed Bank of North Dakota participation in agricultural and small-business loans at a time when commercial banks elsewhere were withdrawing credit; the resulting macroeconomic effect contributed to North Dakota’s relatively mild experience of the crisis.

The Bank of North Dakota model has been the subject of multiple state-level campaigns elsewhere, with active proposals in California, Massachusetts, New Mexico, New Jersey, and several other states. The 2019 California Public Banking Act, signed by Governor Gavin Newsom, authorized California municipalities to establish public banks; the first such bank, the Public Bank East Bay, is in the establishment phase. The structural humanism reading of public banking is that it constitutes a partial institutional answer to the banking-consolidation dynamic documented in Chapter 4 — a publicly accountable banking capacity that can operate countercyclically, support specific public-interest lending, and reduce community-level dependence on the largest commercial banks whose institutional incentives are not aligned with local credit needs. The Bank of North Dakota is not a comprehensive solution. It is a working demonstration that the alternative exists and can be sustained across more than a century of operation.

**Cleveland: anchor-institution purchasing and worker cooperatives**

The Evergreen Cooperatives initiative in Cleveland, launched in 2009 through a partnership of the Cleveland Foundation, the Cleveland Clinic, Case Western Reserve University, University Hospitals, and the city government, is the most developed American application of the Mondragon-derived anchor-institution-and-cooperative model. The initiative’s logic is that the major institutions of a city — hospitals, universities, government entities — collectively purchase enormous quantities of goods and services from outside vendors, and that redirecting a portion of that purchasing to locally based worker-owned cooperatives can produce sustained employment and wealth-building in low-income neighborhoods at scales that traditional economic-development programs do not match.

The initiative has produced three operating worker cooperatives: Evergreen Cooperative Laundry, providing institutional-laundry services to area hospitals; Green City Growers, operating an urban greenhouse producing fresh produce for institutional purchasers; and Evergreen Energy Solutions, providing energy-efficiency services. The cooperatives are structured to allow worker-owners to build equity over time through retained earnings, addressing the wealth-inequality problem that wage-only employment does not address. The Cleveland model has been studied as an institutional template by multiple other cities, and parallel initiatives have been launched in Rochester, New York; Richmond, Virginia; Preston in the United Kingdom (the “Preston model”); and several other municipalities. The empirical record is early-stage but consistent with the broader Mondragon comparative evidence. The American context is different in important respects, but the institutional logic can be transferred in modified form.

**Participatory budgeting in New York and Chicago**

Participatory budgeting, a process by which residents of a defined jurisdiction directly vote on the allocation of a designated portion of the public capital budget, was developed in Porto Alegre, Brazil, in 1989, and has been adopted by multiple American cities. The largest American application has been in New York City, where individual city council districts have, since 2011, allocated portions of their discretionary capital budgets through structured community-deliberation-and-voting processes. The Chicago participatory-budgeting program, in operation since 2009 in Ward 49 and subsequently expanded, has followed a similar institutional design. The Participatory Budgeting Project, a national nonprofit, has supported parallel initiatives in dozens of additional American jurisdictions.

The empirical record on participatory budgeting is documented in the academic work of Hollie Russon Gilman at Columbia University, Sonia Ospina at NYU, and the broader comparative-democracy literature. The outcomes include: measurably increased civic participation in the affected districts, particularly among demographic groups historically less engaged in municipal politics; substantive shifts in budget allocations toward public-infrastructure investments that the community-deliberation process identifies and that traditional budgeting processes have systematically underprovided; and modest but measurable increases in the political legitimacy of local government as measured by survey instruments. The participatory-budgeting mechanism is not a comprehensive solution to the Gilens-Page dynamic. It is a working demonstration that direct community participation in budget allocation, when institutionalized at modest scale, can produce different allocation outcomes than purely representative budgeting produces, and that the institutional architecture for participatory budgeting can be built within existing American municipal governance.

**California: sub-national drug-pricing reform**

California enacted, between 2020 and 2024, a series of state-level prescription-drug pricing reforms that have produced measurable price reductions on specific drug categories within the state. The California Drug Discount Program, the state-level price-transparency requirements, the state’s production of its own generic insulin under the CalRx program announced by Governor Gavin Newsom in March 2023, and the negotiation authority that the Department of Health Care Services exercises through Medi-Cal have all functioned as evidence that drug-price negotiation can operate at a sub-national level even where federal negotiation authority remains constrained. The CalRx insulin specifically is intended to be produced at a manufacturing cost of approximately $30 per vial and sold to consumers at approximately $30 per vial, compared to the $300 per vial price that prevailed at the peak of the insulin pricing crisis documented in Chapter 9.

Multiple states have enacted, through ballot initiative or legislative action, the expanded Medicaid eligibility that the Affordable Care Act made optional, the family-leave statutes that the federal government has not enacted, the minimum-wage levels above the federal $7.25 baseline (now $7.25 since 2009, the longest stretch without an increase in the statute’s history), the marriage-equality protections that preceded the federal recognition, the marijuana legalizations that the federal government has not enacted, and a range of other policy reforms that the federal political deadlock has prevented. The state-level laboratory has produced the demonstration cases. The federal political diffusion has, on most of these issues, eventually followed. The federalist architecture is, on balance, an asset for the reform agenda, not a barrier to it.

◆ ◆ ◆

**The political pathway**

The serious question is not whether the reforms are achievable in principle. The comparative evidence settles that. The serious question is what the realistic political pathway from the present arrangement to the alternative actually looks like, and what citizens acting in the present moment can do to advance it.

The pathway, on the empirical record of American reform history, is consistent in shape across the major reform episodes. A long preparatory period of intellectual development and documentary record-building precedes the political moment. The intellectual development is the work of policy scholars, journalists, organizers, and advocates building the case for reform across years and decades. The documentary record is the empirical evidence that the alternative arrangement works, drawn from comparative international evidence and from sub-national experimentation. The political moment, when it arrives, is typically produced by some combination of acute institutional crisis (the Great Depression for the New Deal, the civil-rights movement’s sustained pressure plus the moral catalyst of specific events for the 1964 and 1965 acts, the environmental movement’s sustained pressure plus events like the 1969 Cuyahoga River fire for the early-1970s environmental statutes) and political-coalition assembly that takes the intellectual and documentary work and converts it into legislative achievement.

The present moment is, by the indicators historians and political scientists use to identify reform moments, approaching that condition on multiple issue areas. The healthcare system’s sustained dysfunction has produced majority public support for substantial reform across multiple decades of polling. The political-economy concentration documented in Chapter 4 has produced bipartisan support for stronger antitrust enforcement, including across the unusual ideological coalition that produced the 2023 FTC and DOJ merger guidelines. The technology-sector concentration has produced bipartisan concern that has not yet translated into legislative action but is at the stage of intellectual and documentary development that historically precedes such action. The civic-toolkit deployment that Chapter 11 documented is what bridges the gap between the present preparatory stage and the future reform moment. The work is the bridge-building.

◆ ◆ ◆

**A particular vision**

Let me describe, with as much concrete specificity as the constraints of a single chapter permit, what a substantially reformed American political economy might look like in twenty years if the reform agenda this book has described were enacted across the sectors it has examined.

On healthcare, the system would be substantially reorganized around a unified national risk pool and a unified national negotiating authority, with the specific design — single-payer, multi-payer with regulated coverage, public-option hybrid — determined by the political compromise required to enact the reform. The result would be per-capita healthcare spending closer to the OECD median, with measurable improvements in coverage, in financial security, and in the principal health outcomes the comparative international data document. Medical debt as a category of household financial obligation would substantially disappear. Pharmaceutical-research investment would continue, at levels modestly below the present and consistent with the levels that produce sustained pharmaceutical innovation in the comparable democracies. The political battle to enact and defend the reform would be sustained and difficult; the post-enactment maintenance against the institutional opposition that the reform displaces would be the work of multiple subsequent political generations.

On higher education and student debt, the system would be substantially reorganized around public financing of public higher education at levels closer to the postwar American baseline and to the contemporary peer-democracy norm. Existing student debt would be substantially reduced through some combination of forgiveness mechanisms and restoration of bankruptcy dischargeability. The age of household formation, first home purchase, and family formation would, on the demographic projections, return toward levels more consistent with the demographic patterns of comparable democracies. The political battle to enact the reform would be sustained and difficult. The post-enactment economic effects, on the relevant comparative evidence, would be substantially positive in the medium term.

On the political economy of concentration, the antitrust reform agenda would supplement or replace the Bork-doctrine consumer-welfare standard with a structural-power standard. The Federal Trade Commission and the Department of Justice Antitrust Division would be funded and staffed at levels permitting meaningful enforcement against the major consolidated sectors. The common-ownership dynamic that the Azár-Schmalz-Tecu literature documented would be addressed through some combination of pass-through voting requirements for the largest institutional investors and meaningful enforcement under existing antitrust authority. The Gramm-Leach-Bliley structural integration of commercial and investment banking would be at least partially reversed. The pharmaceutical, telecommunications, agricultural-input, and platform-technology sectors would be subject to structural rebalancing through enforcement actions, divestiture orders, and new legislative authority. The macroeconomic signature of the reformed political economy — the share of national income going to labor versus capital, the rate of new business formation, the geographic distribution of economic opportunity — would, on the policy literature’s projections, move substantially in directions the public-opinion data indicate Americans want.

On foreign policy and the defense budget, the reform agenda would include the restoration of constitutional war-making procedure through a narrower replacement of the 2001 AUMF, the rationalization of defense procurement against measurable national-security outcomes, the closure of the audit-failure gap that prevents Congress from doing meaningful oversight, the reform of the FARA enforcement architecture that allows substantial foreign-influence operations to operate outside the disclosure regime, and the institutional reforms of the intelligence-community oversight structure that the Church Committee originally recommended. The macroeconomic and human-cost effects of the reform would be substantial. The political battle to enact the reform would face the most concentrated institutional opposition of any element of the agenda.

On the information environment, the reform agenda would include the restoration of meaningful media-ownership limits, the partial reform of Section 230 to distinguish neutral hosting from algorithmic promotion, the codification of algorithmic transparency requirements for the largest platforms, the federal-statutory protection for local journalism through tax-credit and matching-grant mechanisms, and the warrant requirement on Section 702 queries of U.S. persons. The combined effect of the reform would be an information environment more conducive to the kind of sustained civic deliberation the constitutional design requires.

On the broader political-economy architecture, the reform agenda would include the restoration of meaningful campaign-finance limits through the constitutional-amendment route that the post-Citizens United doctrine has made necessary, the reform of the revolving-door governance between regulatory agencies and the regulated industries, the codification of inspector-general independence at the executive level, the federal-statutory protection of whistleblower rights, and the broader application of the Foreign Agents Registration Act to all comparable foreign-state-tied lobbying. The combined effect would be a federal political process measurably less captured by concentrated economic interest than the present arrangement, and measurably more responsive to the preferences the public-opinion data indicate Americans actually hold.

◆ ◆ ◆

**COUNTERARGUMENT**

The reform agenda the chapter describes is so ambitious as to be politically unachievable in any realistic political horizon. The agenda assumes a political coalition substantially more progressive than any currently in evidence in the American electorate, substantially more durable than any historical reform coalition, and substantially better organized against entrenched institutional opposition than the empirical record of American political reform suggests is possible.

**WHY THIS DOES NOT SAVE THE FRAMING**

The reform agenda is ambitious. It is not more ambitious, in scope or scale, than the reform agendas the United States has previously enacted at moments of comparable institutional crisis. The New Deal of 1933–1938 produced more institutional reform, more rapidly, against more concentrated opposition, than the agenda this chapter has described. The Great Society of 1964–1966 produced substantial reform across multiple major policy areas in a similarly compressed period. The post-Watergate reforms of 1974–1978 substantially restructured the intelligence-community oversight, campaign finance, and executive-branch accountability architectures within a five-year window. The political conditions for major reform recur in American history at intervals of approximately a political generation. The conditions are produced by the cumulative pressure of institutional dysfunction, by the cumulative documentary and intellectual work of reform advocates, and by the catalytic political moments that convert sustained pressure into legislative achievement. The present moment is not yet at the catalytic stage. It is at the preparatory stage. The work of the present moment is the building of the documentary and coalitional foundations that the catalytic political moment, when it arrives, will require. The catalytic moment cannot be reliably predicted. The preparatory work can be reliably undertaken. The chapter’s argument is the case for undertaking it.

◆ ◆ ◆

**The moral foundation: dignity, capabilities, and what a humane society owes its members**

Let me end the chapter on the moral foundation the entire book has been pointing toward. The structural humanism framework is, in the end, a moral position before it is a political program. The moral position is that human beings have an irreducible dignity that institutions exist to serve rather than to extract from. The position is not new. It is the position of the major prophetic religious traditions, of the secular humanist tradition from Spinoza through Mill through Sen, and of the constitutional commitments the American republic was founded on. The position has been variously articulated. The articulation matters less than the practical implication. A society organized around the dignity of the human beings inside it looks different from a society organized around the extraction of resources from those human beings. The differences are visible in the texture of daily life, in the financial security of households, in the time available for civic participation, in the health and education and retirement security of citizens, in the relationships between neighbors of different backgrounds, and in the public reputation of the institutions that govern collective life.

The most developed contemporary philosophical framework for translating the moral position of human dignity into specific institutional measures is the capabilities approach, developed principally by the economist Amartya Sen at Harvard University and the philosopher Martha Nussbaum at the University of Chicago. Sen’s Development as Freedom (Knopf, 1999) and Nussbaum’s Creating Capabilities: The Human Development Approach (Belknap, 2011) constitute the principal entry points to the literature. The framework’s central proposition is that the success of social arrangements should be measured not principally by aggregate income, by economic growth rates, or by other macroeconomic indicators, but by the substantive freedoms and capabilities that those arrangements actually enable for the human beings inside them. Nussbaum has elaborated a specific list of ten central capabilities — life, bodily health, bodily integrity, senses, imagination and thought, emotions, practical reason, affiliation, other species, play, and control over one’s environment — that a humane society must afford to its members in some adequate form.

The capabilities approach has been adopted, in various adaptations, by the United Nations Development Programme as the basis for the Human Development Index, by the OECD in the Better Life Index, and by a substantial number of national statistical agencies that have begun measuring societal well-being against capabilities-style criteria rather than against GDP alone. The American policy debate has been slow to absorb the framework. The empirical case for adopting it is substantial. The United States, on the standard capabilities-style measures — life expectancy adjusted for health, educational attainment adjusted for adequacy, financial security adjusted for the conditions of citizen agency, leisure time available for civic and personal life, security of bodily integrity from violence both criminal and state-administered — performs less well than the per-capita-GDP comparison would predict, and substantially less well than the peer democracies that have adopted institutional arrangements explicitly designed to expand citizen capabilities.

The argument for the humane reordering is, in its deepest form, the argument that the human beings whose lives are touched by American institutions deserve to be treated as ends rather than as means — the formulation Immanuel Kant gave to the principle in the Groundwork of the Metaphysic of Morals in 1785, and the principle that the major religious and secular moral traditions have variously affirmed across human history. The argument is older than the United States. It is one of the recurring arguments of human moral history. The argument has been made by people of every religious tradition and of no religious tradition. The argument has been made by people of every political tradition that has any moral seriousness to it. The argument is not the property of any partisan formation. The argument is what the partisan formations claim to serve when they are serving anything beyond their own institutional perpetuation.

The civilization we could be choosing is not a fantasy. It is a documented set of institutional arrangements, operating successfully in comparable societies, awaiting the political coalition large enough to enact and defend it here. The barrier is not technical. The barrier is the political-economic resistance of the institutions that benefit from the current arrangement. The mechanism for overcoming the barrier is the constitutional toolkit Chapter 11 documented, applied sustainedly over the years and decades the reform agenda will require. The work has been done before. The work can be done again. The capacity to do it is what citizenship in a democratic republic actually consists of.

> *The civilization we could be choosing is not a fantasy. It is a documented set of institutional arrangements, awaiting the political coalition large enough to enact and defend it here.*

◆ ◆ ◆

**Pattern**

Twelve chapters of diagnosis. One chapter of construction. The argument of the book reduces, in the end, to a sentence I have written variously throughout the chapters and that I want to write once more, in its strongest form, at the close of the constructive case. The present arrangement is not the limit of what is possible. The alternative is documented in the comparative international record and in the cumulative American policy literature. Germany has had codetermination for seventy years. Denmark has had flexicurity for thirty. Mondragon has operated as a worker-cooperative federation for seven decades. Costa Rica has lived without an army for seventy-six years. Singapore and Vienna have built mass public housing at scales the American policy debate has been told is impossible. Massachusetts achieved near-universal healthcare coverage two decades ago. North Dakota has operated a public bank since 1919. Cleveland and Preston and Rochester and Richmond have built operating worker-cooperative networks. New York City and Chicago have institutionalized participatory budgeting. The arrangements work. The arrangements have been built. The work of construction is the work that diagnosis was always for.

The conclusion that follows summarizes the argument the book has made and turns the reader, finally, toward what comes after the book ends. The bibliography at the back provides the entry points for the reader who wants to verify, extend, or challenge any of the claims the book has made. The back matter’s practical guide provides the first concrete actions a reader can take this week. The book ends here. The work the book is for begins.

**Conclusion**

*We Are Not Stupid, We Are Managed*

**Kai Jashon Price**

Jacksonville, North Carolina

*Independent journalist*

structuralhumanism.com

The argument of this book reduces, at the end, to a single distinction. The American public is not stupid. It is managed. The difference matters because the first is fatal and the second is fixable.

The book has assembled, across thirteen chapters, the documentary record on the management. The mechanisms of manufactured division, the architecture of debt as governance, the narrowing of information, the consolidation of corporate ownership. The political histories of sacred texts, the petrodollar order, the long tail of covert intervention, the documented record on September 11. The extractive healthcare system, the militarized public finance architecture, the civic toolkit citizens still hold, the contemporary men consolidating technological power. The civilization we could be choosing. Each chapter has assembled the documentary record on its specific subject, has steelmanned the strongest counterarguments against its framing, has identified the reform agenda the existing scholarly and policy literature supports, and has connected its specific argument to the broader structural pattern the book has documented. The pattern is consistent. The institutional settings differ. The structural logic does not.

I want to close with three observations the book has been pointing toward but has not yet stated in their compressed form. The three observations together summarize the position the book has been building toward and identify the practical work the position implies.

◆ ◆ ◆

**First: the information is public**

Essentially every primary source on which this book relies is publicly available. The Senate Intelligence Committee’s 2004 report on prewar Iraq intelligence is at intelligence.senate.gov. The Robb-Silberman Commission’s 2005 report on the broader weapons-of-mass-destruction intelligence failure is in the federal documentary archives. The 28 Pages are at the Office of the Director of National Intelligence declassification web portal. The Facebook Files are part of the official congressional record of Frances Haugen’s October 5, 2021 testimony to the Senate Subcommittee on Consumer Protection. The Foreign Intelligence Surveillance Court opinions documenting Section 702 abuse are at the ODNI public portal, including documenting more than 278,000 improper FBI queries. The Costs of War Project publishes its estimates openly at the Watson Institute at Brown University. The Kaiser Family Foundation publishes its medical-debt data openly. The Federal Reserve Bank of New York publishes the Quarterly Report on Household Debt and Credit openly through its Center for Microeconomic Data. The CORPNET research on Big Three asset-management concentration is in the peer-reviewed Business and Politics journal. The Fazzino study on tobacco-owned food brands is in the journal Addiction. The Azár-Schmalz-Tecu finding on common-ownership effects on airline pricing is in the Journal of Finance. The Brzezinski quotes on Operation Cyclone are in Le Nouvel Observateur, January 15–21, 1998. The Ward Boston affidavit is in the public record of the October 22, 2003 Capitol Hill press conference and is reproduced in the USS Liberty Veterans Association archive at gtr5.com. The Operation Mockingbird material is in the Church Committee’s 1976 Final Report and in Carl Bernstein’s October 20, 1977 Rolling Stone investigation.

The information is public. The integration of the information has been the work of this book. The further work is the work of every citizen who reads any of the primary sources for herself, evaluates them on her own terms, and shares what she finds with the people around her. The information is not the barrier. The integration is. The book has tried to lower that barrier by assembling, in one place, the documentary architecture a serious citizen needs to evaluate the present arrangement on the evidence rather than on the slogans.

I want to underline a specific implication of this observation. The standard frame in contemporary American discourse for accusations that significant facts about how the country is governed have been obscured from the public is the frame of conspiracy theory. The frame is rhetorically powerful and is used, routinely, to discredit substantive claims that the available evidence supports. The observation this section is making is that the relevant standard is not whether a claim about institutional behavior sounds conspiratorial in the abstract, but whether the claim is supported by documentary sources a reader can verify. The claims in this book that survive that test — and the chapters have tried to limit themselves to such claims — are not conspiracy theories. They are integrations of public documentary evidence that the standard media architecture has not assembled into the coherent picture the evidence supports. The distinction matters because it determines what kind of intellectual work is required to evaluate the claims. A conspiracy theory cannot, by construction, be evaluated against evidence; the absence of evidence is treated as confirmation of the cover-up. A documentary integration can be evaluated against its sources, and the sources are, in the case of this book, available for the reader to verify.

The deeper implication is for the practice of citizenship. A citizen who relies on cable news, social-media feeds, or the headline summaries of major outlets is not, in the present information environment, being given the integrated picture the public documentary record supports. She is being given a curated subset of the record, selected by the institutional incentives Chapter 3 documented. The remedy is not the rejection of mainstream sources — the mainstream sources contain genuine and important reporting — but the supplementation of those sources with direct engagement with the primary documents the chapters have cited. The work is harder than passive media consumption. The work is what democratic self-government, in the present moment, actually requires.

◆ ◆ ◆

**Second: the framework is moral before it is political**

The structural humanism framework is, at its base, a moral framework before it is a political program. The moral framework is that human beings have an irreducible dignity that institutions exist to serve rather than to extract from. The framework is not the property of any partisan formation. The framework is what every serious moral tradition, religious and secular, has variously articulated across human history. The institutional arrangements that flow from the framework can be debated. The framework itself is the foundation that makes the debate meaningful.

A reader who agrees with the moral framework but disagrees with some of the specific reform proposals in this book has not failed the framework. She has applied it. The chapters have tried throughout to distinguish between the empirical findings (which are, on the documentary record, what they are) and the policy proposals (which are reasonable applications of the findings but are not the only reasonable applications). The empirical record on the price of insulin is what it is. The specific reform that should follow from it is a matter for political deliberation among citizens who share the underlying moral framework. The book has offered its preferred reforms. The book does not pretend that its preferred reforms are the only reforms a structural-humanist position could support. The framework is the shared foundation. The specific applications are the ongoing work of democratic argument.

The moral framework has, I want to note, a specific political consequence that the partisan frame of contemporary American discourse has substantially obscured. The framework cuts across the conventional left-right axis. The position that concentrated corporate power has accumulated to scales that genuinely threaten the conditions of self-government is held by serious thinkers across the conventional political spectrum, from the populist right through the institutionalist center to the structural left. The position that the federal security state has accumulated authorities and operational practices that are difficult to reconcile with the constitutional design is held across the same spectrum. The position that the contemporary information environment has been engineered in ways that systematically advantage certain forms of political expression over others, with consequences for the public’s capacity to evaluate consequential decisions, is held across the same spectrum. The partisan frame of contemporary American politics has organized public attention around a set of cultural and identity disputes that, while real and consequential in their own terms, have systematically distracted from the cross-partisan structural questions on which the actual coalition for institutional reform could be assembled.

I am not arguing that the cultural and identity disputes are unimportant. They are important. I am arguing that they have been disproportionately weighted, in contemporary public attention, against the structural questions on which the institutional reforms the book has described could in principle be enacted. The political coalition for those reforms exists, in latent form, across the conventional partisan boundaries. The work of assembling the coalition into the active political form required to enact the reforms is the work that the moral framework, when articulated honestly, supports.

The deeper point about the moral framework is that it is the foundation that survives changes in political fashion. Specific policy proposals come and go. Specific partisan formations rise and fall. The underlying moral position that human beings have an irreducible dignity that institutions exist to serve has been the position of the major religious traditions for two thousand years and longer, has been the position of the major secular humanist traditions for at least three centuries, and has been the position of the American constitutional commitments since the founding. The framework is older than the contemporary political dispute. The framework will outlive the contemporary political dispute. The chapters have tried to ground their specific arguments in that older and more durable foundation precisely because the foundation is what makes the arguments worth making across political generations.

◆ ◆ ◆

**Third: the work has been done before**

The reform agenda the book has described — healthcare reorganization, antitrust restoration, campaign-finance reform, surveillance accountability, foreign-policy oversight, technology-sector governance — is large. It is also not larger, in scope or scale, than the reform agendas the United States has previously enacted at moments of comparable institutional crisis.

The Progressive Era of the 1900s and 1910s produced the antitrust and pure-food-and-drug architecture that the contemporary system has substantially abandoned. The major statutes of the period — the Sherman Antitrust Act of 1890, the Pure Food and Drug Act of 1906, the Federal Trade Commission Act of 1914, the Clayton Antitrust Act of 1914, the Federal Reserve Act of 1913, the Sixteenth Amendment establishing the federal income tax (1913), the Seventeenth Amendment establishing direct election of senators (1913), the Nineteenth Amendment establishing women’s suffrage (1920) — collectively restructured the relationship between the federal government and the major economic and political institutions of the country. The reforms were enacted against substantial institutional opposition. The reforms required sustained organized political pressure across multiple administrations and Congresses. The reforms were achieved.

The New Deal of 1933–1938 produced the financial-regulation, labor-protection, and social-insurance architecture that has been substantially eroded across the past half-century. The major statutes of the period — the Glass-Steagall Act of 1933, the Securities Act of 1933 and Securities Exchange Act of 1934, the National Labor Relations Act of 1935, the Social Security Act of 1935, the Fair Labor Standards Act of 1938 — collectively built the architecture of the modern American regulatory state. The reforms were enacted in response to the documented institutional failures of the period that preceded them. The reforms were achieved within a compressed political window of perhaps five years. The institutional architecture they built has survived, in modified form, for nearly a century, despite sustained subsequent political pressure for its dismantling.

The Great Society of 1964–1966 produced the civil-rights, voting-rights, Medicare, and Medicaid architectures that the contemporary political battle has been substantially about defending against rollback. The major statutes of the period — the Civil Rights Act of 1964, the Voting Rights Act of 1965, the Social Security Amendments of 1965 establishing Medicare and Medicaid, the Immigration and Nationality Act of 1965, the Higher Education Act of 1965, the Elementary and Secondary Education Act of 1965 — collectively restructured the relationship between the federal government and the most consequential domestic policy areas of the country. The reforms were enacted against the most concentrated political opposition of the post-war period. The reforms were achieved within a roughly two-year political window.

The post-Watergate reforms of 1974–1978 substantially restructured the intelligence-community oversight, campaign finance, and executive-branch accountability architectures within a five-year window. The Federal Election Campaign Act Amendments of 1974, the Foreign Intelligence Surveillance Act of 1978, the Ethics in Government Act of 1978, the Inspector General Act of 1978, the Presidential Records Act of 1978, and the Civil Service Reform Act of 1978 collectively built the post-Watergate institutional architecture. The reforms have been substantially eroded across the subsequent half-century, particularly in the post-2001 period. The reforms were nevertheless achieved within a compressed window and have shaped the institutional reality of every subsequent administration.

The Affordable Care Act of 2010 represented the most significant healthcare reform in nearly half a century, despite operating within the constraints of the consolidated insurance and pharmaceutical sectors. The reform reduced the uninsured rate substantially, established the Medicaid expansion that has produced measurable health and financial outcomes in the states that adopted it, and established the principle that healthcare is appropriately a subject of federal legislative action rather than a market matter beyond federal authority. The reform was incomplete. The reform was achieved against concentrated institutional opposition. The reform demonstrates that consequential reform of the largest sectors of the American economy is, in the contemporary political environment, possible.

The American political system has, repeatedly across its history, proved capable of substantial reform when the political coalition for reform has been adequately assembled. The current moment is not categorically different. The work of assembly is what the present moment calls for. The historical record of past American reform efforts is what supports the empirical claim that the work of assembly, when sustained, produces the institutional changes the work is undertaken to produce.

I want to end the book on the practical note the book has been building toward. The work of citizenship is not the work of a single dramatic gesture. It is the work of sustained, disciplined, ordinary engagement with the institutional mechanisms the constitutional design provides. The work is slow. The work is undramatic. The work is what every previous American reform was built on. The work is what the present arrangement most works to discourage, because the discouragement of the work is the durable strategy by which the present arrangement perpetuates itself. The book ends here. The work the book is for begins where the reader chooses to begin it.

> *We are not stupid. We are managed. The first is fatal. The second is fixable. The work the book is for begins where the reader chooses to begin it.*

**Back Matter**

*Five Things You Can Do This Week*

Every citizen who reaches this page is owed a practical answer to the question this book has been implicitly asking: where do I start? The answer is not a single dramatic action. It is the first of a series of ordinary actions sustained across time. The list that follows is the practical entry point. None of these actions requires special expertise, substantial money, or institutional position. All of them are constitutional. All of them have a documented historical record of producing change when sustained at sufficient scale. Pick one. Do it this week. Add a second the following week. The civic muscle is built one action at a time.

**1. File a Freedom of Information Act request**

Pick a federal agency whose decisions affect you, identify a specific record or category of records you would like to see, and file a FOIA request. The MuckRock platform (muckrock.com) provides templates and walks first-time requesters through the procedural steps. The cost is generally zero. The agency has twenty business days to respond. Most agencies miss the deadline routinely, but the request creates a procedural obligation and, when sufficient requests accumulate on a single issue area, can produce institutional response. Read what the agency releases. Share what you learn.

**2. Comment on an active federal rulemaking**

Go to regulations.gov. Search for rules currently in their public-comment period in a policy area you care about. Read the proposed rule. Write a substantive comment in your own words — identifying specific provisions you support or oppose, citing specific evidence in support of your position, and proposing specific alternative formulations where appropriate. Submit it. The agency is legally required to consider it. Substantive comments meaningfully shape final rules at a rate the empirical legal-scholarship literature has documented.

**3. Contact your representatives, substantively**

Identify two pieces of pending federal legislation you have an opinion about. Call the offices of your two senators and your representative. Identify yourself as a constituent, reference the specific bill numbers, state your position in your own words, and ask for the office’s position. Repeat the contact on each bill at least monthly. The Congressional Management Foundation’s 2017 research indicates that substantive, district-identified constituent contacts at modest volumes shift congressional-office positions in marginal cases more reliably than most citizens believe.

**4. Attend a local public meeting**

Identify the next meeting of your city council, county commission, school board, planning commission, or other local governing body. Attend it. Sit through it. Watch how the decisions are made. Identify the next agenda item you have an opinion about. Speak at the public-comment period on that item. The meetings are open by statute in essentially every American jurisdiction. Attendance is consistently low. A citizen who shows up regularly becomes one of the principal voices the body hears on its issues.

**5. Read one primary source from the bibliography**

Pick one item from the bibliography of this book that addresses a topic you want to understand better. Read it for yourself. Evaluate the book’s use of it on the evidence. Form your own judgment. Share what you find with the people around you. The capacity to evaluate the public documentary record on its own terms is the foundation of the civic engagement the previous four actions are meant to translate into institutional pressure. The reading is not separate from the doing. The reading is what makes the doing serious.

**Recommended Reading**

The following short list is the entry point for readers who want to go deeper on the major subject areas of this book. The list is not exhaustive. The fuller bibliography that follows includes the principal scholarly and journalistic sources each chapter draws on. The recommendations here are the works I have found most useful for the general reader who wants to develop her own informed view.

**On the political economy of consolidation**

Matt Stoller, Goliath: The 100-Year War Between Monopoly Power and Democracy (Simon & Schuster, 2019). Tim Wu, The Curse of Bigness: Antitrust in the New Gilded Age (Columbia Global Reports, 2018). David Dayen, Monopolized: Life in the Age of Corporate Power (The New Press, 2020). Lina Khan, “Amazon’s Antitrust Paradox,” Yale Law Journal 126 (2017). Brian Alexander, Glass House: The 1% Economy and the Shattering of the All-American Town (St. Martin’s, 2017).

**On the information environment**

Edward S. Herman and Noam Chomsky, Manufacturing Consent: The Political Economy of the Mass Media (Pantheon, 1988; updated edition 2002). Ben Bagdikian, The New Media Monopoly (Beacon Press, 2004). Shoshana Zuboff, The Age of Surveillance Capitalism (PublicAffairs, 2019). Frances Haugen, The Power of One: How I Found the Strength to Tell the Truth and Why I Blew the Whistle on Facebook (Little, Brown, 2023).

**On healthcare political economy**

Elisabeth Rosenthal, An American Sickness: How Healthcare Became Big Business and How You Can Take It Back (Penguin Press, 2017). Steven Brill, America’s Bitter Pill: Money, Politics, Backroom Deals, and the Fight to Fix Our Broken Healthcare System (Random House, 2015). T. R. Reid, The Healing of America: A Global Quest for Better, Cheaper, and Fairer Health Care (Penguin Press, 2009). Patrick Radden Keefe, Empire of Pain: The Secret History of the Sackler Dynasty (Doubleday, 2021).

**On foreign policy and intelligence history**

Steve Coll, Ghost Wars: The Secret History of the CIA, Afghanistan, and Bin Laden (Penguin, 2004). James Bamford, Body of Secrets: Anatomy of the Ultra-Secret National Security Agency (Doubleday, 2001). Tim Weiner, Legacy of Ashes: The History of the CIA (Doubleday, 2007). Andrew Bacevich, The Limits of Power: The End of American Exceptionalism (Metropolitan, 2008). Jeremy Scahill, Dirty Wars: The World Is a Battlefield (Nation Books, 2013).

**On the September 11 record**

Thomas Kean and Lee Hamilton, Without Precedent: The Inside Story of the 9/11 Commission (Knopf, 2006). The 28 Pages, declassified July 15, 2016, ODNI public release. Joint Inquiry of the Senate and House Intelligence Committees, Report on the Joint Inquiry into Intelligence Community Activities Before and After the Terrorist Attacks of September 11, 2001 (December 2002). Lawrence Wright, The Looming Tower: Al-Qaeda and the Road to 9/11 (Knopf, 2006).

**On democratic theory and reform**

Erica Chenoweth and Maria Stephan, Why Civil Resistance Works (Columbia University Press, 2011). Erica Chenoweth, Civil Resistance: What Everyone Needs to Know (Oxford University Press, 2021). Martin Gilens and Benjamin Page, “Testing Theories of American Politics,” Perspectives on Politics 12, no. 3 (2014). Lawrence Lessig, Republic, Lost: How Money Corrupts Congress — and a Plan to Stop It (Twelve, 2011). Amartya Sen, Development as Freedom (Knopf, 1999). Martha Nussbaum, Creating Capabilities: The Human Development Approach (Belknap, 2011).

**On religion and historical scholarship**

Mary Boyce, Zoroastrians: Their Religious Beliefs and Practices (Routledge, 1979). Norman Cohn, Cosmos, Chaos, and the World to Come (Yale University Press, 1993). William G. Dever, Did God Have a Wife? Archaeology and Folk Religion in Ancient Israel (Eerdmans, 2005). Mark S. Smith, The Origins of Biblical Monotheism (Oxford University Press, 2001). David Norton, A Textual History of the King James Bible Bruce M. Metzger, The Canon of the New Testament (Clarendon, 1987). Mark Noll, The Civil War as a Theological Crisis (University of North Carolina Press, 2006).

**Bibliography**

The following bibliography lists the principal sources cited or relied upon in the chapters of this book, organized alphabetically by author. The list aims for comprehensiveness within the scope of works directly cited; the chapters themselves contain inline references to additional sources not separately listed here. All entries can be located through standard library and online research databases. Where a source is a federal government document, the relevant archival location is indicated.

Acton, John Emerich Edward Dalberg. Letter to Bishop Mandell Creighton, April 5, 1887. In Acton, Historical Essays and Studies (Macmillan, 1907).

American Society of Civil Engineers. Report Card for America’s Infrastructure. 2025 edition. infrastructurereportcard.org.

Atlantic Council. “De-Baathification and the Birth of ISIS.” Atlantic Council institutional analysis, multiple publications 2014–2018.

Autor, David, David Dorn, Lawrence F. Katz, Christina Patterson, and John Van Reenen. “The Fall of the Labor Share and the Rise of Superstar Firms.” Quarterly Journal of Economics 135, no. 2 (May 2020): 645–709.

Azár, José, Sahil Raina, and Martin Schmalz. “Ultimate Ownership and Bank Competition.” Financial Management 51, no. 1 (2022): 227–269.

Azár, José, Martin C. Schmalz, and Isabel Tecu. “Anticompetitive Effects of Common Ownership.” Journal of Finance 73, no. 4 (August 2018): 1513–1565.

Bacevich, Andrew. The Limits of Power: The End of American Exceptionalism. New York: Metropolitan Books, 2008.

Bacevich, Andrew. Breach of Trust: How Americans Failed Their Soldiers and Their Country. New York: Metropolitan Books, 2013.

Bagdikian, Ben H. The Media Monopoly. 1st through 6th editions. Boston: Beacon Press, 1983–2004.

Bagdikian, Ben H. The New Media Monopoly. Boston: Beacon Press, 2004.

Bamford, James. Body of Secrets: Anatomy of the Ultra-Secret National Security Agency. New York: Doubleday, 2001.

Bashir, Omar S. “Testing Inferences about American Politics: A Review of the ‘Oligarchy’ Result.” Research and Politics 2, no. 4 (2015).

Bernstein, Carl. “The CIA and the Media.” Rolling Stone, October 20, 1977.

Boston, Ward Jr. Sworn Affidavit on the USS Liberty Court of Inquiry. October 22, 2003. Reproduced at the USS Liberty Veterans Association archive, gtr5.com.

Boyce, Mary. A History of Zoroastrianism. 3 vols. Leiden: Brill, 1975–1991.

Boyce, Mary. Zoroastrians: Their Religious Beliefs and Practices. London: Routledge, 1979.

Bower, Tom. Maxwell: The Outsider. London: Aurum Press, 1988.

Branham, J. Alexander, Stuart N. Soroka, and Christopher Wlezien. “When Do the Rich Win?” Political Science Quarterly 132, no. 1 (2017): 43–62.

Brzezinski, Zbigniew. Interview with Vincent Jauvert. Le Nouvel Observateur, January 15–21, 1998.

Bronner, Michael. “9/11 Live: The NORAD Tapes.” Vanity Fair, August 2006.

Burnham, Gilbert, et al. “Mortality after the 2003 invasion of Iraq: a cross-sectional cluster sample survey.” The Lancet 368 (2006): 1421–1428.

Cefalu, William T., et al. “Insulin Access and Affordability Working Group: Conclusions and Recommendations.” Diabetes Care 41, no. 6 (June 2018).

Center for Investigative Reporting / Reveal News. Various investigations, 2018–2025. revealnews.org.

Centers for Disease Control and Prevention. WONDER mortality database. wonder.cdc.gov.

Chenoweth, Erica. Civil Resistance: What Everyone Needs to Know. Oxford: Oxford University Press, 2021.

Chenoweth, Erica, and Maria J. Stephan. Why Civil Resistance Works: The Strategic Logic of Nonviolent Conflict. New York: Columbia University Press, 2011.

Chomsky, Noam, and Edward S. Herman. Manufacturing Consent: The Political Economy of the Mass Media. New York: Pantheon Books, 1988.

Church Committee. Final Report of the Select Committee to Study Governmental Operations with Respect to Intelligence Activities. 6 vols. Washington, DC: U.S. Government Printing Office, 1976. Archived at intelligence.senate.gov.

Cockburn, Andrew. The Spoils of War: Power, Profit and the American War Machine. London: Verso, 2021.

Coglianese, Cary. “Citizen Participation in Rulemaking: Past, Present, and Future.” Duke Law Journal 55 (2006): 943–968.

Cohn, Norman. Cosmos, Chaos, and the World to Come. New Haven: Yale University Press, 1993.

Coll, Steve. Ghost Wars: The Secret History of the CIA, Afghanistan, and Bin Laden, from the Soviet Invasion to September 10, 2001. New York: Penguin Press, 2004.

Commonwealth Fund. Mirror, Mirror 2024: A Portrait of the Failing U.S. Health System. commonwealthfund.org.

Congressional Management Foundation. Communicating with Congress: Perceptions of Citizen Advocacy on Capitol Hill. Washington, DC: CMF, 2017.

Congressional Research Service. Pentagon-Anthropic Dispute over Autonomous Weapon Systems. Issue Brief IN12669, April 2026.

CORPNET research group, University of Amsterdam. Various publications on global corporate ownership networks, 2017–present. corpnet.uva.nl.

Costs of War Project, Watson Institute, Brown University. Various annual updates, 2011–present. watson.brown.edu/costsofwar.

Crone, Patricia. Slaves on Horses: The Evolution of the Islamic Polity. Cambridge: Cambridge University Press, 1980.

Danzon, Patricia M. Pharmaceutical Price Regulation: National Policies versus Global Interests. Washington, DC: AEI Press, 1997.

Department of Defense, Office of Inspector General. Annual Audit Reports, FY 2018–2024. dodig.mil.

Department of Justice. False Claims Act annual recoveries reports. justice.gov.

Dever, William G. Did God Have a Wife? Archaeology and Folk Religion in Ancient Israel. Grand Rapids, MI: Eerdmans, 2005.

Director of National Intelligence, Office of the. Various FISC declassifications, 2013–present. dni.gov.

Drexel University LeBow College of Business et al. Global Sanctions Database. globalsanctionsdatabase.com.

Eichengreen, Barry. Exorbitant Privilege: The Rise and Fall of the Dollar and the Future of the International Monetary System. Oxford: Oxford University Press, 2011.

Ehrman, Bart D. How Jesus Became God: The Exaltation of a Jewish Preacher from Galilee. New York: HarperOne, 2014.

Ehrman, Bart D. Lost Christianities: The Battles for Scripture and the Faiths We Never Knew. Oxford: Oxford University Press, 2003.

Electronic Frontier Foundation. “The Anthropic-DOD Conflict: Privacy Protections Shouldn’t Depend On the Decisions of a Few Powerful People.” EFF Deeplinks, March 2026.

Enns, Peter K. “Relative Policy Support and Coincidental Representation.” Perspectives on Politics 13, no. 4 (2015): 1053–1064.

Ennes, James M. Assault on the Liberty. New York: Random House, 1979.

Fazzino, Tera L., et al. “U.S. Tobacco Companies Selectively Disseminated Hyper-Palatable Foods into the U.S. Food System.” Addiction 119, no. 1 (September 2023).

Federal Reserve Bank of New York, Center for Microeconomic Data. Quarterly Report on Household Debt and Credit. Various editions, 2003–present.

Federal Reserve Bank of St. Louis. FRED economic data series. fred.stlouisfed.org.

Fichtner, Jan, Eelke M. Heemskerk, and Javier Garcia-Bernardo. “Hidden Power of the Big Three? Passive Index Funds, Re-concentration of Corporate Ownership, and New Financial Risk.” Business and Politics 19, no. 2 (2017): 298–326.

Friedman, Michael; Howard Udell; Paul Goldenheim. Guilty pleas, United States District Court for the Western District of Virginia, May 2007. Department of Justice press release.

Gates, Robert M. From the Shadows: The Ultimate Insider’s Story of Five Presidents and How They Won the Cold War. New York: Simon & Schuster, 1996.

Gilens, Martin, and Benjamin I. Page. “Testing Theories of American Politics: Elites, Interest Groups, and Average Citizens.” Perspectives on Politics 12, no. 3 (September 2014): 564–581.

Gilman, Hollie Russon. Democracy Reinvented: Participatory Budgeting and Civic Innovation in America. Washington, DC: Brookings Institution Press, 2016.

Glied, Sherry, and Peter Muennig. “Changes in Health Outcomes after Massachusetts Health Reform.” New England Journal of Medicine, multiple publications 2010–2014.

Government Accountability Office. High-Risk Series: An Update. January 2024 (and prior editions). gao.gov.

Government Accountability Office. Assessments of Major Weapon Programs. Annual editions, gao.gov.

Graeber, David. Debt: The First 5,000 Years. Brooklyn: Melville House, 2011.

Gruber, Jonathan. “Massachusetts Points the Way to Successful Health Care Reform.” Journal of Policy Analysis and Management 30, no. 1 (2011): 184–192.

Harrington v. Purdue Pharma. 603 U.S. \_\_\_ (June 27, 2024).

Hartung, William D. Prophets of War: Lockheed Martin and the Making of the Military-Industrial Complex. New York: Nation Books, 2011.

Haugen, Frances. Testimony before the Senate Subcommittee on Consumer Protection. October 5, 2021. commerce.senate.gov.

Herkert, Darby, et al. “Cost-Related Insulin Underuse Among Patients With Diabetes.” JAMA Internal Medicine 179, no. 1 (2019): 112–114.

Himmelstein, David U., et al. “Medical Bankruptcy in the United States, 2007.” American Journal of Medicine 122, no. 8 (August 2009): 741–746.

Hulsey, Leroy, et al. A Structural Reevaluation of the Collapse of World Trade Center 7. University of Alaska Fairbanks, March 2020. Scholarworks UAF archive.

Iraq Body Count Project. Ongoing public database. iraqbodycount.org.

Jäger, Simon, et al. “Workers in the Boardroom: Codetermination and Firm Performance.” American Economic Review 111, no. 8 (2021).

Joint Inquiry of the Senate and House Intelligence Committees. Report on the Joint Inquiry into Intelligence Community Activities Before and After the Terrorist Attacks of September 11, 2001. December 2002.

Juergensmeyer, Mark. Terror in the Mind of God: The Global Rise of Religious Violence. 4th ed. Berkeley: University of California Press, 2017.

Kaiser Family Foundation. Health Care Debt in the U.S. June 2022. kff.org.

Kasmir, Sharryn. The Myth of Mondragón: Cooperatives, Politics, and Working-Class Life in a Basque Town. Albany: SUNY Press, 1996.

Kean, Thomas H., and Lee H. Hamilton. Without Precedent: The Inside Story of the 9/11 Commission. New York: Knopf, 2006.

Khan, Lina M. “Amazon’s Antitrust Paradox.” Yale Law Journal 126, no. 3 (2017): 710–805.

Lazonick, William. “Profits Without Prosperity.” Harvard Business Review (September 2014).

Loper Bright Enterprises v. Raimondo. 603 U.S. \_\_\_ (June 28, 2024).

Lowi, Theodore J. The End of Liberalism: The Second Republic of the United States. 2nd ed. New York: W. W. Norton, 1979.

Lutz, Ashley. “These 6 Corporations Control 90% Of The Media In America.” Business Insider, June 14, 2012.

Mearsheimer, John J., and Stephen M. Walt. The Israel Lobby and U.S. Foreign Policy. New York: Farrar, Straus and Giroux, 2007.

Medsger, Betty. The Burglary: The Discovery of J. Edgar Hoover’s Secret FBI. New York: Knopf, 2014.

Metzger, Bruce M. The Canon of the New Testament: Its Origin, Development, and Significance. Oxford: Clarendon, 1987.

Moussaoui v. Kingdom of Saudi Arabia. Multidistrict Litigation in U.S. District Court for the Southern District of New York. Active docket.

National Institute of Standards and Technology. NCSTAR 1A: Final Report on the Collapse of World Trade Center Building 7. November 2008.

Noll, Mark A. The Civil War as a Theological Crisis. Chapel Hill: University of North Carolina Press, 2006.

Norton, David. A Textual History of the King James Bible. Cambridge:

Northwestern University Local News Initiative. State of Local News Report. 2024 edition.

Nussbaum, Martha. Creating Capabilities: The Human Development Approach. Cambridge, MA: Belknap Press, 2011.

OECD. Health Statistics 2024 Release. oecd.org.

OECD. Education at a Glance. Annual reports. oecd.org.

Pew Research Center. News Platform Fact Sheet. Annual. pewresearch.org.

Pfiffner, James P. “U.S. Blunders in Iraq: De-Baathification and Disbanding the Army.” Intelligence and National Security 25, no. 1 (2010): 76–85.

Posner, Eric A., and E. Glen Weyl. Radical Markets: Uprooting Capitalism and Democracy for a Just Society. Princeton: Princeton University Press, 2018.

Poteshman, Allen M. “Unusual Option Market Activity and the Terrorist Attacks of September 11, 2001.” The Journal of Business 79, no. 4 (2006): 1703–1726.

Project on Government Oversight. Brass Parachutes: Defense Contractors’ Capture of Pentagon Officials Through the Revolving Door. November 2018. pogo.org.

Public Religion Research Institute. Various polling on American religious attitudes, 2010–present. prri.org.

Ravid, Barak. Various Israeli political reporting. Axios, 2018–present.

Reuter, Christoph. “Secret Files Reveal the Structure of Islamic State.” Der Spiegel, April 18, 2015.

Robb-Silberman Commission. The Commission on the Intelligence Capabilities of the United States Regarding Weapons of Mass Destruction. Final Report. March 2005.

Sachs, Jeffrey D., and Mark Weisbrot. “Economic Sanctions as Collective Punishment: The Case of Venezuela.” Center for Economic and Policy Research, April 2019.

Schmidt, Laura A., et al. “Following the Footprints of Big Tobacco: How Tobacco Companies Shaped the Food Industry.” University of California San Francisco research, 2018–2020.

Sen, Amartya. Development as Freedom. New York: Knopf, 1999.

Senate Select Committee on Intelligence. Report on the U.S. Intelligence Community’s Prewar Intelligence Assessments on Iraq. July 2004. intelligence.senate.gov.

Senate Select Committee on Intelligence. The 28 Pages (declassified section of the Joint Inquiry Report). Released July 15, 2016. ODNI declassification portal.

SIGAR (Special Inspector General for Afghanistan Reconstruction). Quarterly Reports to the United States Congress. 2008–present. sigar.mil.

SIGIR (Special Inspector General for Iraq Reconstruction). Learning from Iraq: A Final Report from the Special Inspector General for Iraq Reconstruction. March 2013.

Smith, Mark S. The Origins of Biblical Monotheism: Israel’s Polytheistic Background and the Ugaritic Texts. Oxford: Oxford University Press, 2001.

Spiro, David E. The Hidden Hand of American Hegemony: Petrodollar Recycling and International Markets. Ithaca: Cornell University Press, 1999.

Stigler, George J. “The Theory of Economic Regulation.” Bell Journal of Economics and Management Science 2, no. 1 (1971): 3–21.

Stoller, Matt. Goliath: The 100-Year War Between Monopoly Power and Democracy. New York: Simon & Schuster, 2019.

Thomas, Gordon, and Martin Dillon. Robert Maxwell: Israel’s Superspy. New York: Carroll & Graf, 2002.

National Commission on Terrorist Attacks Upon the United States. The 9/11 Commission Report: Final Report of the National Commission on Terrorist Attacks Upon the United States. Authorized edition. New York: W. W. Norton, 2004.

Vanderlip, Frank A. “From Farm Boy to Financier.” Saturday Evening Post, February 9, 1935.

Wagner, Wendy E. “Administrative Law, Filter Failure, and Information Capture.” Duke Law Journal 59 (2010): 1321–1432.

Wansbrough, John. Quranic Studies: Sources and Methods of Scriptural Interpretation. Oxford: Oxford University Press, 1977.

Warren, Elizabeth, and Amelia Warren Tyagi. The Two-Income Trap: Why Middle-Class Mothers and Fathers Are Going Broke. New York: Basic Books, 2003.

Wilken, Robert Louis. The First Thousand Years: A Global History of Christianity. New Haven: Yale University Press, 2012.

Willett, Walter C., et al. “Intake of trans fatty acids and risk of coronary heart disease among women.” The Lancet 341, no. 8845 (March 1993): 581–585.

Wirls, Daniel. Buildup: The Politics of Defense in the Reagan Era. Ithaca: Cornell University Press, 1992.

Wright, Lawrence. The Looming Tower: Al-Qaeda and the Road to 9/11. New York: Knopf, 2006.

**GLOSSARY**

*Key terms, institutional actors, and analytical frameworks used in this book. Terms marked with a chapter reference appear in more detail there. For each term defined elsewhere in the glossary, that definition is cross-referenced.*

**Administrative Procedure Act (APA)**

> Federal statute (5 U.S.C. § 551 et seq.) governing the process by which federal agencies develop and issue regulations, including the requirement to publish proposed rules in the Federal Register and accept public comments. Provides the legal basis for judicial review of agency action (5 U.S.C. §§ 701–706). See Chapter 11.

**Antitrust Paradox, The**

> 1978 book by Robert Bork (Basic Books) arguing that antitrust enforcement should be reoriented around a single empirical test: short-run consumer prices. Adopted by the Reagan Justice Department's 1982 Merger Guidelines. Its application across four decades has produced the concentrated operating economy documented in Chapter 4.

**Asset-management common ownership**

> The structural situation in which a single large institutional investor—particularly a passive-index fund manager such as BlackRock, Vanguard, or State Street—simultaneously holds significant ownership stakes in multiple competing firms in the same industry. Documented to be associated with price elevation in affected industries. See Chapter 4.

**August 6, 2001 PDB**

> Presidential Daily Brief titled 'Bin Ladin Determined to Strike in U.S.,' declassified at the request of the 9/11 Commission and released April 2004. Established that the intelligence community had assessed, 36 days before the September 11 attacks, that bin Laden intended to attack the United States and that preparations for hijackings or other attacks were underway. Available through the National Archives. See Chapter 8.

**BAPCPA**

> The Bankruptcy Abuse Prevention and Consumer Protection Act of 2005. Tightened eligibility for Chapter 7 personal bankruptcy, imposed means testing, lengthened look-back periods, and preserved the non-dischargeability of most student loan debt. Passed 74-25 in the Senate; principal lobbyists were the credit-card industry. See Chapter 2.

**Big Three (asset managers)**

> Informal designation for BlackRock, the Vanguard Group, and State Street Global Advisors, the three largest passive-investment asset managers in the world, which together manage approximately $24 trillion in assets (2025) and collectively constitute the largest shareholder in 88 percent of S&P 500 companies. See Chapter 4.

**Blowback**

> Intelligence-community term, popularized by the political scientist Chalmers Johnson's 2000 book of the same name (Metropolitan), for the unintended consequences of covert foreign-policy operations—specifically, the ways in which covert actions generate threats that the sponsoring state later asks its public to fund the response to, without informing the public of the original causal contribution. See Chapter 7.

**Bork doctrine**

> See Antitrust Paradox, The.

**COINTELPRO**

> The FBI's Counterintelligence Program, 1956–1971. A documented program of manufactured division targeting civil-rights, antiwar, Black nationalist, American Indian, Puerto Rican independence, and women's liberation organizations through forged letters, fabricated affairs, planted informants, anonymous leaks, and other disruption tactics. Exposed by the Citizens' Commission to Investigate the FBI (1971) and documented by the Church Committee (1976). See Chapter 1.

**Church Committee**

> The U.S. Senate Select Committee to Study Governmental Operations with Respect to Intelligence Activities, chaired by Senator Frank Church (D-ID), 1975–1976. Its final report, published in multiple volumes, established the documentary record on COINTELPRO, CIA media relationships (Operation Mockingbird), assassination plots against foreign leaders, and other domestic and foreign intelligence abuses. Available at intelligence.senate.gov. See Chapters 1, 3, 7.

**Common ownership**

> See Asset-management common ownership.

**Consumer Financial Protection Bureau (CFPB)**

> Independent federal agency created by the Dodd-Frank Wall Street Reform and Consumer Protection Act of 2010, charged with regulating consumer financial products and protecting borrowers from abusive practices. Maintains a public complaint database at consumerfinance.gov/complaint. Its independence has been subject to multiple executive-branch challenges in 2025–2026. See Chapter 2.

**CORPNET project**

> Research project at the University of Amsterdam, led by Jan Fichtner, Eelke Heemskerk, and Javier Garcia-Bernardo, that produced the 2017 Business and Politics paper establishing the extent of Big Three asset-manager ownership concentration across the S&P 500. Principal empirical source for Chapter 4's asset-management analysis.

**Costs of War Project**

> Research initiative at Brown University's Watson Institute for International and Public Affairs that has, since 2011, produced the most rigorous available accounting of post-9/11 war costs. Places total U.S. military, security, and veterans-care costs at approximately $8 trillion through fiscal year 2050. Available at watson.brown.edu/costsofwar. See Chapter 6.

**Disclaimer of opinion**

> The formal statement issued by an independent auditor when insufficient appropriate audit evidence exists to issue any opinion on the accuracy of a financial statement. The Department of Defense has received a disclaimer of opinion on its consolidated financial statements in every audit conducted since the first full audit in fiscal year 2018. See Chapter 10.

**Facebook Files**

> Internal Facebook corporate documents disclosed in 2021 by former product manager Frances Haugen, provided to the Wall Street Journal and to the U.S. Senate. Document that Facebook's internal researchers had measured the divisive effects of the platform's algorithmic ranking changes and that proposed fixes had been rejected because they reduced engagement. Haugen's testimony is part of the official congressional record, dated October 5, 2021. See Chapter 1.

**False Claims Act (FCA)**

> Federal statute (31 U.S.C. § 3729 et seq.) that permits private citizens (relators) to file lawsuits on behalf of the federal government alleging fraud against federal programs. Relators receive 15–30 percent of recovered funds. Modernized in 1986; has produced more than $50 billion in federal recoveries since then. See Chapter 11.

**FISA / Section 702**

> The Foreign Intelligence Surveillance Act (1978) and its 2008 Amendments Act, Section 702, which permits warrantless collection of communications to and from non-U.S. persons reasonably believed to be located abroad. A Foreign Intelligence Surveillance Court opinion released in May 2023 documented more than 278,000 improper FBI queries on the Section 702 database in 2020–2021. See Chapter 3.

**Flexicurity**

> The Danish labor-market model combining flexible hiring and firing rules with generous unemployment insurance (traditionally ~90 percent wage replacement for lower-income workers) and extensive active labor-market policy (publicly funded retraining and job placement). Associated with low unemployment and high labor-market mobility. See Chapter 13.

**FOIA (Freedom of Information Act)**

> Federal statute (5 U.S.C. § 552) requiring federal agencies to respond to written requests for records within twenty business days, with nine enumerated exemptions. Requesters may administratively appeal denials and seek federal-court review. Cost is generally zero for non-commercial first-page requests. MuckRock (muckrock.com) provides templates and tracking. See Chapter 11.

**Foreign Agents Registration Act (FARA)**

> Federal statute (22 U.S.C. §§ 611–621) requiring persons acting as agents of foreign principals to register with the Department of Justice and disclose their activities and financial arrangements. The chapter cites the 1962–1963 Fulbright hearings and the 2008 declassification of relevant FARA records in connection with AIPAC's predecessor organization. See Chapter 7.

**Gilens-Page finding**

> The principal empirical finding of political scientists Martin Gilens (Princeton) and Benjamin Page (Northwestern), published in Perspectives on Politics in September 2014. Based on approximately 1,779 policy issues from 1981–2002, the paper found that the preferences of economic elites and business-oriented interest groups had substantial independent effects on policy outcomes, while average citizens' preferences had near-zero independent effect when controlling for elite preferences. See Chapter 10.

**Glass-Steagall Act**

> Informal name for the Banking Act of 1933, which separated commercial banking from investment banking. Its relevant provisions were repealed by the Gramm-Leach-Bliley Act of 1999, enabling the formation of modern financial conglomerates such as Citigroup in its present form. See Chapter 4.

**Government Accountability Office (GAO)**

> The independent, nonpartisan watchdog agency of Congress that audits federal programs, investigates government operations, and produces annual assessments of major defense-acquisition programs. Has maintained the Department of Defense's financial management on its High-Risk List continuously since 1995. Reports searchable at gao.gov/reports.

**Gramm-Leach-Bliley Act**

> Financial services deregulation legislation enacted in 1999 repealing the Glass-Steagall separation of commercial and investment banking. See Chapter 4.

**Jekyll Island meeting (1910)**

> A secret November 1910 meeting on Jekyll Island, Georgia, at which a small group of senior bankers and a Treasury official drafted what became the basis for the Federal Reserve Act of 1913. Documented primarily by participant Frank Vanderlip in the Saturday Evening Post, February 9, 1935. See Chapter 2.

**Masoretic tradition**

> The Jewish scribal tradition, centered in Tiberias and Babylon, that standardized the text, vocalization, and cantillation of the Hebrew Bible between approximately the 7th and 10th centuries of the common era. The Hebrew Bible in modern editions reflects this Masoretic standard. Variant readings were illuminated by the Dead Sea Scrolls discoveries (1947–1956). See Chapter 5.

**Mitbestimmung (codetermination)**

> The German system of worker representation on corporate supervisory boards, institutionalized under the Codetermination Act of 1976. Requires that companies above specified employment thresholds reserve up to half of supervisory-board seats for worker representatives elected by the workforce. Associated in the academic literature with more equitable distribution of corporate value and sustained labor-market outcomes. See Chapter 13.

**News desert**

> A county or other geographic area with no local news outlet of any kind. The Northwestern University Local News Initiative's 2024 State of Local News Report identified more than 200 such counties in the United States, See Chapter 3.

**Operation Cyclone**

> The CIA covert program, authorized by a presidential finding signed July 3, 1979 (prior to the Soviet invasion of Afghanistan), that channeled approximately $600 million per year through Pakistan's ISI to Afghan mujahideen factions at its peak, with matching Saudi funding bringing the annual total above $1 billion. The infrastructure built under the program provided the organizational basis from which al-Qaeda later recruited. See Chapter 7.

**Operation Mockingbird**

> Popular name for the documented CIA program of relationships with American journalists, news executives, and editors during the Cold War. Established by the Church Committee (1976) and further detailed in Carl Bernstein's October 20, 1977 Rolling Stone investigation, which reported that more than 400 American journalists had carried out assignments for the CIA over the preceding quarter century. See Chapter 3.

**Petrodollar system**

> The post-1971 international monetary arrangement under which Saudi Arabia (and subsequently other OPEC producers) priced oil exports in U.S. dollars and recycled dollar earnings into U.S. Treasury securities and U.S. arms purchases, in exchange for U.S. security guarantees. Created a structural source of global demand for dollars and financing for U.S. fiscal deficits. Principal scholarly source: David E. Spiro, The Hidden Hand of American Hegemony (Cornell, 1999). See Chapter 6.

**Pharmacy benefit managers (PBMs)**

> Intermediaries in the pharmaceutical supply chain that negotiate drug prices between manufacturers and insurers, manage formularies, and process prescriptions. The rebate structures that PBMs negotiate with drug manufacturers flow back through the insurance system rather than to patients at the pharmacy counter—a structural mechanism that has contributed to maintained pricing power on drugs such as insulin. See Chapter 9.

**Propaganda model**

> The framework for analyzing mass-media production developed by Noam Chomsky and Edward S. Herman in Manufacturing Consent (Pantheon, 1988). Identifies five structural 'filters' through which news production is shaped: ownership concentration, advertising dependence, sourcing from official institutions, disciplinary responses to threatening coverage, and an ambient ideological framework. See Chapter 3.

**Qui tam**

> Latin shorthand ('qui tam pro domino rege quam pro se ipso'—'who sues on behalf of the king as well as for himself') for the mechanism under the False Claims Act (31 U.S.C. § 3730) by which private citizens can file federal lawsuits on behalf of the government and receive 15–30 percent of recovered funds. See Chapter 11.

**Regulatory capture**

> The process by which regulatory agencies, over time, come to be dominated by the industries they nominally regulate, producing a systematic bias toward industry interests. Developed theoretically by economist George Stigler in a 1971 paper. Applied in this book to the FDA's delays on trans fats (Chapter 9) and to the broader defense-procurement architecture (Chapter 10).

**Revolving door**

> The movement of personnel between senior government positions and senior positions in the industries they formerly regulated or contracted with. The Project on Government Oversight documented that 60 percent of retired three- and four-star generals and admirals who retired 2008–2017 took defense-industry jobs. See Chapter 10.

**Section 230 (CDA)**

> Section 230 of the Communications Decency Act of 1996, which provides that 'no provider or user of an interactive computer service shall be treated as the publisher or speaker of any information provided by another information content provider.' Shields internet platforms from publisher liability for user-generated content, while (controversially) also shielding platforms that perform substantial editorial functions through algorithmic ranking and amplification. See Chapter 3.

**Sherman Antitrust Act**

> Federal statute enacted in 1890 prohibiting contracts, combinations, and conspiracies in restraint of trade and monopolization. The basis for the Standard Oil breakup (1911) and the general structural-antitrust enforcement era that preceded the Bork doctrine. The Reagan administration's 1982 Merger Guidelines reoriented enforcement away from the act's original structural concerns toward a consumer-price test. See Chapter 4.

**SIGAR / SIGIR**

> The Special Inspector General for Afghanistan Reconstruction (established 2008; sigar.mil) and the Special Inspector General for Iraq Reconstruction (operated 2004–2013). Together produced the most comprehensive federal documentation of reconstruction-contract fraud and waste in American history, identifying tens of billions in waste, fraud, and abuse. SIGIR's 2013 final report concluded approximately $60 billion in Iraqi reconstruction funds had produced 'limited or no benefit.' See Chapter 10.

**Structural humanism**

> The analytical framework developed in this book. Core position: contemporary American crises are not isolated failures but interlocking systems of managed division, economic extraction, historical amnesia, and institutional impunity—and ordinary people are still capable of building something better. 'Structural' because the focus is on institutional arrangements rather than individual villains. 'Humanist' because the test of every institution is whether it serves the dignity, agency, and material well-being of the actual human beings whose lives it touches. See the Introduction.

**Superstar firms**

> Term from the economics literature—associated with the paper by Autor, Dorn, Katz, Patterson, and Van Reenen in the Quarterly Journal of Economics (May 2020)—for the small number of firms in each industry capturing an increasing share of industry sales, associated with rising corporate profits, falling labor share of income, and rising within-industry concentration across the American economy since the early 1980s. See Chapter 4.

**Telecommunications Act of 1996**

> Federal legislation signed by President Clinton on February 8, 1996 (passed 414-16 in the House, 91-5 in the Senate) that lifted caps on the number of radio stations a single company could own nationally, eliminated cross-ownership rules in some markets, and enabled the merger waves that produced the modern media-telecommunications conglomerates. Sold as a deregulation that would increase competition; the empirical record over 30 years has not supported this prediction. See Chapter 3.

**Third-party doctrine**

> The Supreme Court doctrine, originating in United States v. Miller (1976) and Smith v. Maryland (1979), that individuals have no Fourth Amendment reasonable expectation of privacy in information voluntarily shared with third parties. Applied to digital-era communications, the doctrine has been used to justify warrantless government access to records held by banks, telephone companies, and internet platforms. The Court has partially retreated from the doctrine's strongest applications in Carpenter v. United States (2018). See Chapter 3.

**Twenty-eight Pages, the**

> The previously classified section of the December 2002 Joint Inquiry report of the Senate and House Intelligence Committees, documenting specific contacts between two September 11 hijackers and individuals connected to the Saudi consulate in Los Angeles. Declassified on July 15, 2016, after a fourteen-year public campaign led by Senator Bob Graham. Available through the Office of the Director of National Intelligence's declassification web portal. See Chapter 8.

**Uthmanic recension**

> The standardization of the Quranic text under the Caliph Uthman in the mid-seventh century, which produced an official recension and the destruction of variant manuscripts. The historical fact of the recension is documented in Islamic theological literature and is not, within Islamic scholarship, a controversial fact; the theological interpretation of what it means for the text's divine preservation is contested across scholarly traditions. See Chapter 5.

**Worker cooperative**

> A firm owned and democratically governed by its workers, in which each worker-member holds one vote regardless of capital contribution and profits are distributed substantially to worker-owners rather than to outside shareholders. The Mondragon Corporation (Basque region, Spain) is the world's largest federation of worker cooperatives, with and 70,000 employees. The United States Federation of Worker Cooperatives (usfwc.coop) maintains a directory of U.S. co-ops. See Chapter 13.

**Zoroastrianism**

> The monotheistic religion founded by the prophet Zarathustra (Zoroaster) in northeastern Iran (traditionally dated to approximately 1500–1000 BCE), which served as the state religion of the Achaemenid Persian Empire (6th–4th century BCE) and the Sasanian Persian Empire (3rd–7th century CE). Its theological concepts—including final judgment, bodily resurrection, cosmic dualism, and end-of-history eschatology—are documented by scholar Mary Boyce to have entered Second Temple Jewish apocalyptic literature during the Persian period and, through that literature, to have shaped Christian eschatology. See Chapter 5.

**INDEX**

*Page numbers are approximate and based on the manuscript as submitted. Final published page numbers may differ. Entries containing "See" and "See also" cross-references point the reader to the preferred indexing term.*

**A**

Affordable Care Act (2010) 5, 51, 390, 406

Afghanistan, reconstruction 296–300

Afghanistan, Soviet war (Operation Cyclone) 177–185, 416

AIPAC (American Israel Public Affairs Committee) 7, 207–210

al-Bayoumi, Omar 218, 222, 224

al-Qaeda, origins 183–185, 193

Altman, Annie (litigation) 336, 353–356

Altman, Sam (OpenAI) 336, 347–358

*American Israel Public Affairs Committee. See AIPAC*

Amodei, Dario (Anthropic) 336, 358–368

Antitrust Paradox, The (Bork, 1978) 96, 98, 414

Azár, Schmalz, Tecu (airline pricing study) 5, 103–104, 108

**B**

Bagdikian, Ben (The Media Monopoly) 70–71

Balaji, Suchir (death of) 350–353

Bank of North Dakota 393–394

BAPCPA (Bankruptcy Abuse Prevention and Consumer Protection Act, 2005) 45, 47–48, 51–52, 415

Bernstein, Carl ('The CIA and the Media,' 1977) 84, 403

Big Three asset managers 4, 91–110, 415

BlackRock 92–96, 101, 108, 110, 113. See also Big Three

Boyce, Mary (historian, Zoroastrianism) 8, 125, 133–137, 416

Bremer, L. Paul (CPA Orders 1 and 2) 193–198

*Brown University Costs of War Project. See Costs of War Project*

Brzezinski, Zbigniew (Operation Cyclone) 178–181, 403, 415

Building 7 (WTC) 219–222

**C**

Carter, Jimmy (Afghanistan presidential finding) 178–179

*CFPB. See Consumer Financial Protection Bureau*

Chomsky, Noam, and Herman, Edward S. (Manufacturing Consent) 72, 416

Church Committee (1976) 21–23, 84, 178, 403

Citizens' Commission to Investigate the FBI (1971) 23–24

Clinton, Bill (Telecommunications Act) 73, 417

COINTELPRO 21–26, 32, 415

*Common ownership. See asset-management common ownership*

Consumer Financial Protection Bureau (CFPB) 52, 84, 328, 415

CORPNET project (Fichtner, Heemskerk, Garcia-Bernardo) 93–96, 415

Costa Rica (army abolition) 386–387

Costs of War Project (Brown University) 153–157, 403, 415

CPA Order 2 (dissolution of Iraqi army) 193–198

**D**

Dead Sea Scrolls 130, 133, 415

De-Ba'athification (CPA Order 1) 193–198

Denmark (flexicurity) 382–384

Department of Defense audit failures 271–282, 416

Dever, William G. (Did God Have a Wife?) 8, 125, 141–142

*Disinformation. See manufactured division*

**E**

Ehrman, Bart (Lost Christianities) 131, 144

Engine No. 1 (ExxonMobil proxy campaign) 330

Evergreen Cooperatives (Cleveland) 384

**F**

F-35 Joint Strike Fighter 283–285, 290

Facebook Files 26–29, 415

Fair Credit Reporting Act (FCRA) 421

False Claims Act (qui tam) 322–323, 416

*FARA. See Foreign Agents Registration Act*

Federal Reserve Act (1913) 48–49

FISA / Section 702 85–87, 416

Flexicurity (Denmark) 382–384, 416

*FOIA. See Freedom of Information Act*

Foreign Agents Registration Act (FARA) 7, 207–210, 416

Freedom of Information Act (FOIA) 303–305, 416

**G**

Germany (codetermination) 379–381

Gilens, Martin, and Page, Benjamin 292–295, 416

Glass-Steagall Act (1933) 110–111, 416

Government Accountability Office (GAO) 280–282, 284

Gramm-Leach-Bliley Act (1999) 110–111, 416

Graeber, David (Debt: The First 5,000 Years) 43

**H**

Haiti (debt indemnity) 50–51

Hamas (Israeli containment policy) 198–206

Haugen, Frances 26–29

Hegseth, Pete (Anthropic dispute) 364

Household debt (U.S., 2024) 43–46

Hulsey, Leroy (UAF Building 7 study) 220–222

Himmelstein, David (medical bankruptcy study) 48

**I**

Inflation Reduction Act (2022) 252

Insulin pricing 249–255, 421

Iraq (2003 invasion) 149–160, 193–198

ISIS, origins of 193–198

Israel–Palestine conflict 198–210

**J**

Jekyll Island meeting (1910) 48–49, 416

Justice Against Sponsors of Terrorism Act (JASTA, 2016) 218, 223

**K**

Kaiser Family Foundation (medical debt report, 2022) 51, 421

Karp, Alex (Palantir) 336, 339–345

KC-46 Pegasus tanker program 288–291

Kean, Thomas, and Hamilton, Lee (Without Precedent) 220, 228

Khashoggi, Jamal (murder of) 165

King James Bible (1611) 8, 125, 137–139

**L**

Libya (2011 intervention) 161–163

Local news collapse 88–89

Loper Bright Enterprises v. Raimondo (2024) 329

**M**

Manufactured division 20–38

Marquette National Bank v. First of Omaha (1978) 52

Masoretic tradition 129–130, 416

Massachusetts (near-universal coverage) 391–392

Medicare drug-price negotiation 258–260

*Mitbestimmung. See codetermination*

Mondragon Corporation 384–385, 416

Moussaoui v. Kingdom of Saudi Arabia 218, 222–225

**N**

Netanyahu, Benjamin (Hamas strategy) 198–204

News deserts 88–89, 416

NIST NCSTAR 1A (Building 7 report) 219–222

9/11 Commission Report 152, 213, 217, 226–228

North Dakota (public bank) 393–394

Norton, David (textual history, KJV) 8, 125, 137–139

**O**

Obama, Barack (Libya mistake) 162

OECD Health Statistics 242–244

Operation Cyclone 177–185, 416

Operation Mockingbird 83–85, 403, 416

OpenAI 347–358

Opioid crisis (OxyContin, Purdue Pharma) 256–262

**P**

Palantir Technologies 339–345

Petrodollar system 149–151, 163–166, 416

Phoenix Memo (FBI, July 10, 2001) 213–214, 403

Pharmacy benefit managers (PBMs) 252, 416

Project on Government Oversight (POGO) 291–292, 421

Propaganda model (Herman and Chomsky) 72, 416

Public Banking Institute 394, 421

Purdue Pharma / Sackler family 257–262

**Q**

Qatar (cash transfers to Hamas) 199–204

*Qui tam. See False Claims Act*

**R**

Reagan administration (antitrust doctrine) 98, 415

Regulatory capture 258, 416

Revolving door (DoD–contractor) 291–293, 416

Robb-Silberman Commission (2005) 3, 152, 401

Romney, Mitt (Massachusetts healthcare reform) 391

**S**

*Sackler family. See Purdue Pharma*

Saudi Arabia (U.S. alliance) 164–165, 218, 222–225

Section 230 (CDA) 88, 416

*Section 702. See FISA / Section 702*

Senate Intelligence Committee report (Iraq, 2004) 3, 152, 403

September 11 (2001) 1–4, 33–34, 211–232

Sherman Antitrust Act (1890) 95, 405, 416

SIGAR / SIGIR 296–300, 416

Singapore (public housing) 387–389

Sinclair Broadcast Group 75–76

Smith, Mark S. (Origins of Biblical Monotheism) 8, 125, 141–143

Snowden, Edward 85

Sodhi, Balbir Singh (murder of) 3

Standard Oil (1911 breakup) 95

State Street Global Advisors 92–96. See also Big Three

Structural humanism 5–6, 416

Student debt 43–47, 52–53

Superstar firms (Autor et al.) 108–109, 416

**T**

Telecommunications Act (1996) 69–70, 73–78, 417

Third-party doctrine 87, 417

Trans fats (regulatory delay) 255–259

Trump administration (second, 2025) 6, 52, 360, 364

Twenty-eight Pages 212, 217–219, 224–225, 403, 417

**U**

*University of Alaska Fairbanks (Building 7 study). See Hulsey, Leroy*

USASpending.gov 283, 421

USS Liberty (1967 attack) 206–207

Uthmanic recension 131, 417

**V**

Vanderlip, Frank (Jekyll Island) 48–49

Vanguard Group 92–96, 101, 110. See also Big Three

Venezuela (sanctions) 163–166

Vienna (social housing) 389

**W**

Wallace, David Foster ('This Is Water' speech) 1

Warren, Elizabeth (Two-Income Trap) 53

Williams, Kenneth (Phoenix Memo) 213–214

Worker cooperatives 384–385, 417

*World Trade Center Building 7. See Building 7 (WTC)*

**Z**

Zoroastrianism / Zoroastrian sources 125, 133–137, 417

**A Final Note**

I owe the reader a final piece of honesty before the book ends.

This book has been written across more than a year of reading, drafting, revising, and arguing with editors, advisors, friends, family, and the artificial-intelligence drafting tools I disclosed at the beginning. The book is not perfect. There are claims in it I will, in five years, wish I had stated more carefully. There are arguments I will, in ten years, regret making at all, and there are arguments I will, in ten years, wish I had made more forcefully. The honest acknowledgment of this is the precondition of any serious nonfiction. A book that pretends to a finality the evidence does not support is a book whose author has not done her work. I have tried not to write that book.

What I am confident of, at the end, is the following. The empirical record on which the book’s major claims rest is documented in the sources I have cited and is verifiable by any reader willing to do the verification. The moral framework that organizes the argument — the dignity of the human beings whose lives are touched by American institutions, and the demand that those institutions exist to serve that dignity rather than to extract from it — is the moral framework of the major prophetic religious traditions, of the secular humanist tradition, and of the constitutional commitments the American republic was founded on. The reform agenda that flows from the framework and the evidence is documented in the policy literature and operating in successful arrangements elsewhere. The barrier to enactment is political, not technical. The political work is the work of citizens willing to do it. The work is slow. The work is the only thing that has ever produced the reforms a humane society depends on.

I am one writer. The book is one entry in an ongoing argument that began long before I joined it and will continue long after I leave it. The argument is the argument of every generation of American citizens who have taken seriously the proposition that the republic exists for the people who live in it rather than for the institutions that profit from them. I am grateful to have been able to contribute to the argument. I am more grateful for the readers who will carry the argument forward into the work the book has been pointing toward.

We are not stupid. We are managed. The difference matters. The work begins.

Kai Jashon Price

Jacksonville, North Carolina

structuralhumanism.com
