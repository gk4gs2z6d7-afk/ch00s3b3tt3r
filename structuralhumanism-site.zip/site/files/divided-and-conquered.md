# Divided and Conquered

*How the Oldest Weapon in History Is Still Being Used Against You*

**Kai Jashon Price** · Structural Humanism Series — Document I · 2025
— structuralhumanism.com —

---

## The Single Engineering Problem

Before you can control a large number of people without constant violence, you have to solve one problem: what happens when they all get together and realize they have the same grievances?

The answer, refined across every civilization in recorded history, is elegantly simple. You make sure they never do. You give them identities — tribe, nation, religion, race, political party — that feel more urgent than their shared humanity. You make those identities feel natural and eternal rather than constructed and contingent. Then you step back and let them exhaust themselves fighting each other while you consolidate power above the fray.

**The capacity for tribalism is human nature — psychologists have shown that people will form loyal in-groups over distinctions as trivial as which painting they prefer. But which divisions become urgent, armed, and permanent is a managed condition. The same human beings who will kill a stranger over a flag will die trying to save that same stranger from a burning building.**

September 11th proved the second half of that sentence. For seventy-two hours, Americans of every background stood in the same blood donation lines, carried each other down fifty flights of stairs, and grieved together in public. The tribalism that is the normal background noise of American life disappeared. The question this document asks is not why September 12th happened. The question is why we can only access that version of ourselves when catastrophe forces it — and what structural mechanisms prevent it the rest of the time.

*SOURCE: Tajfel, H. (1970). Experiments in Intergroup Discrimination. Scientific American, 223(5). | Gramsci, A. (1971). Prison Notebooks. International Publishers. | Zinn, H. (1980). A People's History of the United States. Harper & Row.*

## The Documented History of Manufactured Division

This is not a new observation. Machiavelli described divide and rule in the 1500s as the foundational art of maintaining power over populations that outnumber their rulers. The British Empire turned it into formal administrative doctrine — deploying it in India, Africa, and the Middle East to manage populations that vastly outnumbered colonial administrators. The result in each case: people with more in common with each other than with their rulers spent their energy fighting the group next door while rulers extracted labor, land, and resources unmolested.

In the United States, the most thoroughly documented modern application of this mechanism was COINTELPRO — the FBI program running from 1956 to 1971. Its existence and methods were officially confirmed by the Church Committee Senate investigation in 1975. Its explicit goal, documented in internal FBI memoranda: prevent the rise of a "Black messiah" who could "unify and electrify" a broad movement. The tactic was not open suppression — it was manufactured division. Forged letters between organizations. Planted informants who created internal conflicts. Fabricated evidence designed to produce distrust between allied groups. The program succeeded not by defeating the movement ideologically but by ensuring solidarity remained structurally impossible.

**Every time ordinary people across tribal lines have organized together — the interracial labor movements of the early 20th century, the Poor People's Campaign of 1968 — the institutional response was infiltration, discrediting, and manufactured division. The pattern is documented. It is not a theory.**

The modern version operates without requiring FBI programs. Political parties offer two flavors of the same economic arrangement while conducting culture war at the level of rhetoric. Media covers culture war stories rather than class interest stories. Algorithms designed to maximize engagement discovered that outrage, fear, and tribal identity outperform information in capturing attention — and built products accordingly. No central coordinator is required. The incentives do the work automatically.

*SOURCE: Church Committee Final Report (1976). US Senate Select Committee to Study Governmental Operations. | O'Reilly, K. (1989). Racial Matters: The FBI's Secret File on Black America. Free Press.*

## Who Controls What You Think: The Media Architecture

In 1983, roughly fifty companies controlled the majority of American media. By the 2010s the legacy core — film, television, and national news — had consolidated into a handful: Comcast, Disney, Warner Bros. Discovery, Paramount, News Corp, and Sony. That consolidation is documented market structure, not interpretation. But the modern architecture has a second layer the old ownership statistic misses: the discovery layer. Federal court findings in the Google antitrust litigation put the company's share of general search at roughly ninety percent. Pew Research finds about half of American adults now get news through social platforms whose feeds are curated by a few engagement algorithms. And in local television — the news Americans report trusting most — two companies, Sinclair and Nexstar, own stations reaching most of the country. The consolidation happened gradually through mergers that each appeared isolated and each received regulatory approval — and the cumulative result is an information landscape in which what gets amplified is determined by a few boardrooms and a few algorithms.

Edward Herman and Noam Chomsky's propaganda model, published in Manufacturing Consent (1988), identified five filters through which this operates without requiring central coordination: ownership concentrated in profit-driven corporations; advertising revenue favoring content supportive of consumerism; sourcing reliance on official government and corporate voices; institutional "flak" punishing deviations from acceptable discourse; and ideological marginalization of perspectives that challenge the arrangement. No conspiracy is required. The filters are structural. The incentives are automatic.

The most concrete documented evidence of ownership-driven content control came from the Sinclair Broadcast Group in 2018. Sinclair owned approximately 200 local television stations across the United States — the local news that a significant portion of Americans trust more than national outlets. Deadspin published a video compilation documenting that Sinclair required anchors at every one of its stations to read identical mandatory editorial scripts. The footage showed dozens of local anchors in different cities, on different stations, delivering word-for-word identical content on the same day. The Columbia Journalism Review and The Guardian subsequently documented this as a direct application of centralized ownership to local news content. This is not theoretical structural bias. It is a documented ownership-driven editorial mandate, traceable to a single corporate decision.

*SOURCE: Bagdikian, B. (2004). The New Media Monopoly. Beacon Press. | United States v. Google LLC (D.D.C. 2024), findings on search market share. | Pew Research Center, Social Media and News Fact Sheet. | Herman, E. & Chomsky, N. (1988). Manufacturing Consent. Pantheon. | Deadspin (April 2, 2018). Sinclair's Soldiers in Trump's War on Media. | Columbia Journalism Review, Sinclair consolidation coverage.*

## The Facebook Papers: When the Company's Own Research Proves It

Frances Haugen, a former Facebook data scientist, disclosed internal company documents to the Securities and Exchange Commission and to Congress in 2021. The documents — subsequently published as the Facebook Papers — revealed that Meta's internal research showed the company's algorithm was actively amplifying content that produced outrage, division, and tribalism because it generated higher engagement than accurate or constructive content. The company knew this. Its own researchers documented it. The company chose not to change the algorithm because the engagement served advertising revenue.

This is not an inference about what social media does. It is the company's documented internal admission of what it knew and chose to continue. The platform that two billion people use to understand the world was deliberately designed — with full internal knowledge of the consequences — to prioritize tribal outrage over accurate information because outrage is more profitable.

**We are not stupid. We are managed. The system does not require us to be ignorant by nature — it requires only that the incentives for managing our attention be more powerful than the incentives for informing it.**

*SOURCE: Haugen, F. Congressional testimony (October 5, 2021). | The Facebook Papers. Wall Street Journal, The Atlantic, and consortium of news organizations (October 2021).*

## The Overton Window: How the Range of Acceptable Thought Is Managed

The Overton Window describes the range of ideas that can be discussed in mainstream political discourse without the speaker being dismissed as extreme. The insight is simple and structurally important: the window's position at any given moment does not primarily reflect the merits of the ideas inside and outside it. It reflects the resources available to the institutional actors with interests in its position.

Medicare drug price negotiation — allowing the largest pharmaceutical purchaser in the country to negotiate prices the way every other large purchaser in every other industry does — was outside the Overton Window for twenty years. It entered the window when political cost of its absence exceeded the lobbying capacity to keep it out. The policy did not become more rational. The power balance shifted. The window moved.

Once a population understands that the range of acceptable political discussion is itself a managed artifact rather than a natural feature of reality, the window loses a significant portion of its power. This is why the institutions with the most to lose from an informed citizenry invest in maintaining the window's position. It is also why the first act of structural reform is always naming what is happening — which is what this document is.

*SOURCE: Overton, J. The Overton Window. Mackinac Center for Public Policy. | Herman & Chomsky (1988), Chapter 1.*

## What This Means and What to Do

The three mechanisms documented above — tribal division, consolidated media ownership with algorithm-driven amplification, and managed discourse windows — are not independent failures. They are reinforcing components of the same system. A population divided by tribe cannot build the solidarity that threatens concentrated power. A population receiving algorithmically filtered information cannot accurately assess its condition. A population operating within a managed discourse window cannot conceive of solutions that fall outside it.

Understanding the architecture is the first requirement of dismantling it. The second is refusing to participate in its mechanisms: choosing information sources with documented independence, seeking out people across tribal lines who share structural interests rather than tribal identities, and applying the same evidentiary standard to institutional claims that you apply to any other claim.

The third is the hardest: recognizing that the solidarity available on September 12th is always available, and that the only thing preventing it on September 10th is the system's successful management of our attention. The system is not all-powerful. It requires our participation. Every person who withdraws that participation — who refuses to perform the tribal role assigned to them — weakens it by exactly that much.

The river does not ask permission. It simply flows.
