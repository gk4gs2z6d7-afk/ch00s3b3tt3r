# What They Did in Your Name

*The Documented Record of Foreign Policy, Manufactured Enemies, and Suppressed Accountability*

**Kai Jashon Price** · Structural Humanism Series — Document III · 2025
— structuralhumanism.com —

---

## The Question Nobody Follows to Its Conclusion

In February 2003, Secretary of State Colin Powell presented intelligence to the United Nations Security Council establishing that Iraq possessed weapons of mass destruction and maintained links to al-Qaeda. Every major claim in that presentation was false. The intelligence had been fabricated, cherry-picked, and distorted by an intelligence apparatus responding to political pressure. Powell himself later called it a "blot" on his record. No weapons were found. No credible al-Qaeda link was established. Approximately 4,400 American service members died. Estimates of Iraqi civilian deaths range from 150,000 to over a million, depending on methodology.

**If the government lied about Iraq with this level of institutional commitment and consequence, the honest question is not whether that was a unique failure. The honest question is what else the same apparatus has lied about — and what the documented record shows when you look.**

Plato observed in the Republic that the justice of a nation can be read the same way the justice of a person can — by asking whether its stated principles and its actual conduct are aligned. A nation that demands honesty from citizens while presenting fabricated intelligence to justify war; that demands lawfulness from citizens while ignoring its own foreign lobbying registration statutes; that demands nonviolence from citizens while arming networks that become its declared enemies — is not a just nation experiencing temporary lapses. It is a nation whose institutions have normalized the gap between stated principle and operational conduct. What follows is that gap, documented.

*SOURCE: Powell, C. UN Security Council Presentation (February 5, 2003). | Senate Intelligence Committee Report on Pre-War Intelligence on Iraq (2004). | Iraq Body Count Project (2024). | Plato. Republic, Book IV, 434c-444e.*

## Operation Cyclone: The Ecosystem America Built

In 1979, the Carter administration authorized Operation Cyclone — a CIA program to arm and finance Afghan mujahideen fighters resisting the Soviet presence in Afghanistan. The program channeled approximately $3 billion through Pakistani intelligence (ISI) to fighters whose ranks included the networks that became al-Qaeda.

In a 1998 interview with the French magazine Le Nouvel Observateur, Zbigniew Brzezinski — Carter's National Security Advisor and the architect of the program — stated that the operation had begun before the Soviet invasion, not in response to it. The July 1979 presidential finding authorized aid — officially nonlethal — to the insurgents months before Soviet tanks crossed the border, and Brzezinski described the purpose as drawing the Soviets into their own Vietnam. Portions of that interview's translation have been contested; the date of the finding has not. "What is most important to the history of the world?" Brzezinski asked the interviewer. "The Taliban or the collapse of the Soviet empire? Some stirred-up Muslims or the liberation of Central Europe and the end of the Cold War?"

Precision matters here, because the record is damning enough without overstatement. Steve Coll's Ghost Wars — the definitive account — documents that CIA money and weapons flowed through Pakistani intelligence to Afghan mujahideen commanders, while Osama bin Laden and the Arab volunteers were financed separately, by Gulf donors and bin Laden's own fortune. There is no documented evidence that CIA funds or training went to bin Laden directly, and this document does not claim there is. What the record does establish is this: the United States co-built the ecosystem — the training pipeline, the weapons flow, the ISI infrastructure, the global recruitment of jihadist volunteers it welcomed as allies against the Soviets — and then walked away from Afghanistan when the Soviets left. Al-Qaeda organized itself inside the infrastructure that American policy helped create and then abandoned. The network that killed 2,977 Americans on September 11, 2001 was not built on a CIA payroll. It was incubated in a war America funded, in an ecosystem America's policy assembled — and the architect of that policy, on the record, considered the trade worth it.

*SOURCE: Brzezinski, Z. Interview. Le Nouvel Observateur (January 15-21, 1998). | Coll, S. (2004). Ghost Wars: The Secret History of the CIA, Afghanistan, and Bin Laden. Penguin. | 9/11 Commission Report (2004), Chapter 2.*

## Hamas and the Documented Containment Strategy

The Israeli government's relationship with Hamas has been documented by Israeli journalists and officials as a deliberate strategic choice rather than a security failure. The logic was specific: a strong Hamas governing Gaza prevented the emergence of a unified Palestinian political leadership capable of credibly negotiating a two-state settlement. A divided Palestinian polity — with Hamas controlling Gaza and the Palestinian Authority controlling parts of the West Bank — could not produce the unified negotiating partner that international pressure demanded.

Barak Ravid, reporting for Axios in November 2023 based on statements from multiple Israeli officials, documented that Prime Minister Netanyahu had actively encouraged Qatari financial transfers to Hamas in Gaza as a mechanism to sustain this division. The transfers — which Qatar made with Israeli knowledge and approval — provided Hamas with the financial capacity to govern Gaza and maintain its political position. The strategy treated Hamas as a manageable tool for preventing a political solution.

The October 7, 2023 attack did not occur despite this strategy; it grew inside the capacity the strategy sustained. Causation in history is never single-threaded, and Hamas bears the agency for its own atrocity — but a policy designed to keep Hamas strong enough to govern cannot disclaim the strength it purchased. A strategy that deliberately sustained a hostile governing entity to avoid a political resolution helped produce a humanitarian catastrophe on both sides of the boundary. The pattern — creating or sustaining an adversary to avoid a solution — matches the Afghanistan case with structural precision.

*SOURCE: Ravid, B. (November 2023). Axios. | Harel, A. (2023). Ha'aretz analysis of Hamas-Qatar-Israel financial relationship. | UN Security Council Resolution 242 (1967), establishing two-state framework.*

## The USS Liberty: What Suppressed Accountability Looks Like

On June 8, 1967, Israeli air and naval forces attacked the USS Liberty, a clearly marked American intelligence vessel operating in international waters during the Six-Day War. The attack lasted approximately two hours. Thirty-four American sailors were killed. One hundred seventy-one were wounded. The ship flew an American flag throughout the attack. Its hull markings were visible from the air.

The U.S. Navy's Court of Inquiry was convened within days and completed within a week — the fastest resolution of an inquiry into a military attack of this magnitude in American naval history. Ward Boston, the Navy attorney who led the inquiry, signed a sworn affidavit in 2003, stating: "I know from personal conversations I had with Admiral Kidd that President Lyndon Johnson and Secretary of Defense Robert McNamara ordered him to conclude that the attack was a case of 'mistaken identity' despite overwhelming evidence to the contrary."

Admiral Thomas Moorer, former Chairman of the Joint Chiefs of Staff, stated publicly in 2004 that the Liberty investigation had been a cover-up ordered at the highest levels of the Johnson administration. Thirty-four American sailors died in an attack on a clearly marked American vessel, and the official investigation was ordered to reach a predetermined conclusion. No criminal accountability followed. No diplomatic consequence followed. The crew members who survived spent decades attempting to obtain a genuine inquiry and did not receive one.

The strongest case against this reading must be stated, because the project's own standard requires it. Roughly a dozen official American and Israeli reviews over the decades endorsed the mistaken-identity conclusion; NSA intercepts declassified in 2003 were read by some analysts as consistent with genuine confusion among the attacking forces; and Judge A. Jay Cristol's book-length study, The Liberty Incident, argues the attack was a tragic error of war. A serious reader should weigh that record. But it does not answer the narrower, documented indictment: a one-week Court of Inquiry into the deaths of thirty-four American sailors — the fastest such inquiry in American naval history — whose own senior legal counsel swore under oath that its conclusion was ordered in advance. Whatever happened in the air over the Liberty, what happened inside the inquiry is attested by the man who helped run it. An investigation whose verdict precedes its evidence is not an investigation, whichever side its verdict favors.

**James Ennes, a lieutenant aboard the Liberty during the attack, spent the rest of his life documenting what happened and what was suppressed. He died in 2020 without seeing accountability. The sworn affidavit of the Navy's own lead attorney exists in the public record. The conclusion it indicts also exists in the public record. Both cannot be true.**

*SOURCE: Boston, W. Sworn Affidavit (January 9, 2004). | Ennes, J. (1979). Assault on the Liberty. Random House. | Moorer, T. Capitol Hill Club Statement (2004). | Cristol, A.J. (2002). The Liberty Incident. Brassey's. | NSA USS Liberty document release (2003). | National Security Archive, USS Liberty documents.*

## The American Zionist Council, AIPAC, and the FARA Evasion

In 1962, Senator J. William Fulbright, Chairman of the Senate Foreign Relations Committee, launched an investigation into the American Zionist Council — a lobbying organization receiving funds from the Jewish Agency, an arm of the Israeli government — for operating as an unregistered foreign agent. The Foreign Agents Registration Act requires any organization operating on behalf of a foreign government's interests to register with the Justice Department and disclose its activities. The AZC had not registered.

The investigation produced documented evidence of the funding relationship. The Justice Department requested registration. The AZC did not comply. Instead, in 1963, it reorganized under a new name: the American Israel Public Affairs Committee — AIPAC. AIPAC has never registered as a foreign agent — and the legal distinction must be stated plainly, because it is the strongest rebuttal to any insinuation beyond the record. FARA turns on an agency relationship: direction or control by a foreign principal, not alignment of views. AIPAC today is funded by American citizens, no court has held it to be a foreign agent, and this document makes no such claim. The documented foreign-government funding belongs to the AZC, in 1962. What remains documented about the successor organization is its influence: AIPAC became the most consequential foreign policy lobbying organization in Washington by most standard measures, with documented influence over congressional career outcomes and American Middle East policy for six decades.

The Kennedy administration's documented pressure on the AZC to register under FARA was the last serious American governmental enforcement attempt against this organizational lineage. The structural pattern: an organization with documented foreign-government funding faced a registration demand, dissolved, and was succeeded by an organization structured so the statute no longer reached it — and the enforcement effort was never reconstituted, for this lineage or, with rare exceptions, for any comparable lobby. The transparency the statute promised has gone unenforced for sixty years. What is documented is the evasion and its consequences. The cause of why the enforcement effort ended is theory. The structural beneficiary of its ending is not.

*SOURCE: Senate Foreign Relations Committee Hearings on Foreign Agents (1962-1963). | FARA registration database, Department of Justice. | Fulbright, J.W. Congressional Record (1963). | Mearsheimer, J. & Walt, S. (2007). The Israel Lobby and U.S. Foreign Policy. Farrar, Straus and Giroux.*

## The Pattern and What It Demands

Four cases. The American-built ecosystem that incubated al-Qaeda. Israeli-sustained Hamas. Suppressed USS Liberty accountability. Sixty years of unregistered foreign lobbying. Each case involves an official account that diverges from the documented record, a suppressed accountability process, a structural beneficiary of the suppression, and a continuing policy built on the official account rather than the documented one.

The cases span different actors, different decades, different geographies. What connects them is not a single conspiracy. It is a single institutional logic: when accountability costs more politically than suppression, suppression is chosen, and the information architecture is adjusted accordingly.

The honest response is not conspiracy theorizing and not cynicism. It is the application of the same evidentiary standard to government claims that governments apply to citizens: documentation, verification, and accountability for the gap between what was said and what the record shows. The record is public. The gap is visible. The question is whether enough people look at it to make the cost of the gap higher than the cost of closing it.
