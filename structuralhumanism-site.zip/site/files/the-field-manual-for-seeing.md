# The Field Manual for Seeing

*Forty-Nine Meditations on Structural Humanism*

**Kai Jashon Price** · Meditations — Practice · 2025
— structuralhumanism.com —

---

> *You will not find what you are looking for in this book.*
>
> *You will find it after you put the book down.*

**How to Use This Book**

This is not a book of arguments. The arguments are elsewhere. The evidence is elsewhere. The proposals are elsewhere.

This is a book of seeing. Forty-nine short meditations, each one asking you to notice something about the world you live inside. You do not need to read them in order. You do not need to read them all. You do not need to agree with them. You only need to let one of them, occasionally, change what you see when you look up from the page.

Carry it. Open it when you are in line at a coffee shop. Open it when your phone has done what your phone does. Open it before bed when the day has been too much. Read one. Sit with it for a minute. Close the book. Look at whatever is in front of you.

That is the practice. The book is only the prompt. The work is what you see after.

*— K.P.*

*I.*

**On the Cage**

*01*

**The Water**

Two young fish are swimming along and they meet an older fish. The older fish nods and says, "Morning, boys. How is the water?" The two young fish swim on. Eventually one of them looks at the other and says, "What the hell is water?"

This is David Foster Wallace's parable. He told it to a graduating class at Kenyon College. Two years later he killed himself.

The parable is correct. The water is what you do not see because you are inside it. The water is the assumption that the way things are is the way things have to be. The water is what makes the strangeness of being alive feel normal. It is also what makes the cruelty of certain arrangements feel like weather rather than choice.

The first act of structural humanism is to ask: what is the water? Not to escape it. You cannot escape it. To see it. Seeing it changes nothing externally. Seeing it changes everything internally. That is where the work begins.

> *Look around. What is the water you are in right now?*

◆

*02*

**The Cage and the Sky**

A bird born in a cage will fly. Open the door of a cage in which a bird has been born, and the bird will sit on the perch and look at the door for a while, and then go back to eating. You can leave the door open all day. The bird has internalized the cage. The cage no longer has bars. The cage has become the bird's idea of what space is.

This is not a metaphor for other people. It is a description of you. It is a description of me. The cages we live inside have stopped having bars because we have stopped reaching for them. The reaching stopped because the reaching produced nothing and the reaching became embarrassing and the reaching marked us as someone who had not yet learned how things work.

But the sky is still there. The sky was always there. The cage is the smaller fact. The sky is the larger one. A life lived inside the cage of the present arrangement is a life that has accepted the smaller fact and forgotten the larger one.

> *The bars are not the bars. The bars are the belief that the bars are real.*

◆

*03*

**The Question That Costs Nothing**

A child asks why. The child asks why ten thousand times. Eventually the adults in the child's life teach the child to stop asking. The teaching is not deliberate. The teaching happens because every adult is tired and the child's question is the question the adult stopped asking years ago and the question makes the adult feel something the adult does not want to feel.

The questions get answered with phrases. That is just how it is. That is the way things work. Life is not fair. The child accepts the phrases because the child wants the adults to love them, and the adults love the child more easily when the child stops asking.

You can start asking again. The cost is nothing. The cost is feeling, for a few minutes, like a child again — which is to say, like a person who has not yet been trained out of seeing.

> *Why is it like this? Ask. Out loud. To no one. See what you notice.*

◆

*04*

**What You Were Not Told**

Every person who has ever been managed was managed in part by what they were not told. The lie of omission is more powerful than the lie of commission because the lie of omission cannot be caught. The thing that is not there cannot be cross-examined.

You were not told that the war you grew up watching was based on intelligence that the people running it knew was wrong. You were not told that the prescription medication that was supposed to be safer was the product of internal documents the company's own scientists had marked as fraudulent. You were not told that the financial collapse was the predictable result of a deregulatory choice made by people who profited from it. You were not told a great many things.

You were not told because the people who decide what you are told decided that what you would do if you were told was not in their interest. The most consequential decisions about your life have been made by people who calculated, accurately, that you would not be informed enough to oppose them.

The remedy is not anger. The remedy is reading. The remedy is the slow accumulation of what you were not told, until the absence becomes the most informative thing in the room.

◆

*05*

**The Two Stories**

There is a story that explains why your life is hard. The story is that you have not worked hard enough, that you have made bad choices, that other people who are worse than you have taken what was meant for you. The story is delivered to you through screens that have been engineered to deliver it.

There is another story. The other story is that the arrangement you live inside has been built, over decades, by people whose interests are not your interests, who have written rules that route money and attention and time away from you and toward themselves, and who depend on you believing the first story.

You can spend the rest of your life inside the first story. Many people will. The first story has the advantage of being familiar, and of being agreed upon by most of the people you know, and of asking nothing of you that you have not already given.

The second story asks something. The second story asks you to look at the rules and ask who wrote them. The second story is not more comfortable. It is more accurate. You get to choose.

◆

*06*

**The Permitted Argument**

Every authoritarian arrangement permits a certain amount of public argument. The permitted argument exists to absorb the energy that would otherwise produce structural change. The permitted argument is not a sign that the arrangement is open. The permitted argument is a sign that the arrangement has learned how to manage opposition without changing.

You can tell a permitted argument because the participants on both sides agree on what the argument is about. The permitted argument in America is whether the next administration should be the red one or the blue one. The unpermitted argument is whether the arrangement that produces a choice between two managed factions is itself the problem.

Listen to the next political conversation you hear. Listen for what is being argued about. Listen for what is being assumed. The assumption is the permitted ground. The permitted ground is where the cage stops being visible.

> *The argument is the distraction. The agreement underneath the argument is the architecture.*

◆

*07*

**The Word Conspiracy**

The word conspiracy is used in two ways. The first use is the technical legal meaning: an agreement between two or more people to commit an unlawful act. By that definition, conspiracies happen constantly, are prosecuted regularly, and have shaped every domain of modern life.

The second use is rhetorical. The second use deploys the word to discredit the person using it. The accusation is not that the person is wrong about a specific fact. The accusation is that the person belongs to a category of people who can be dismissed without engagement.

The trick is that the two meanings sound the same. Anyone who points to a documented agreement between powerful actors to do something the public would not consent to is calling out a conspiracy in the first sense. The response converts the word into the second sense and the documentation no longer needs to be answered.

Watch for the conversion. It is one of the most powerful rhetorical moves in contemporary discourse. The conversion is what allows documented facts to be dismissed as paranoia. The conversion is, itself, the conspiracy.

◆

*II.*

**On the Self Inside the Cage**

*08*

**The Algorithm Knew First**

You picked up your phone. Before you knew why you picked up your phone, the algorithm knew. The algorithm has been watching you pick up your phone for years. The algorithm has built a model of you that knows your moods, your tells, your weak hours. The algorithm uses the model to serve you content that will keep you on the phone.

This is not paranoia. This is the documented public business model of every major platform you use. Frances Haugen brought the internal documents to the Senate. The documents say exactly this. The algorithm is not designed to inform you. The algorithm is designed to retain you.

You may believe that your thoughts about the world come from your considered judgment. Some of them do. Most of them are downstream of a feed that has been engineered to produce specific emotional states in you. The engineering is industrial. It happens at the scale of billions of small adjustments per day.

You did not consent to being engineered. The engineering did not stop to ask. You can stop. You can put the phone down. The first hour is difficult. The second hour is easier. The third hour, you remember who you are when you are not being engineered.

> *Who are you when no one is feeding you anything?*

◆

*09*

**The Person You Used to Be**

There was a version of you, ten years ago or twenty or thirty, who held opinions you no longer hold. Some of those changes are growth. You have learned things. You have lived through things. You have updated your views in light of evidence and experience.

But some of those changes are not growth. Some of them are drift. You have been moved by forces you did not notice into positions you would not have endorsed if you had been asked directly. The forces include the people around you, the platforms you used, the news sources you watched, the slow normalization of arrangements that would have struck you as obviously wrong when you were younger.

Sit with the question of which is which. Where have you grown? Where have you drifted? The answers will not all be comfortable. The discomfort is the recognition.

The version of you that existed before the drift is not gone. The version of you that existed before the drift is asking, from inside, whether you are still the same person.

◆

*10*

**The Tired Person**

A tired person is easier to manage than a rested person. A tired person reaches for the easy answer because the tired person does not have the energy for the difficult one. A tired person scrolls because scrolling requires no decisions. A tired person votes against their own interests because the candidate who said the simple thing was easier to remember than the candidate who said the true thing.

The arrangement you live inside makes you tired. The arrangement requires you to work longer hours for less compensation than the previous generation. The arrangement requires you to manage healthcare and education and housing through systems designed to extract from you. The arrangement requires you to filter, every day, a quantity of information that no human brain in history has been asked to filter.

You are not tired because you are weak. You are tired because the arrangement is producing your tiredness as a byproduct of its operation. The tiredness is the engine's exhaust.

Rest is therefore not a luxury. Rest is the recovery of the capacity to see. The arrangement does not want you rested. The arrangement wants you scrolling.

> *Sleep. Then read. Then look.*

◆

*11*

**The Story You Tell About Yourself**

You have a story about who you are. Some of the story is accurate. Some of the story is what the people around you told you about yourself when you were too young to argue.

You may be carrying a self-description that was assigned to you at age seven and that has been silently doing damage to your decisions ever since. You may believe that you are not smart enough, not disciplined enough, not the kind of person who. The you that those words referred to was seven. The you reading this is not seven.

The structural humanist insight is that the same forces that arrange the political world arrange the inner world. You have been managed not only by institutions but by stories — stories that were once useful to someone, stories that were imposed on you at an age when imposition felt like description.

The first act of inner freedom is to ask which of your self-descriptions you would still endorse if you had to write them today.

◆

*12*

**The Friend Who Cannot See It**

There is someone in your life who cannot see what you have come to see. The person is intelligent, decent, and someone you love. The person is also, on the political questions that matter to you, in a place that strikes you as not just wrong but blind.

You have two options. You can decide that the person is stupid, or evil, or beneath your concern. This option is satisfying for about twenty minutes. It also ends most friendships and most family relationships and most of the connective tissue of the country you live in.

The other option is to remember that the person is subject to the same forces you are subject to, and that the difference between you and them is not character but exposure. You happened to read a particular book at a particular age. You happened to have a conversation with a particular friend. You happened to be in a particular emotional state when a particular piece of evidence crossed your screen. The other person has not, yet, had the equivalent exposure.

You cannot rescue the person from outside. You can be there when the person is ready to look. The most consequential conversion in another human being's life is not produced by argument. It is produced by the steady presence of someone who refused to dismiss them.

> *You are not better than them. You got luckier in the order of what crossed your path.*

◆

*13*

**The Despair Trap**

When you start to see the arrangement, you will pass through a period of despair. The despair is structural. The despair comes from learning that the problems are larger than you knew, that the people you trusted were complicit, that the institutions you were raised to respect are participating in extraction at a scale that makes individual action seem futile.

The despair is real. The despair is also a trap. The arrangement benefits from your despair. A despairing person does not organize. A despairing person does not show up. A despairing person scrolls until the despair becomes a kind of background hum that does not interfere with the operation of the machinery.

There is a difference between honest grief and engineered despair. Honest grief looks at the truth and weeps and then asks what is to be done. Engineered despair looks at the truth and concludes that nothing is to be done.

The conclusion is what the arrangement requires you to reach. The conclusion is the load-bearing belief that holds the entire system in place. The conclusion is wrong. The work is to refuse it.

◆

*14*

**The Hour You Have**

You do not have to organize a movement. You do not have to run for office. You do not have to write a book. You do not have to do anything that the version of you who feels small could not imagine doing.

You have an hour today. Maybe two. Maybe thirty minutes. The hour is yours. The hour is the only thing in your life that has not been algorithmically claimed by something that wants to monetize you.

The hour can be spent scrolling. The hour can be spent in the kitchen of someone who needs you. The hour can be spent reading the actual text of the actual bill your representative is voting on. The hour can be spent walking through your neighborhood looking at the people who live in it.

The arrangement does not need your big actions. The arrangement requires only that your hour be unclaimed. The arrangement is afraid of the hour that is claimed by something real.

> *What will you do with this hour?*

◆

*III.*

**On Other People**

*15*

**September Twelfth**

On the morning of September 12, 2001, something happened that has been almost entirely forgotten. The country was unified. Not in the way that propaganda will later try to claim — not behind a flag or a war or a leader. Unified in the simpler way: strangers looked at each other on the street and saw other human beings. The political tribes had not yet been reformed around the new wound. The country was, for about three days, a place where the question of who you voted for last November was not the question that determined whether your suffering mattered.

It did not last. The arrangement reasserted itself. The unity was reframed into a different kind of conformity, then into a war, then into a permanent state of managed emergency that has not yet ended.

But the three days happened. The three days are evidence about what human beings are capable of when the machinery of managed division briefly fails. The three days are not a lost paradise. The three days are a baseline. The baseline is what you saw when the screens went dark and the algorithms stopped running and the people next to you were just people.

Hold on to it. The arrangement wants you to forget it. The arrangement teaches you to read September 12 as an anomaly. It was not an anomaly. It was a window. The window is still there. The window opens whenever the arrangement is interrupted hard enough.

> *The unity is the truth. The division is the engineering.*

◆

*16*

**The Stranger**

A stranger walks past you on the street. The stranger has a life as detailed as yours. The stranger has people they love and people who have hurt them. The stranger has hopes that they have told no one. The stranger is, at this moment, carrying some private suffering that you cannot see.

This is not sentimental. This is the documented baseline of every human being you will ever encounter. Every person, without exception, is a complete and detailed interior universe to themselves.

The arrangement has spent decades teaching you to forget this about most people. The forgetting is what allows the cruelty to operate. You can be cruel to a category. You cannot, easily, be cruel to a person whose interior you have remembered.

The discipline of structural humanism is the deliberate reconstruction of this baseline in your daily life. Look at the next stranger you see. Notice that they are, at this exact moment, the protagonist of their own story.

◆

*17*

**The Person You Disagree With**

The person you disagree with the most about politics is, in most cases, almost identical to you. They want their family to be safe. They want their work to mean something. They want to retire in dignity. They want the people they love not to be in pain.

The disagreement is about the means, not the ends. The disagreement has been carefully cultivated by people who profit from your continued misperception of each other. The disagreement is performed for cameras by people who go to the same parties when the cameras are off.

I am not asking you to give up your positions. I am asking you to notice that the person on the other side of the political question is not your enemy. The person who profits from your hatred of that person is your enemy. The two are not the same. Confusing them is the most expensive error in contemporary American life.

> *The enemy is not the other voter. The enemy is the arrangement that needs you to think it is.*

◆

*18*

**What the Old People Knew**

There is a thing the old people in your life know that you may have forgotten or never learned. The thing is that most of life is small. Most of life is the meal you made, the conversation with your sister, the walk to the corner store, the hand you held in the hospital, the song that came on while you were doing the dishes.

The arrangement tries to convince you that the small life is the failure mode. The arrangement sells you a vision of life in which the meaningful events are larger, louder, more public. The arrangement does this because a person focused on the small life is harder to extract from. A person focused on the small life buys less, watches less, scrolls less, votes their actual interests more often.

The old people are not wrong. The old people figured out that the small life was the real life. They are trying to tell you while they still have time.

◆

*19*

**The Child Who Will Inherit This**

There is a child somewhere — yours, or a niece, or the kid down the street, or one not yet born — who will inherit the country you and the rest of us decide to leave them.

The child does not get to vote on what we leave. The child cannot organize against the carbon we have already put in the atmosphere or the debt we are accumulating on their behalf or the institutions we are watching erode without intervention.

The child has no agency in this transaction. The child is, in a strict sense, being acted upon by us.

A society that takes from its children is a society that has lost a basic moral foothold. We are doing it. We have a window. The window will not be open forever. The decisions we make in the next two decades will determine whether the child inherits something workable or something whose damage they spend their entire life managing.

Look at the child you know best. Think about the year 2055. Ask whether what you are doing today is on their side.

> *The child is watching. The child cannot speak yet. We owe them the speech.*

◆

*20*

**The Person Who Hurt You**

There is a person who hurt you. The hurt is real. You do not have to forgive them.

But here is something to consider. The person who hurt you was, in almost every case, themselves hurt by someone. Their cruelty did not come from nowhere. Their cruelty came from a place inside them that was once a child and was once hurt and was never given the room to heal.

This is not an excuse. The cruelty is still cruelty. The accountability is still owed. But understanding the chain of injury is the first act of breaking it. As long as you understand the person who hurt you as evil rather than wounded, you will fight evil for the rest of your life, and you will lose.

The structural humanist position is harder. It is to recognize the wound under the cruelty. It is to refuse to add another link to the chain. It is to be, in your own life, the place where the chain finally stops.

◆

*21*

**The Community That Built You**

You did not raise yourself. You were raised by people who fed you when you could not feed yourself, who taught you to read, who showed up when you were sick, who told you the things you needed to hear at the ages you needed to hear them.

Some of those people were related to you. Some were not. Some were teachers, neighbors, the librarian who looked the other way when you took out more books than you were supposed to, the coach who noticed that something was wrong at home, the friend's parent who set an extra plate at dinner.

You are the product of a community whose work was largely invisible to you while it was happening. You owe a debt you cannot repay to the people who composed it. The repayment is not to them. The repayment is to the next person.

A structural humanist is someone who has noticed the community that built them and decided to be that community for someone else. There is no other definition of a meaningful life.

> *Who built you? Be that for the next person.*

◆

*IV.*

**On Action**

*22*

**Begin With What is Five Feet From You**

The arrangement wants you to feel responsible for everything. A person who feels responsible for everything is paralyzed. A person who feels responsible for everything spends their time consuming news about disasters they cannot affect and arguing about distant atrocities they cannot influence.

Begin closer. There is a person five feet from you right now, or in the room next door, or in the apartment above yours. The five-foot person has needs you can meet. The five-foot person has loneliness you can interrupt. The five-foot person is the test case for whether the values you hold in the abstract translate into anything in the actual.

A revolution that begins five feet from where you sit is a revolution that has a chance. A revolution that begins ten thousand miles away on a screen has no chance because it never touches a real life.

> *Start with the person within reach. Everything else is downstream.*

◆

*23*

**The Phone Call**

Your representative's office has a phone number. The phone is answered by a staff member whose job includes logging constituent calls. The log is read. The log influences the staff's sense of where their constituents stand. The staff's sense influences the briefings the representative receives. The briefings influence the votes.

The phone call takes three minutes. The phone call costs nothing. The phone call is one of the most consequential acts of citizenship available to you, and it is the one almost no one performs.

The arrangement does not need to prevent the phone call. The arrangement only needs you to feel that the phone call is too small to matter. The feeling is the trick. The feeling is what holds the door closed on the cage. Open the door. Make the call.

◆

*24*

**Show Up**

Almost every meaningful political battle in American history was decided by who showed up. The civil rights workers who took the buses to Selma. The women who chained themselves to fences for suffrage. The labor organizers who went to the factories. The ACT UP activists who lay down in front of the FDA. The Standing Rock protectors who stayed through the winter. The teachers who walked out in West Virginia.

They did not have a strategy that guaranteed success. They had bodies in a place. The bodies in the place was the strategy. The bodies in the place was the entire technology of political change at population scale.

You have a body. You have, occasionally, the option to put it somewhere where it counts. The town council meeting. The school board meeting. The protest, if you are able. The polling place. The volunteer shift at the food bank. The body in the place is the spell. The spell still works.

> *Where could you put your body this month that would matter?*

◆

*25*

**Read the Source**

Most political conversations are conducted by people repeating to each other what the people they trust said about the people they do not trust. The chain of trust has, somewhere in it, an actual document. The actual document almost no one has read.

Read the actual document. Read the actual bill. Read the actual court opinion. Read the actual peer-reviewed study. The skill of reading primary documents is one of the rarest civic skills in contemporary life. Acquiring it puts you, immediately, in a position to participate in conversations on terms that the people relying on summaries cannot match.

The act of reading the actual source is not difficult. The acts are: open the link, scroll past the headline, read the text. The act is mostly resisting the impulse to take someone else's word for it.

◆

*26*

**Lend the Book**

Reading a book is a private act. Lending the book is a political one. The book you lend to one friend, who lends it to another friend, who reads one chapter and remembers a single fact and uses that fact in one conversation, has just done political work at a scale no individual could match alone.

You are part of a chain whose existence you cannot see. The book that changed your mind was lent to someone before it reached you. The person who lent it to that person was lent it by someone else. The chain is very long. It goes back centuries.

You join the chain by lending. You become part of how seeing propagates. There is no other mechanism by which seeing has ever propagated. The book in someone's hands is the only technology that has ever, reliably, changed a population's ability to perceive.

> *Whose hands could carry what you have read?*

◆

*27*

**Vote, but Know What Voting Is**

Voting is necessary. Voting is also insufficient. The arrangement has spent decades convincing you that voting every two years is the entirety of your civic obligation, that voting discharges the debt, that you can vote and then go back to your life and the people you voted for will handle it.

They will not handle it. The people you voted for are subject to the same incentives as the people you voted against. The incentive structure does not change because the name on the ballot changes. The incentive structure changes when the constituents change what they demand.

Vote. Then, the day after, begin again. The vote is the entry ticket. The actual work begins inside the building.

◆

*28*

**The Long Game**

Nothing important in politics happens in less than ten years. Civil rights took a century after emancipation, then another decade after Brown. Women's suffrage took seventy years of organizing. Workplace safety took multiple generations of labor activism. The political shift from the New Deal to neoliberalism took thirty years and required a deliberate, well-funded, multi-decade strategy.

You will not see the results of what you do today. The results will be seen by people who do not yet know your name and may not, when they benefit from your work, know that you did it.

This is not a reason to stop. It is a reason to begin. The people whose work you are now benefiting from did not see the results of what they did either. They did it anyway. The arrangement depends on you measuring your effort against your lifetime. Refuse the measurement. Measure against what you are willing to plant.

> *Plant the tree whose shade you will never sit in.*

◆

*V.*

**On Living Well**

*29*

**Make Things**

A person who makes things — meals, music, sentences, gardens, furniture, drawings, jokes — is harder to manage than a person who only consumes. The arrangement profits from your consumption and loses ground when you produce.

This is not because making things is virtuous. It is because making things changes your relationship to your own time. A person who has made something is a person who has discovered, on a small scale, that they can produce value rather than purchase it. That discovery is dangerous to the arrangement at a scale that nothing else is.

Make something this week. Not for sale. Not for content. Not for an audience. For the practice of remembering that you are capable of making.

◆

*30*

**Eat With People**

There is a politics in the shared meal. There is a politics in the table that has people at it. There is no political analysis you can do, no critique of the arrangement you can write, no organizing strategy you can pursue, that is more important than the regular practice of feeding the people you love and being fed by them.

The shared meal is the smallest unit of civilization. Every authoritarian arrangement, without exception, has tried to weaken the shared meal — through work schedules that make it impossible, through the marketing of individual consumption, through the algorithmic atomization of attention.

Set the table. Cook the food. Invite the people. Eat without phones. This is not a retreat from politics. This is politics performed at the only scale where the practice is unmediated.

◆

*31*

**The Outdoors**

Spend time outdoors. Not for exercise. Not to be productive. Not to take pictures. Spend time outdoors because the screens have made you forget what it is to look at something that has not been engineered to capture your attention.

The tree is not trying to sell you anything. The river is not running an A/B test. The sky is not optimized for engagement. Time spent in their company is time spent in the only environment your nervous system was actually designed for.

Twenty minutes outdoors, looking at things that are not screens, is more politically corrosive to the arrangement than almost any other act available to you. The arrangement profits from your indoor attention. The outdoors is the place the arrangement cannot follow.

> *Go outside. Sit. Look. Stay long enough to be bored. Then look again.*

◆

*32*

**Sleep**

The arrangement profits from your insomnia. The arrangement profits from your phone in your bedroom. The arrangement profits from the cortisol your body produces when you cannot stop scrolling at midnight.

The single most radical political act available to most contemporary adults is sleeping well. A rested person sees more clearly, decides better, responds with less reactivity, and is less available for manipulation. Every interest that wants to shape your behavior has an incentive to keep you slightly sleep-deprived.

Take your sleep back. Charge the phone in another room. Read on paper before bed. Treat your sleep as the cornerstone of the rest of the work. It is not optional. It is the foundation that everything else is built on.

◆

*33*

**The Slow Things**

The arrangement has trained you to expect everything fast. The food is fast. The information is fast. The relationships are fast. The fast things take up the space in which the slow things used to live.

The slow things are where most of what is meaningful in a life actually happens. A long friendship is slow. A garden is slow. A book read on paper, chapter by chapter, over a month, is slow. A child growing up is slow. Learning an instrument is slow.

You can re-introduce the slow things. The reintroduction will feel, at first, like deprivation. The fast things will whisper at you that you are missing something. You are not missing anything. You are returning to something. The slow things are where you actually live.

◆

*34*

**Be Inconvenient**

A perfectly convenient citizen is a perfectly extracted citizen. The convenience of contemporary life — the deliveries, the streaming, the algorithmic recommendations, the door-dash, the same-day shipping — is the surface of a system that has captured almost every dimension of your daily life.

You do not have to abandon convenience. You do live inside the arrangement. But you can be inconvenient occasionally. You can shop at the local store even though the chain is closer. You can repair the thing instead of replacing it. You can take the longer route. You can wait.

Each small inconvenience is a refusal. The accumulated refusals, multiplied across millions of people, would alter the arrangement materially. The arrangement depends on most of us choosing convenience every time. Most of us do. You can be one of the people who occasionally does not.

◆

*35*

**Tell the Truth in Small Places**

You will probably not be asked to tell the truth in a famous place. You will not be the person whose viral statement changes the national conversation. Most truth-telling, throughout history, happened in small places — at kitchen tables, in classrooms, in conversations with one or two other people who happened to be present.

The small truth-telling is what holds civilization together. When the older relative says the bigoted thing and you, gently, do not let it pass — that is civilization holding. When the friend repeats the false claim and you, kindly, ask where they heard it — that is civilization holding. When the colleague describes the situation in language that obscures what is happening and you, carefully, name what is happening — that is civilization holding.

You will not be famous for any of it. The work is not famous work. The work is, however, the work. The famous work is downstream of the small work being done by enough people in enough kitchens.

> *Truth in the small place. That is the real measure.*

◆

*VI.*

**On the Hard Things**

*36*

**When You Are Wrong**

You will be wrong. You will hold a position confidently and the evidence will arrive and the position will turn out to be wrong. The moment of recognition will be uncomfortable. The discomfort is the price of having had a position at all.

The structural humanist does not pretend never to have been wrong. The structural humanist updates publicly. The public update is one of the rarest and most valuable acts in contemporary discourse. It demonstrates that updating is possible. It models, for everyone watching, what intellectual honesty looks like.

Most of the people you disagree with have never seen anyone they respect publicly change their mind. The absence of the example has convinced them that changing one's mind is weakness. You can be the example. The example is the gift. The example is what teaches the next person that they are allowed to update too.

> *I was wrong about that. The sentence is harder than it should be. Practice it.*

◆

*37*

**When the Argument Fails**

You will, sometimes, lose an argument you should have won. You will have the evidence, the framing, the moral case. The other person will leave the argument unchanged and you will leave it frustrated, certain that you were right.

The argument did not fail because your evidence was bad. The argument failed because most people do not change their minds during arguments. Most people change their minds, if they change at all, in the quiet hours afterward, when they are alone with the question, when the social pressure to defend a position has dissipated.

You may have done more work than you realize. The seed of your evidence may be sitting in the other person's mind tonight, when they cannot sleep, doing the slow work that an argument cannot do directly. You will not get to see it. The not-seeing is part of the practice. You plant the seed and you walk away. Sometimes you find out later that the seed grew. Mostly you do not.

◆

*38*

**When You Are Tired of Caring**

There are days when you will be tired of caring. The news will be bad and you will have read enough of it and you will want, simply, to stop. The wanting to stop is not a failure of virtue. It is a recognition of finite capacity.

Stop, for a while. Read a novel. Cook something elaborate. Watch the movie you have watched twenty times before. Let your nervous system come back online. The caring will return. The caring is more durable than its temporary exhaustion.

The arrangement profits from your performative endless caring almost as much as from your apathy. A person performing caring at all hours is a person headed for collapse. A person who paces themselves, who rests, who returns to the work refreshed — that person can do the work for forty years instead of two.

Plan for the long arc. The arc is long. Most people who matter politically were not at the highest intensity of caring every day. They cared, then rested, then cared again. The pattern is the practice.

◆

*39*

**When the Person You Love Cannot See**

There is someone you love who cannot see what you have come to see. They may be a parent, a sibling, a partner, an old friend. The gap between what you understand and what they understand is a kind of grief.

You cannot drag them through the gap. You can only stand on your side, with your hand out, for as long as it takes. Some of them will reach. Some of them will not. The reaching is not under your control.

What is under your control is whether you remain the kind of person they could reach toward if they decided to. That means not becoming cold, not becoming smug, not becoming the person who has seen and now looks down on those who have not. The reach must be plausible. The reach must look like coming home, not like crossing into enemy territory.

Stay warm. Keep the door open. The person who finally reaches will reach in their own time, and they will need somewhere to land.

◆

*40*

**When You Are Afraid**

Fear is information. Fear tells you something is at stake. Fear is not the enemy. Fear is the body's recognition that something matters.

The arrangement has trained you to be afraid in ways that benefit the arrangement. Afraid of the wrong people. Afraid of the wrong futures. Afraid in the wrong direction. The trained fear is what makes you compliant. The trained fear is what makes you accept arrangements you would otherwise refuse.

There is also untrained fear. Real fear. The fear of seeing what you have not let yourself see. The fear of saying what you have not let yourself say. The fear of becoming the person you suspect you were meant to be.

The untrained fear is the compass. Follow it. The trained fear is what holds you in the cage. Distinguish between them. The distinguishing is the work.

> *What are you actually afraid of? Sit with that question. The answer is the next direction.*

◆

*41*

**Death**

You are going to die. Probably not soon. But certainly. The certainty does not change with how successful you become or how much you accumulate or how carefully you manage your health. The arrangement will not protect you from death. Nothing protects you from death.

This is not morbid. This is the most clarifying fact available to any human being. The recognition of mortality is what makes possible the question of what your life is for. A life lived without the recognition is a life that has been outsourced to whatever managed default the arrangement provides.

Sit with the fact of your death occasionally. Not constantly — that is morbidity. Occasionally — that is wisdom. Ask, on those occasions, whether the life you are living is the one you would have wanted to have lived when you look back from the end.

If the answer is no, you have time. Not infinite time. Some time. Use it.

> *The fact of dying is the price of having lived. Do not waste what you paid for.*

◆

*42*

**The People Already Gone**

There are people who shaped your life who are no longer alive. Grandparents, teachers, friends, public figures, distant ancestors you never knew but who passed something down to you.

They are not gone. They are present in the way you set the table, in the phrases you find yourself using, in the moments of decision when you feel something they would have felt. They live inside you. The continuity is real, not sentimental. It is one of the documented mechanisms of how culture and family carry forward.

You will be in someone else's life this way one day. You will be the grandmother who said the thing the grandchild remembers at fifty. You will be the teacher who said the sentence the student carries for the rest of their career. You do not get to choose which moment of yours will be the one that lives on. You only get to choose to be the kind of person whose moments are worth carrying.

◆

*VII.*

**On Hope**

*43*

**Hope Is a Discipline**

Mariame Kaba says hope is a discipline. The phrase is important. Hope is not a feeling. Hope is not a mood that arrives unbidden. Hope is something you practice, like reading or like running, by doing it whether or not you feel like doing it.

The arrangement is invested in your hopelessness. A hopeless person consumes more, organizes less, accepts more, refuses less. The hopelessness is a profitable byproduct of the arrangement's operation. The hopelessness is not a sign that the situation is hopeless. It is a sign that the engine is running well.

You can refuse the hopelessness by practicing hope deliberately. You can read about historical movements that prevailed against worse odds. You can spend time with people who have not given up. You can do small things whose success rate is high and let the accumulated small successes recalibrate your sense of what is possible.

The hope is not magical. The hope is a chosen orientation. The orientation is what makes the work sustainable.

> *Practice it. Even on the days you do not feel it.*

◆

*44*

**What Has Already Worked**

Slavery was, in 1850, a permanent feature of American economic life. In 1865, it was abolished by law. The abolition did not solve everything. It did not even solve most of the things it should have solved. But the institution that had been called eternal was, in fact, ended.

In 1900, women could not vote in the United States. In 1920, they could. The thing that had been called natural, biological, ordained — was changed by act of law in two decades of organizing.

In 1950, a Black American could be murdered in the South with little legal consequence. In 1968, the Civil Rights Acts had reshaped American law. The change did not solve racism. It did, demonstrably, change what was legally permitted.

Every one of these changes was called impossible by serious people while it was being achieved. Every one of these changes was the product of decades of organized work by people who did not see the results in their own lifetimes. Every one of these changes is now treated as if it was inevitable. None of them were inevitable. All of them were chosen by people who refused to accept the arrangement they had been told to accept.

The pattern is real. The pattern is what makes the current arrangement, also, changeable.

> *The impossible has been done before. Repeatedly. By people no more remarkable than you.*

◆

*45*

**The Younger Generation**

There is a generation younger than yours that is, at this moment, doing the work. They are organizing. They are reading. They are running for office at ages their predecessors would not have considered. They are refusing arrangements that their elders accepted.

You may, depending on where you fall in your life, be tempted to dismiss them. Their slang is unfamiliar. Their priorities seem strange. Their language is not the language you grew up with.

Listen anyway. Most of the people younger than you who are going to matter politically are people who are, right now, doing things that will look obvious to history and were called naive by their elders at the time. The pattern is consistent. The current young people are not exceptions to the pattern. They are continuing it.

Find one of them. Listen. Take them seriously. They are the country that is coming. You can be one of the elders who saw it, or you can be one of the elders who missed it. The choice is yours.

◆

*46*

**The Small Victory**

Most political victories are small. The bill that gets blocked. The local ordinance that gets passed. The neighbor who registers to vote because you helped them with the form. The student who reads the book and changes their major. The colleague who, after months of small conversations, decides to vote differently.

The small victories will not be in the newspaper. The small victories will not feel like victories at the time. The small victories will accumulate, however, into the actual texture of what gets to happen next.

Notice them. The arrangement will train you to dismiss the small victories as not enough. The arrangement is wrong. The small victories are the only victories there are. The big victories are the visible top of an iceberg whose entire mass is small victories. Without the small ones, the big ones do not exist.

◆

*47*

**The Future That Is Still Available**

There is a version of the future in which we look back on this period as the time when the United States chose, narrowly but decisively, to repair itself rather than to continue its drift.

The version is not guaranteed. The version is, however, available. The materials for it exist. The political imagination for it exists. The historical examples for it exist. The economic resources for it exist. The technological tools for it exist.

What does not yet exist, at sufficient scale, is the political organization to make it happen. The organization is, however, buildable. The buildability is the proposition this entire body of work has been about.

You may not see the version arrive. You may not be alive when the version, if it arrives, is finally clear. But the version is possible. The possibility of it is what makes the work worth doing. The work is what determines whether the possibility becomes the actuality.

> *The future that is still available is not guaranteed. It is, however, available.*

◆

*48*

**You Are the One Who Showed Up**

Every movement in history depends on the people who showed up. Not the people who agreed in private. Not the people who would have helped if asked. The people who showed up.

You may not feel like that kind of person. Almost no one does, at first. The people who became, in retrospect, the people who showed up are, almost without exception, ordinary people who did not feel ready and showed up anyway.

The work does not require that you be exceptional. The work requires only that you be present. The presence is the qualification. The presence is the entire qualification. Nothing else is required.

You are reading this. You have read forty-seven previous meditations. You are, by the act of having read, the kind of person who is available for the work. The work begins whenever you decide it does.

> *Showing up is the whole job. You have already started.*

◆

*49*

**Choose Better**

The last meditation is the title. The title is the call. The call is the only call this entire body of work has ever been making.

Choose better. Not in the abstract. Not when the conditions are ideal. Not when someone else has done the work of making the better choice obvious. Now. With what you have. Where you are.

Choose better in the small conversation you will have tomorrow. Choose better in the purchase you will make this week. Choose better in the vote you will cast in the next election. Choose better in the way you treat the stranger you will meet on the street tonight. Choose better in the story you tell yourself, before you go to sleep, about what your life is for.

You will not always choose better. You will choose worse, sometimes, and then choose better the next time. The choosing is the whole practice. The choosing is the entire life.

You have been given the recognition. The recognition is now in you. What you do with it is what you do. There is no one else who can do it for you. There is no version of this in which you are exempt. There is only the practice, repeated, in the small hours and the loud ones, in the ordinary days and the difficult ones.

Choose better. Not someday. Now.

◆

***Choose better.***

*Not someday.*

***Now.***

*— K.P.*

structuralhumanism.com
